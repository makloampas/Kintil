module.exports = {
  tokens: "8420004150:AAEaGk2Fdqgxql6Kwoo70wXxK6PlIuxsdmk",  // Ubah Jadi Token Bot Mu !!!
  owner: "7337925651", // Ubah Jadi Id Mu !!!
  port: "3489", // Ubah Jadi Port Panel Mu !!!
  ipvps: "http://barzsync.abrdns.com/" // Ubah Jadi Ip Vps Mu !!!
};