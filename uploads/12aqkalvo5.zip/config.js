module.exports = {
  tokens: "8402796366:AAHWH-l64WirKXch72JnYlsuNWhV5JYqPSs", // Ubah Jadi Token Bot Mu !!!
  owner: "8402796366", // Ubah Jadi Id Mu !!!
  port: "2804", // Ubah Jadi Port Panel Mu !!!
  ipvps: "https://taaammmmaaaa.jhonaleytech.web.id" // Ubah Jadi Ip Vps Mu !!!
};