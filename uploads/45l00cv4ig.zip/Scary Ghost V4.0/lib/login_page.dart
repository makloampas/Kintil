import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:video_player/video_player.dart';
import 'dart:ui';

const String baseUrl = "http://privserv.my.id:2321";

// Warna tema hitam dengan aksen biru muda
class AppColors {
  static const Color lightBlue = Color(0xFF64B5F6); // Biru muda utama
  static const Color mediumBlue = Color(0xFF42A5F5); // Biru sedang
  static const Color darkBlue = Color(0xFF2196F3); // Biru gelap untuk aksen
  static const Color background = Color(0xFF121212); // Latar belakang hitam
  static const Color cardBackground = Color(0x00000000); // Transparan hitam
  static const Color textDark = Color(0xFFFFFFFF); // Teks putih
  static const Color textLight = Color(0xFF90CAF9); // Teks biru muda
  static const Color buttonBackground = Color(0x33000000); // Transparan hitam dengan opacity
  static const Color accentBlue = Color(0xFF1E88E5); // Aksen biru
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final userController = TextEditingController();
  final passController = TextEditingController();
  bool isLoading = false;
  String? androidId;
  late VideoPlayerController _videoController;

  @override
  void initState() {
    super.initState();
    initLogin();
    // Initialize video controller
    _videoController = VideoPlayerController.asset('assets/videos/login.mp4')
      ..initialize().then((_) {
        setState(() {});
        _videoController.setLooping(true);
        _videoController.play();
        _videoController.setVolume(0);
      });
  }

  @override
  void dispose() {
    _videoController.dispose();
    super.dispose();
  }

  Future<void> initLogin() async {
    androidId = await getAndroidId();

    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      final uri = Uri.parse(
        "$baseUrl/api/auth/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey",
      );
      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);

        if (data['valid'] == true) {
          Navigator.pushReplacementNamed(
            context,
            '/loader',
            arguments: {
              'username': savedUser,
              'password': savedPass,
              'role': data['role'],
              'key': data['key'],
              'expiredDate': data['expiredDate'],
              'listBug': data['listBug'] ?? [],
              'listPayload': data['listPayload'] ?? [],
              'listDDoS': data['listDDoS'] ?? [],
              'news': data['news'] ?? [],
            },
          );
        }
      } catch (_) {}
    }
  }

  Future<String> getAndroidId() async {
    final deviceInfo = DeviceInfoPlugin();
    final android = await deviceInfo.androidInfo;
    return android.id ?? "unknown_device";
  }

  Future<void> login() async {
    final username = userController.text.trim();
    final password = passController.text.trim();

    if (username.isEmpty || password.isEmpty) {
      _showAlert("⚠️ Error", "Username and password are required.");
      return;
    }

    setState(() => isLoading = true);

    try {
      final validate = await http.post(
        Uri.parse("$baseUrl/api/auth/validate"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId ?? "unknown_device",
        },
      );

      final validData = jsonDecode(validate.body);

      if (validData['expired'] == true) {
        _showAlert("⛔ Access Expired", "Your access has expired.\nPlease renew it.", showContact: true);
      } else if (validData['valid'] != true) {
        _showAlert("🚫 Login Failed", "Invalid username or password.", showContact: true);
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", username);
        prefs.setString("password", password);
        prefs.setString("key", validData['key']);

        Navigator.pushNamed(
          context,
          '/loader',
          arguments: {
            'username': username,
            'password': password,
            'role': validData['role'],
            'key': validData['key'],
            'expiredDate': validData['expiredDate'],
            'listBug': validData['listBug'] ?? [],
            'listPayload': validData['listPayload'] ?? [],
            'listDDoS': validData['listDDoS'] ?? [],
            'news': validData['news'] ?? [],
          },
        );
      }
    } catch (_) {
      _showAlert("🌐 Connection Error", "Failed to connect to the server.");
    }

    setState(() => isLoading = false);
  }

  void _showAlert(String title, String msg, {bool showContact = false}) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.cardBackground.withOpacity(0.8),
        title: Text(
          title,
          style: const TextStyle(
            color: AppColors.textDark,
            fontSize: 18,
            fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron',
          ),
        ),
        content: Text(
          msg,
          style: const TextStyle(
            color: AppColors.textDark,
            fontSize: 14,
            fontFamily: 'ShareTechMono',
          ),
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: AppColors.mediumBlue.withOpacity(0.5), width: 1),
        ),
        actions: [
          if (showContact)
            TextButton(
              onPressed: () async {
                final uri = Uri.parse("tg://resolve?domain=RezzaJe");
                if (await canLaunchUrl(uri)) {
                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                } else {
                  await launchUrl(Uri.parse("https://t.me/RezzaJe"),
                      mode: LaunchMode.externalApplication);
                }
              },
              child: const Text(
                "Contact Admin",
                style: TextStyle(
                  color: AppColors.lightBlue,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              "CLOSE",
              style: TextStyle(
                color: AppColors.lightBlue,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _showBuyAccountDialog() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.cardBackground.withOpacity(0.8),
        title: const Text(
          "Choose Your Account",
          style: TextStyle(
            color: AppColors.textDark,
            fontSize: 18,
            fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron',
          ),
        ),
        content: SizedBox(
          width: double.maxFinite,
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildRoleCard(
                  "Member",
                  [
                    "Basic Feature ( Bug WhatsApp, Spam NGL )",
                    "Cooldown Bug 50 Sec",
                    "Dedicated Sender",
                  ],
                  "30 Day = 25K",
                  "Permanent = 100K",
                  AppColors.mediumBlue,
                ),
                const SizedBox(height: 16),
                _buildRoleCard(
                  "VIP",
                  [
                    "VIP Feature ( VIP Sender, Custom Bug, Group Bug )",
                    "All member Benefit",
                    "Cooldown Bug 60 Sec",
                    "Send Bug With More Than 1 Sender",
                  ],
                  "30 Day = 70K",
                  "Permanent = 200k",
                  AppColors.darkBlue,
                ),
                const SizedBox(height: 16),
                _buildRoleCard(
                  "Reseller",
                  [
                    "Reseller Feature ( Create Member Account )",
                    "All Premium Benefit",
                    "Cooldown Bug 50 Sec",
                    "Dedicated Sender",
                  ],
                  "30 Day = 50K",
                  "Permanent = 150K",
                  AppColors.accentBlue,
                ),
                const SizedBox(height: 16),
                _buildRoleCard(
                  "XOWN",
                  [
                    "Admin Feature ( Can Create All Role Account )",
                    "No Cooldown",
                    "Control Account",
                  ],
                  "Permanent = 500K",
                  "",
                  AppColors.lightBlue,
                ),
              ],
            ),
          ),
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: AppColors.mediumBlue.withOpacity(0.5), width: 1),
        ),
        actions: [
          TextButton(
            onPressed: () async {
              final uri = Uri.parse("tg://resolve?domain=RezzaJe");
              if (await canLaunchUrl(uri)) {
                await launchUrl(uri, mode: LaunchMode.externalApplication);
              } else {
                await launchUrl(Uri.parse("https://t.me/RezzaJe"),
                    mode: LaunchMode.externalApplication);
              }
            },
            child: const Text(
              "Contact Admin",
              style: TextStyle(
                color: AppColors.lightBlue,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              "CLOSE",
              style: TextStyle(
                color: AppColors.lightBlue,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRoleCard(
      String title,
      List<String> benefits,
      String price30Days,
      String pricePermanent,
      Color color,
      ) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.cardBackground.withOpacity(0.3),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.5), width: 1),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 12,
                height: 12,
                decoration: BoxDecoration(
                  color: color,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 8),
              Text(
                title,
                style: TextStyle(
                  color: color,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          ...benefits.map(
                (benefit) => Padding(
              padding: const EdgeInsets.only(bottom: 4, left: 20),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "• ",
                    style: TextStyle(
                      color: color.withOpacity(0.8),
                      fontSize: 14,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                  Expanded(
                    child: Text(
                      benefit,
                      style: const TextStyle(
                        color: AppColors.textDark,
                        fontSize: 14,
                        fontFamily: 'ShareTechMono',
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          if (price30Days.isNotEmpty)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                price30Days,
                style: TextStyle(
                  color: color,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ),
          if (price30Days.isNotEmpty && pricePermanent.isNotEmpty)
            const SizedBox(height: 8),
          if (pricePermanent.isNotEmpty)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: color.withOpacity(0.2),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(
                pricePermanent,
                style: TextStyle(
                  color: color,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'ShareTechMono',
                ),
              ),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        children: [
          // Background video with blur effect
          SizedBox(
            height: double.infinity,
            width: double.infinity,
            child: FittedBox(
              fit: BoxFit.cover,
              child: _videoController.value.isInitialized
                  ? SizedBox(
                width: _videoController.value.size.width,
                height: _videoController.value.size.height,
                child: VideoPlayer(_videoController),
              )
                  : Container(color: AppColors.background),
            ),
          ),
          // Blur overlay
          BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Container(
              color: Colors.black.withOpacity(0.6),
            ),
          ),
          // Login form
          Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(28),
              child: Column(
                children: [
                  Image.asset('assets/images/logo.png', height: 140),
                  const SizedBox(height: 20),
                  const Text(
                    "Welcome Back",
                    style: TextStyle(
                      color: AppColors.textDark,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    "Login to continue",
                    style: TextStyle(
                      color: AppColors.textLight,
                      fontSize: 14,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                  const SizedBox(height: 30),
                  _neonInput("Username", userController),
                  const SizedBox(height: 16),
                  _neonInput("Password", passController, isPassword: true),
                  const SizedBox(height: 25),

                  // Login Button
                  ElevatedButton(
                    onPressed: isLoading ? null : login,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.buttonBackground,
                      minimumSize: const Size(double.infinity, 48),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(24),
                        side: BorderSide(color: AppColors.mediumBlue.withOpacity(0.5)),
                      ),
                    ),
                    child: isLoading
                        ? SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(
                        color: AppColors.lightBlue,
                        strokeWidth: 2,
                      ),
                    )
                        : const Text(
                      "LOGIN",
                      style: TextStyle(
                        fontSize: 16,
                        color: AppColors.lightBlue,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                  const SizedBox(height: 18),

                  // Buy Account Button
                  ElevatedButton(
                    onPressed: _showBuyAccountDialog,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.buttonBackground,
                      minimumSize: const Size(double.infinity, 48),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(24),
                        side: BorderSide(color: AppColors.mediumBlue.withOpacity(0.5)),
                      ),
                    ),
                    child: const Text(
                      "Buy Account",
                      style: TextStyle(
                        fontSize: 16,
                        color: AppColors.lightBlue,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _neonInput(String hint, TextEditingController controller,
      {bool isPassword = false}) {
    return TextField(
      controller: controller,
      obscureText: isPassword,
      style: const TextStyle(color: AppColors.textDark),
      cursorColor: AppColors.lightBlue,
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(
          color: AppColors.textLight,
          fontFamily: 'ShareTechMono',
        ),
        filled: true,
        fillColor: AppColors.buttonBackground,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide(color: AppColors.mediumBlue.withOpacity(0.5)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide(color: AppColors.mediumBlue.withOpacity(0.5)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: const BorderSide(color: AppColors.lightBlue, width: 2),
        ),
      ),
    );
  }
}