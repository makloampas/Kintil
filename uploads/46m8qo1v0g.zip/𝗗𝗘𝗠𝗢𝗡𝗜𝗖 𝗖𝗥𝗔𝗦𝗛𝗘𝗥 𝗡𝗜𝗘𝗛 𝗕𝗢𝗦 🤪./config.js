module.exports = {
  BOT_TOKEN: "8403158341:AAFOYtr3tqvAWqRoyl3N8IShNnER70qrfyM",
  OWNER_IDS: ["7571435782"]
};