let GLOBAL_CD_DURATION = 10 * 60 * 1000; // default 10 menit
let globalCooldownUntil = 0;

// ===== PARSE DURASI =====
function parseDuration(text = "") {
  text = text.toLowerCase().trim();
  const match = text.match(/(\d+)\s*(s|sec|detik|m|min|menit|h|jam)/);
  if (!match) return null;

  const val = Number(match[1]);
  const unit = match[2];

  if (["s", "sec", "detik"].includes(unit)) return val * 1000;
  if (["m", "min", "menit"].includes(unit)) return val * 60 * 1000;
  if (["h", "jam"].includes(unit)) return val * 60 * 60 * 1000;

  return null;
}

// ===== GLOBAL COOLDOWN =====
function setGlobalCooldown() {
  globalCooldownUntil = Date.now() + GLOBAL_CD_DURATION;
}

function isOnGlobalCooldown() {
  return Date.now() < globalCooldownUntil;
}

function getGlobalRemaining() {
  return Math.max(
    0,
    Math.ceil((globalCooldownUntil - Date.now()) / 1000)
  );
}

function setGlobalDuration(ms) {
  GLOBAL_CD_DURATION = ms;
}

module.exports = {
  parseDuration,
  setGlobalCooldown,
  isOnGlobalCooldown,
  getGlobalRemaining,
  setGlobalDuration
};