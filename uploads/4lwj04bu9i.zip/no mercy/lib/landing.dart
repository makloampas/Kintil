import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  late VideoPlayerController _controller;
  bool _isVideoInitialized = false;

  // --- PALET WARNA (Merah - Hitam) ---
  final Color deepRed = const Color(0xFF8B0000);   
  final Color mainRed = const Color(0xFFB71C1C);   
  final Color accentRed = const Color(0xFFFF5252);  
  final Color bgBlack = const Color(0xFF000000);   

  @override
  void initState() {
    super.initState();
    // Video Background: assets/videos/login.mp4
    _controller = VideoPlayerController.asset("assets/videos/login.mp4")
      ..initialize().then((_) {
        setState(() {
          _isVideoInitialized = true;
        });
        _controller.setLooping(true);
        _controller.setVolume(0);
        _controller.play();
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      body: Stack(
        children: [
          // 1. VIDEO BACKGROUND
          if (_isVideoInitialized)
            SizedBox.expand(
              child: FittedBox(
                fit: BoxFit.cover,
                child: SizedBox(
                  width: _controller.value.size.width,
                  height: _controller.value.size.height,
                  child: VideoPlayer(_controller),
                ),
              ),
            )
          else
            Container(color: bgBlack),

          // 2. BLUR & OVERLAY GELAP
          BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5), // Blur sedikit
            child: Container(
              color: Colors.black.withOpacity(0.6), // Overlay gelap
            ),
          ),

          // 3. KONTEN UTAMA
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 30),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // FOTO TRANSPARAN (Agak ke atas)
                    // Gunakan Spacer atau SizedBox jika ingin lebih ke atas secara relatif
                    // Di sini saya pakai Transform untuk menggeser sedikit ke atas jika perlu
                    Transform.translate(
                      offset: const Offset(0, -20), 
                      child: Image.asset(
                        'assets/images/wel.png',
                        height: 180, // Sesuaikan ukuran
                        fit: BoxFit.contain,
                      ),
                    ),

                    const SizedBox(height: 20),

                    // TEKS JUDUL
                    Text(
                      "NoMercy",
                      style: TextStyle(
                        fontSize: 32,
                        fontWeight: FontWeight.w900,
                        color: Colors.white,
                        letterSpacing: 2,
                        fontFamily: 'Orbitron', // Pastikan font terdaftar atau hapus jika error
                        shadows: [
                          Shadow(
                            color: mainRed.withOpacity(0.8),
                            blurRadius: 20,
                            offset: const Offset(0, 0),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 10),
                    // TEKS KECIL (Subjudul)
                    Text(
                      "The Ultimate Digital Tools & Security",
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 14,
                        color: Colors.grey.shade400,
                        letterSpacing: 1,
                      ),
                    ),

                    const SizedBox(height: 50),

                    // TOMBOL 1: LOGIN (Merah Solid)
                    Container(
                      width: double.infinity,
                      height: 55,
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [deepRed, accentRed],
                          begin: Alignment.centerLeft,
                          end: Alignment.centerRight,
                        ),
                        borderRadius: BorderRadius.circular(15),
                        boxShadow: [
                          BoxShadow(
                            color: mainRed.withOpacity(0.4),
                            blurRadius: 15,
                            offset: const Offset(0, 5),
                          ),
                        ],
                      ),
                      child: ElevatedButton(
                        onPressed: () {
                          Navigator.pushNamed(context, "/login");
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.transparent,
                          shadowColor: Colors.transparent,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                        ),
                        child: const Text(
                          "Login Account",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 15),

                    // TOMBOL 2: BUY ACCOUNT (Outline Merah)
                    SizedBox(
                      width: double.infinity,
                      height: 55,
                      child: OutlinedButton(
                        onPressed: () => _openUrl("https://DiyyOfficial"),
                        style: OutlinedButton.styleFrom(
                          side: BorderSide(color: accentRed, width: 1.5),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(15),
                          ),
                          backgroundColor: Colors.black.withOpacity(0.3),
                        ),
                        child: Text(
                          "Buy Account",
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: accentRed,
                            letterSpacing: 1,
                          ),
                        ),
                      ),
                    ),

                    const SizedBox(height: 60),

                    // AREA TELEGRAM (Footer)
                    GestureDetector(
                      onTap: () => _openUrl("https://t.me/DiyyOfficial"),
                      child: Column(
                        children: [
                          Container(
                            padding: const EdgeInsets.all(12),
                            decoration: BoxDecoration(
                              color: mainRed.withOpacity(0.1),
                              shape: BoxShape.circle,
                              border: Border.all(
                                color: mainRed.withOpacity(0.5),
                              ),
                            ),
                            child: Icon(
                              FontAwesomeIcons.telegram,
                              color: Colors.white,
                              size: 24,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            "Join Our Community",
                            style: TextStyle(
                              color: Colors.grey.shade500,
                              fontSize: 12,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
