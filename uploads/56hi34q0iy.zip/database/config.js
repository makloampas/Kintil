module.exports = {
  tokens: "8477944977:AAHbb6EPPUT8y2bNXF1bJEdMeCEMguV3W4I",  // Masukin Bot token kamu
  owners: "6282224853", // Masukin ID Telegram kamu
  port: "4214", // Masukin Port panel kamu 
  ipvps: "https://shadowdizznoddos.panel-host.biz.id/" // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://AiiSigma.id ) menjadi ( http://AiiSigma.id )
};

/* WAJIB BACA !!!
 cari di index.js halaman 1710-1711 di situ masukin bot token sama id tele lu.

 emngnya knpa bang?
 lu buka aja dulu. di sana udah gw kasi penjelasannya
*/