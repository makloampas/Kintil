module.exports = {
  tokens: "8466467907:AAE7kPk_vGzPoINVQ8SiPbQCE4UycW_GYQg",  // Masukin Bot token kamu
  owners: "7882058841", // Masukin ID Telegram kamu
  port: "3000", // Masukin Port panel kamu 
  ipvps: "http://178.128.29.123"
};