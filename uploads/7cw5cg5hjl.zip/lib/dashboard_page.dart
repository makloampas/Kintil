import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:video_player/video_player.dart';

import 'bug_sender.dart';
import 'nik_check.dart';
import 'admin_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'anime_home.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> with TickerProviderStateMixin {
  late WebSocketChannel channel;
  String androidId = "unknown";
  int onlineUsers = 0;
  int activeConnections = 0;
  final Color cardDark = const Color(0xFF1A1A1A);

  int _selectedIndex = 0;
  bool _isSidebarOpen = false;
  late Widget _selectedPage;

  @override
  void initState() {
    super.initState();
    _selectedPage = _buildMainDashboardView();
    _initAndroidIdAndConnect();
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(Uri.parse('wss://ws-pterodactyl.jwxhost.site:2070'));
    channel.sink.add(jsonEncode({
      "type": "validate",
      "key": widget.sessionKey,
      "androidId": androidId,
    }));
    channel.sink.add(jsonEncode({"type": "stats"}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'stats') {
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConnections = data['activeConnections'] ?? 0;
        });
      }
    });
  }

  void _onTabTapped(int index) {
    setState(() {
      _selectedIndex = index;
      if (index == 0) {
        _selectedPage = _buildMainDashboardView();
      } else if (index == 1) {
        _selectedPage = HomePage(
          username: widget.username,
          password: widget.password,
          listBug: widget.listBug,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
        );
      } else if (index == 2) {
        _selectedPage = ToolsPage(
          sessionKey: widget.sessionKey, 
          userRole: widget.role, 
          listDoos: widget.listDoos
        );
      } else if (index == 3) {
        _selectedPage = const HomeAnimePage();
      }
    });
  }

  void _toggleTopSidebar() => setState(() => _isSidebarOpen = !_isSidebarOpen);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          _selectedPage,

          if (_isSidebarOpen) 
            GestureDetector(
              onTap: _toggleTopSidebar, 
              child: Container(color: Colors.black87)
            ),

          AnimatedPositioned(
            duration: const Duration(milliseconds: 400),
            curve: Curves.fastOutSlowIn,
            top: _isSidebarOpen ? 0 : -MediaQuery.of(context).size.height * 0.5,
            left: 0, right: 0,
            child: _buildTopSidebar(),
          ),
        ],
      ),
      bottomNavigationBar: _buildBottomNavbar(),
    );
  }

  Widget _buildNewsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "Latest News",
          style: TextStyle(
            color: Colors.white,
            fontSize: 18,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 200,
          child: PageView.builder(
            controller: PageController(viewportFraction: 0.9),
            itemCount: widget.news.length,
            itemBuilder: (context, index) {
              final item = widget.news[index];
              return Container(
                margin: const EdgeInsets.only(right: 16),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  color: cardDark,
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      if (item['image'] != null && item['image'].toString().isNotEmpty)
                        NewsMedia(url: item['image']),
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [Colors.black.withOpacity(0.7), Colors.transparent],
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 16, left: 16, right: 16,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              item['title'] ?? 'No Title',
                              style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              item['desc'] ?? '',
                              style: TextStyle(color: Colors.white.withOpacity(0.7), fontSize: 14),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }

  Widget _buildMainDashboardView() {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 30),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(),
            const SizedBox(height: 20),
            _buildNewsSection(),
            const SizedBox(height: 40),
            Row(
              children: [
                _buildStatCard(Icons.people, "Online Users", onlineUsers.toString()),
                const SizedBox(width: 12),
                _buildStatCard(Icons.link, "Connections", activeConnections.toString()),
              ],
            ),
            const SizedBox(height: 16),
            _buildAccountInfo(),
            const SizedBox(height: 16),
Row(
  children: [
    _buildActionBtn(
      Icons.send_rounded,
      "Manage Sender",
      () => Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => BugSenderPage(
            sessionKey: widget.sessionKey,
            username: widget.username,
            role: widget.role,
          ),
        ),
      ),
    ),
    const SizedBox(width: 12),
    _buildActionBtn(
      Icons.bug_report_outlined,
      "Manage Bugs",
      () {
        setState(() {
          _selectedIndex = 1;
          _selectedPage = HomePage(
            username: widget.username,
            password: widget.password,
            sessionKey: widget.sessionKey,
            listBug: widget.listBug,
            role: widget.role,
            expiredDate: widget.expiredDate,
          );
        });
      },
    ),
  ],
),
const SizedBox(height: 40),
            const Text("Overview", style: TextStyle(fontFamily: 'Orbitron', fontSize: 16, color: Colors.white60)),
            const SizedBox(height: 15),
            Row(
              children: [
                _buildOverviewItem(Icons.verified_user, "Anti-Spam", 0.4),
                const SizedBox(width: 12),
                _buildOverviewItem(Icons.bar_chart, "Health", 0.76),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Welcome back", style: TextStyle(color: Colors.white24, fontSize: 14)),
            SizedBox(height: 4),
            Text("My Dashboard", style: TextStyle(fontFamily: 'Orbitron', fontSize: 26, fontWeight: FontWeight.bold, color: Colors.white70)),
          ],
        ),
        IconButton(onPressed: _toggleTopSidebar, icon: const Icon(Icons.menu_open_rounded, color: Colors.white70, size: 28)),
      ],
    );
  }

  Widget _buildTopSidebar() {
  final String role = widget.role;

  return Container(
    height: MediaQuery.of(context).size.height * 0.5,
    padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 40),
    decoration: const BoxDecoration(
      color: Color(0xFF111111),
      borderRadius: BorderRadius.only(bottomLeft: Radius.circular(24), bottomRight: Radius.circular(24)),
      border: Border(bottom: BorderSide(color: Colors.white10)),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          "QUICK ACCESS",
          style: TextStyle(
            fontFamily: 'Orbitron',
            fontSize: 12,
            color: Colors.white24,
            letterSpacing: 2,
          ),
        ),
        const SizedBox(height: 20),

        if (role == "owner")
          _sidebarTile(
            Icons.admin_panel_settings,
            "Admin Page",
            () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => AdminPage(sessionKey: widget.sessionKey)),
            ),
          ),
        if (role == "reseller" || role == "owner")
          _sidebarTile(
            Icons.storefront_outlined,
            "Seller Page",
            () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => SellerPage(keyToken: widget.sessionKey)),
            ),
          ),

        _sidebarTile(
          Icons.verified_user_outlined,
          "Nik Checker",
          () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const NikCheckerPage()),
          ),
        ),
        _sidebarTile(
          Icons.password_rounded,
          "Change Password",
          () => Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => ChangePasswordPage(
              username: widget.username,
              sessionKey: widget.sessionKey,
            )),
          ),
        ),

        const Spacer(),
        Center(
          child: Text(
            "Your Role: $role",
            style: const TextStyle(
              fontSize: 10,
              color: Colors.white10,
              letterSpacing: 2,
            ),
          ),
        ),
      ],
    ),
  );
}

  Widget _sidebarTile(IconData icon, String title, VoidCallback? onTap) {
    final bool isLocked = onTap == null;
    return ListTile(
      onTap: isLocked ? null : onTap,
      leading: Icon(isLocked ? Icons.lock_outline_rounded : icon, color: isLocked ? Colors.white10 : Colors.white38, size: 22),
      title: Text(title, style: TextStyle(color: isLocked ? Colors.white10 : Colors.white70, fontSize: 16, fontFamily: 'ShareTechMono')),
      trailing: isLocked ? null : const Icon(Icons.chevron_right, size: 16, color: Colors.white10),
    );
  }

  Widget _buildAccountInfo() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: _matteDecoration(),
      child: Column(
        children: [
          _infoTile(Icons.person, widget.username, badge: widget.role),
          const Divider(color: Colors.white10, height: 24),
          _infoTile(Icons.calendar_today, "Expires ${widget.expiredDate}"),
        ],
      ),
    );
  }

  Widget _buildBottomNavbar() {
  return Container(
    decoration: const BoxDecoration(
      border: Border(top: BorderSide(color: Colors.white10)),
    ),
    child: BottomNavigationBar(
      currentIndex: _selectedIndex,
      onTap: _onTabTapped,
      backgroundColor: Colors.black,
      selectedItemColor: Colors.white,
      unselectedItemColor: Colors.white24,
      type: BottomNavigationBarType.fixed,
      items: [
        BottomNavigationBarItem(
          icon: Icon(Icons.dashboard_outlined),
          activeIcon: Icon(Icons.dashboard_rounded),
          label: 'Home',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.bug_report_outlined),
          activeIcon: Icon(Icons.bug_report_rounded),
          label: 'WhatsApp',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.construction_outlined),
          activeIcon: Icon(Icons.construction_rounded),
          label: 'Tools',
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.movie_filter_outlined),
          activeIcon: Icon(Icons.movie_filter),
          label: 'Anime',
        ),
      ],
    ),
  );
}

  BoxDecoration _matteDecoration() => BoxDecoration(
    color: const Color(0xFF151515), 
    borderRadius: BorderRadius.circular(12), 
    border: Border.all(color: Colors.white10)
  );

  Widget _buildStatCard(IconData icon, String label, String value) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: _matteDecoration(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [Icon(icon, size: 16, color: Colors.white30), const SizedBox(width: 8), Text(label, style: const TextStyle(fontSize: 12, color: Colors.white30))]),
            const SizedBox(height: 10),
            Text(value, style: const TextStyle(fontFamily: 'Orbitron', fontSize: 24, color: Colors.white70)),
          ],
        ),
      ),
    );
  }

  Widget _buildActionBtn(IconData icon, String label, VoidCallback onTap) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 14),
          decoration: _matteDecoration(),
          child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [Icon(icon, size: 18, color: Colors.white30), const SizedBox(width: 10), Text(label, style: const TextStyle(fontSize: 13, color: Colors.white60))]),
        ),
      ),
    );
  }

  Widget _infoTile(IconData icon, String text, {String? badge}) {
    return Row(
      children: [
        Icon(icon, size: 20, color: Colors.white30),
        const SizedBox(width: 12),
        Text(text, style: const TextStyle(fontSize: 15, color: Colors.white60)),
        const Spacer(),
        if (badge != null)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 2),
            decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(4)),
            child: Text(badge, style: const TextStyle(fontSize: 10, color: Colors.white24)),
          ),
        const Icon(Icons.chevron_right, size: 18, color: Colors.white12),
      ],
    );
  }

  Widget _buildOverviewItem(IconData icon, String label, double progress) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: _matteDecoration(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(children: [Icon(icon, size: 16, color: Colors.white30), const SizedBox(width: 8), Expanded(child: Text(label, style: const TextStyle(fontSize: 10, color: Colors.white30), overflow: TextOverflow.ellipsis))]),
            const SizedBox(height: 10),
            Container(
              height: 4, width: double.infinity,
              decoration: BoxDecoration(color: Colors.white10, borderRadius: BorderRadius.circular(2)),
              child: FractionallySizedBox(alignment: Alignment.centerLeft, widthFactor: progress, child: Container(decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(2)))),
            ),
          ],
        ),
      ),
    );
  }
}

class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;
  bool isVideo = false;

  @override
  void initState() {
    super.initState();
    isVideo = widget.url.toLowerCase().endsWith(".mp4") || widget.url.toLowerCase().endsWith(".mov");
    if (isVideo) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(0.0);
          _controller?.play();
        });
    }
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (isVideo) {
      return _controller != null && _controller!.value.isInitialized
          ? AspectRatio(aspectRatio: _controller!.value.aspectRatio, child: VideoPlayer(_controller!))
          : const Center(child: CircularProgressIndicator(color: Colors.blue));
    } else {
      return Image.network(widget.url, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const Icon(Icons.error));
    }
  }
}

/* 

{ Creators By @KaiiOfficial }
- ChatGPT? MayBee! (My GPT Premium Is Expired)
- Gemini AI? MayBee! (Not Used To Gemini AI)
- Don't Sell This Base!

Credits Base?
- YoungKaii {This Creators}
- Sya?? {My Lovers}
- PermenMD {My Idol}
- AiiSigma {Best My Friends}
- Zsnz {Best My Friends}
- Zarr {Best My Friends}
- Pdl.Pdf {Best My Friends}
- Zyrex {Best My Friends}
- Kyingz {Best My Friends}
- DX FadilTzy {My Friends}

Supports?
- ChatGPT {Digital Assistant}
- Gemini {Digital Assistant}
- Llama 4.0 {Digital Assistant}
- MT Manager {Donors}
- VsCode {Donors}

My Old Friends?
- Sarip444 {Donors}
- Danzy Xnxx {Donors} & {Sensei}
- Deffa {Sensei}

Conntact Telegram: @KaiiOfficial
# Just chat if there is an interest!
# Base Error? Please Fix It Yourself!
See You Next Time.

Kata" Hari Ini Boskuu: Jangan Pantang Menyerah, Hasil Di Awal Emang Pahit Tapi Tidak Berlaku Di Akhir!
Kesimpulannya: Lu Udah Buang Waktu Lu? Dan Tiba-tiba Lu Menyerah? Sama Aja Lu Itu Sampah! (Bukan Hinaan! Tapi Motivasi!)

Motivasi Hari Ini Boskuu: Makanlah Hinaan, Jangan Karena Kau Di Hina, Kau Mendramai Nya!
Hinaan Lebih Manis Dari Pada Drama Yang Pahit itu!

Kesimpulannya: Jika Lu Di Hina? Ya Jangan Di Urus (Di Diemin Dan Tunjukin Bahwa Diri Lu Itu Bisa! Jangan Malah Ga Terima Terus Lu Drama!)
Hinaan Akan Mencerna Sampai Otak Kita Dan Susah Untuk Di Lupakan! Maka Lu Akan Merubah Diri Lu Dikit Demi Sedikit! Dan Akhirnya Menjadi Besar!

Bukan Alay Atau Apa! Ini Hanya Motivasi Bro! Lu Bilang Alay? Mungkin Otak Lu Kurang Sampe Di Posisi Ini!

#SensitifBacaNiMotivasi?SkipAja
#GaBuatBocahKemarinSore!
#KenalinNihGPT!

That's All, Thank You.

*/