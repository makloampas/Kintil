module.exports = {
  tokens: "YOUR_TOKEN_BOT",
  owners: ["7250235697"],
  ipvps: "http://panelprivateez.yayz-offline.biz.id", 
  port: 2002
};

/* WAJIB BACA !!!
 cari di index.js halaman 2323-2324 di situ masukin bot token sama id tele lu.

 emngnya knpa bang?
 lu buka aja dulu. di sana udah gw kasi penjelasannya
*/