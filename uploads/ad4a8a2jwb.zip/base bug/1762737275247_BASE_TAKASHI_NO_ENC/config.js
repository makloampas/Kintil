module.exports = {
  TOKEN_USER: "8147705376:AAFA71cPdx_zG7D5i8RhuF8EhXA7UebgEjU", //Ganti Token Bot
  ModuleApiBot: "AphoppisApi77", // Api Bot Jangan Ganti 
};