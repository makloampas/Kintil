const { Telegraf } = require('telegraf');
const fetch = require('node-fetch');
const axios = require('axios');
const fs = require('fs');
const pino = require('pino');
const { Boom } = require('@hapi/boom');
const { default: makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestWaWebVersion } = require('@whiskeysockets/baileys');


// ==========================
// KONFIGURASI DASAR 
const ADMIN_ID = 2146698809;
const ADMIN = 2146698809;
// GANTI ID DENGAN ID TELEGRAM KAMU SAMA JUGA INI BIAR BISA LIST EMAIL DLL
const OWNER = "2146698809";
//ganti semua pakai id kamu

// ==========================
const BOT_TOKEN = '8500402389:AAFOHwXwcZfRUC4GHjJsHOOpvuSHna6aWPo';


//yabg ini jangan di ganti kecuali admin mengatakan apikey ganti ke xxx lalu ganti apkikey misal adminv ganti menjadi memek nah ganti sudah itu run aja 
//by lunzy kontol

const API_KEY = 'adminv';
const BASE_URL = 'https://frivate-lunzy4.vercel.app/api';
const SESSION_NAME = './sessions'; // folder penyimpanan data WA
const bot = new Telegraf(BOT_TOKEN);

let waClient = null;
let waConnectionStatus = 'closed';
const userCooldowns = {}; // { userId: timestamp_end_cooldown }

// =========================
// CONFIG GITHUB
// =========================
const { Octokit } = require("@octokit/rest");


//ganti id tele mu

// ==========================
// HELPER FUNCTION UMUM
// ==========================

function formatResult(data) {
  let out = '📨 *Hasil API:*\n';
  if (data.success !== undefined)
    out += `• Status: ${data.success ? '✅ Berhasil' : '❌ Gagal'}\n`;
  if (data.message) out += `• Pesan: ${data.message}\n`;
  if (data.nomor) out += `• Nomor: ${data.nomor}\n`;
  if (data.email) out += `• Email: ${data.email}\n`;
  if (data.subject) out += `• Subjek: ${data.subject}\n`;
  if (data.response) out += `• Respon: ${data.response}\n`;
  return out;
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}
//pepelekeb


const GITHUB_TOKEN = "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"; // <- isi sendiri
const GITHUB_OWNER = "F12241";
const GITHUB_REPO = "frivate-lunzy4";
const GITHUB_FILE = "dataimel.txt";
const GITHUB_BRANCH = "main";

const octokit = new Octokit({ auth: GITHUB_TOKEN });

async function deleteEmailFromGithub(target) {
  try {
    const url = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/${GITHUB_FILE}`;

    const res = await axios.get(url, {
      headers: { Authorization: `token ${GITHUB_TOKEN}` }
    });

    const sha = res.data.sha;
    const content = Buffer.from(res.data.content, "base64").toString("utf8");

    // Hapus baris yang cocok
    const newContent = content
      .split("\n")
      .filter(line => line.trim() !== target.trim())
      .join("\n");

    if (newContent === content) {
      return { success: false, message: "Data tidak ditemukan." };
    }

    // Upload ulang
    await axios.put(
      url,
      {
        message: `Delete email: ${target}`,
        content: Buffer.from(newContent, "utf8").toString("base64"),
        sha
      },
      {
        headers: { Authorization: `token ${GITHUB_TOKEN}` }
      }
    );

    return { success: true, message: "Berhasil menghapus." };

  } catch (e) {
    console.log(e.response?.data || e);
    return { success: false, message: e.response?.data?.message || e.message };
  }
}


    
async function githubGetFileRaw() {
  try {
    const url = `https://api.github.com/repos/${GITHUB_OWNER}/${GITHUB_REPO}/contents/${GITHUB_FILE}`;
    const res = await axios.get(url, {
      headers: { Authorization: `Bearer ${GITHUB_TOKEN}` }
    });

    return {
      content: Buffer.from(res.data.content, "base64").toString("utf8"),
      sha: res.data.sha
    };

  } catch (err) {
    if (err.response && err.response.status === 404) {
      return { content: "", sha: null };
    }
    throw err;
  }
}
//github
async function githubGetFile() {
  try {
    const res = await octokit.repos.getContent({
      owner: GITHUB_OWNER,
      repo: GITHUB_REPO,
      path: GITHUB_FILE,
      ref: GITHUB_BRANCH
    });

    const content = Buffer.from(res.data.content, "base64").toString("utf8");
    return { content, sha: res.data.sha };

  } catch (err) {
    if (err.status === 404) return { content: "", sha: null };
    throw err;
  }
}

async function githubUpdateFile(newContent, sha) {
  return await octokit.repos.createOrUpdateFileContents({
    owner: GITHUB_OWNER,
    repo: GITHUB_REPO,
    path: GITHUB_FILE,
    message: "Update via Telegram Bot",
    content: Buffer.from(newContent).toString("base64"),
    sha: sha || undefined,
    branch: GITHUB_BRANCH
  });
}
// ==========================
// FITUR PREMIUM USER
// ==========================
// ==========================
// FITUR KHUSUS GRUP
// ==========================


const premiumFile = './premium.json';
let premiumUsers = fs.existsSync(premiumFile)
  ? JSON.parse(fs.readFileSync(premiumFile))
  : [];

function savePremium() {
  fs.writeFileSync(premiumFile, JSON.stringify(premiumUsers, null, 2));
}

function isPremium(id) {
  return premiumUsers.includes(id);
}

// GANTI ID ADMIN DENGAN ID KAMU SENDIRI


bot.command('listgrup', async (ctx) => {
  if (ctx.from.id.toString() !== OWNER) {
    return ctx.reply("❌ Hanya OWNER yang bisa melihat daftar grup.");
  }

  if (grupList.length === 0) {
    return ctx.reply("📭 Tidak ada grup yang terdaftar.");
  }

  let text = "📌 *Daftar Grup Terdaftar:*\n\n";
  grupList.forEach((id, i) => {
    text += `${i + 1}. \`${id}\`\n`;
  });

  ctx.replyWithMarkdown(text);
});
// ➕ ADDPREM
bot.command('addprem', async (ctx) => {
  if (ctx.from.id !== ADMIN_ID) return ctx.reply('❌ Hanya admin yang bisa menambah premium.');
  let targetId = ctx.message.reply_to_message
    ? ctx.message.reply_to_message.from.id
    : parseInt(ctx.message.text.split(' ')[1]);
  if (!targetId) return ctx.reply('❌ Gunakan: /addprem <id> atau reply pesan user.');
  if (!premiumUsers.includes(targetId)) {
    premiumUsers.push(targetId);
    savePremium();
    ctx.reply(`✅ User ${targetId} ditambahkan ke daftar premium.`);
  } else ctx.reply('⚠️ User sudah premium.');
});

// ➖ DELPREM
bot.command('delprem', async (ctx) => {
  if (ctx.from.id !== ADMIN_ID) return ctx.reply('❌ Hanya admin yang bisa menghapus premium.');
  let targetId = ctx.message.reply_to_message
    ? ctx.message.reply_to_message.from.id
    : parseInt(ctx.message.text.split(' ')[1]);
  if (!targetId) return ctx.reply('❌ Gunakan: /delprem <id> atau reply pesan user.');
  if (premiumUsers.includes(targetId)) {
    premiumUsers = premiumUsers.filter(id => id !== targetId);
    savePremium();
    ctx.reply(`✅ User ${targetId} dihapus dari daftar premium.`);
  } else ctx.reply('⚠️ User tidak ada di daftar premium.');
});

// 📜 LISTPREM
bot.command('listprem', async (ctx) => {
  if (!premiumUsers.length) return ctx.reply('📭 Belum ada user premium.');
  const list = premiumUsers.map((id, i) => `${i + 1}. ${id}`).join('\n');
  ctx.reply(`💎 *Daftar Premium:*\n${list}`, { parse_mode: 'Markdown' });
});

// ==========================
// PROTEKSI PREMIUM UNTUK FITUR LAIN
// ==========================

// Middleware global (cek semua command selain /start dan fitur admin)
// Middleware global (cek semua command selain /start dan fitur admin)
const channel = "@jualnoktel1";
const channelLink = `https://t.me/${channel.replace("@", "")}`;
const group = "@basejualnokos";
const groupLink = `https://t.me/${group.replace("@", "")}`;

async function isMember(ctx) {
  try {
    const member = await ctx.telegram.getChatMember(channel, ctx.from.id);
    return ["creator", "administrator", "member", "restricted"].includes(member.status);
  } catch {
    return false;
  }
}

const forceJoinKeyboard = {
  reply_markup: {
    inline_keyboard: [
      [
        { text: "𝑱𝒐𝒊𝒏 𝑪𝒉𝒂𝒏𝒏𝒆𝒍 🔒", url: channelLink }
      ],
      [
        { text: "𝑱𝒐𝒊𝒏 𝑮𝒓𝒐𝒖𝒑 🔒", url: groupLink }
      ]
    ]
  }
};

bot.use(async (ctx, next) => {
  if (ctx.updateType === "callback_query" && ctx.update.callback_query?.data === "check_join") {
    return next();
  }

  if (ctx.chat?.type === "private" && ctx.from) {
    const joined = await isMember(ctx);

    if (!joined) {
      const caption = `
\`\`\`
<b>ᴀᴋsᴇs ᴅɪ ᴛᴏʟᴀᴋ ✦</b>

ᴊɪᴋᴀ ɪɴɢɪɴ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ғɪᴛᴜʀ ʙᴏᴛ,
ɪᴋᴜᴛɪ ʟᴀɴɢᴋᴀʜ-ʟᴀɴɢᴋᴀʜ ᴅɪ ʙᴀᴡᴀʜ

<b>1.</b> ᴍᴀsᴜᴋ ᴄʜᴀɴɴᴇʟ ᴅᴀɴ ɢʀᴏᴜᴘ 
<b>2.</b> sʜᴀʀᴇ ʙᴏᴛ ᴍɪɴɪᴍᴀʟ 4 ɢʀᴏᴜᴘ / ᴏʀᴀɴɢ

ᴊɪᴋᴀ sᴜᴅᴀʜ. sᴛᴀʀᴛ ᴜʟᴀɴɢ ʙᴏᴛ ɴʏᴀ

@wikihoftboys
\`\`\`
`;

      if (ctx.message) {
        await ctx.replyWithPhoto(
          'https://files.catbox.moe/crro59.jpg',
          {
            caption,
            parse_mode: "HTML",
            ...forceJoinKeyboard
          }
        );
      } 
      else if (ctx.callbackQuery) {
        await ctx.answerCbQuery("❌ Kamu belum menjadi member komunitas kami", { show_alert: true });
      }

      return;
    }
  }

  return next();
});

bot.action("check_join", async (ctx) => {
  const joined = await isMember(ctx);
  if (joined) {
    await ctx.answerCbQuery("✅ ☇ Sudah menjadi member komunitas, sekarang kamu bisa pakai bot");
    await ctx.editMessageText("✅ ☇ Terima kasih sudah menjadi member di komunitas kami, sekarang kamu bisa menggunakan bot");
  } else {
    await ctx.answerCbQuery("❌ Kamu belum menjadi member komunitas kami", { show_alert: true });
    await ctx.reply("❌ ☇ Kamu belum menjadi member komunitas kami", forceJoinKeyboard);
  }
});
// ==========================
// WHATSAPP CLIENT (BAILEYS)
// ==========================

// Helper
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// ===========================
// BOT LISTENER UNTUK FILE
// ===========================


// ===========================
// COMMAND UNTUK CEK NOMOR LANGSUNG
// ===========================

// ==========================
//  COMMANDS TELEGRAM
// ==========================


// ==========================
//  COMMANDS TELEGRAM
// ==========================




bot.command("addemail", async (ctx) => {
  // HANYA OWNER / ADMIN YANG BOLEH
  if (ctx.from.id !== ADMIN) {
    return ctx.reply("❌ Perintah ini hanya untuk OWNER.");
  }

  const text = ctx.message.text.replace("/addemail", "").trim();

  if (!text || !text.includes(":")) {
    return ctx.reply("⚠️ Format salah.\nGunakan:\n`/addemail email:pass`", {
      parse_mode: "Markdown"
    });
  }

  try {
    const { content, sha } = await githubGetFile();
    const newContent = (content ? content.trim() + "\n" : "") + text + "\n";

    await githubUpdateFile(newContent, sha);

    ctx.reply("✅ email berhasil ditambahkan !");
  } catch (err) {
    console.error(err);
    ctx.reply("❌ Gagal add email  .");
  }
});



bot.command("listemail", async (ctx) => {
  if (ctx.from.id !== ADMIN)
    return ctx.reply("❌ Perintah ini hanya untuk OWNER.");

  try {
    const { content } = await githubGetFileRaw();

    if (!content.trim())
      return ctx.reply("📭 Tidak ada data email.");

    const list = content
      .trim()
      .split("\n")
      .map((v, i) => `${i + 1}. ${v}`)
      .join("\n");

    ctx.reply(`📄 *List Email:*\n${list}`, { parse_mode: "Markdown" });

  } catch (err) {
    console.log(err);
    ctx.reply("❌ Gagal mengambil data ");
  }
});

bot.command("delemail", async (ctx) => {
  const userId = ctx.from.id.toString();
  const message = ctx.message.text;

  if (userId !== OWNER) {
    return ctx.reply("❌ Kamu tidak memiliki akses menggunakan perintah ini.");
  }

  const target = message.split(" ")[1];

  if (!target || !target.includes("@") || !target.includes(":")) {
    return ctx.reply("⚠️ Format salah!\nContoh:\n/delemail email:password");
  }

  await ctx.reply("🧹 Menghapus email!!.");

  try {
    const result = await deleteEmailFromGithub(target);

    if (result.success) {
      ctx.reply(`✅ Berhasil dihapus:\n${target}`);
    } else {
      ctx.reply(`❌ Gagal menghapus:\n${result.message}`);
    }

  } catch (err) {
    console.log(err);
    ctx.reply("❌ Error server, cek console.");
  }
});


// Helper: panggil API
async function callApi(endpoint, params = {}) {
  const url = new URL(BASE_URL + endpoint);
  params.apikey = API_KEY;
  Object.keys(params).forEach(k => url.searchParams.append(k, params[k]));
  const res = await fetch(url.toString());
  return res.json();
}



// ==========================

// ==========================
function dashboardText() {
  return (
` 
\`\`\`
『 𝙒𝙞𝙠𝙞 𝙏𝙖𝙢𝙫𝙖𝙣 🦋 』
\`\`\`
[ 🍁 ] 𝙊𝙡𝙖𝙖 , 𝙄 𝙝𝙖𝙫𝙚 𝙖 𝙗𝙤𝙩 𝙩𝙝𝙖𝙩 𝙞𝙨 𝙙𝙚𝙨𝙞𝙜𝙣𝙚𝙙 𝙩𝙤 𝙝𝙚𝙡𝙥 
 𝙛𝙞𝙭 𝙣𝙪𝙢𝙗𝙚𝙧𝙨 𝙩𝙝𝙖𝙩 𝙘𝙖𝙣𝙣𝙤𝙩 𝙗𝙚 𝙖𝙘𝙘𝙚𝙨𝙨𝙚𝙙.

╔━━━ ( 𝘿𝙖𝙨𝙗𝙤𝙖𝙧𝙙 𝙎𝙞𝙨𝙩𝙚𝙢 🦋  ) ━━⬡
│ 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧 : @wikihoftboys
│ 𝙑𝙚𝙧𝙨𝙞𝙤𝙣 : 1
│ 𝙈𝙮 𝘾𝙝𝙖𝙣𝙣𝙚𝙡 : @jualnoktel1
│ 𝙎𝙪𝙥𝙥𝙤𝙧𝙩 𝘽𝙮 :  Support ? i'm solo bos
╰━━━━━━━━━━━━━━━━━━━━━━━━⬡
•• ━━━━━ •• ━━━━━ •• ━━━━━ •• ━━━━━ 
╔━━━ ( 𝘼𝙡𝙡 𝙈𝙚𝙣𝙪 ) ━━━━⬡
│/addemail -> Menambahkan Email Sender 
│/delemail -> Menghapus Email Sender 
│/listemail -> Melihat Semua Email
│/addprem -> Menambahkan User Premium 
│/delprem -> Menghapus User Premium 
│/listgrup -> Melihat Grup Terdaftar 
╰━━━━━━━━━━━━━━━━━━━━━━━━⬡

`
  );
}
bot.start((ctx) => {
  ctx.replyWithPhoto(
    { url: "https://files.catbox.moe/crro59.jpg" }, // bebas, ganti link fotomu sendiri
    {
      caption: dashboardText(),
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: '𝙁𝙞𝙭 𝙈𝙚𝙧𝙖𝙝 📌', callback_data: 'banding' }]
        ]
      }
    }
  );
});
// 🎯 Command /start → kirim dashboard utama
bot.start((ctx) => {
  ctx.replyWithMarkdown(dashboardText(), dashboardMenu());
});

// Handler tombol utama dashboard
bot.on('callback_query', async (ctx) => {
  const action = ctx.callbackQuery.data;
  const msgId = ctx.callbackQuery.message.message_id;
  const chatId = ctx.callbackQuery.message.chat.id;

  try {

    // =======================
    // DASHBOARD UTAMA
    // =======================
    if (action === 'menu') {
      await ctx.telegram.editMessageMedia(
        chatId,
        msgId,
        undefined,
        {
          type: 'photo',
          media: 'https://files.catbox.moe/crro59.jpg',
          caption: dashboardText(),
          parse_mode: 'Markdown'
        },
        {
          reply_markup: {
            inline_keyboard: [
              [{ text: '𝙁𝙞𝙭 𝙈𝙚𝙧𝙖𝙝 📌', callback_data: 'banding' }]
            ]
          }
        }
      );
      return;
    }


    // =======================
    // APPEAL MODE / BANDING
    // =======================
    if (action === 'banding') {
      await ctx.telegram.editMessageMedia(
        chatId,
        msgId,
        undefined,
        {
          type: 'photo',
          media: 'https://files.catbox.moe/crro59.jpg',
          caption:
            '╭───────Appeal mode───────\n' +
            '│ Use the format:\n' +
            '│ `/banding <nomor>`\n' +
            '│ example: `/banding 628123456789`\n' +
            '│\n' +
            '│ 🔹 The red fix is text says contact us\n' +
            '╰───────────────────────\n' +
            'αρρєαℓ ву ωιкι тαмναη',
          parse_mode: 'Markdown'
        },
        {
          reply_markup: {
            inline_keyboard: [
              [{ text: '𝘽𝙖𝙘𝙠 𝙈𝙚𝙣𝙪 <-', callback_data: 'menu' }]
            ]
          }
        }
      );
      return;
    }



  } catch (err) {
    console.error('Callback Error:', err);
    await ctx.answerCbQuery(`❌ Error: ${err.message}`, { show_alert: true });
  }

  await ctx.answerCbQuery();
});


bot.command('broadcast', async (ctx) => {
  if (!ADMIN_ID.includes(ctx.from.id))
    return ctx.reply('❌ Hanya admin yang bisa melakukan broadcast.');

  const text = ctx.message.text.split(' ').slice(1).join(' ');
  if (!text)
    return ctx.reply('Gunakan format: /broadcast <pesan>');

  const username = ctx.from.username ? `@${ctx.from.username}` : ctx.from.first_name || 'Admin';
  const pesan = `📢 *Pesan dari owner ${username}*\n\n${text}`;

  await ctx.reply(`🚀 Mengirim broadcast ke ${users.length} user...`);

  let sukses = 0, gagal = 0;
  for (const id of users) {
    try {
      await bot.telegram.sendMessage(id, pesan, { parse_mode: 'Markdown' });
      sukses++;
      await sleep(150);
    } catch (err) {
      gagal++;
    }
  }

  ctx.reply(`✅ Broadcast selesai!\n\nBerhasil✅: ${sukses}\n\nGagal❌: ${gagal}`);
});


// 📲 MODE BANDING (COOLDOWN 120s)
bot.command('banding', async (ctx) => {
  const userId = ctx.from.id;
  const now = Date.now();

  const args = ctx.message.text.split(' ').slice(1);
  const nomor = args[0]?.trim();

  if (!nomor) {
    return ctx.replyWithMarkdown(
      '⚠️ Kirim nomor setelah command.\n\n📌 *Contoh:*\n`/banding 6281234567890`'
    );
  }

  if (!/^\d{8,15}$/.test(nomor)) {
    return ctx.reply('❌ Nomor tidak valid. Gunakan hanya angka tanpa spasi atau simbol.');
  }

  // COOLDOWN
  const cooldownEnd = userCooldowns[userId] || 0;
  if (now < cooldownEnd) {
    const wait = Math.ceil((cooldownEnd - now) / 1000);
    return ctx.reply(`🕓 Tunggu ${wait}s sebelum bisa cek nomor lagi.`);
  }

  // MULAI COOLDOWN
 

  try {
    const data = await callApi('/banding', { nomor });

    const resultText = `✅ Laporan Berhasil Dikirim!
╭──────────────────────
│📞 Nomor : *${nomor}*
│📊 Status : *${data.status || '✅'}*
│📂 Email: ${data.email}
│📬 Tujuan: WhatsApp Support
╰──────────────────────`;

    await ctx.replyWithMarkdown(resultText);
  } catch (err) {
    await ctx.reply(`❌ Terjadi kesalahan: ${err.message}`);
  }
});

bot.launch().then(() => console.log('🤖 BOT TELE AKTIF | WA CLIENT JALAN ✅'));

