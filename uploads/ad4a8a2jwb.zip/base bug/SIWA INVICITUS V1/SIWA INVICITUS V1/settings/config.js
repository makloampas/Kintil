module.exports = {
  BOT_TOKEN: "your token", /// token bot lu
  OWNER_ID: ["your id"], // id telegram lu
};