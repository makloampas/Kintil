module.exports = {
  BOT_TOKEN: "TOKENS",
};

//=========================//
//Credits Base: @OBITOBOYS
//==========================//