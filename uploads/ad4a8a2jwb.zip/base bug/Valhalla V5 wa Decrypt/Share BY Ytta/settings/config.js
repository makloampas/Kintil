
/*─────────────────────────────────────────
  GitHub   : https://github.com/ErlanggaaXzzz    
  YouTube  : https://youtube.com/@ErlanggaOfficial-t2z
  Telegram : https://t.me/langgxyz2
  Base: ErlanggaOfficial
──────────────────────────────────────────*/

const fs = require('fs')

const config = {
    owner: "-",
    botNumber: "-",
    setPair: "ERLANGGA",
    thumbUrl: "https://files.catbox.moe/bs0vlw.jpg",
    session: "sessions",
    status: {
        public: true,
        terminal: true,
        reactsw: false
    },
    message: {
        owner: "( # ) ---> No Acces Only Owner",
        group: "( # ) ---> No Acces For Group Only",
        admin: "( # ) ---> No Acces This Is Command Is For Admin Only",
        private: "( # ) ---> No Acces This Is Specifically For Private Chat"
    },
    settings: {
        title: "valhalla crash",
        packname: 'Rann is a cool man',
        description: "this script was created by RannOfficial",
        author: 'https://erlanggaofficial-web-shop.vercel.app/',
        footer: "RannBukanPemula"
    },
    newsletter: {
        name: "\0",
        id: "120363398138670718@newsletter"
    },
    socialMedia: {
        YouTube: "https://youtube.com/@rann",
        GitHub: "https://github.com/ErlanggaaXzzz",
        Telegram: "https://t.me/rannloww",
        ChannelWA: "https://whatsapp.com/channel/0029Vb0xQopJf05efvI5Da2y"
    }
}

module.exports = config;

let file = require.resolve(__filename)
require('fs').watchFile(file, () => {
  require('fs').unwatchFile(file)
  console.log('\x1b[0;32m'+__filename+' \x1b[1;32mupdated!\x1b[0m')
  delete require.cache[file]
  require(file)
})
