module.exports = {
  BOT_TOKEN: "7778819006:AAFioOad8zoKcqCk94GtXo88DHh-uI4obYw",
  OWNER_ID: ["7822996621"],
};