module.exports = {
  tokens: "8414888839:AAEEr3iasx_X0YgAkrxhOgj70jTkEPN_Q0U",  // Masukin Bot token kamu
  owners: "8152544297", // Masukin ID Telegram kamu
  port: "2031", // Masukin Port panel kamu 
  ipvps: "http://panel-jarr.storedigital.web.id" // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://AiiSigma.id ) menjadi ( http://AiiSigma.id )
};

/* WAJIB BACA !!!
 cari di index.js halaman 1710-1711 di situ masukin bot token sama id tele lu.

 emngnya knpa bang?
 lu buka aja dulu. di sana udah gw kasi penjelasannya
*/