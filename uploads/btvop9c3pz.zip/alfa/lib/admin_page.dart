import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class AdminPage extends StatefulWidget {
  final String sessionKey;

  const AdminPage({super.key, required this.sessionKey});

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> with TickerProviderStateMixin {
  late String sessionKey;
  List<dynamic> fullUserList = [];
  List<dynamic> filteredList = [];
  final List<String> roleOptions = ['member', 'vip', 'reseller', 'reseller1', 'owner'];
  String selectedRole = 'member';
  int currentPage = 1;
  int itemsPerPage = 15;

  final deleteController = TextEditingController();
  final createUsernameController = TextEditingController();
  final createPasswordController = TextEditingController();
  final createDayController = TextEditingController();
  String newUserRole = 'member';
  bool isLoading = false;

  // UBAH: Theme Colors ke Deep Green & Black (Cyber Theme)
  final Color bgBlack = const Color(0xFF050505);
  final Color accentGreen = const Color(0xFF1B5E20);
  final Color lightGreen = const Color(0xFF2ECC71);
  final Color glassBorder = Colors.white.withOpacity(0.08);
  final Color glassBg = Colors.white.withOpacity(0.03);
  final Color dangerRed = const Color(0xFFFF5252);
  final Color successGreen = const Color(0xFF00C853);

  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  int _selectedTab = 0;

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    _animationController = AnimationController(duration: const Duration(milliseconds: 800), vsync: this);
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(CurvedAnimation(parent: _animationController, curve: Curves.easeIn));
    _animationController.forward();
    _fetchUsers();
  }

  // --- CORE LOGIC ---

  Future<void> _fetchUsers() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('http://public-server.verlang.id:4981/listUsers?key=$sessionKey'));
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        fullUserList = data['users'] ?? [];
        _filterAndPaginate();
      } else {
        _showNotification("UNAUTHORIZED", "Protocol Rejected: Invalid Session", dangerRed);
      }
    } catch (e) {
      _showNotification("ERROR", "Uplink Failed: Server Unreachable", dangerRed);
    }
    setState(() => isLoading = false);
  }

  void _filterAndPaginate() {
    setState(() {
      currentPage = 1;
      filteredList = fullUserList.where((u) => u['role'] == selectedRole).toList();
    });
  }

  void _deleteUser() async {
    final target = deleteController.text.trim();
    if (target.isEmpty) {
      _showNotification("NULL TARGET", "Username required for termination", dangerRed);
      return;
    }

    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('http://public-server.verlang.id:4981/deleteUser?key=$sessionKey&username=$target'));
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        _showNotification("TERMINATED", "User $target wiped from database", successGreen);
        deleteController.clear();
        _fetchUsers();
      } else {
        _showNotification("FAILED", data['message'] ?? "Deletion Sequence Failed", dangerRed);
      }
    } catch (_) {}
    setState(() => isLoading = false);
  }

  void _createAccount() async {
    final user = createUsernameController.text.trim();
    final pass = createPasswordController.text.trim();
    final day = createDayController.text.trim();

    if (user.isEmpty || pass.isEmpty || day.isEmpty) {
      _showNotification("DATA INCOMPLETE", "All fields must be provisioned", dangerRed);
      return;
    }

    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('http://public-server.verlang.id:4981/userAdd?key=$sessionKey&username=$user&password=$pass&day=$day&role=$newUserRole'));
      final data = jsonDecode(res.body);
      if (data['valid'] == true) {
        _showNotification("PROVISIONED", "User $user has been initialized", successGreen);
        createUsernameController.clear();
        createPasswordController.clear();
        createDayController.clear();
        _fetchUsers();
      } else {
        _showNotification("FAILED", data['message'] ?? "Initialization Failed", dangerRed);
      }
    } catch (_) {}
    setState(() => isLoading = false);
  }

  void _showNotification(String title, String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        content: _buildGlassContainer(
          borderColor: color.withOpacity(0.3),
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Icon(Icons.terminal_rounded, color: color, size: 20),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 12, letterSpacing: 1)),
                    Text(message, style: const TextStyle(color: Colors.white70, fontSize: 11)),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // --- UI COMPONENTS ---

  Widget _buildGlassContainer({required Widget child, EdgeInsetsGeometry? padding, Color? borderColor}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: glassBg,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: borderColor ?? glassBorder),
          ),
          child: child,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      body: Stack(
        children: [
          Positioned(top: -100, right: -50, child: _buildGlowOrb(300, accentGreen.withOpacity(0.15))),
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  children: [
                    const SizedBox(height: 20),
                    _buildHeader(),
                    const SizedBox(height: 25),
                    _buildModernTabBar(),
                    const SizedBox(height: 20),
                    Expanded(
                      child: IndexedStack(
                        index: _selectedTab,
                        children: [
                          _buildDeleteTab(),
                          _buildCreateTab(),
                          _buildListTab(),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("ADMIN PANEL", style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 2)),
            Text("Mainframe Management System", style: TextStyle(color: Colors.white38, fontSize: 10, letterSpacing: 1)),
          ],
        ),
        _buildGlassContainer(
          padding: const EdgeInsets.all(4),
          child: IconButton(
            icon: Icon(Icons.sync_rounded, color: lightGreen),
            onPressed: _fetchUsers,
          ),
        )
      ],
    );
  }

  Widget _buildModernTabBar() {
    return _buildGlassContainer(
      padding: const EdgeInsets.all(6),
      child: Row(
        children: [
          _buildTabItem(0, "TERMINATE", Icons.no_accounts_rounded),
          _buildTabItem(1, "PROVISION", Icons.person_add_alt_1_rounded),
          _buildTabItem(2, "MAINFRAME", Icons.dns_rounded),
        ],
      ),
    );
  }

  Widget _buildTabItem(int index, String label, IconData icon) {
    bool isSelected = _selectedTab == index;
    return Expanded(
      child: GestureDetector(
        onTap: () => setState(() => _selectedTab = index),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 300),
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: isSelected ? lightGreen : Colors.transparent,
            borderRadius: BorderRadius.circular(18),
          ),
          child: Column(
            children: [
              Icon(icon, color: isSelected ? Colors.black : Colors.white30, size: 20),
              const SizedBox(height: 4),
              Text(label, style: TextStyle(color: isSelected ? Colors.black : Colors.white30, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDeleteTab() {
    return SingleChildScrollView(
      child: _buildGlassContainer(
        padding: const EdgeInsets.all(24),
        borderColor: dangerRed.withOpacity(0.2),
        child: Column(
          children: [
            Icon(Icons.report_gmailerrorred_rounded, color: dangerRed, size: 48),
            const SizedBox(height: 16),
            const Text("TERMINATE ACCOUNT", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18, letterSpacing: 1)),
            const Text("Warning: Action is irreversible", style: TextStyle(color: Colors.white38, fontSize: 11)),
            const SizedBox(height: 30),
            _buildCyberField(deleteController, "Target Username", Icons.person_off_rounded),
            const SizedBox(height: 25),
            _buildActionBtn("AUTHORIZE DELETION", dangerRed, _deleteUser),
          ],
        ),
      ),
    );
  }

  Widget _buildCreateTab() {
    return SingleChildScrollView(
      child: _buildGlassContainer(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            const Text("USER PROVISIONING", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 18, letterSpacing: 1)),
            const SizedBox(height: 25),
            _buildCyberField(createUsernameController, "New Identity", Icons.assignment_ind_rounded),
            const SizedBox(height: 15),
            _buildCyberField(createPasswordController, "Access Key", Icons.vpn_key_rounded, obscure: true),
            const SizedBox(height: 15),
            _buildCyberField(createDayController, "Uptime (Days)", Icons.shutter_speed_rounded, type: TextInputType.number),
            const SizedBox(height: 20),
            _buildRoleSelector(),
            const SizedBox(height: 30),
            _buildActionBtn("INITIATE SEQUENCE", lightGreen, _createAccount),
          ],
        ),
      ),
    );
  }

  Widget _buildListTab() {
    final pageData = _getCurrentPageData();
    return Column(
      children: [
        _buildListFilter(),
        const SizedBox(height: 15),
        Expanded(
          child: isLoading
              ? Center(child: CircularProgressIndicator(color: lightGreen))
              : pageData.isEmpty
              ? _buildEmptyState()
              : Column(
            children: [
              Expanded(
                child: ListView.builder(
                  physics: const BouncingScrollPhysics(),
                  itemCount: pageData.length,
                  itemBuilder: (context, index) => _buildUserCard(pageData[index]),
                ),
              ),
              _buildPaginationControls(),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildPaginationControls() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          IconButton(
            icon: Icon(Icons.keyboard_double_arrow_left_rounded, color: currentPage > 1 ? lightGreen : Colors.white10),
            onPressed: currentPage > 1 ? () => setState(() => currentPage--) : null,
          ),
          _buildGlassContainer(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Text("$currentPage", style: TextStyle(color: lightGreen, fontWeight: FontWeight.bold, fontSize: 12, fontFamily: 'monospace')),
          ),
          IconButton(
            icon: Icon(Icons.keyboard_double_arrow_right_rounded, color: filteredList.length > currentPage * itemsPerPage ? lightGreen : Colors.white10),
            onPressed: filteredList.length > currentPage * itemsPerPage ? () => setState(() => currentPage++) : null,
          ),
        ],
      ),
    );
  }

  // --- HELPERS ---

  Widget _buildCyberField(TextEditingController ctrl, String hint, IconData icon, {bool obscure = false, TextInputType? type}) {
    return TextField(
      controller: ctrl,
      obscureText: obscure,
      keyboardType: type,
      style: const TextStyle(color: Colors.white, fontSize: 14, fontFamily: 'monospace'),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(color: Colors.white.withOpacity(0.15), fontSize: 13),
        prefixIcon: Icon(icon, color: lightGreen.withOpacity(0.5), size: 18),
        filled: true,
        fillColor: Colors.black.withOpacity(0.3),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: glassBorder)),
      ),
    );
  }

  Widget _buildActionBtn(String label, Color color, VoidCallback onTap) {
    bool isDanger = color == dangerRed;
    return GestureDetector(
      onTap: isLoading ? null : onTap,
      child: Container(
        height: 55, width: double.infinity,
        decoration: BoxDecoration(
          color: isDanger ? color.withOpacity(0.1) : color,
          borderRadius: BorderRadius.circular(15),
          border: isDanger ? Border.all(color: color.withOpacity(0.5)) : null,
          boxShadow: !isDanger ? [BoxShadow(color: color.withOpacity(0.2), blurRadius: 15, offset: const Offset(0, 5))] : [],
        ),
        child: Center(
          child: isLoading
              ? SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: isDanger ? color : Colors.black, strokeWidth: 2))
              : Text(label, style: TextStyle(color: isDanger ? color : Colors.black, fontWeight: FontWeight.bold, letterSpacing: 1.5, fontSize: 13)),
        ),
      ),
    );
  }

  Widget _buildUserCard(Map user) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: _buildGlassContainer(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(color: lightGreen.withOpacity(0.05), shape: BoxShape.circle),
              child: Icon(Icons.person_rounded, color: lightGreen.withOpacity(0.7), size: 20),
            ),
            const SizedBox(width: 15),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(user['username'], style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
                  const SizedBox(height: 2),
                  Text("EXPIRES: ${user['expiredDate']}", style: TextStyle(color: lightGreen.withOpacity(0.4), fontSize: 10, fontFamily: 'monospace')),
                ],
              ),
            ),
            _buildRoleBadge(user['role']),
          ],
        ),
      ),
    );
  }

  Widget _buildRoleBadge(String role) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: lightGreen.withOpacity(0.05),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: lightGreen.withOpacity(0.2)),
      ),
      child: Text(role.toUpperCase(), style: TextStyle(color: lightGreen, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
    );
  }

  Widget _buildListFilter() {
    return _buildGlassContainer(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: selectedRole,
          dropdownColor: const Color(0xFF0A0A0A),
          isExpanded: true,
          icon: Icon(Icons.filter_list_rounded, color: lightGreen, size: 18),
          style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.bold),
          items: roleOptions.map((e) => DropdownMenuItem(value: e, child: Text("FILTER: ${e.toUpperCase()}"))).toList(),
          onChanged: (val) { if (val != null) { setState(() { selectedRole = val; _filterAndPaginate(); }); } },
        ),
      ),
    );
  }

  Widget _buildRoleSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text("ASSIGNMENT ROLE", style: TextStyle(color: Colors.white38, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1)),
        const SizedBox(height: 10),
        _buildGlassContainer(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: DropdownButtonHideUnderline(
            child: DropdownButton<String>(
              value: newUserRole,
              dropdownColor: const Color(0xFF0A0A0A),
              isExpanded: true,
              icon: Icon(Icons.layers_rounded, color: lightGreen, size: 18),
              style: const TextStyle(color: Colors.white, fontSize: 14),
              items: roleOptions.map((e) => DropdownMenuItem(value: e, child: Text(e.toUpperCase()))).toList(),
              onChanged: (val) => setState(() => newUserRole = val ?? 'member'),
            ),
          ),
        ),
      ],
    );
  }

  List<dynamic> _getCurrentPageData() {
    if (filteredList.isEmpty) return [];
    final start = (currentPage - 1) * itemsPerPage;
    int end = start + itemsPerPage;
    if (end > filteredList.length) end = filteredList.length;
    if (start >= filteredList.length) return [];
    return filteredList.sublist(start, end);
  }

  Widget _buildEmptyState() => const Center(child: Padding(
    padding: EdgeInsets.all(40.0),
    child: Text("NO RECORDS IN MAINFRAME", style: TextStyle(color: Colors.white12, letterSpacing: 2, fontSize: 12, fontWeight: FontWeight.bold)),
  ));

  Widget _buildGlowOrb(double size, Color color) => Container(
    width: size, height: size,
    decoration: BoxDecoration(shape: BoxShape.circle, color: color, boxShadow: [BoxShadow(color: color, blurRadius: 100, spreadRadius: 40)]),
  );

  @override
  void dispose() {
    _animationController.dispose();
    deleteController.dispose();
    createUsernameController.dispose();
    createPasswordController.dispose();
    createDayController.dispose();
    super.dispose();
  }
}