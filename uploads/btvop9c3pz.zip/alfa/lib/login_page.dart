import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';

// Pastikan lokasi file SplashScreen Anda benar
import 'splash.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> with TickerProviderStateMixin {
  final userController = TextEditingController();
  final passController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  bool isLoading = false;
  bool _obscurePassword = true;
  String? androidId;

  // Animations
  late AnimationController _animController;
  late Animation<double> _blurAnim;
  late Animation<double> _opacityAnim;

  @override
  void initState() {
    super.initState();
    _animController = AnimationController(vsync: this, duration: const Duration(seconds: 2));
    _blurAnim = Tween<double>(begin: 0, end: 15).animate(CurvedAnimation(parent: _animController, curve: Curves.easeOut));
    _opacityAnim = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(parent: _animController, curve: const Interval(0.5, 1.0)));

    _animController.forward();
    _getDeviceInfo();
    _checkAutoLogin();
  }

  // --- LOGIC AREA ---
  Future<void> _getDeviceInfo() async {
    final android = await DeviceInfoPlugin().androidInfo;
    if (mounted) setState(() => androidId = android.id);
  }

  Future<void> _checkAutoLogin() async {
    final prefs = await SharedPreferences.getInstance();
    final u = prefs.getString("username");
    final p = prefs.getString("password");
    final k = prefs.getString("key");

    if (u != null && p != null && k != null) {
      if (androidId == null) await _getDeviceInfo();
      _attemptLogin(u, p, isAuto: true);
    }
  }

  Future<void> _attemptLogin(String user, String pass, {bool isAuto = false}) async {
    if (!isAuto && !(_formKey.currentState?.validate() ?? false)) return;

    setState(() => isLoading = true);
    try {
      final response = await http.post(
        Uri.parse("http://public-server.verlang.id:4981/validate"),
        body: {"username": user, "password": pass, "androidId": androidId ?? "unknown"},
      ).timeout(const Duration(seconds: 10));

      final data = jsonDecode(response.body);
      if (data['valid'] == true) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setString("username", user);
        await prefs.setString("password", pass);
        await prefs.setString("key", data['key']);

        if (mounted) _pushToSplash(user, pass, data);
      } else {
        if (!isAuto) _showError(data['expired'] == true ? "LICENSE EXPIRED" : "INVALID ACCESS");
      }
    } catch (e) {
      if (!isAuto) _showError("SERVER UNREACHABLE");
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  void _pushToSplash(String user, String pass, dynamic data) {
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (_) => SplashScreen(
      username: user, password: pass, role: data['role'], sessionKey: data['key'],
      expiredDate: data['expiredDate'], listBug: List.from(data['listBug'] ?? []),
      listDoos: List.from(data['listDDoS'] ?? []), news: List.from(data['news'] ?? []),
    )));
  }

  void _showError(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
      backgroundColor: Colors.redAccent.withOpacity(0.8),
      behavior: SnackBarBehavior.floating,
    ));
  }

  // --- UI AREA ---
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF050505),
      body: Stack(
        children: [
          // Background Elements
          _buildAnimatedBg(),

          Center(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 30),
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    return ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 450),
                      child: FadeTransition(
                        opacity: _opacityAnim,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            _buildBranding(),
                            const SizedBox(height: 50),
                            _buildLoginForm(),
                            const SizedBox(height: 30),
                            _buildFooter(),
                          ],
                        ),
                      ),
                    );
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAnimatedBg() {
    return Stack(
      children: [
        Positioned(
          top: -100, right: -50,
          // UBAH: Glow Orb Hijau Tua
          child: _buildGlowOrb(300, const Color(0xFF1B5E20).withOpacity(0.2)),
        ),
        Positioned(
          bottom: -50, left: -50,
          // UBAH: Glow Orb Hijau Gelap
          child: _buildGlowOrb(250, const Color(0xFF0D2310).withOpacity(0.25)),
        ),
        Positioned.fill(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 30, sigmaY: 30),
            child: Container(color: Colors.transparent),
          ),
        ),
      ],
    );
  }

  Widget _buildGlowOrb(double size, Color color) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color),
    );
  }

  Widget _buildBranding() {
    return Column(
      children: [
        Container(
          height: 80, width: 80,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            // UBAH: Border Hijau Accent
            border: Border.all(color: Colors.greenAccent.withOpacity(0.5), width: 2),
            boxShadow: [BoxShadow(color: Colors.greenAccent.withOpacity(0.2), blurRadius: 20)],
          ),
          child: ClipOval(child: Image.asset("assets/images/logo.jpg", fit: BoxFit.cover)),
        ),
        const SizedBox(height: 20),
        const Text("TEXAS TR4SH", style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w900, letterSpacing: 2)),
        // UBAH: Label Hijau
        Text("SYSTEM PROTOCOL V2", style: TextStyle(color: Colors.greenAccent.withOpacity(0.7), fontSize: 10, letterSpacing: 5)),
      ],
    );
  }

  Widget _buildLoginForm() {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          _buildCustomField(controller: userController, label: "USERNAME", icon: Icons.person_outline),
          const SizedBox(height: 20),
          _buildCustomField(controller: passController, label: "PASSWORD", icon: Icons.lock_outline, isPass: true),
          const SizedBox(height: 40),
          _buildFancyButton(),
        ],
      ),
    );
  }

  Widget _buildCustomField({required TextEditingController controller, required String label, required IconData icon, bool isPass = false}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(16),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: Colors.white.withOpacity(0.1)),
          ),
          child: TextFormField(
            controller: controller,
            obscureText: isPass ? _obscurePassword : false,
            style: const TextStyle(color: Colors.white),
            decoration: InputDecoration(
              labelText: label,
              labelStyle: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 12),
              // UBAH: Icon Hijau Accent
              prefixIcon: Icon(icon, color: Colors.greenAccent, size: 20),
              suffixIcon: isPass ? IconButton(
                icon: Icon(_obscurePassword ? Icons.visibility_off : Icons.visibility, color: Colors.white24, size: 18),
                onPressed: () => setState(() => _obscurePassword = !_obscurePassword),
              ) : null,
              border: InputBorder.none,
              contentPadding: const EdgeInsets.all(20),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFancyButton() {
    return GestureDetector(
      onTap: isLoading ? null : () => _attemptLogin(userController.text, passController.text),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        width: double.infinity,
        height: 60,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          // UBAH: Gradasi Hijau Tua
          gradient: const LinearGradient(colors: [Color(0xFF1B5E20), Color(0xFF2E7D32)]),
          boxShadow: [
            // UBAH: Glow Hijau
            BoxShadow(color: Colors.greenAccent.withOpacity(isLoading ? 0 : 0.2), blurRadius: 20, offset: const Offset(0, 10))
          ],
        ),
        child: Center(
          child: isLoading
              ? const CircularProgressIndicator(color: Colors.white, strokeWidth: 2)
              : const Text("AUTHORIZE ACCESS", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 2)),
        ),
      ),
    );
  }

  Widget _buildFooter() {
    return Column(
      children: [
        Text("ID: ${androidId ?? 'Scanning...'}", style: TextStyle(color: Colors.white24, fontSize: 10)),
        const SizedBox(height: 10),
        TextButton(
          onPressed: () => launchUrl(Uri.parse("https://store.nullxteam.fun")),
          child: Text("REQUEST ACCESS LICENSE", style: TextStyle(color: Colors.white.withOpacity(0.5), fontSize: 11, fontWeight: FontWeight.w600)),
        ),
      ],
    );
  }
}