import 'dart:typed_data';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';

class QrGeneratorPage extends StatefulWidget {
  const QrGeneratorPage({super.key});

  @override
  State<QrGeneratorPage> createState() => _QrGeneratorPageState();
}

class _QrGeneratorPageState extends State<QrGeneratorPage> with TickerProviderStateMixin {
  final TextEditingController _textController = TextEditingController();
  bool _isLoading = false;
  Uint8List? _qrImage;
  String? _errorMessage;

  // Theme Colors (Deep Green & Black)
  final Color bgBlack = const Color(0xFF050505);
  final Color accentGreen = const Color(0xFF1B5E20);
  final Color lightGreen = const Color(0xFF2ECC71);
  final Color glassBorder = Colors.white.withOpacity(0.08);
  final Color glassBg = Colors.white.withOpacity(0.04);

  late AnimationController _pulseController;
  late AnimationController _slideController;
  late Animation<double> _pulseAnimation;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat(reverse: true);
    _slideController = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));

    _pulseAnimation = Tween<double>(begin: 1.0, end: 1.03).animate(CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut));
    _slideAnimation = Tween<Offset>(begin: const Offset(0, 0.05), end: Offset.zero).animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOutCubic));

    _slideController.forward();
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _slideController.dispose();
    _textController.dispose();
    super.dispose();
  }

  Future<void> _generateQR() async {
    final text = _textController.text.trim();
    if (text.isEmpty) {
      _showSnackBar("REJECTED: Data payload empty", Colors.redAccent);
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _qrImage = null;
    });

    try {
      final response = await http.get(Uri.parse("https://api.siputzx.my.id/api/tools/text2qr?text=${Uri.encodeComponent(text)}"));
      if (response.statusCode == 200) {
        setState(() => _qrImage = response.bodyBytes);
        HapticFeedback.heavyImpact();
      } else {
        setState(() => _errorMessage = "UPLINK_FAILURE: Server denied request");
      }
    } catch (e) {
      setState(() => _errorMessage = "CONNECTION_INTERRUPTED");
    } finally {
      setState(() => _isLoading = false);
    }
  }

  Future<void> _shareQR() async {
    if (_qrImage == null) return;
    try {
      final tempDir = await getTemporaryDirectory();
      final file = File('${tempDir.path}/qr_exp_${DateTime.now().millisecondsSinceEpoch}.png');
      await file.writeAsBytes(_qrImage!);
      await Share.shareXFiles([XFile(file.path)], text: 'ENCRYPTED_QR_MATRIX_SYSTEM');
    } catch (e) {
      _showSnackBar("EXPORT_FAILED: IO Error", Colors.redAccent);
    }
  }

  void _showSnackBar(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, fontFamily: 'monospace')),
        backgroundColor: color.withOpacity(0.9),
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(20),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  Widget _buildGlassContainer({required Widget child, EdgeInsetsGeometry? padding, Color? borderColor}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: glassBg,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: borderColor ?? glassBorder),
          ),
          child: child,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      body: Stack(
        children: [
          // Background Glows
          Positioned(top: -50, right: -50, child: _buildGlowOrb(250, accentGreen.withOpacity(0.15))),
          Positioned(bottom: -50, left: -50, child: _buildGlowOrb(200, lightGreen.withOpacity(0.05))),

          SafeArea(
            child: SlideTransition(
              position: _slideAnimation,
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  children: [
                    const SizedBox(height: 20),
                    _buildHeader(),
                    const SizedBox(height: 30),

                    // Generator Card
                    _buildGlassContainer(
                      padding: const EdgeInsets.all(22),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text("HEX_ENCODE_DATA", style: TextStyle(color: Colors.white24, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 3)),
                          const SizedBox(height: 15),
                          TextField(
                            controller: _textController,
                            style: const TextStyle(color: Colors.white, fontSize: 13, fontFamily: 'monospace'),
                            decoration: InputDecoration(
                              hintText: "INSERT STRING OR URL...",
                              hintStyle: const TextStyle(color: Colors.white10, fontSize: 11),
                              filled: true,
                              fillColor: Colors.black.withOpacity(0.3),
                              prefixIcon: Icon(Icons.qr_code_scanner_rounded, color: lightGreen, size: 20),
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
                              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: glassBorder)),
                              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: lightGreen.withOpacity(0.3))),
                            ),
                          ),
                          const SizedBox(height: 20),
                          _buildPrimaryButton(),
                        ],
                      ),
                    ),

                    const SizedBox(height: 30),

                    // Result Area
                    if (_isLoading) _buildLoadingState(),
                    if (_errorMessage != null) _buildErrorState(),
                    if (_qrImage != null && !_isLoading) _buildQRResult(),
                    if (_qrImage == null && !_isLoading && _errorMessage == null) _buildEmptyState(),

                    const SizedBox(height: 30),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: _buildGlassContainer(
            padding: const EdgeInsets.all(10),
            child: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 18),
          ),
        ),
        const SizedBox(width: 15),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("QR ENGINE", style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 1)),
            Text("Text to Matrix Synthesis", style: TextStyle(color: lightGreen, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
          ],
        ),
      ],
    );
  }

  Widget _buildPrimaryButton() {
    return GestureDetector(
      onTap: _isLoading ? null : _generateQR,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        height: 60,
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [accentGreen, lightGreen]),
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            if (!_isLoading) BoxShadow(color: lightGreen.withOpacity(0.2), blurRadius: 15, offset: const Offset(0, 8))
          ],
        ),
        child: Center(
          child: _isLoading
              ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2))
              : const Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.terminal_rounded, color: Colors.black, size: 20),
              SizedBox(width: 12),
              Text("GENERATE_MATRIX", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, letterSpacing: 1.5, fontSize: 13)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildQRResult() {
    return _buildGlassContainer(
      padding: const EdgeInsets.all(25),
      child: Column(
        children: [
          ScaleTransition(
            scale: _pulseAnimation,
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(24),
                boxShadow: [
                  BoxShadow(color: lightGreen.withOpacity(0.3), blurRadius: 30, spreadRadius: -5),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(15),
                child: Image.memory(_qrImage!, width: 220, height: 220, filterQuality: FilterQuality.high),
              ),
            ),
          ),
          const SizedBox(height: 30),
          GestureDetector(
            onTap: _shareQR,
            child: _buildGlassContainer(
              borderColor: lightGreen.withOpacity(0.3),
              padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 20),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.ios_share_rounded, color: lightGreen, size: 20),
                  const SizedBox(width: 12),
                  const Text("DISTRIBUTE_PAYLOAD", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1, fontSize: 13)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Opacity(
      opacity: 0.15,
      child: Column(
        children: [
          Icon(Icons.qr_code_2_rounded, size: 100, color: lightGreen),
          const SizedBox(height: 15),
          const Text("AWAITING_INPUT_STREAM", style: TextStyle(color: Colors.white, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 2)),
        ],
      ),
    );
  }

  Widget _buildLoadingState() {
    return Column(
      children: [
        SizedBox(
          width: 40,
          height: 40,
          child: CircularProgressIndicator(color: lightGreen, strokeWidth: 3),
        ),
        const SizedBox(height: 20),
        const Text("SYNTHESIZING_MATRIX...", style: TextStyle(color: Colors.white24, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1)),
      ],
    );
  }

  Widget _buildErrorState() {
    return _buildGlassContainer(
      borderColor: Colors.redAccent.withOpacity(0.3),
      padding: const EdgeInsets.all(20),
      child: Row(
        children: [
          const Icon(Icons.gpp_bad_rounded, color: Colors.redAccent, size: 20),
          const SizedBox(width: 15),
          Expanded(
            child: Text(_errorMessage ?? "SYSTEM_ERROR",
                style: const TextStyle(color: Colors.redAccent, fontSize: 12, fontWeight: FontWeight.bold, fontFamily: 'monospace')),
          ),
        ],
      ),
    );
  }

  Widget _buildGlowOrb(double size, Color color) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color, boxShadow: [BoxShadow(color: color, blurRadius: 100, spreadRadius: 40)]),
    );
  }
}