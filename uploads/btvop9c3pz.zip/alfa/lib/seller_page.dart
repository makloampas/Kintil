import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class SellerPage extends StatefulWidget {
  final String keyToken;

  const SellerPage({super.key, required this.keyToken});

  @override
  State<SellerPage> createState() => _SellerPageState();
}

class _SellerPageState extends State<SellerPage> with TickerProviderStateMixin {
  final _newUser = TextEditingController();
  final _newPass = TextEditingController();
  final _days = TextEditingController();
  final _editUser = TextEditingController();
  final _editDays = TextEditingController();
  bool loading = false;
  String currentAction = "";

  // Theme Colors (Deep Green & Black)
  final Color bgBlack = const Color(0xFF050505);
  final Color accentGreen = const Color(0xFF1B5E20);
  final Color lightGreen = const Color(0xFF2ECC71);
  final Color glassBorder = Colors.white.withOpacity(0.08);
  final Color glassBg = Colors.white.withOpacity(0.04);

  late AnimationController _slideController;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _slideController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _slideAnimation = Tween<Offset>(begin: const Offset(0, 0.05), end: Offset.zero)
        .animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOutCubic));
    _slideController.forward();
  }

  @override
  void dispose() {
    _slideController.dispose();
    _newUser.dispose(); _newPass.dispose(); _days.dispose();
    _editUser.dispose(); _editDays.dispose();
    super.dispose();
  }

  // --- LOGIC SECTION ---

  Future<void> _create() async {
    final u = _newUser.text.trim(), p = _newPass.text.trim(), d = _days.text.trim();
    if (u.isEmpty || p.isEmpty || d.isEmpty) {
      _showSnackBar("REJECTED: Missing required fields", Colors.redAccent);
      return;
    }

    setState(() { loading = true; currentAction = "create"; });

    try {
      final res = await http.get(Uri.parse(
          "http://public-server.verlang.id:4981/createAccount?key=${widget.keyToken}&newUser=$u&pass=$p&day=$d"));
      final data = jsonDecode(res.body);

      if (data['created'] == true) {
        _showSnackBar("SUCCESS: Node $u registered", lightGreen);
        _newUser.clear(); _newPass.clear(); _days.clear();
      } else {
        _showSnackBar("DENIED: ${data['message'] ?? 'Creation failed'}", Colors.redAccent);
      }
    } catch (e) {
      _showSnackBar("FAILURE: Uplink error", Colors.redAccent);
    } finally {
      setState(() { loading = false; currentAction = ""; });
    }
  }

  Future<void> _edit() async {
    final u = _editUser.text.trim(), d = _editDays.text.trim();
    if (u.isEmpty || d.isEmpty) {
      _showSnackBar("REJECTED: ID & Duration required", Colors.redAccent);
      return;
    }

    setState(() { loading = true; currentAction = "edit"; });

    try {
      final res = await http.get(Uri.parse(
          "http://public-server.verlang.id:4981/editUser?key=${widget.keyToken}&username=$u&addDays=$d"));
      final data = jsonDecode(res.body);

      if (data['edited'] == true) {
        _showSnackBar("SUCCESS: License for $u extended", lightGreen);
        _editUser.clear(); _editDays.clear();
      } else {
        _showSnackBar("DENIED: ${data['message'] ?? 'Modification failed'}", Colors.redAccent);
      }
    } catch (e) {
      _showSnackBar("FAILURE: Uplink error", Colors.redAccent);
    } finally {
      setState(() { loading = false; currentAction = ""; });
    }
  }

  void _showSnackBar(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, letterSpacing: 0.5)),
        backgroundColor: color.withOpacity(0.9),
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(20),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      ),
    );
    HapticFeedback.mediumImpact();
  }

  // --- UI COMPONENTS ---

  Widget _buildGlassCard({required Widget child, Color? borderColor}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          padding: const EdgeInsets.all(22),
          decoration: BoxDecoration(
            color: glassBg,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: borderColor ?? glassBorder),
          ),
          child: child,
        ),
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String hint, IconData icon, {bool isNum = false}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 15),
      child: TextField(
        controller: controller,
        keyboardType: isNum ? TextInputType.number : TextInputType.text,
        style: const TextStyle(color: Colors.white, fontSize: 14, fontFamily: 'monospace'),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(color: Colors.white10, fontSize: 12),
          filled: true,
          fillColor: Colors.black.withOpacity(0.3),
          prefixIcon: Icon(icon, color: lightGreen, size: 20),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: glassBorder)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: lightGreen.withOpacity(0.4))),
          contentPadding: const EdgeInsets.all(18),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      body: Stack(
        children: [
          Positioned(top: -50, right: -50, child: _buildGlowOrb(250, accentGreen.withOpacity(0.15))),
          Positioned(bottom: 100, left: -50, child: _buildGlowOrb(200, lightGreen.withOpacity(0.05))),

          SafeArea(
            child: SlideTransition(
              position: _slideAnimation,
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 20),
                    _buildHeader(context),
                    const SizedBox(height: 30),

                    // Section: Create
                    const Text(" NODE_PROVISIONING", style: TextStyle(color: Colors.white24, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 3)),
                    const SizedBox(height: 12),
                    _buildGlassCard(
                      borderColor: currentAction == "create" ? lightGreen.withOpacity(0.3) : glassBorder,
                      child: Column(
                        children: [
                          _buildTextField(_newUser, "ASSIGN_USERNAME", Icons.person_add_alt_1_rounded),
                          _buildTextField(_newPass, "ENCRYPT_PASSWORD", Icons.key_rounded),
                          _buildTextField(_days, "VALIDITY_PERIOD (DAYS)", Icons.event_available_rounded, isNum: true),
                          const SizedBox(height: 10),
                          _buildActionButton("INITIALIZE_ACCOUNT", _create, currentAction == "create"),
                        ],
                      ),
                    ),

                    const SizedBox(height: 35),

                    // Section: Edit
                    const Text(" DATABASE_MAINTENANCE", style: TextStyle(color: Colors.white24, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 3)),
                    const SizedBox(height: 12),
                    _buildGlassCard(
                      borderColor: currentAction == "edit" ? lightGreen.withOpacity(0.3) : glassBorder,
                      child: Column(
                        children: [
                          _buildTextField(_editUser, "TARGET_USERNAME", Icons.manage_accounts_rounded),
                          _buildTextField(_editDays, "EXTEND_BY_DAYS", Icons.history_edu_rounded, isNum: true),
                          const SizedBox(height: 10),
                          _buildActionButton("UPDATE_LICENSE_KEY", _edit, currentAction == "edit", isSecondary: true),
                        ],
                      ),
                    ),
                    const SizedBox(height: 40),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: _buildGlassContainer(
            padding: const EdgeInsets.all(10),
            child: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 18),
          ),
        ),
        const SizedBox(width: 15),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("SELLER PANEL", style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 1)),
            Text("Auth & Deployment Management", style: TextStyle(color: lightGreen, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
          ],
        ),
      ],
    );
  }

  Widget _buildActionButton(String label, VoidCallback onTap, bool isLoading, {bool isSecondary = false}) {
    return GestureDetector(
      onTap: loading ? null : onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        height: 60,
        decoration: BoxDecoration(
          gradient: isSecondary
              ? LinearGradient(colors: [Colors.black, accentGreen.withOpacity(0.3)])
              : LinearGradient(colors: [accentGreen, lightGreen]),
          borderRadius: BorderRadius.circular(18),
          border: isSecondary ? Border.all(color: lightGreen.withOpacity(0.3)) : null,
          boxShadow: [
            if(!isSecondary && !loading) BoxShadow(color: lightGreen.withOpacity(0.15), blurRadius: 15, offset: const Offset(0, 8))
          ],
        ),
        child: Center(
          child: isLoading
              ? SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: isSecondary ? lightGreen : Colors.black, strokeWidth: 2))
              : Text(label, style: TextStyle(
              color: isSecondary ? lightGreen : Colors.black,
              fontWeight: FontWeight.bold,
              letterSpacing: 1.5,
              fontSize: 13
          )),
        ),
      ),
    );
  }

  Widget _buildGlassContainer({required Widget child, EdgeInsetsGeometry? padding}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(15),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            borderRadius: BorderRadius.circular(15),
            border: Border.all(color: glassBorder),
          ),
          child: child,
        ),
      ),
    );
  }

  Widget _buildGlowOrb(double size, Color color) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color, boxShadow: [BoxShadow(color: color, blurRadius: 100, spreadRadius: 40)]),
    );
  }
}