module.exports = {
  tokens: "8283116262:AAHbeRvSf5Sy9NAjdW0d7B4957MqNraPtv0", 
  owner: "8204814098", 
  port: "4003", // Ini Wajib Jangan Diubah
  ipvps: "http://raffiprivatt-srv.rasyaaxinsa.web.id" // Jangan Diubah Nanti Eror!!
};