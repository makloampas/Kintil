import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
// Pastikan package ini ada di pubspec.yaml, jika belum ada bisa pakai Icons biasa
// import 'package:font_awesome_flutter/font_awesome_flutter.dart'; 
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';

class ToolsPage extends StatefulWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  @override
  State<ToolsPage> createState() => _ToolsPageState();
}

class _ToolsPageState extends State<ToolsPage> with TickerProviderStateMixin {
  late AnimationController _bgController;
  late AnimationController _cardController;
  late Animation<double> _bgAnimation;
  late Animation<double> _cardAnimation;

  // --- TEMA WARNA UNGU PINK HITAM MENYALA (NEON) ---
  final Color bgBlack = const Color(0xFF050505); // Hitam Pekat
  final Color cardBlack = const Color(0xFF121212); // Hitam Card
  final Color primaryPurple = const Color(0xFFD500F9); // Ungu Neon
  final Color primaryPink = const Color(0xFFFF4081); // Pink Neon
  final Color primaryBlue = const Color(0xFF2979FF); // Biru Neon (untuk gradasi)
  final Color textWhite = Colors.white;
  final Color textGrey = Colors.white70;

  @override
  void initState() {
    super.initState();
    _bgController = AnimationController(
      duration: const Duration(seconds: 10),
      vsync: this,
    )..repeat(reverse: true);

    _cardController = AnimationController(
      duration: const Duration(milliseconds: 1200),
      vsync: this,
    );

    _bgAnimation = Tween<double>(begin: 0, end: 1).animate(_bgController);
    _cardAnimation = Tween<double>(begin: 0, end: 1).animate(
      CurvedAnimation(
        parent: _cardController,
        curve: Curves.easeOutCubic,
      ),
    );

    _cardController.forward();
  }

  @override
  void dispose() {
    _bgController.dispose();
    _cardController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      body: Stack(
        children: [
          // Background dengan animasi partikel & gradient
          _buildAnimatedBackground(),

          // Konten utama
          SafeArea(
            child: Column(
              children: [
                // Header dengan desain baru
                _buildNewHeader(),

                // Kategori tools (Diubah menjadi ListView)
                Expanded(
                  child: _buildToolCategories(),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAnimatedBackground() {
    return AnimatedBuilder(
      animation: _bgAnimation,
      builder: (context, child) {
        return Stack(
          children: [
            // Background gradient gelap
            Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: Alignment.topLeft,
                  radius: 1.5,
                  colors: [
                    Color.lerp(bgBlack, const Color(0xFF1A0033), _bgAnimation.value)!,
                    bgBlack,
                  ],
                ),
              ),
            ),

            // Efek cahaya ungu bergerak
            Positioned(
              top: -100,
              right: -100,
              child: Container(
                width: 300,
                height: 300,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: RadialGradient(
                    colors: [
                      primaryPurple.withOpacity(0.2),
                      Colors.transparent,
                    ],
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildNewHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
      child: Row(
        children: [
          // Logo Box
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [primaryPurple, primaryBlue]),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: primaryPurple.withOpacity(0.4),
                  blurRadius: 10,
                  offset: const Offset(0, 4),
                ),
              ],
            ),
            child: const Icon(
              Icons.grid_view_rounded,
              color: Colors.white,
              size: 24,
            ),
          ),

          const SizedBox(width: 16),

          // Judul
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "Tools Gateway",
                  style: TextStyle(
                    color: textWhite,
                    fontSize: 22,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron', // Jika font tidak ada, akan fallback ke default
                    letterSpacing: 1,
                  ),
                ),
                Text(
                  "Select your weapon",
                  style: TextStyle(
                    color: textGrey,
                    fontSize: 12,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),

          // Status user badge
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: primaryPurple.withOpacity(0.1),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: primaryPurple.withOpacity(0.3)),
            ),
            child: Text(
              widget.userRole.toUpperCase(),
              style: TextStyle(
                color: primaryPurple,
                fontSize: 12,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Diubah dari GridView menjadi ListView
  Widget _buildToolCategories() {
    return AnimatedBuilder(
      animation: _cardAnimation,
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(0, (1 - _cardAnimation.value) * 50),
          child: Opacity(
            opacity: _cardAnimation.value,
            child: ListView(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
              children: [
                // List item dibangun manual atau dengan loop agar bisa custom section
                _buildNewToolCard(0), // DDoS
                const SizedBox(height: 15),
                _buildNewToolCard(1), // Network
                const SizedBox(height: 15),
                _buildNewToolCard(2), // OSINT
                const SizedBox(height: 15),
                _buildNewToolCard(3), // Downloader
                const SizedBox(height: 15),
                _buildNewToolCard(4), // Utilities
                const SizedBox(height: 15),
                _buildNewToolCard(5), // Quick Access
                const SizedBox(height: 80), // Padding bawah
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildNewToolCard(int index) {
    // Definisi data tools
    final List<Map<String, dynamic>> tools = [
      {
        "icon": Icons.flash_on_rounded,
        "title": "DDoS Panel",
        "subtitle": "L4/L7 Stress Test Attack",
        "gradient": [const Color(0xFFD500F9), const Color(0xFFFF4081)], // Purple to Pink
        "onTap": () => _showDDoSTools(context),
      },
      {
        "icon": Icons.wifi_tethering,
        "title": "Network Tools",
        "subtitle": "WiFi Killer & Spam NGL",
        "gradient": [const Color(0xFF2962FF), const Color(0xFF448AFF)], // Blue Gradient
        "onTap": () => _showNetworkTools(context),
      },
      {
        "icon": Icons.travel_explore,
        "title": "OSINT Tools",
        "subtitle": "NIK Checker, Domain, IP",
        "gradient": [const Color(0xFF00BFA5), const Color(0xFF1DE9B6)], // Teal Gradient
        "onTap": () => _showOSINTTools(context),
      },
      {
        "icon": Icons.download_rounded,
        "title": "Media Downloader",
        "subtitle": "TikTok & Instagram No Watermark",
        "gradient": [const Color(0xFF6200EA), const Color(0xFFB388FF)], // Deep Purple Gradient
        "onTap": () => _showDownloaderTools(context),
      },
      {
        "icon": Icons.auto_fix_high,
        "title": "Generator Tools",
        "subtitle": "QR Generator & Utilities",
        "gradient": [const Color(0xFFFF6D00), const Color(0xFFFFAB40)], // Orange Gradient
        "onTap": () => _showUtilityTools(context),
      },
      {
        "icon": Icons.rocket_launch_rounded,
        "title": "Quick Access",
        "subtitle": "Favorites Shortcuts",
        "gradient": [const Color(0xFFC6FF00), const Color(0xFF76FF03)], // Lime Gradient
        "onTap": () => _showQuickAccess(context),
      },
    ];

    final tool = tools[index];
    final List<Color> gradientColors = tool["gradient"];

    return GestureDetector(
      onTap: tool["onTap"],
      child: Container(
        height: 90, // Tinggi tetap untuk tampilan List Card
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          gradient: LinearGradient(
            colors: gradientColors,
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          boxShadow: [
            BoxShadow(
              color: gradientColors[0].withOpacity(0.4),
              blurRadius: 15,
              offset: const Offset(0, 8),
            ),
          ],
        ),
        child: Stack(
          children: [
            // Lingkaran dekorasi
            Positioned(
              right: -20,
              top: -20,
              child: Container(
                width: 100,
                height: 100,
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.1),
                  shape: BoxShape.circle,
                ),
              ),
            ),

            // Konten Card
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
              child: Row(
                children: [
                  // Icon Box
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      color: Colors.white.withOpacity(0.2),
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(color: Colors.white.withOpacity(0.1)),
                    ),
                    child: Icon(tool["icon"], color: Colors.white, size: 26),
                  ),
                  
                  const SizedBox(width: 16),
                  
                  // Teks
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          tool["title"],
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            fontFamily: 'Orbitron',
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          tool["subtitle"],
                          style: TextStyle(
                            color: Colors.white.withOpacity(0.8),
                            fontSize: 12,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),

                  // Panah
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.1),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.arrow_forward_ios_rounded,
                      color: Colors.white70,
                      size: 14,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  // --- LOGIC MODAL SHEETS (TIDAK ADA YANG DIHAPUS) ---

  void _showDDoSTools(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _buildNewModalSheet(
        context,
        "DDoS Tools",
        Icons.flash_on,
        [
          _buildModalOption(
            icon: Icons.flash_on,
            label: "Attack Panel",
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => AttackPanel(
                    sessionKey: widget.sessionKey,
                    listDoos: widget.listDoos,
                  ),
                ),
              );
            },
          ),
          _buildModalOption(
            icon: Icons.dns,
            label: "Manage Server",
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => ManageServerPage(keyToken: widget.sessionKey),
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  void _showNetworkTools(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _buildNewModalSheet(
        context,
        "Network Tools",
        Icons.wifi,
        [
          _buildModalOption(
            icon: Icons.newspaper_outlined,
            label: "Spam NGL",
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => NglPage()),
              );
            },
          ),
          _buildModalOption(
            icon: Icons.wifi_off,
            label: "WiFi Killer (Internal)",
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => WifiKillerPage()),
              );
            },
          ),
          if (widget.userRole == "vip" || widget.userRole == "owner")
            _buildModalOption(
              icon: Icons.router,
              label: "WiFi Killer (External)",
              onTap: () {
                Navigator.pop(context);
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => WifiInternalPage(sessionKey: widget.sessionKey),
                  ),
                );
              },
            ),
        ],
      ),
    );
  }

  void _showOSINTTools(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _buildNewModalSheet(
        context,
        "OSINT Tools",
        Icons.search,
        [
          _buildModalOption(
            icon: Icons.badge,
            label: "NIK Detail",
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const NikCheckerPage()),
              );
            },
          ),
          _buildModalOption(
            icon: Icons.domain,
            label: "Domain OSINT",
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const DomainOsintPage()),
              );
            },
          ),
          _buildModalOption(
            icon: Icons.person_search,
            label: "Phone Lookup",
            onTap: () => _showComingSoon(context),
          ),
          _buildModalOption(
            icon: Icons.email,
            label: "Email OSINT",
            onTap: () => _showComingSoon(context),
          ),
        ],
      ),
    );
  }

  void _showDownloaderTools(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _buildNewModalSheet(
        context,
        "Media Downloader",
        Icons.download,
        [
          _buildModalOption(
            icon: Icons.video_library,
            label: "TikTok Downloader",
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const TiktokDownloaderPage()),
              );
            },
          ),
          _buildModalOption(
            icon: Icons.camera_alt,
            label: "Instagram Downloader",
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const InstagramDownloaderPage()),
              );
            },
          ),
        ],
      ),
    );
  }

  void _showUtilityTools(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => _buildNewModalSheet(
        context,
        "Utility Tools",
        Icons.build,
        [
          _buildModalOption(
            icon: Icons.qr_code,
            label: "QR Generator",
            onTap: () {
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const QrGeneratorPage()),
              );
            },
          ),
          _buildModalOption(
            icon: Icons.security,
            label: "IP Scanner",
            onTap: () => _showComingSoon(context),
          ),
          _buildModalOption(
            icon: Icons.network_check,
            label: "Port Scanner",
            onTap: () => _showComingSoon(context),
          ),
        ],
      ),
    );
  }

  void _showQuickAccess(BuildContext context) {
    _showComingSoon(context);
  }

  Widget _buildNewModalSheet(
      BuildContext context,
      String title,
      IconData icon,
      List<Widget> options,
      ) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.6,
      decoration: BoxDecoration(
        color: cardBlack, // Update warna modal
        borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(30),
          topRight: Radius.circular(30),
        ),
        border: Border.all(color: primaryPurple.withOpacity(0.3)),
        boxShadow: [
          BoxShadow(
            color: primaryPurple.withOpacity(0.2),
            blurRadius: 20,
            spreadRadius: 5,
          ),
        ],
      ),
      child: Column(
        children: [
          // Header modal
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [primaryPurple, primaryPink],
                begin: Alignment.centerLeft,
                end: Alignment.centerRight,
              ),
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(30),
                topRight: Radius.circular(30),
              ),
            ),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(icon, color: textWhite),
                ),
                const SizedBox(width: 16),
                Text(
                  title,
                  style: TextStyle(
                    color: textWhite,
                    fontSize: 20,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ),

          // Opsi-opsi
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: ListView(
                children: options,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildModalOption({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05), // Sedikit transparan
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 5),
        leading: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [primaryPurple, primaryBlue],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, color: textWhite),
        ),
        title: Text(
          label,
          style: TextStyle(
            color: textWhite,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.w500,
          ),
        ),
        trailing: Container(
          width: 30,
          height: 30,
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.1),
            shape: BoxShape.circle,
          ),
          child: const Icon(Icons.arrow_forward_ios, color: Colors.white70, size: 14),
        ),
        onTap: onTap,
      ),
    );
  }

  void _showComingSoon(BuildContext context) {
    HapticFeedback.lightImpact();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Icon(Icons.hourglass_top, color: textWhite),
            const SizedBox(width: 8),
            Text(
              'Feature Coming Soon!',
              style: TextStyle(
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
                color: textWhite,
              ),
            ),
          ],
        ),
        backgroundColor: primaryPurple,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }
}