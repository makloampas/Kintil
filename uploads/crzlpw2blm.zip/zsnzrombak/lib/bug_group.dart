import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'dart:ui';

class GroupBugPage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final String role;
  final String expiredDate;

  const GroupBugPage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<GroupBugPage> createState() => _GroupBugPageState();
}

class _GroupBugPageState extends State<GroupBugPage>
    with TickerProviderStateMixin {
  final linkGroupController = TextEditingController();
  static const String baseUrl = "http://thefools.serverkuu.my.id:7170";

  // Animation controllers
  late AnimationController _buttonController;
  late AnimationController _fadeController;
  late Animation<double> _scaleAnimation;
  late Animation<double> _fadeAnimation;

  // Video controllers
  late VideoPlayerController _videoController;
  bool _videoInitialized = false;
  bool _videoError = false;

  // State variables
  bool _isSending = false;

  // Warna Tema Ungu Magenta
  final Color _primaryMagenta = const Color(0xFFFF00FF); // Magenta Murni
  final Color _secondaryPurple = const Color(0xFF9D00FF); // Ungu Gelap
  final Color _accentPurple = const Color(0xFFE056FD); // Ungu Terang
  final Color _bgOverlay = Colors.black87;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _initializeVideoController();
  }

  void _initializeAnimations() {
    _buttonController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 150),
    );

    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.95).animate(
      CurvedAnimation(parent: _buttonController, curve: Curves.easeInOut),
    );
  }

  void _initializeVideoController() {
    try {
      _videoController = VideoPlayerController.asset('assets/videos/banner.mp4')
        ..initialize()
            .then((_) {
              if (mounted) {
                setState(() {
                  _videoInitialized = true;
                });
                _videoController.setLooping(true);
                _videoController.play();
                _videoController.setVolume(0);
              }
            })
            .catchError((error) {
              print('Video initialization error: $error');
              if (mounted) {
                setState(() {
                  _videoError = true;
                });
              }
            });
    } catch (e) {
      print('Video controller creation error: $e');
      if (mounted) {
        setState(() {
          _videoError = true;
        });
      }
    }
  }

  bool _isValidGroupLink(String input) {
    // Validasi format link grup WhatsApp
    final regex = RegExp(r'https://chat\.whatsapp\.com/[a-zA-Z0-9]{22}');
    return regex.hasMatch(input);
  }

  Future<void> _sendGroupBug() async {
    if (_isSending) return;

    setState(() {
      _isSending = true;
    });

    _buttonController.forward().then((_) {
      _buttonController.reverse();
    });

    final linkGroup = linkGroupController.text.trim();
    final key = widget.sessionKey;

    if (linkGroup.isEmpty || !_isValidGroupLink(linkGroup)) {
      _showAlert("❌ Invalid Link", "Please enter a valid WhatsApp group link.");
      setState(() {
        _isSending = false;
      });
      return;
    }

    try {
      final res = await http.get(
        Uri.parse(
          "$baseUrl/api/whatsapp/groupBug?key=$key&linkGroup=$linkGroup",
        ),
      );
      final data = jsonDecode(res.body);

      if (data["valid"] == false) {
        _showAlert("❌ Failed", data["message"] ?? "Failed to send group bug.");
      } else {
        _showSuccessPopup(linkGroup, data);
      }
    } catch (_) {
      _showAlert("❌ Error", "Terjadi kesalahan. Coba lagi.");
    } finally {
      setState(() {
        _isSending = false;
      });
    }
  }

  void _showSuccessPopup(String linkGroup, Map<String, dynamic> data) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => GroupBugSuccessDialog(
        themeColor: _accentPurple,
        linkGroup: linkGroup,
        data: data,
        onDismiss: () => Navigator.of(context).pop(),
      ),
    );
  }

  void _showAlert(String title, String msg) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: Colors.black.withOpacity(0.9),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(18),
          side: BorderSide(color: _primaryMagenta.withOpacity(0.3), width: 1),
        ),
        title: Text(
          title,
          style: TextStyle(color: _primaryMagenta, fontFamily: 'Orbitron'),
        ),
        content: Text(
          msg,
          style: TextStyle(color: _accentPurple, fontFamily: 'ShareTechMono'),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text("OK", style: TextStyle(color: _primaryMagenta)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // Only allow access to VIP and Owner roles
    if (!["vip", "owner"].contains(widget.role.toLowerCase())) {
      return Scaffold(
        backgroundColor: Colors.black,
        body: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(FontAwesomeIcons.lock, color: Colors.red, size: 60),
              const SizedBox(height: 20),
              const Text(
                "ACCESS DENIED",
                style: TextStyle(
                  color: Colors.red,
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                ),
              ),
              const SizedBox(height: 10),
              Text(
                "This feature is only available for VIP and Owner users",
                style: TextStyle(
                  color: _accentPurple.withOpacity(0.7),
                  fontSize: 16,
                ),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          // Background
          Container(
            color: Colors.black,
            child: _videoInitialized && !_videoError
                ? SizedBox.expand(
                    child: FittedBox(
                      fit: BoxFit.cover,
                      child: SizedBox(
                        width: _videoController.value.size.width,
                        height: _videoController.value.size.height,
                        child: VideoPlayer(_videoController),
                      ),
                    ),
                  )
                : null,
          ),

          // Gradient overlay (Ungu Gelap ke Hitam)
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.black.withOpacity(0.8),
                  _secondaryPurple.withOpacity(0.2),
                  Colors.black,
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
          ),

          // Main content
          SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    // User info header
                    _buildUserInfoHeader(),

                    const SizedBox(height: 24),

                    // Main content cards
                    _buildGroupLinkCard(),

                    const SizedBox(height: 24),

                    _buildStatusIndicators(),

                    const SizedBox(height: 24),

                    _buildSendButton(),

                    const SizedBox(height: 16),

                    _buildFooterInfo(),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildUserInfoHeader() {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _primaryMagenta.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _primaryMagenta.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: widget.role.toLowerCase() == "vip"
                ? Colors.deepPurple.withOpacity(0.3)
                : Colors.orange.withOpacity(0.3),
            child: Icon(
              widget.role.toLowerCase() == "vip"
                  ? FontAwesomeIcons.crown
                  : FontAwesomeIcons.userShield,
              color: widget.role.toLowerCase() == "vip"
                  ? _accentPurple
                  : Colors.orange,
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  widget.username,
                  style: TextStyle(
                    color: _primaryMagenta,
                    fontWeight: FontWeight.bold,
                    fontFamily: 'Orbitron',
                    fontSize: 16,
                  ),
                ),
                Text(
                  widget.role.toUpperCase(),
                  style: TextStyle(
                    color: _accentPurple.withOpacity(0.8),
                    fontSize: 12,
                    fontFamily: 'ShareTechMono',
                  ),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: _secondaryPurple.withOpacity(0.3),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              "EXP: ${widget.expiredDate}",
              style: TextStyle(
                color: _primaryMagenta,
                fontSize: 12,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildGroupLinkCard() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: _secondaryPurple.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: _accentPurple.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: _primaryMagenta.withOpacity(0.2),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(
                  FontAwesomeIcons.users,
                  color: _primaryMagenta,
                  size: 16,
                ),
              ),
              const SizedBox(width: 10),
              Text(
                "Group Link",
                style: TextStyle(
                  color: _primaryMagenta,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: linkGroupController,
            style: TextStyle(color: _primaryMagenta),
            cursorColor: _primaryMagenta,
            decoration: InputDecoration(
              hintText: "https://chat.whatsapp.com/...",
              hintStyle: TextStyle(color: _accentPurple.withOpacity(0.5)),
              filled: true,
              fillColor: _secondaryPurple.withOpacity(0.1),
              enabledBorder: OutlineInputBorder(
                borderSide: BorderSide(color: _accentPurple.withOpacity(0.3)),
                borderRadius: BorderRadius.circular(12),
              ),
              focusedBorder: OutlineInputBorder(
                borderSide: BorderSide(color: _primaryMagenta),
                borderRadius: BorderRadius.circular(12),
              ),
              prefixIcon: Icon(
                FontAwesomeIcons.link,
                color: _primaryMagenta,
                size: 16,
              ),
              contentPadding: const EdgeInsets.symmetric(vertical: 12),
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: _primaryMagenta.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: _primaryMagenta.withOpacity(0.3)),
            ),
            child: Row(
              children: [
                Icon(
                  FontAwesomeIcons.infoCircle,
                  color: _accentPurple,
                  size: 16,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    "This tool will automatically join the group, send a bug, and leave without leaving any trace.",
                    style: TextStyle(
                      color: _accentPurple.withOpacity(0.9),
                      fontSize: 12,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusIndicators() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _statusIndicator(
          icon: FontAwesomeIcons.server,
          label: "Server",
          isOnline: true,
        ),
        _statusIndicator(
          icon: FontAwesomeIcons.shieldAlt,
          label: "Security",
          isOnline: true,
        ),
        _statusIndicator(
          icon: FontAwesomeIcons.database,
          label: "Database",
          isOnline: true,
        ),
      ],
    );
  }

  Widget _statusIndicator({
    required IconData icon,
    required String label,
    required bool isOnline,
  }) {
    return Column(
      children: [
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: isOnline
                ? _secondaryPurple.withOpacity(0.3)
                : _secondaryPurple.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: isOnline
                  ? _primaryMagenta.withOpacity(0.5)
                  : _primaryMagenta.withOpacity(0.2),
            ),
          ),
          child: Icon(
            icon,
            color: isOnline ? _primaryMagenta : _accentPurple.withOpacity(0.5),
            size: 20,
          ),
        ),
        const SizedBox(height: 5),
        Text(
          label,
          style: TextStyle(
            color: _accentPurple.withOpacity(0.7),
            fontSize: 12,
            fontFamily: 'ShareTechMono',
          ),
        ),
      ],
    );
  }

  Widget _buildSendButton() {
    return Container(
      width: double.infinity,
      height: 56,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: _primaryMagenta.withOpacity(0.5), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: _primaryMagenta.withOpacity(0.2),
            blurRadius: 10,
            spreadRadius: 1,
          ),
        ],
      ),
      child: ElevatedButton.icon(
        icon: _isSending
            ? SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  color: _primaryMagenta,
                  strokeWidth: 2,
                ),
              )
            : Icon(FontAwesomeIcons.bug, color: _primaryMagenta, size: 18),
        label: Text(
          _isSending ? "PROCESSING..." : "ATTACK GROUP",
          style: TextStyle(
            fontSize: 16,
            fontFamily: 'Orbitron',
            fontWeight: FontWeight.bold,
            letterSpacing: 1.4,
            color: _primaryMagenta,
          ),
        ),
        style: ElevatedButton.styleFrom(
          backgroundColor: _primaryMagenta.withOpacity(0.1),
          foregroundColor: _primaryMagenta,
          shadowColor: Colors.transparent,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        onPressed: _isSending ? null : _sendGroupBug,
      ),
    );
  }

  Widget _buildFooterInfo() {
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: _secondaryPurple.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            FontAwesomeIcons.infoCircle,
            color: _accentPurple.withOpacity(0.6),
            size: 14,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              "This tool will join the group, send a bug, and leave without any trace.",
              style: TextStyle(
                color: _accentPurple.withOpacity(0.6),
                fontSize: 11,
                fontFamily: 'ShareTechMono',
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _buttonController.dispose();
    _videoController.dispose();
    linkGroupController.dispose();
    super.dispose();
  }
}

// Custom success dialog for group bug
class GroupBugSuccessDialog extends StatefulWidget {
  final String linkGroup;
  final Map<String, dynamic> data;
  final VoidCallback onDismiss;
  final Color themeColor;

  const GroupBugSuccessDialog({
    super.key,
    required this.linkGroup,
    required this.data,
    required this.onDismiss,
    required this.themeColor,
  });

  @override
  State<GroupBugSuccessDialog> createState() => _GroupBugSuccessDialogState();
}

class _GroupBugSuccessDialogState extends State<GroupBugSuccessDialog>
    with TickerProviderStateMixin {
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;
  bool _showDetails = false;

  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );

    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(parent: _fadeController, curve: Curves.easeIn));

    // Show details after a short delay
    Future.delayed(const Duration(milliseconds: 300), () {
      if (mounted) {
        setState(() {
          _showDetails = true;
        });
        _fadeController.forward();
      }
    });
  }

  @override
  void dispose() {
    _fadeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Get screen dimensions for responsive sizing
    final screenSize = MediaQuery.of(context).size;
    final dialogWidth = screenSize.width * 0.9;
    final dialogHeight = screenSize.height * 0.6;

    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: EdgeInsets.zero,
      child: ConstrainedBox(
        constraints: BoxConstraints(
          maxWidth: dialogWidth,
          maxHeight: dialogHeight,
        ),
        child: Container(
          width: dialogWidth,
          height: dialogHeight,
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.95),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: widget.themeColor.withOpacity(0.5),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: widget.themeColor.withOpacity(0.2),
                blurRadius: 15,
                spreadRadius: 2,
              ),
            ],
          ),
          child: Stack(
            children: [
              // Success icon and title
              Positioned(
                top: 20,
                left: 0,
                right: 0,
                child: Column(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: widget.themeColor.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(100),
                        border: Border.all(
                          color: widget.themeColor.withOpacity(0.8),
                          width: 2,
                        ),
                      ),
                      child: Icon(
                        FontAwesomeIcons.checkDouble,
                        color: widget.themeColor,
                        size: 40,
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      "GROUP BUG SENT!",
                      style: TextStyle(
                        color: widget.themeColor,
                        fontSize: 18, // Adjusted slightly for visibility
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                        letterSpacing: 2,
                      ),
                    ),
                    const SizedBox(height: 8),
                  ],
                ),
              ),

              // Group details
              if (_showDetails)
                Positioned(
                  top: 120,
                  left: 20,
                  right: 20,
                  bottom: 80,
                  child: FadeTransition(
                    opacity: _fadeAnimation,
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: widget.themeColor.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(
                          color: widget.themeColor.withOpacity(0.3),
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            "Attack Details:",
                            style: TextStyle(
                              color: widget.themeColor,
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Orbitron',
                            ),
                          ),
                          const SizedBox(height: 12),
                          _buildDetailRow("Group Link", widget.linkGroup),
                          _buildDetailRow(
                            "Success",
                            widget.data["success"] ? "Yes" : "No",
                          ),
                          if (widget.data["canSendMessage"] != null)
                            _buildDetailRow(
                              "Can Send Message",
                              widget.data["canSendMessage"] ? "Yes" : "No",
                            ),
                          if (widget.data["groupInfo"] != null) ...[
                            _buildDetailRow(
                              "Group Name",
                              widget.data["groupInfo"]["subject"] ?? "Unknown",
                            ),
                            _buildDetailRow(
                              "Members",
                              widget.data["groupInfo"]["participants"]
                                      ?.toString() ??
                                  "Unknown",
                            ),
                            _buildDetailRow(
                              "Description",
                              widget.data["groupInfo"]["desc"] ??
                                  "No description",
                            ),
                          ],
                        ],
                      ),
                    ),
                  ),
                ),

              // Close button
              Positioned(
                bottom: 20,
                left: 20,
                right: 20,
                child: ElevatedButton(
                  onPressed: widget.onDismiss,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: widget.themeColor.withOpacity(0.2),
                    foregroundColor: widget.themeColor,
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(30),
                      side: BorderSide(
                        color: widget.themeColor.withOpacity(0.5),
                      ),
                    ),
                  ),
                  child: Text(
                    "DONE",
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      letterSpacing: 1,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              "$label:",
              style: TextStyle(
                color: widget.themeColor.withOpacity(0.7),
                fontSize: 12,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: TextStyle(
                color: widget.themeColor,
                fontSize: 12,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ),
        ],
      ),
    );
  }
}
