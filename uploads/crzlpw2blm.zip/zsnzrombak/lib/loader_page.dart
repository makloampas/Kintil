// ignore_for_file: use_build_context_synchronously
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:url_launcher/url_launcher.dart';
import 'package:video_player/video_player.dart';

// Import halaman-halaman lain
import 'admin_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'ddos_page.dart';
import 'chat_page.dart';
import 'login_page.dart';
import 'custom_bug.dart';
import 'bug_group.dart';
import 'ddos_panel.dart';
import 'sender_page.dart';

// --- TEMA "OS 26" CYBERPUNK (GLOBAL) ---
final Color _os26Primary = const Color(0xFFFF00FF); // Magenta Neon
final Color _os26Secondary = const Color(0xFF7000FF); // Violet Neon
final Color _os26Bg = const Color(0xFF050510); // Deepest Space Black
final Color _os26Surface = const Color(0xFF12122A); // Dark Panel
final Color _os26Glass = const Color(0x0FFFFFFF); // Transparent Glass

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listPayload;
  final List<Map<String, dynamic>> listDDoS;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listPayload,
    required this.listDDoS,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  late WebSocketChannel channel;

  // Data Variables
  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listPayload;
  late List<Map<String, dynamic>> listDDoS;
  late List<dynamic> newsList;

  String androidId = "unknown";
  int _selectedIndex = 0;
  Widget _selectedPage = const SizedBox();

  // UI Keys & Controllers
  final GlobalKey _bugButtonKey = GlobalKey();
  final PageController _pageController = PageController(viewportFraction: 0.90);
  int _currentNewsIndex = 0;

  @override
  void initState() {
    super.initState();

    // Initialize Data
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listPayload = widget.listPayload;
    listDDoS = widget.listDDoS;
    newsList = widget.news;

    // Setup Animation OS 26 Style
    _controller = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );
    _animation = CurvedAnimation(
      parent: _controller,
      curve: Curves.easeInOutQuart,
    );
    _controller.forward();

    _selectedPage = _buildNewsPage();
    _initAndroidIdAndConnect();
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(
      Uri.parse('wss://manipulator.panel.serverku.space:2012'),
    );
    channel.sink.add(
      jsonEncode({
        "type": "validate",
        "key": sessionKey,
        "androidId": androidId,
      }),
    );
    channel.sink.add(jsonEncode({"type": "stats"}));
    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo' && data['valid'] == false) {
        final msg = data['reason'] == 'androidIdMismatch'
            ? "Your account has logged on another device."
            : "Key is not valid. Please login again.";
        _handleInvalidSession(msg);
      }
    });
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.95),
      builder: (_) => AlertDialog(
        backgroundColor: _os26Surface,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: _os26Primary, width: 2),
        ),
        title: const Center(
          child: Text(
            "SESSION TERMINATED",
            style: TextStyle(
              color: Color(0xFF6C63FF),
              fontFamily: "Orbitron",
              letterSpacing: 2,
            ),
          ),
        ),
        content: Text(
          message,
          style: const TextStyle(color: Colors.white70, fontFamily: "Rajdhani"),
          textAlign: TextAlign.center,
        ),
        actions: [
          Center(
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: _os26Primary,
                shadowColor: _os26Primary,
                shape: const StadiumBorder(),
              ),
              onPressed: () => Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => const LoginPage()),
                (route) => false,
              ),
              child: const Text(
                "REBOOT SYSTEM",
                style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _onTabSelected(int index) {
    setState(() {
      _selectedIndex = index;
      _controller.reset();
      _controller.forward();

      switch (index) {
        case 0:
          _selectedPage = _buildNewsPage();
          break;
        case 1:
          if (["vip", "owner"].contains(role.toLowerCase())) {
            _showBugMenu();
          } else {
            _selectedPage = AttackPage(
              username: username,
              password: password,
              listBug: listBug,
              role: role,
              expiredDate: expiredDate,
              sessionKey: sessionKey,
            );
          }
          break;
        case 2:
          _selectedPage = AttackPanel(
            sessionKey: sessionKey,
            listDDoS: listDDoS,
          );
          break;
        case 3:
          _selectedPage = ToolsPage(sessionKey: sessionKey, userRole: role);
          break;
      }
    });
  }

  void _showBugMenu() {
    final RenderBox renderBox =
        _bugButtonKey.currentContext?.findRenderObject() as RenderBox;
    final Offset offset = renderBox.localToGlobal(Offset.zero);
    final Size size = renderBox.size;

    List<Map<String, dynamic>> options = [
      {'title': 'Custom Bug', 'icon': FontAwesomeIcons.code},
      {'title': 'Group Bug', 'icon': FontAwesomeIcons.users},
      {'title': 'Bug', 'icon': FontAwesomeIcons.bug},
    ];

    showMenu(
      context: context,
      position: RelativeRect.fromLTRB(
        offset.dx,
        offset.dy - size.height * 2,
        offset.dx + size.width,
        offset.dy,
      ),
      items: options
          .map(
            (option) => PopupMenuItem(
              value: option['title'],
              child: Row(
                children: [
                  Icon(option['icon'], color: _os26Primary, size: 20),
                  const SizedBox(width: 12),
                  Text(
                    option['title'],
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                      fontFamily: "Rajdhani",
                    ),
                  ),
                ],
              ),
            ),
          )
          .toList(),
      color: _os26Surface,
      elevation: 20,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(color: _os26Primary.withOpacity(0.3), width: 1),
      ),
    ).then((value) {
      if (value != null) {
        setState(() {
          if (value == 'Custom Bug')
            _selectedPage = CustomAttackPage(
              username: username,
              password: password,
              listPayload: listPayload,
              role: role,
              expiredDate: expiredDate,
              sessionKey: sessionKey,
            );
          else if (value == 'Group Bug')
            _selectedPage = GroupBugPage(
              username: username,
              password: password,
              role: role,
              expiredDate: expiredDate,
              sessionKey: sessionKey,
            );
          else if (value == 'Bug')
            _selectedPage = AttackPage(
              username: username,
              password: password,
              listBug: listBug,
              role: role,
              expiredDate: expiredDate,
              sessionKey: sessionKey,
            );
        });
      }
    });
  }

  void _selectFromDrawer(String page) {
    Navigator.pop(context);
    setState(() {
      if (page == 'reseller')
        _selectedPage = SellerPage(keyToken: sessionKey);
      else if (page == 'admin')
        _selectedPage = AdminPage(sessionKey: sessionKey);
      else if (page == 'sender')
        _selectedPage = SenderPage(sessionKey: sessionKey);
    });
  }

  Widget _buildNewsPage() {
    return RefreshIndicator(
      color: _os26Primary,
      backgroundColor: _os26Surface,
      onRefresh: () async {
        await Future.delayed(const Duration(seconds: 1));
        setState(() {});
      },
      child: SingleChildScrollView(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.only(bottom: 100),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 20),
            _buildWelcomeSection(),
            const SizedBox(height: 30),
            _buildNewsCarousel(),
            const SizedBox(height: 30),
            _buildQuickActionsGrid(),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  // --- UI BUILDERS (OS 26 STYLE) ---

  Widget _buildWelcomeSection() {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(horizontal: 20),
      padding: const EdgeInsets.all(25),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: LinearGradient(
          colors: [
            _os26Surface.withOpacity(0.8),
            _os26Surface.withOpacity(0.4),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        border: Border.all(color: _os26Primary.withOpacity(0.3), width: 1.5),
        boxShadow: [
          BoxShadow(
            color: _os26Primary.withOpacity(0.1),
            blurRadius: 20,
            spreadRadius: 0,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                height: 55,
                width: 55,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: [_os26Primary, _os26Secondary],
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: _os26Primary.withOpacity(0.4),
                      blurRadius: 15,
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.person_rounded,
                  color: Colors.white,
                  size: 30,
                ),
              ),
              const SizedBox(width: 20),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      "IDENTITY DETECTED",
                      style: TextStyle(
                        color: _os26Primary.withOpacity(0.8),
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 2,
                        fontFamily: "Orbitron",
                      ),
                    ),
                    Text(
                      username.toUpperCase(),
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontFamily: "Orbitron",
                        fontWeight: FontWeight.w800,
                        shadows: [Shadow(color: Colors.black, blurRadius: 5)],
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: 12,
                  vertical: 6,
                ),
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: _getRoleColor(), width: 1.5),
                ),
                child: Text(
                  role.toUpperCase(),
                  style: TextStyle(
                    color: _getRoleColor(),
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    fontFamily: "Rajdhani",
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 12),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.3),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: Colors.white.withOpacity(0.05)),
            ),
            child: Row(
              children: [
                Icon(Icons.hourglass_bottom, color: _os26Secondary, size: 20),
                const SizedBox(width: 12),
                Text(
                  "EXPIRATION: $expiredDate",
                  style: const TextStyle(
                    color: Colors.white70,
                    fontFamily: "ShareTechMono",
                    fontSize: 14,
                    letterSpacing: 1,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Color _getRoleColor() {
    switch (role.toLowerCase()) {
      case 'owner':
        return Colors.pinkAccent; // Sekarang Magenta untuk Owner
      case 'vip':
        return Colors.amber;
      case 'reseller':
        return Colors.purpleAccent;
      default:
        return Colors.grey;
    }
  }

  Widget _buildNewsCarousel() {
    if (newsList.isEmpty) return _buildEmptyNews();

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                "INI ADALAH VERSI TERBARU",
                style: TextStyle(
                  color: Colors.white,
                  fontFamily: "Orbitron",
                  letterSpacing: 2,
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Container(width: 40, height: 3, color: _os26Secondary),
            ],
          ),
        ),
        SizedBox(
          height: 200,
          child: PageView.builder(
            controller: _pageController,
            itemCount: newsList.length,
            onPageChanged: (index) => setState(() => _currentNewsIndex = index),
            itemBuilder: (context, index) {
              final item = newsList[index];
              final isActive = _currentNewsIndex == index;

              return AnimatedContainer(
                duration: const Duration(milliseconds: 400),
                curve: Curves.easeOut,
                margin: EdgeInsets.symmetric(
                  horizontal: isActive ? 5 : 15,
                  vertical: 10,
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    if (isActive)
                      BoxShadow(
                        color: _os26Primary.withOpacity(0.3),
                        blurRadius: 20,
                        spreadRadius: 0,
                      ),
                  ],
                ),
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      if (item['image'] != null) NewsMedia(url: item['image']),
                      Container(
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [
                              Colors.black.withOpacity(0.95),
                              Colors.black.withOpacity(0.5),
                              Colors.transparent,
                            ],
                            begin: Alignment.bottomCenter,
                            end: Alignment.topCenter,
                            stops: const [0.1, 0.4, 1],
                          ),
                        ),
                      ),
                      Positioned(
                        bottom: 20,
                        left: 20,
                        right: 20,
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 2,
                              ),
                              decoration: BoxDecoration(
                                color: _os26Primary, // Badge Magenta
                                borderRadius: BorderRadius.circular(4),
                              ),
                              child: const Text(
                                "MY KISAH",
                                style: TextStyle(
                                  color: Colors.black,
                                  fontSize: 10,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              item['title'] ?? 'No Title',
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 18,
                                fontFamily: "Orbitron",
                                fontWeight: FontWeight.bold,
                                shadows: [
                                  Shadow(color: Colors.black, blurRadius: 10),
                                ],
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              item['desc'] ?? '',
                              style: const TextStyle(
                                color: Colors.white70,
                                fontFamily: "Rajdhani",
                                height: 1.3,
                              ),
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
        if (newsList.length > 1)
          Padding(
            padding: const EdgeInsets.only(top: 15),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(
                newsList.length,
                (index) => AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  margin: const EdgeInsets.symmetric(horizontal: 4),
                  height: 4,
                  width: _currentNewsIndex == index ? 24 : 6,
                  decoration: BoxDecoration(
                    color: _currentNewsIndex == index
                        ? _os26Primary // Indicator Aktif Magenta
                        : Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(4),
                    boxShadow: _currentNewsIndex == index
                        ? [BoxShadow(color: _os26Primary, blurRadius: 8)]
                        : [],
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }

  Widget _buildEmptyNews() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
      height: 160,
      decoration: BoxDecoration(
        color: _os26Surface.withOpacity(0.5),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: Colors.white.withOpacity(0.05)),
      ),
      child: const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.signal_wifi_statusbar_connected_no_internet_4,
              color: Colors.white24,
            ),
            SizedBox(height: 10),
            Text(
              "NO DATA TRANSMISSION",
              style: TextStyle(
                color: Colors.white38,
                fontFamily: "Orbitron",
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildQuickActionsGrid() {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "JOIN CHANNEL DAN ADD SENDER",
            style: TextStyle(
              color: Colors.white,
              fontFamily: "Orbitron",
              letterSpacing: 2,
            ),
          ),
          const SizedBox(height: 20),
          GridView.count(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            crossAxisCount: 2,
            crossAxisSpacing: 20,
            mainAxisSpacing: 20,
            childAspectRatio: 1.3,
            children: [
              // CHANNEL CARD (Telegram Logo)
              _buildOs26Card(
                icon: FontAwesomeIcons.telegram,
                title: "Join Channel",
                subtitle: "DarkLight",
                color: const Color(0xFF29B6F6),
                onTap: () async {
                  final uri = Uri.parse("tg://resolve?domain=LynexSoftSpoken");
                  if (await canLaunchUrl(uri))
                    await launchUrl(uri, mode: LaunchMode.externalApplication);
                  else
                    await launchUrl(
                      Uri.parse("https://t.me/LynexSoftSpoken"),
                      mode: LaunchMode.externalApplication,
                    );
                },
              ),
              // SENDER CARD (HP/Smartphone Logo)
              _buildOs26Card(
                icon: FontAwesomeIcons.mobileScreenButton,
                title: "Senders",
                subtitle: "Device Manager",
                color: _os26Secondary, // Menggunakan warna Violet Secondary
                onTap: () => setState(
                  () => _selectedPage = SenderPage(sessionKey: sessionKey),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildOs26Card({
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required VoidCallback onTap,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      splashColor: color.withOpacity(0.1),
      child: Container(
        decoration: BoxDecoration(
          color: _os26Surface.withOpacity(0.4),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color.withOpacity(0.2), width: 1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.4),
              blurRadius: 15,
              spreadRadius: 0,
            ),
          ],
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.15),
                  shape: BoxShape.circle,
                  border: Border.all(color: color.withOpacity(0.4), width: 1),
                ),
                child: Icon(icon, color: color, size: 24),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontFamily: "Orbitron",
                        fontSize: 13,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      subtitle,
                      style: TextStyle(
                        color: color.withOpacity(0.8),
                        fontFamily: "Rajdhani",
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.chevron_right, color: Colors.white.withOpacity(0.3)),
            ],
          ),
        ),
      ),
    );
  }

  void _showAccountMenu() {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (_) => Container(
        margin: const EdgeInsets.only(bottom: 30, left: 20, right: 20),
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: _os26Surface,
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: _os26Primary.withOpacity(0.3), width: 1),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.8),
              blurRadius: 30,
              spreadRadius: 5,
            ),
          ],
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 60,
              height: 4,
              color: _os26Primary.withOpacity(0.3),
              margin: const EdgeInsets.only(bottom: 25),
            ),
            const Text(
              "USER CONFIGURATION",
              style: TextStyle(
                color: Colors.white,
                fontSize: 20,
                fontFamily: "Orbitron",
                letterSpacing: 2,
              ),
            ),
            const SizedBox(height: 25),
            _buildInfoRow(Icons.person_outline, username),
            _buildInfoRow(Icons.event_available, expiredDate),
            _buildInfoRow(Icons.security, role.toUpperCase()),
            const SizedBox(height: 30),
            Row(
              children: [
                Expanded(
                  child: _buildOs26Btn(
                    "CHANGE PAS",
                    Icons.lock_outline,
                    _os26Primary,
                    () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => ChangePasswordPage(
                            username: username,
                            sessionKey: sessionKey,
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(width: 15),
                Expanded(
                  child: _buildOs26Btn(
                    "LOGOUT",
                    Icons.power_settings_new,
                    Colors.redAccent,
                    () async {
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(builder: (_) => const LoginPage()),
                        (route) => false,
                      );
                    },
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.3),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: Colors.white.withOpacity(0.05)),
        ),
        child: Row(
          children: [
            Icon(icon, color: _os26Secondary, size: 20),
            const SizedBox(width: 15),
            Text(
              text,
              style: const TextStyle(
                color: Colors.white,
                fontFamily: "ShareTechMono",
                fontSize: 15,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildOs26Btn(
    String label,
    IconData icon,
    Color color,
    VoidCallback onTap,
  ) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withOpacity(0.4)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(width: 10),
            Text(
              label,
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.bold,
                fontFamily: "Orbitron",
                letterSpacing: 1,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLogo({double height = 40}) {
    // Placeholder Logo Jika Asset Error
    return Container(
      height: height,
      width: height * 2,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        gradient: LinearGradient(colors: [_os26Primary, _os26Secondary]),
      ),
      child: Center(
        child: Text(
          "AKUN",
          style: TextStyle(
            color: Colors.white,
            fontFamily: "Orbitron",
            fontWeight: FontWeight.bold,
            fontSize: height * 0.5,
            letterSpacing: 2,
          ),
        ),
      ),
    );
  }

  // UPDATE ICONS
  List<BottomNavigationBarItem> _buildBottomNavBarItems() {
    return [
      const BottomNavigationBarItem(
        icon: Icon(Icons.dashboard_rounded),
        label: "Home",
      ),
      // UPDATE: Icon Bug diganti WhatsApp
      BottomNavigationBarItem(
        key: _bugButtonKey,
        icon: const FaIcon(FontAwesomeIcons.whatsapp), // Changed
        label: "Bug",
      ),
      // UPDATE: Icon DDoS diganti Server (Oket)
      const BottomNavigationBarItem(
        icon: FaIcon(FontAwesomeIcons.server), // Changed
        label: "DDoS",
      ),
      // UPDATE: Icon Tools
      const BottomNavigationBarItem(
        icon: FaIcon(FontAwesomeIcons.toolbox),
        label: "Tools",
      ),
    ];
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBodyBehindAppBar: true,
      backgroundColor: _os26Bg,
      // UPDATE: AppBar sekarang menampilkan Judul "DASHBOARD CONTROL"
      appBar: AppBar(
        title: const Text(
          "DarkLight", // Judul Jelas di Tengah
          style: TextStyle(
            color: Colors.white,
            fontFamily: "Orbitron",
            fontWeight: FontWeight.bold,
            letterSpacing: 2,
            fontSize: 18,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        flexibleSpace: ClipRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [_os26Bg.withOpacity(0.95), _os26Bg.withOpacity(0.6)],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
                border: Border(
                  bottom: BorderSide(
                    color: _os26Primary.withOpacity(0.2),
                    width: 1,
                  ),
                ),
              ),
            ),
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 15.0),
            child: InkWell(
              onTap: _showAccountMenu,
              child: Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: _os26Primary.withOpacity(0.3)),
                ),
                child: Icon(Icons.person_outline, color: _os26Primary),
              ),
            ),
          ),
        ],
      ),
      drawer: Drawer(
        backgroundColor: Colors.transparent,
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(colors: [_os26Bg, Colors.black]),
            border: Border(
              right: BorderSide(color: _os26Primary.withOpacity(0.1)),
            ),
          ),
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              DrawerHeader(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [_os26Surface, Colors.black],
                  ),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // UPDATE: Logo OS 26 dipindah ke sini (Drawer Header)
                    _buildLogo(height: 50),
                    const SizedBox(height: 20),
                    Text(
                      username,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 22,
                        fontFamily: "Orbitron",
                      ),
                    ),
                    Text(
                      role.toUpperCase(),
                      style: TextStyle(
                        color: _os26Secondary,
                        letterSpacing: 2,
                        fontFamily: "Rajdhani",
                      ),
                    ),
                  ],
                ),
              ),
              if (role == "reseller" || role == "owner")
                _drawerItem(
                  Icons.people_outline,
                  "Reseller Panel",
                  () => _selectFromDrawer('reseller'),
                ),
              if (role == "owner")
                _drawerItem(
                  Icons.admin_panel_settings_outlined,
                  "Admin Panel",
                  () => _selectFromDrawer('admin'),
                ),
              _drawerItem(
                Icons.smartphone,
                "Sender Management",
                () => _selectFromDrawer('sender'),
              ),
            ],
          ),
        ),
      ),
      body: Stack(
        children: [
          // OS 26 Background Grid Effect
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: RadialGradient(
                  center: const Alignment(0, -0.2),
                  radius: 1.2,
                  colors: [_os26Surface.withOpacity(0.3), _os26Bg],
                ),
              ),
            ),
          ),
          // Grid Lines Overlay
          Positioned.fill(
            child: Opacity(
              opacity: 0.05,
              child: Image.network(
                'https://transparenttextures.com/patterns/carbon-fibre.png',
                repeat: ImageRepeat.repeat,
              ),
            ),
          ),

          SafeArea(
            child: FadeTransition(opacity: _animation, child: _selectedPage),
          ),
        ],
      ),
      bottomNavigationBar: Container(
        height: 80,
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
        decoration: BoxDecoration(
          color: _os26Surface.withOpacity(0.6),
          borderRadius: BorderRadius.circular(30),
          border: Border.all(color: _os26Primary.withOpacity(0.2), width: 1.5),
          boxShadow: [
            BoxShadow(
              color: _os26Primary.withOpacity(0.1),
              blurRadius: 20,
              spreadRadius: 0,
            ),
            const BoxShadow(
              color: Colors.black,
              blurRadius: 20,
              spreadRadius: 5,
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(30),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
            child: BottomNavigationBar(
              backgroundColor: Colors.transparent,
              selectedItemColor: _os26Primary,
              unselectedItemColor: Colors.white38,
              currentIndex: _selectedIndex,
              onTap: _onTabSelected,
              type: BottomNavigationBarType.fixed,
              elevation: 0,
              showSelectedLabels: false,
              showUnselectedLabels: false,
              items: _buildBottomNavBarItems(),
            ),
          ),
        ),
      ),
    );
  }

  Widget _drawerItem(IconData icon, String text, VoidCallback onTap) {
    return ListTile(
      leading: Icon(icon, color: _os26Primary.withOpacity(0.8)),
      title: Text(
        text,
        style: const TextStyle(
          color: Colors.white70,
          fontFamily: "Rajdhani",
          fontSize: 18,
        ),
      ),
      onTap: onTap,
    );
  }

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    _controller.dispose();
    _pageController.dispose();
    super.dispose();
  }
}

class NewsMedia extends StatefulWidget {
  final String url;
  const NewsMedia({super.key, required this.url});

  @override
  State<NewsMedia> createState() => _NewsMediaState();
}

class _NewsMediaState extends State<NewsMedia> {
  VideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    if (_isVideo(widget.url)) {
      _controller = VideoPlayerController.networkUrl(Uri.parse(widget.url))
        ..initialize().then((_) {
          setState(() {});
          _controller?.setLooping(true);
          _controller?.setVolume(0.0);
          _controller?.play();
        });
    }
  }

  bool _isVideo(String url) =>
      url.endsWith(".mp4") || url.endsWith(".webm") || url.endsWith(".mov");

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_isVideo(widget.url)) {
      if (_controller != null && _controller!.value.isInitialized) {
        return FittedBox(
          fit: BoxFit.cover,
          child: SizedBox(
            width: _controller!.value.size.width,
            height: _controller!.value.size.height,
            child: VideoPlayer(_controller!),
          ),
        );
      } else {
        return const Center(
          // Loader color juga disesuaikan
          child: CircularProgressIndicator(color: Color(0xFFFF00FF)),
        );
      }
    } else {
      return Image.network(
        widget.url,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => Container(color: Colors.black26),
      );
    }
  }
}
