import 'dart:math' as math;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'dart:ui';
import 'package:url_launcher/url_launcher.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:video_player/video_player.dart';

// KONFIGURASI BASE URL
const String baseUrl = "http://thefools.serverkuu.my.id:7170";

// KONFIGURASI WARNA BARU (UNGU KEPINK / PURPLE PINK)
class AppColors {
  static const Color primaryPurple = Color(0xFF7B1FA2);
  static const Color pinkAccent = Color(0xFFFF4081);
  static const Color background = Color(0xFF0F0518);
  static const Color cardBackground = Color(0x00000000);
  static const Color textDark = Color(0xFFFFFFFF);
  static const Color textLight = Color(0xFFE1BEE7);
  static const Color buttonBackground = Color(0x33170D29);
  static const Color borderGlow = Color(0x80AB47BC);
}

// ==========================================
// MAIN APP ENTRY
// ==========================================
void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'DarkLight App',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(fontFamily: 'Orbitron'),
      initialRoute: '/',
      routes: {
        '/': (context) => const LoginPage(),
        '/loader': (context) => const LoaderPage(),
      },
    );
  }
}

// ==========================================
// LOGIN PAGE
// ==========================================
class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final userController = TextEditingController();
  final passController = TextEditingController();
  bool isLoading = false;
  String? androidId;
  late VideoPlayerController _videoController;

  @override
  void initState() {
    super.initState();
    initLogin();

    try {
      _videoController = VideoPlayerController.asset('assets/videos/login.mp4')
        ..initialize().then((_) {
          setState(() {});
          _videoController.setLooping(true);
          _videoController.play();
          _videoController.setVolume(1.0);
        });
    } catch (e) {
      print("Error loading video: $e");
    }
  }

  @override
  void dispose() {
    _videoController.dispose();
    super.dispose();
  }

  Future<void> initLogin() async {
    androidId = await getAndroidId();
    final prefs = await SharedPreferences.getInstance();
    final savedUser = prefs.getString("username");
    final savedPass = prefs.getString("password");
    final savedKey = prefs.getString("key");

    if (savedUser != null && savedPass != null && savedKey != null) {
      final uri = Uri.parse(
        "$baseUrl/api/auth/myInfo?username=$savedUser&password=$savedPass&androidId=$androidId&key=$savedKey",
      );
      try {
        final res = await http.get(uri);
        final data = jsonDecode(res.body);

        if (data['valid'] == true) {
          if (!mounted) return;
          Navigator.pushReplacementNamed(
            context,
            '/loader',
            arguments: {
              'username': savedUser,
              'password': savedPass,
              'role': data['role'],
              'key': data['key'],
              'expiredDate': data['expiredDate'],
              'listBug': data['listBug'] ?? [],
              'listPayload': data['listPayload'] ?? [],
              'listDDoS': data['listDDoS'] ?? [],
              'news': data['news'] ?? [],
            },
          );
        }
      } catch (_) {}
    }
  }

  Future<String> getAndroidId() async {
    final deviceInfo = DeviceInfoPlugin();
    final android = await deviceInfo.androidInfo;
    return android.id ?? "unknown_device";
  }

  Future<void> login() async {
    final username = userController.text.trim();
    final password = passController.text.trim();

    if (username.isEmpty || password.isEmpty) {
      _showAlert("⚠️ Error", "Username and password are required.");
      return;
    }

    setState(() => isLoading = true);

    try {
      final validate = await http.post(
        Uri.parse("$baseUrl/api/auth/validate"),
        body: {
          "username": username,
          "password": password,
          "androidId": androidId ?? "unknown_device",
        },
      );

      final validData = jsonDecode(validate.body);

      if (validData['expired'] == true) {
        _showAlert(
          "⛔ Access Expired",
          "Your access has expired.\nPlease renew it.",
          showContact: true,
        );
      } else if (validData['valid'] != true) {
        _showAlert(
          "🚫 Login Failed",
          "Invalid username or password.",
          showContact: true,
        );
      } else {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString("username", username);
        prefs.setString("password", password);
        prefs.setString("key", validData['key']);

        if (!mounted) return;
        Navigator.pushNamed(
          context,
          '/loader',
          arguments: {
            'username': username,
            'password': password,
            'role': validData['role'],
            'key': validData['key'],
            'expiredDate': validData['expiredDate'],
            'listBug': validData['listBug'] ?? [],
            'listPayload': validData['listPayload'] ?? [],
            'listDDoS': validData['listDDoS'] ?? [],
            'news': validData['news'] ?? [],
          },
        );
      }
    } catch (_) {
      _showAlert("🌐 Connection Error", "Failed to connect to the server.");
    }

    setState(() => isLoading = false);
  }

  void _showAlert(String title, String msg, {bool showContact = false}) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: AppColors.cardBackground.withOpacity(0.9),
        title: Text(
          title,
          style: const TextStyle(
            color: AppColors.textDark,
            fontSize: 18,
            fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron',
          ),
        ),
        content: Text(
          msg,
          style: const TextStyle(
            color: AppColors.textDark,
            fontSize: 14,
            fontFamily: 'ShareTechMono',
          ),
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(
            color: AppColors.primaryPurple.withOpacity(0.5),
            width: 1,
          ),
        ),
        actions: [
          if (showContact)
            TextButton(
              onPressed: () async {
                final uri = Uri.parse("tg://resolve?domain=LynexSoftSpoken");
                if (await canLaunchUrl(uri)) {
                  await launchUrl(uri, mode: LaunchMode.externalApplication);
                } else {
                  await launchUrl(
                    Uri.parse("https://t.me/LynexSoftSpoken"),
                    mode: LaunchMode.externalApplication,
                  );
                }
              },
              child: const Text(
                "Contact Admin",
                style: TextStyle(
                  color: AppColors.pinkAccent,
                  fontFamily: 'Orbitron',
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text(
              "CLOSE",
              style: TextStyle(
                color: AppColors.pinkAccent,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        children: [
          SizedBox(
            height: double.infinity,
            width: double.infinity,
            child: FittedBox(
              fit: BoxFit.cover,
              child: _videoController.value.isInitialized
                  ? SizedBox(
                      width: _videoController.value.size.width,
                      height: _videoController.value.size.height,
                      child: VideoPlayer(_videoController),
                    )
                  : Container(color: AppColors.background),
            ),
          ),
          BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Container(color: Colors.black.withOpacity(0.6)),
          ),
          Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(28),
              child: Column(
                children: [
                  Image.asset('assets/images/logo.png', height: 140),
                  const SizedBox(height: 20),
                  const Text(
                    "Welcome Back",
                    style: TextStyle(
                      color: AppColors.textDark,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    "Login to continue",
                    style: TextStyle(
                      color: AppColors.textLight,
                      fontSize: 14,
                      fontFamily: 'ShareTechMono',
                    ),
                  ),
                  const SizedBox(height: 30),
                  _neonInput("Username", userController),
                  const SizedBox(height: 16),
                  _neonInput("Password", passController, isPassword: true),
                  const SizedBox(height: 25),
                  ElevatedButton(
                    onPressed: isLoading ? null : login,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.buttonBackground,
                      minimumSize: const Size(double.infinity, 48),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(24),
                        side: BorderSide(
                          color: AppColors.primaryPurple.withOpacity(0.5),
                        ),
                      ),
                    ),
                    child: isLoading
                        ? SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(
                              color: AppColors.pinkAccent,
                              strokeWidth: 2,
                            ),
                          )
                        : const Text(
                            "LOGIN",
                            style: TextStyle(
                              fontSize: 16,
                              color: AppColors.pinkAccent,
                              fontFamily: 'Orbitron',
                              letterSpacing: 1.5,
                            ),
                          ),
                  ),
                  const SizedBox(height: 18),
                  ElevatedButton(
                    onPressed: () {
                      _showBuyMenu();
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.buttonBackground,
                      minimumSize: const Size(double.infinity, 48),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(24),
                        side: BorderSide(
                          color: AppColors.primaryPurple.withOpacity(0.5),
                        ),
                      ),
                    ),
                    child: const Text(
                      "Buy Account",
                      style: TextStyle(
                        fontSize: 16,
                        color: AppColors.pinkAccent,
                        fontFamily: 'Orbitron',
                        letterSpacing: 1.5,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _neonInput(
    String hint,
    TextEditingController controller, {
    bool isPassword = false,
  }) {
    return TextField(
      controller: controller,
      obscureText: isPassword,
      style: const TextStyle(color: AppColors.textDark),
      cursorColor: AppColors.pinkAccent,
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(
          color: AppColors.textLight,
          fontFamily: 'ShareTechMono',
        ),
        filled: true,
        fillColor: AppColors.buttonBackground,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide(
            color: AppColors.primaryPurple.withOpacity(0.5),
          ),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: BorderSide(
            color: AppColors.primaryPurple.withOpacity(0.5),
          ),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(18),
          borderSide: const BorderSide(color: AppColors.pinkAccent, width: 2),
        ),
      ),
    );
  }

  void _showBuyMenu() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.7,
        decoration: BoxDecoration(
          color: AppColors.cardBackground.withOpacity(0.9),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          border: Border(
            top: BorderSide(
              color: AppColors.primaryPurple.withOpacity(0.5),
              width: 2,
            ),
          ),
        ),
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(bottom: 20),
              decoration: BoxDecoration(
                color: AppColors.primaryPurple,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const Text(
              "Select Package",
              style: TextStyle(
                color: AppColors.pinkAccent,
                fontSize: 20,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
              ),
            ),
            const SizedBox(height: 20),
            Expanded(
              child: SingleChildScrollView(
                child: Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  alignment: WrapAlignment.center,
                  children: [
                    _buildSmallCard(
                      "Member 30H",
                      "20K",
                      AppColors.primaryPurple,
                      () => _showConfirmation("Member", "20K"),
                    ),
                    _buildSmallCard(
                      "Member Perm",
                      "30K",
                      AppColors.pinkAccent,
                      () => _showConfirmation("Member", "30K"),
                    ),
                    _buildSmallCard(
                      "VIP 30H",
                      "blm open",
                      AppColors.primaryPurple,
                      () => _showConfirmation("VIP", "blm open"),
                    ),
                    _buildSmallCard(
                      "VIP Perm",
                      "blm open",
                      AppColors.pinkAccent,
                      () => _showConfirmation("VIP", "blm open"),
                    ),
                    _buildSmallCard(
                      "Reseller 30H",
                      "35K",
                      AppColors.primaryPurple,
                      () => _showConfirmation("Reseller", "35K"),
                    ),
                    _buildSmallCard(
                      "Reseller Perm",
                      "40K",
                      AppColors.pinkAccent,
                      () => _showConfirmation("Reseller", "40K"),
                    ),
                    _buildSmallCard(
                      "XOWN Perm",
                      "60K",
                      AppColors.textDark,
                      () => _showConfirmation("XOWN", "60K"),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 10),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => Navigator.pop(context),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red.withOpacity(0.2),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                    side: const BorderSide(color: Colors.red),
                  ),
                ),
                child: const Text(
                  "CLOSE",
                  style: TextStyle(
                    color: Colors.redAccent,
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSmallCard(
    String title,
    String price,
    Color color,
    VoidCallback onTap,
  ) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: 140,
        height: 100,
        decoration: BoxDecoration(
          color: color.withOpacity(0.15),
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: color.withOpacity(0.6), width: 1.5),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              title,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: color,
                fontSize: 14,
                fontWeight: FontWeight.bold,
                fontFamily: 'Orbitron',
              ),
            ),
            const SizedBox(height: 8),
            Text(
              price,
              style: const TextStyle(
                color: AppColors.textDark,
                fontSize: 16,
                fontWeight: FontWeight.bold,
                fontFamily: 'ShareTechMono',
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showConfirmation(String packageName, String price) {
    Navigator.pop(context);
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: AppColors.cardBackground.withOpacity(0.95),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: AppColors.primaryPurple.withOpacity(0.5)),
        ),
        title: const Text(
          "Konfirmasi Transaksi",
          style: TextStyle(
            color: AppColors.textDark,
            fontSize: 18,
            fontWeight: FontWeight.bold,
            fontFamily: 'Orbitron',
          ),
        ),
        content: Text(
          "Kamu akan diarahkan ke Channel Admin untuk pembelian Package: $packageName ($price).\n\nLanjutkan?",
          style: const TextStyle(
            color: AppColors.textDark,
            fontSize: 14,
            fontFamily: 'ShareTechMono',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text(
              "BATAL",
              style: TextStyle(
                color: Colors.redAccent,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
          TextButton(
            onPressed: () async {
              Navigator.of(context).pop();
              final uri = Uri.parse("tg://resolve?domain=LynexSoftSpoken");
              if (await canLaunchUrl(uri)) {
                await launchUrl(uri, mode: LaunchMode.externalApplication);
              } else {
                await launchUrl(
                  Uri.parse("https://t.me/LynexSoftSpoken"),
                  mode: LaunchMode.externalApplication,
                );
              }
            },
            child: const Text(
              "YA, BELI SEKARANG",
              style: TextStyle(
                color: AppColors.pinkAccent,
                fontFamily: 'Orbitron',
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ==========================================
// LOADER PAGE (BERSIH TANPA ERROR PARTICLE)
// ==========================================

class LoaderPage extends StatefulWidget {
  const LoaderPage({super.key});

  @override
  State<LoaderPage> createState() => _LoaderPageState();
}

class _LoaderPageState extends State<LoaderPage>
    with SingleTickerProviderStateMixin {
  late VideoPlayerController _landingController;
  bool _isVideoInitialized = false;

  late AnimationController _animController;
  late Animation<double> _progressAnimation;
  late Animation<double> _fadeInAnimation;

  @override
  void initState() {
    super.initState();
    _initializeVideo();

    // Controller untuk animasi loading dan text
    _animController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 2500),
    );

    _progressAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animController, curve: const Interval(0.0, 0.6)),
    );

    _fadeInAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animController, curve: const Interval(0.7, 1.0)),
    );

    _animController.forward();
  }

  void _initializeVideo() async {
    try {
      _landingController =
          VideoPlayerController.asset('assets/videos/landing.mp4')
            ..initialize().then((_) {
              setState(() {
                _isVideoInitialized = true;
              });
              _landingController.setLooping(true);
              _landingController.play();
              _landingController.setVolume(0.0);
            });
    } catch (e) {
      print("Video error: $e");
    }
  }

  @override
  void dispose() {
    _landingController.dispose();
    _animController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final args = ModalRoute.of(context)?.settings.arguments as Map?;
    final username = args?['username'] ?? "User";

    return Scaffold(
      backgroundColor: AppColors.background,
      body: Stack(
        fit: StackFit.expand,
        children: [
          // 1. VIDEO BACKGROUND
          if (_isVideoInitialized)
            FittedBox(
              fit: BoxFit.cover,
              child: SizedBox(
                width: _landingController.value.size.width,
                height: _landingController.value.size.height,
                child: VideoPlayer(_landingController),
              ),
            )
          else
            Container(color: AppColors.background),

          // 2. DARKENING OVERLAY
          Container(color: Colors.black.withOpacity(0.6)),

          // 3. KONTEN UTAMA
          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(24.0),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // ICON ATAS
                  const Icon(
                    Icons.shield_moon,
                    color: AppColors.pinkAccent,
                    size: 80,
                  ),
                  const SizedBox(height: 30),

                  // TEXT "ACCESS GRANTED"
                  const Text(
                    "ACCESS GRANTED",
                    style: TextStyle(
                      fontSize: 16,
                      letterSpacing: 4,
                      color: AppColors.textLight,
                      fontFamily: 'ShareTechMono',
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 15),

                  // USERNAME ANIMATION (Typewriter)
                  _TypewriterText(
                    text: username.toUpperCase(),
                    style: const TextStyle(
                      fontSize: 36,
                      color: AppColors.textDark,
                      fontWeight: FontWeight.bold,
                      fontFamily: 'Orbitron',
                      shadows: [
                        Shadow(
                          blurRadius: 20,
                          color: AppColors.pinkAccent,
                          offset: Offset(0, 0),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 40),

                  // LOADING BAR ANIMATION
                  SizedBox(
                    width: 200,
                    child: Column(
                      children: [
                        AnimatedBuilder(
                          animation: _progressAnimation,
                          builder: (context, child) {
                            return LinearProgressIndicator(
                              value: _progressAnimation.value,
                              backgroundColor: AppColors.buttonBackground,
                              valueColor: const AlwaysStoppedAnimation<Color>(
                                AppColors.primaryPurple,
                              ),
                              minHeight: 4,
                            );
                          },
                        ),
                        const SizedBox(height: 10),
                        AnimatedBuilder(
                          animation: _progressAnimation,
                          builder: (context, child) {
                            return Text(
                              "INITIALIZING SYSTEM... ${(_progressAnimation.value * 100).toInt()}%",
                              style: const TextStyle(
                                fontSize: 12,
                                color: AppColors.primaryPurple,
                                fontFamily: 'ShareTechMono',
                              ),
                            );
                          },
                        ),
                      ],
                    ),
                  ),

                  const Spacer(),

                  // TOMBOL MASUK (Fade In)
                  AnimatedBuilder(
                    animation: _fadeInAnimation,
                    builder: (context, child) {
                      return Opacity(
                        opacity: _fadeInAnimation.value,
                        child: Transform.translate(
                          offset: Offset(0, 50 * (1 - _fadeInAnimation.value)),
                          child: child,
                        ),
                      );
                    },
                    child: Container(
                      width: double.infinity,
                      height: 60,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(30),
                        boxShadow: [
                          BoxShadow(
                            color: AppColors.pinkAccent.withOpacity(0.4),
                            blurRadius: 20,
                            spreadRadius: 2,
                          ),
                        ],
                      ),
                      child: ElevatedButton(
                        onPressed: () {
                          // Di sini navigasi ke dashboard
                          print("Masuk Dashboard: $username");
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.pinkAccent,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(30),
                            side: BorderSide.none,
                          ),
                        ),
                        child: const Text(
                          "ENTER DASHBOARD",
                          style: TextStyle(
                            fontSize: 18,
                            color: Colors.black,
                            fontFamily: 'Orbitron',
                            fontWeight: FontWeight.w900,
                            letterSpacing: 2,
                          ),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 30),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// Widget Helper untuk efek mengetik pada Username
class _TypewriterText extends StatefulWidget {
  final String text;
  final TextStyle style;

  const _TypewriterText({required this.text, required this.style});

  @override
  State<_TypewriterText> createState() => _TypewriterTextState();
}

class _TypewriterTextState extends State<_TypewriterText>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<int> _charCount;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: Duration(milliseconds: 100 * widget.text.length),
      vsync: this,
    );
    _charCount = IntTween(
      begin: 0,
      end: widget.text.length,
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeOut));
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _charCount,
      builder: (context, child) {
        String displayedText = widget.text.substring(0, _charCount.value);
        return Text(displayedText, style: widget.style);
      },
    );
  }
}
