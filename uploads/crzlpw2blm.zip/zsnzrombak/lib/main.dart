import 'package:flutter/material.dart';
import 'login_page.dart';
import 'loader_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'admin_page.dart';
import 'buy_account.dart';
// Import halaman dashboard yang sudah dirombak
import 'custom_bug.dart';
import 'bug_group.dart';
import 'ddos_panel.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Anonymous',
      theme: ThemeData(
        brightness: Brightness.dark,
        fontFamily: 'ShareTechMono',
        scaffoldBackgroundColor: Colors.black,
        colorScheme: const ColorScheme.dark().copyWith(
          secondary: Colors.purple,
        ),
      ),
      initialRoute: '/', // Mulai dari splash/login screen
      onGenerateRoute: (settings) {
        switch (settings.name) {
          case '/':
            return MaterialPageRoute(builder: (_) => const LoginPage());

          case '/buy_account':
            return MaterialPageRoute(builder: (_) => const BuyAccountPage());

          case '/loader': // Saya asumsikan ini rute menuju Dashboard
            final args = settings.arguments as Map<String, dynamic>?;

            // Validasi agar tidak error jika args null
            if (args == null) {
              return MaterialPageRoute(
                builder: (_) => const Scaffold(
                  body: Center(child: Text("Error: Missing arguments")),
                ),
              );
            }

            return MaterialPageRoute(
              builder: (_) => DashboardPage(
                username: args['username'] ?? "User",
                password: args['password'] ?? "",
                role: args['role'] ?? "user",
                sessionKey: args['key'] ?? "",
                expiredDate: args['expiredDate'] ?? "Unknown",
                listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
                listPayload: List<Map<String, dynamic>>.from(
                  args['listPayload'] ?? [],
                ),
                listDDoS: List<Map<String, dynamic>>.from(
                  args['listDDoS'] ?? [],
                ),
                news: List<Map<String, dynamic>>.from(args['news'] ?? []),
              ),
            );

          case '/attack':
            final args = settings.arguments as Map<String, dynamic>?;
            if (args == null) {
              return MaterialPageRoute(
                builder: (_) => const Scaffold(
                  body: Center(child: Text("Error: Missing arguments")),
                ),
              );
            }
            // Menggunakan class AttackPage yang ada di bawah ini
            return MaterialPageRoute(
              builder: (_) => AttackPage(
                username: args['username'] ?? "User",
                password: args['password'] ?? "",
                listBug: List<Map<String, dynamic>>.from(args['listBug'] ?? []),
                role: args['role'] ?? "user",
                expiredDate: args['expiredDate'] ?? "Unknown",
                sessionKey: args['sessionKey'] ?? "",
              ),
            );

          case '/seller':
            final args = settings.arguments as Map<String, dynamic>?;
            return MaterialPageRoute(
              builder: (_) => SellerPage(keyToken: args?['keyToken'] ?? ""),
            );

          case '/admin':
            final args = settings.arguments as Map<String, dynamic>?;
            return MaterialPageRoute(
              builder: (_) => AdminPage(sessionKey: args?['sessionKey'] ?? ""),
            );

          default:
            return MaterialPageRoute(
              builder: (_) => const Scaffold(
                body: Center(
                  child: Text(
                    "404 - Not Found",
                    style: TextStyle(color: Colors.redAccent),
                  ),
                ),
              ),
            );
        }
      },
    );
  }
}

// ==========================================
// ATTACK PAGE TEMPORARY (Karena file tidak ada)
// ==========================================
class AttackPage extends StatelessWidget {
  final String username;
  final String password;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;
  final String sessionKey;

  const AttackPage({
    super.key,
    required this.username,
    required this.password,
    required this.listBug,
    required this.role,
    required this.expiredDate,
    required this.sessionKey,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        title: const Text("Bug Attack", style: TextStyle(color: Colors.white)),
        backgroundColor: Colors.transparent,
        iconTheme: const IconThemeData(color: Colors.lightBlue),
        elevation: 0,
      ),
      body: listBug.isEmpty
          ? const Center(
              child: Text(
                "No Bugs Available",
                style: TextStyle(color: Colors.white54),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: listBug.length,
              itemBuilder: (context, index) {
                final bug = listBug[index];
                return Container(
                  margin: const EdgeInsets.only(bottom: 15),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.05),
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(
                      color: Colors.lightBlue.withOpacity(0.3),
                    ),
                  ),
                  child: ListTile(
                    contentPadding: const EdgeInsets.all(16),
                    leading: CircleAvatar(
                      backgroundColor: Colors.lightBlue.withOpacity(0.2),
                      child: Icon(Icons.bug_report, color: Colors.lightBlue),
                    ),
                    title: Text(
                      bug['name'] ?? 'Bug ${index + 1}',
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontFamily: 'Orbitron',
                      ),
                    ),
                    subtitle: Padding(
                      padding: const EdgeInsets.only(top: 5.0),
                      child: Text(
                        bug['desc'] ?? 'Tap to execute',
                        style: const TextStyle(color: Colors.white70),
                      ),
                    ),
                    trailing: const Icon(
                      Icons.arrow_forward_ios,
                      color: Colors.white38,
                      size: 16,
                    ),
                    onTap: () {
                      // Logic kirim bug bisa ditambahkan di sini
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text("Executing ${bug['name']}..."),
                          backgroundColor: Colors.lightBlue,
                        ),
                      );
                    },
                  ),
                );
              },
            ),
    );
  }
}
