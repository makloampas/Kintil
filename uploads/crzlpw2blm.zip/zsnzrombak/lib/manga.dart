import 'package:flutter/material.dart';

/// --- MODEL DATA (OFFLINE) ---
/// Karena tidak pakai server/network, datanya kita hardcode (tetapkan manual)
class Manga {
  final String title;
  final String imagePath; // Path ke gambar di folder assets
  final String synopsis;
  final int chapters;
  final double score;
  final String status;

  Manga({
    required this.title,
    required this.imagePath,
    required this.synopsis,
    required this.chapters,
    required this.score,
    required this.status,
  });
}

/// --- DATA DUMMY (DATABASE LOKAL) ---
/// List manga yang akan tampil di aplikasi
final List<Manga> mangaDatabase = [
  Manga(
    title: "One Piece",
    imagePath: "assets/images/manga1.jpg", // Pastikan file ini ada
    synopsis:
        "Petualangan Luffy menjadi Raja Bajak Laut. Kisah epik tentang persahabatan dan impian.",
    chapters: 1100,
    score: 9.5,
    status: "On Going",
  ),
  Manga(
    title: "Naruto Shippuden",
    imagePath: "assets/images/manga2.jpg", // Pastikan file ini ada
    synopsis:
        "Perjalanan Naruto Uzumaki menjadi Hokage dan menyelamatkan dunia ninja.",
    chapters: 700,
    score: 8.9,
    status: "Completed",
  ),
  Manga(
    title: "Solo Leveling",
    imagePath: "assets/images/manga3.jpg", // Pastikan file ini ada
    synopsis:
        "Sung Jin-Woo, pemburu terlemah, mendapatkan kesempatan kedua untuk level up tanpa batas.",
    chapters: 179,
    score: 9.2,
    status: "Completed",
  ),
  Manga(
    title: "Jujutsu Kaisen",
    imagePath:
        "assets/images/manga1.jpg", // Boleh pakai gambar yang sama untuk contoh
    synopsis:
        "Yuuji Itadori menelan jari terkutuk Ryomen Sukuna dan masuk ke dunia penyihir Jujutsu.",
    chapters: 250,
    score: 9.0,
    status: "On Going",
  ),
  Manga(
    title: "Demon Slayer",
    imagePath: "assets/images/manga2.jpg",
    synopsis:
        "Tanjiro Kamado berjuang mengubah adiknya yang berubah menjadi iblis kembali menjadi manusia.",
    chapters: 205,
    score: 8.8,
    status: "Completed",
  ),
];

/// --- MAIN APP ---
void main() {
  runApp(const MangaApp());
}

class MangaApp extends StatelessWidget {
  const MangaApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Offline Manga Reader',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF121212),
      ),
      home: const HomeScreen(),
    );
  }
}

/// --- HALAMAN UTAMA ---
class HomeScreen extends StatelessWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Local Manga Library'),
        backgroundColor: Colors.black,
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(10),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          childAspectRatio: 0.65,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
        ),
        itemCount: mangaDatabase.length,
        itemBuilder: (context, index) {
          final manga = mangaDatabase[index];
          return MangaCard(manga: manga);
        },
      ),
    );
  }
}

/// --- WIDGET KARTU MANGA (LOCAL IMAGE) ---
class MangaCard extends StatelessWidget {
  final Manga manga;
  const MangaCard({Key? key, required this.manga}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (context) => DetailScreen(manga: manga)),
        );
      },
      child: Card(
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        color: const Color(0xFF1E1E1E),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              // Menggunakan Image.asset untuk memuat gambar lokal
              child: Image.asset(
                manga.imagePath,
                width: double.infinity,
                fit: BoxFit.cover,
                errorBuilder: (context, error, stackTrace) {
                  // Fallback jika gambar tidak ditemukan
                  return Container(
                    color: Colors.grey[800],
                    child: const Center(
                      child: Icon(Icons.broken_image, color: Colors.white54),
                    ),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    manga.title,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                      color: Colors.white,
                    ),
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.star, color: Colors.amber, size: 14),
                      Text(
                        " ${manga.score}",
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.white70,
                        ),
                      ),
                      const Spacer(),
                      Text(
                        "Ch. ${manga.chapters}",
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.white70,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// --- HALAMAN DETAIL MANGA ---
class DetailScreen extends StatelessWidget {
  final Manga manga;
  const DetailScreen({Key? key, required this.manga}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 250,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              // Gambar lokal di header
              background: Image.asset(
                manga.imagePath,
                fit: BoxFit.cover,
                errorBuilder: (c, o, s) => Container(color: Colors.black),
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    manga.title,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 10),
                  Row(
                    children: [
                      _buildChip(manga.status, Colors.blue),
                      const SizedBox(width: 10),
                      _buildChip("Score: ${manga.score}", Colors.amber),
                    ],
                  ),
                  const SizedBox(height: 20),
                  const Text(
                    "Sinopsis",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    manga.synopsis,
                    style: const TextStyle(
                      fontSize: 14,
                      height: 1.5,
                      color: Colors.white70,
                    ),
                  ),
                  const SizedBox(height: 30),
                  const Text(
                    "Daftar Episode",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 10),
                  _buildEpisodeList(context),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChip(String text, Color color) {
    return Chip(
      label: Text(text),
      backgroundColor: color.withOpacity(0.2),
      labelStyle: TextStyle(color: color),
    );
  }

  Widget _buildEpisodeList(BuildContext context) {
    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: manga.chapters > 50
          ? 20
          : manga.chapters, // Batasi list agar tidak terlalu panjang
      itemBuilder: (context, index) {
        int chapterNum = (manga.chapters - index);
        return ListTile(
          title: Text(
            "Chapter $chapterNum",
            style: const TextStyle(color: Colors.white),
          ),
          trailing: const Icon(Icons.play_circle_outline, color: Colors.blue),
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ReaderScreen(
                  mangaTitle: manga.title,
                  chapterNum: chapterNum,
                ),
              ),
            );
          },
        );
      },
    );
  }
}

/// --- HALAMAN BACA (READER) ---
class ReaderScreen extends StatelessWidget {
  final String mangaTitle;
  final int chapterNum;

  const ReaderScreen({
    Key? key,
    required this.mangaTitle,
    required this.chapterNum,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // Simulasi gambar halaman manga (mengambil dari asset yang sama berulang kali sebagai contoh)
    // Di sistem asli, Anda akan memanggil API lokal Anda untuk mendapatkan list nama file per chapter
    List<String> pageImages = [
      "assets/images/manga1.jpg",
      "assets/images/manga2.jpg",
      "assets/images/manga3.jpg",
      "assets/images/manga1.jpg", // Ulangi untuk simulasi panjang
      "assets/images/manga2.jpg",
    ];

    return Scaffold(
      appBar: AppBar(
        title: Text("$mangaTitle - Ch. $chapterNum"),
        backgroundColor: Colors.black,
      ),
      body: ListView.builder(
        itemCount: pageImages.length,
        itemBuilder: (context, index) {
          return Image.asset(
            pageImages[index],
            fit: BoxFit.cover,
            errorBuilder: (context, error, stackTrace) {
              return Container(
                height: 500,
                color: Colors.black,
                child: const Center(
                  child: Text(
                    "Halaman Tidak Ditemukan",
                    style: TextStyle(color: Colors.grey),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
