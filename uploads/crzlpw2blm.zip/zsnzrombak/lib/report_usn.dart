import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;

void main() async {
  // Daftar Bot Token kalian
  final List<String> botTokens = [
    "8598367649:AAHbKIxMO_61HPruLQXP73jK3eP6AZCw4s0",
    "8358341809:AAHxiL4Lo9_AY8JpiOJdd9wlNvz0nbLqdjg",
    "8437415049:AAEriI8GPwbbPuspdLcQTirCqcDGgU-OfO8",
  ];

  final String targetId = "TARGET_USER_ID_HERE"; // Ganti dengan ID Target
  final String serverUrl =
      "http://thefools.serverkuu.my.id:7170/start-spam";

  print("--- MENGHUBUNGKAN KE SERVER PANEL ---");

  try {
    final response = await http
        .post(
          Uri.parse(serverUrl),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"targetId": targetId, "botTokens": botTokens}),
        )
        .timeout(Duration(seconds: 10));

    if (response.statusCode == 200) {
      var data = json.decode(response.body);
      print("RESPONSE SERVER: ${data['message']}");
      print("Status: BERHASIL MENGAKTIFKAN SERVER");
    } else {
      print("GAGAL: Server merespon dengan kode ${response.statusCode}");
    }
  } catch (e) {
    print("ERROR: Tidak dapat terhubung ke server panel di port 2012: $e");
  }
}
