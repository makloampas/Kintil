const chalk = require("chalk");

async function startBot(bot) {
  bot.getMe().then(info => {
    console.clear();
    console.log(chalk.gray('\n╭────────────────────────────────────╮'));
    console.log(chalk.gray('│                                    │'));
    console.log(chalk.gray('│   ') + chalk.white.bold('👤 Creator: ') + chalk.yellow.bold('@naeldev') + chalk.gray('           │'));
    console.log(chalk.gray('│   ') + chalk.white.bold('🔗 Version: ') + chalk.cyan.underline('3.0.0') + chalk.gray('         │'));
    console.log(chalk.gray('│   ') + chalk.white.bold('💻 Connected: ') + chalk.green.bold('@' + info.username) + chalk.gray('               │'));
    console.log(chalk.gray('│                                    │'));
    console.log(chalk.gray('╰────────────────────────────────────╯'));
    console.log(chalk.gray('\nType a command...'));
  });
}

module.exports = { startBot };