const fs = require('fs');
const { loadJsonData, saveJsonData } = require('../lib/function')
const settings = require('../settings.js');

const OWNER_ID = settings.ownerId;
const OWNER_FILE = './db/users/adminID.json';
const PREMIUM_FILE = './db/users/premiumUsers.json';
const RESS_FILE = './db/users/resellerUsers.json';

module.exports = (bot) => {
// command /addtk
bot.onText(/^\/addtk(?:\s+(.+))?$/, (msg, match) => { 
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    // cek owner
    const owners = loadJsonData(OWNER_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }
    
    const text = match[1];
    if (!text) {
        bot.sendMessage(chatId, '❌ Format salah!\nContoh: /addtk 123456789');
        return;
    }

    const targetUserId = match[1].trim();

    // validasi id
    if (!/^\d+$/.test(targetUserId)) {
        return bot.sendMessage(chatId, '❌ User ID harus berupa angka!');
    }

    // load file
    const premiumUsers = loadJsonData(PREMIUM_FILE);
    const ressUsers = loadJsonData(RESS_FILE);
    const ownerUsers = loadJsonData(OWNER_FILE);

    let addedPrem = false;
    let addedRes = false;
    let addedOwner = false;

    // tambahkan ke premium
    if (!premiumUsers.includes(targetUserId)) {
        premiumUsers.push(targetUserId);
        saveJsonData(PREMIUM_FILE, premiumUsers);
        addedPrem = true;
    }

    // tambahkan ke reseller
    if (!ressUsers.includes(targetUserId)) {
        ressUsers.push(targetUserId);
        saveJsonData(RESS_FILE, ressUsers);
        addedRes = true;
    }
    
    // tambahkan ke owner
    if (!ownerUsers.includes(targetUserId)) {
        ownerUsers.push(targetUserId);
        saveJsonData(OWNER_FILE, ownerUsers);
        addedOwner = true;
    }

    if (addedPrem || addedRes || addedOwner) {
        bot.sendMessage(chatId, `✅ ᴜꜱᴇʀ ɪᴅ ${targetUserId} ʙᴇʀʜᴀꜱɪʟ ᴅɪᴛᴀᴍʙᴀʜᴋᴀɴ ᴍᴇɴᴊᴀᴅɪ ᴛᴀɴɢᴀɴ ᴋᴀɴᴀɴ ᴘᴀɴᴇʟ!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    } else {
        bot.sendMessage(chatId, `⚠️ User ID ${targetUserId} sudah menjadi Tangan Kanan Panel!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    }
});

// command /addpt
bot.onText(/^\/addpt(?:\s+(.+))?$/, (msg, match) => { 
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    // cek owner
    const owners = loadJsonData(OWNER_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }
    
    const text = match[1];
    if (!text) {
        bot.sendMessage(chatId, '❌ Format salah!\nContoh: /addpt 123456789');
        return;
    }

    const targetUserId = match[1].trim();

    // validasi id
    if (!/^\d+$/.test(targetUserId)) {
        return bot.sendMessage(chatId, '❌ User ID harus berupa angka!');
    }

    // load file
    const premiumUsers = loadJsonData(PREMIUM_FILE);
    const ressUsers = loadJsonData(RESS_FILE);
    const ownerUsers = loadJsonData(OWNER_FILE);

    let addedPrem = false;
    let addedRes = false;
    let addedOwner = false;

    // tambahkan ke premium
    if (!premiumUsers.includes(targetUserId)) {
        premiumUsers.push(targetUserId);
        saveJsonData(PREMIUM_FILE, premiumUsers);
        addedPrem = true;
    }

    // tambahkan ke reseller
    if (!ressUsers.includes(targetUserId)) {
        ressUsers.push(targetUserId);
        saveJsonData(RESS_FILE, ressUsers);
        addedRes = true;
    }
    
    // tambahkan ke owner
    if (!ownerUsers.includes(targetUserId)) {
        ownerUsers.push(targetUserId);
        saveJsonData(OWNER_FILE, ownerUsers);
        addedOwner = true;
    }

    if (addedPrem || addedRes || addedOwner) {
        bot.sendMessage(chatId, `✅ ᴜꜱᴇʀ ɪᴅ ${targetUserId} ʙᴇʀʜᴀꜱɪʟ ᴅɪᴛᴀᴍʙᴀʜᴋᴀɴ ᴍᴇɴᴊᴀᴅɪ ᴘᴀʀᴛɴᴇʀ ᴘᴀɴᴇʟ!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    } else {
        bot.sendMessage(chatId, `⚠️ User ID ${targetUserId} sudah menjadi Partner Panel!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    }
});

// command /addown panel
bot.onText(/^\/addown(?:\s+(.+))?$/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    // cek owner
    const owners = loadJsonData(OWNER_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ ʙᴏᴛ');
    }

    const text = match[1];
    if (!text) {
        bot.sendMessage(chatId, '❌ Format salah!\nContoh: /addown 123456789');
        return;
    }
    
    const targetUserId = match[1].trim();

    // validasi id
    if (!/^\d+$/.test(targetUserId)) {
        return bot.sendMessage(chatId, '❌ User ID harus berupa angka!');
    }

    // load file
    const premiumUsers = loadJsonData(PREMIUM_FILE);
    const ressUsers = loadJsonData(RESS_FILE);
    const ownerUsers = loadJsonData(OWNER_FILE);

    let addedPrem = false;
    let addedRes = false;
    let addedOwner = false;

    // tambahkan ke premium
    if (!premiumUsers.includes(targetUserId)) {
        premiumUsers.push(targetUserId);
        saveJsonData(PREMIUM_FILE, premiumUsers);
        addedPrem = true;
    }

    // tambahkan ke reseller
    if (!ressUsers.includes(targetUserId)) {
        ressUsers.push(targetUserId);
        saveJsonData(RESS_FILE, ressUsers);
        addedRes = true;
    }
    
    // tambahkan ke owner
    if (!ownerUsers.includes(targetUserId)) {
        ownerUsers.push(targetUserId);
        saveJsonData(OWNER_FILE, ownerUsers);
        addedOwner = true;
    }

    if (addedPrem || addedRes || addedOwner) {
        bot.sendMessage(chatId, `✅ ᴜꜱᴇʀ ɪᴅ ${targetUserId} ʙᴇʀʜᴀꜱɪʟ ᴅɪᴛᴀᴍʙᴀʜᴋᴀɴ ᴍᴇɴᴊᴀᴅɪ ᴏᴡɴᴇʀ ᴘᴀɴᴇʟ!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    } else {
        bot.sendMessage(chatId, `⚠️ User ID ${targetUserId} sudah menjadi Owner Panel!`);
    }
});
    
// command add premium & reseller
bot.onText(/^\/addpr (.+)$/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id.toString();
    
    // cek owner
    const owners = loadJsonData(OWNER_FILE);
    if (msg.from.id !== OWNER_ID && !owners.includes(userId)) {
        return bot.sendMessage(chatId, '❌ ᴋʜᴜsᴜs ᴏᴡɴᴇʀ');
    }

    const text = match[1];
    if (!text) {
        bot.sendMessage(chatId, '❌ Format salah!\nContoh: /addpr 123456789');
        return;
    }
    
    const targetUserId = match[1].trim();

    // validasi id
    if (!/^\d+$/.test(targetUserId)) {
        return bot.sendMessage(chatId, '❌ User ID harus berupa angka!');
    }

    // load file
    const premiumUsers = loadJsonData(PREMIUM_FILE);
    const ressUsers = loadJsonData(RESS_FILE);

    let addedPrem = false;
    let addedRes = false;

    // tambahkan ke premium
    if (!premiumUsers.includes(targetUserId)) {
        premiumUsers.push(targetUserId);
        saveJsonData(PREMIUM_FILE, premiumUsers);
        addedPrem = true;
    }

    // tambahkan ke reseller
    if (!ressUsers.includes(targetUserId)) {
        ressUsers.push(targetUserId);
        saveJsonData(RESS_FILE, ressUsers);
        addedRes = true;
    }

    if (addedPrem || addedRes) {
        bot.sendMessage(chatId, `✅ User ID ${targetUserId} berhasil ditambahkan menjadi Premium & Reseller`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    } else {
        bot.sendMessage(chatId, `⚠️ ᴜꜱᴇʀ ${targetUserId} ꜱᴜᴅᴀʜ ᴍᴇɴᴊᴀᴅɪ ᴘʀᴇᴍɪᴜᴍ ᴅᴀɴ ʀᴇꜱᴇʟʟᴇʀ!`, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
    }
});
    
}