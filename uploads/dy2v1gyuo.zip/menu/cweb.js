const fetch = require("node-fetch");
const unzipper = require("unzipper");
const { loadJsonData, saveJsonData } = require("../lib/function");

const settings = require("../settings");
const userState = {};

module.exports = (bot) => {
  bot.onText(/^\/cweb$/, async (msg) => {
    const chatId = msg.chat.id
    const keyboard = {
      inline_keyboard: [
        [{ text: "📤 Create Website", callback_data: "menu_deploy" }],
        [{ text: "🌐 Web2Zip", callback_data: "menu_web2zip" }]
      ]
    }
    await bot.sendMessage(chatId, `<b>🌐 ᴡᴇʙ ᴅᴇᴘʟᴏʏ ᴍᴇɴᴜ</b>\nᴛʜᴀɴᴋꜱ ꜰʀᴏᴍ @${settings.dev}`, {
      parse_mode: "HTML",
      reply_markup: keyboard
    })
  })

  bot.on("callback_query", async (callbackQuery) => {
    const chatId = callbackQuery.message.chat.id
    const data = callbackQuery.data
    const userId = callbackQuery.from.id

    if (data === "menu_deploy") {
      userState[userId] = { step: "upload", data: {} }
      bot.answerCallbackQuery(callbackQuery.id)
      return bot.sendMessage(chatId, `<blockquote>✅ Kirim file dengan format\n.zip atau .html untuk dideploy.</blockquote>`, { parse_mode: "HTML" })
    }

    if (data === "menu_web2zip") {
      userState[userId] = { step: "web2zip", data: {} }
      bot.answerCallbackQuery(callbackQuery.id)
      return bot.sendMessage(chatId, `<blockquote>🌐 Kirim URL website.\nContoh: https://example.com</blockquote>`, { parse_mode: "HTML" })
    }
  })

  bot.on("document", async (msg) => {
    const chatId = msg.chat.id
    const userId = msg.from.id
    if (!userState[userId] || userState[userId].step !== "upload") return

    const fileId = msg.document.file_id
    const file = await bot.getFile(fileId)
    const fileLink = `https://api.telegram.org/file/bot${settings.token}/${file.file_path}`

    userState[userId] = {
      step: "name",
      data: {
        file: fileLink,
        isZip: msg.document.file_name.endsWith(".zip"),
        isHtml: msg.document.file_name.endsWith(".html")
      }
    }

    await bot.sendMessage(chatId, `<blockquote>📦 Sukses terima file!\nSekarang kirim nama untuk website anda.</blockquote>`, { parse_mode: "HTML" })
  })

  bot.on("message", async (msg) => {
    const chatId = msg.chat.id
    const userId = msg.from.id
    const text = msg.text?.trim()
    if (!text || !userState[userId]) return

    const state = userState[userId]

    if (state.step === "web2zip") {
      userState[userId] = null

      if (!text.startsWith("http://") && !text.startsWith("https://")) {
        return bot.sendMessage(chatId, `<blockquote>❌ URL tidak valid!</blockquote>`, { parse_mode: "HTML" })
      }

      await bot.sendMessage(chatId, `<blockquote>⏳ Processing website...</blockquote>`, { parse_mode: "HTML" })
      try {
        const encodedUrl = encodeURIComponent(text)
        const apiUrl = `https://api.nekolabs.my.id/tools/web2zip?url=${encodedUrl}`
        const response = await fetch(apiUrl)
        if (!response.ok) throw new Error(`HTTP error ${response.status}`)

        const json = await response.json()
        if (!json.status || !json.result?.downloadUrl) throw new Error("Gagal ambil source")

        const zipRes = await fetch(json.result.downloadUrl)
        const buffer = await zipRes.buffer()

        await bot.sendDocument(chatId, buffer, {
          parse_mode: "HTML"
        }, {
          filename: `website-by-@${settings.dev}.zip`,
          contentType: "application/zip"
        })
      } catch (e) {
        bot.sendMessage(chatId, `<blockquote>❌ Error extract:\n${e.message}</blockquote>`, { parse_mode: "HTML" })
      }
      return
    }

    if (state.step === "name") {
      const webName = text.toLowerCase().replace(/[^a-z0-9-_]/g, "")
      await bot.sendMessage(chatId, "<blockquote>⏳ Mengecek nama website...</blockquote>", { parse_mode: "HTML" })

      try {
        const domainCheckUrl = `https://${webName}.vercel.app`
        try { await fetch(domainCheckUrl) } catch {}

        const fileBuffer = await fetch(state.data.file).then(res => res.buffer())
        const filesToUpload = []

        if (state.data.isZip) {
          const directory = await unzipper.Open.buffer(Buffer.from(fileBuffer))
          for (const zipFile of directory.files) {
            if (zipFile.type === "File") {
              const content = await zipFile.buffer()
              const filePath = zipFile.path.replace(/^\/+/, "")
              filesToUpload.push({ file: filePath, data: content.toString("base64"), encoding: "base64" })
            }
          }
        } else if (state.data.isHtml) {
          filesToUpload.push({ file: "index.html", data: Buffer.from(fileBuffer).toString("base64"), encoding: "base64" })
        }

        const headers = { Authorization: `Bearer ${settings.vercelToken}`, "Content-Type": "application/json" }
        await fetch("https://api.vercel.com/v9/projects", { method: "POST", headers, body: JSON.stringify({ name: webName }) }).catch(() => {})
        const deployRes = await fetch("https://api.vercel.com/v13/deployments", { method: "POST", headers, body: JSON.stringify({ name: webName, project: webName, files: filesToUpload }) })
        const deployData = await deployRes.json()

        if (!deployData.url || !deployData.id) throw new Error("Deploy gagal")

        await fetch(`https://api.vercel.com/v2/deployments/${deployData.id}/aliases`, { method: "POST", headers, body: JSON.stringify({ alias: `${webName}.vercel.app` }) })
        await bot.sendMessage(chatId, `<blockquote><b>✅ Website berhasil dibuat!</b>\n\n🔗 https://${webName}.vercel.app</blockquote>`, {
          parse_mode: "HTML",
          reply_markup: { inline_keyboard: [[{ text: "🌐 ᴄᴇᴋ ᴡᴇʙꜱɪᴛᴇ", url: `https://${webName}.vercel.app` }]] }
        })
      } catch (e) {
        bot.sendMessage(chatId, `<blockquote>❌ Deploy gagal:\n${e.message}</blockquote>`, { parse_mode: "HTML" })
      }
      userState[userId] = null
    }
  })
}
