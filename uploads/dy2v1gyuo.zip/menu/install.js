const axios = require("axios");
const fs = require("fs");
const path = require('path');
const { Client } = require("ssh2");
const { loadJsonData } = require("../lib/function");

const settings = require("../settings.js");
const dev = settings.dev;
const OWNER_ID = "./db/onlyID.json";
const ownerId = settings.ownerId;
const panel = settings.panel;
const ppNebula = "https://files.catbox.moe/sbqsli.jpg";

const OWNER_FILE = './db/users/adminID.json';

// fungsi validasi IP
function isValidIP(ip) {
  const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
  return ipRegex.test(ip);
}

global.subdomain = { 
    "naell.my.id": { 
        zone: "090a81422da7b258cdf3ef02de1e4ca3",
        apitoken: "QNK-xHIcdvNGxTWzvHl9IIP73Yyj0AwGLZ0r7iU0",
    },
    "pteroweb.my.id": {
        zone: "714e0f2e54a90875426f8a6819f782d0",
        apitoken: "vOn3NN5HJPut8laSwCjzY-gBO0cxeEdgSLH9WBEH"
    },
    "panelwebsite.biz.id": {
        zone: "2d6aab40136299392d66eed44a7b1122",
        apitoken: "CcavVSmQ6ZcGSrTnOos-oXnawq4yf86TUhmQW29S"
    },
    "privatserver.my.id": {
        zone: "699bb9eb65046a886399c91daacb1968",
        apitoken: "CcavVSmQ6ZcGSrTnOos-oXnawq4yf86TUhmQW29S"
    },
    "pterohost.my.id": {
        zone: "1bb268eff31c9811b1eb051431485358",
        apitoken: "C6vyp_OsbVAnLQ_18_BZdbQ_o_hUupJEQNdT6jgY"
    }
};

const userStates = new Map();
let lastMessageContent = {};

module.exports = (bot) => {
    // log command
function notifyOwner(commandName, msg) {
    const userId = msg.from.id;
    const username = msg.from.username || msg.from.first_name;
    const chatId = msg.chat.id;
    const now = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });

    const logMessage = `<pre>💬 Command: /${commandName}
👤 User: @${username}
🆔 ID: ${userId}
🕒 Waktu: ${now}
</pre>
    `;
    bot.sendMessage(OWNER_ID, logMessage, { parse_mode: 'HTML' });
}
    
    // createloc
bot.onText(/^\/createloc (.+)$/, async (msg, match) => {
  notifyOwner('createloc', msg);
  const chatId = msg.chat.id;
  const args = match[1].split("|");

  if (args.length < 3) {
    return bot.sendMessage(chatId, "❌ Format salah!\n\nContoh:\n/createloc https://domain|ptlaApikey|SG");
  }

  const domain = args[0].trim();
  const ptla = args[1].trim();
  const shortCode = args[2].trim().toUpperCase();

  try {
    const locationData = {
      short: shortCode,
      description: `Location ${shortCode}`
    };

    const response = await axios.post(
      `${domain}/api/application/locations`,
      locationData,
      {
        headers: {
          "Authorization": `Bearer ${ptla}`,
          "Content-Type": "application/json",
          "Accept": "Application/vnd.pterodactyl.v1+json"
        }
      }
    );

    const location = response.data.attributes;

    bot.sendMessage(
      chatId,
      `✅ *ʟᴏᴄᴀᴛɪᴏɴ ʙᴇʀʜᴀꜱɪʟ ᴅɪʙᴜᴀᴛ!*\n\nShort Code: ${location.short}\nID: ${location.id}`,
      { parse_mode: "Markdown" }
    );
  } catch (error) {
    console.error("Error creating location:", error.response?.data || error.message);

    if (error.response?.data?.errors) {
      const errorDetails = error.response.data.errors;
      let errorMessage = "❌ Gagal membuat location:\n";

      errorDetails.forEach(err => {
        errorMessage += `• ${err.detail || err.code}\n`;
      });

      bot.sendMessage(chatId, errorMessage);
    } else {
      bot.sendMessage(chatId, "❌ Terjadi kesalahan saat membuat location. Silakan coba lagi.");
    }
  }
});

    // createnode
bot.onText(/^\/createnode (.+)$/, (msg, match) => {
  notifyOwner('createnode', msg);
  const chatId = msg.chat.id;
  const args = match[1].split("|");

  if (args.length < 2) {
    return bot.sendMessage(chatId, "❌ Format salah!\n\nContoh:\n/createnode https://domain|ptlaApikey");
  }

  const domain = args[0].trim();
  const ptla = args[1].trim();

  userStates.set(chatId, { step: "name", domain, ptla });

  bot.sendMessage(chatId, '📡 *ᴍᴇᴍʙᴜᴀᴛ ɴᴏᴅᴇ ʙᴀʀᴜ...*\n\nMasukkan nama node baru:', {
    parse_mode: 'Markdown',
    reply_markup: { force_reply: true }
  });
});

    // handle createnode
bot.on('message', async (msg) => {
    if (!msg.text || msg.text.startsWith('/')) return;
    
    const chatId = msg.chat.id;
    const state = userStates.get(chatId);
    
    if (!state) return;

    try {
        switch (state.step) {
            case 'name':
                state.name = msg.text;
                state.step = 'description';
                bot.sendMessage(chatId, '📝 ᴍᴀꜱᴜᴋᴋᴀɴ ᴅᴇꜱᴋʀɪᴘꜱɪ ɴᴏᴅᴇ:', {
                    reply_markup: { force_reply: true }
                });
                break;

            case 'description':
                state.description = msg.text;
                state.step = 'location';
                bot.sendMessage(chatId, '📍 ꜱɪʟᴀʜᴋᴀɴ ᴘɪʟɪʜ ʟᴏᴋᴀꜱɪ:\n\nSG - Singapore', {
                    reply_markup: {
                        keyboard: [[{ text: 'SG' }]],
                        resize_keyboard: true,
                        one_time_keyboard: true
                    }
                });
                break;

            case 'location':
                state.location = msg.text;
                state.step = 'visibility';
                bot.sendMessage(chatId, '👁️ ᴄʜᴏᴏꜱᴇ ᴠɪꜱɪʙɪʟɪᴛᴀꜱ:', {
                    reply_markup: {
                        keyboard: [[{ text: 'Public' }]],
                        resize_keyboard: true,
                        one_time_keyboard: true
                    }
                });
                break;

            case 'visibility':
                state.visibility = msg.text.toLowerCase() === 'public';
                state.step = 'fqdn';
                bot.sendMessage(chatId, '🌐 Masukkan FQDN untuk node (e.g., node.example.com):', {
                    reply_markup: { force_reply: true }
                });
                break;

            case 'fqdn':
                state.fqdn = msg.text;
                state.step = 'memory';
                bot.sendMessage(chatId, '💾 ᴍᴀꜱᴜᴋᴋᴀɴ ᴛᴏᴛᴀʟ ᴍᴇᴍᴏʀʏ (e.g, 160000):', {
                    reply_markup: { force_reply: true }
                });
                break;

            case 'memory':
                state.memory = parseInt(msg.text);
                state.step = 'memory_overallocation';
                bot.sendMessage(chatId, '📊 ᴍᴀꜱᴜᴋᴋᴀɴ ᴍᴇᴍᴏʀʏ ᴏᴠᴇʀ-ᴀʟʟᴏᴄᴀᴛɪᴏɴ ᴘᴇʀᴄᴇɴᴛᴀɢᴇ (-1: disable, 0: default):', {
                    reply_markup: { force_reply: true }
                });
                break;

            case 'memory_overallocation':
                state.memory_overallocation = parseInt(msg.text);
                state.step = 'disk';
                bot.sendMessage(chatId, '💿 ᴍᴀꜱᴜᴋᴋᴀɴ ᴛᴏᴛᴀʟ ᴅɪꜱᴋ ꜱᴘᴀᴄᴇ (e.g, 160000):', {
                    reply_markup: { force_reply: true }
                });
                break;

            case 'disk':
                state.disk = parseInt(msg.text);
                state.step = 'disk_overallocation';
                bot.sendMessage(chatId, '📊 ᴍᴀꜱᴜᴋᴋᴀɴ ᴅɪꜱᴋ ᴏᴠᴇʀ-ᴀʟʟᴏᴄᴀᴛɪᴏɴ ᴘᴇʀᴄᴇɴᴛᴀɢᴇ (-1: disable, 0: default):', {
                    reply_markup: { force_reply: true }
                });
                break;
             
            case 'disk_overallocation':
    state.disk_overallocation = parseInt(msg.text);
    state.step = 'ip_alias';
    bot.sendMessage(chatId, '👤 ᴍᴀꜱᴜᴋᴋᴀɴ ɪᴘ ᴀʟɪᴀꜱ ᴜɴᴛᴜᴋ ᴀʟʟᴏᴄᴀᴛɪᴏɴ (e.g, NAELL🌐):', {
        reply_markup: { force_reply: true }
    });
    break;

            case 'ip_alias':
    state.ip_alias = msg.text;
                
    const { domain, ptla } = state;
    
    // Create node
    const nodeData = {
        name: state.name,
        description: state.description,
        location_id: 1,
        fqdn: state.fqdn,
        scheme: 'https',
        behind_proxy: false,
        memory: state.memory,
        memory_overallocate: state.memory_overallocation,
        disk: state.disk,
        disk_overallocate: state.disk_overallocation,
        upload_size: 100,
        daemon_listen: 8080,
        daemon_sftp: 2022,
        public: state.visibility
    };

    const response = await axios.post(
        `${domain}/api/application/nodes`,
        nodeData,
        {
            headers: {
                'Authorization': `Bearer ${ptla}`,
                'Content-Type': 'application/json',
                'Accept': 'Application/vnd.pterodactyl.v1+json'
            }
        }
    );

    const nodeId = response.data.attributes.id;
    
    const allocationData = {
        ip: '0.0.0.0',
        ip_alias: state.ip_alias,
        ports: ['3000-3800']
    };

    await axios.post(
        `${domain}/api/application/nodes/${nodeId}/allocations`,
        allocationData,
        {
            headers: {
                'Authorization': `Bearer ${ptla}`,
                'Content-Type': 'application/json'
            }
        }
    );

try {
    const configResponse = await axios.get(
        `${domain}/api/application/nodes/${nodeId}/configuration`,
        {
            headers: {
                'Authorization': `Bearer ${ptla}`,
                'Content-Type': 'application/json',
                'Accept': 'Application/vnd.pterodactyl.v1+json'
            }
        }
    );

    const configuration = configResponse.data.attributes;
    const deploymentCommand = `curl -sSL ${domain}/api/application/nodes/configuration/${configuration.token} | sudo bash -s -- ${nodeId} ${configuration.token}`;

    bot.sendMessage(chatId, `✅ *Node Berhasil Dibuat!*

📋 *Information Node:*
Nama: ${state.name}
FQDN: ${state.fqdn}
Memory: ${state.memory} MiB
Disk: ${state.disk} MiB

📡 *Deployment Command:*
\`\`\`${deploymentCommand}\`\`\`

Salin command di atas untuk deploy wings di server tujuan.`, {
        parse_mode: 'Markdown'
    });

} catch (error) {
    console.error('Error getting configuration:', error.response?.data || error.message);
    bot.sendMessage(chatId, `✅ <b>ɴᴏᴅᴇ ʙᴇʀʜᴀꜱɪʟ ᴅɪʙᴜᴀᴛ!</b>
<pre>📋 <b>Information Node:</b>
Nama: ${state.name}
FQDN: ${state.fqdn}
Memory: ${state.memory} MiB
Disk: ${state.disk} MiB

⚠️ <b>Token Deployment</b>
1. Login panel Pterodactyl
2. Pilih ke node yang baru dibuat
3. Klik tab "Configuration"
4. Auto Generate Token, salin
5. Ketik /swings ipvps|pwvps|token
</pre>`, {
        parse_mode: 'HTML'
    });
}

userStates.delete(chatId);
                break;
        }
    } catch (error) {
        console.error('Error:', error.response?.data || error.message);
        bot.sendMessage(chatId, '❌ Terjadi kesalahan saat membuat node. Silakan coba lagi.');
        userStates.delete(chatId);
    }
});

    // runtimevps public
bot.onText(/^\/vpspublic$/, async (msg) => {
  const chatId = msg.chat.id;

  // IP & password
  const host = settings.vpsPublic;
  const password = settings.pwPublic;

  try {
    const conn = new Client();
    conn
      .on("ready", () => {
        conn.exec("uptime -p", (err, stream) => {
          if (err) {
            bot.sendMessage(chatId, "❌ Gagal eksekusi command uptime.");
            return conn.end();
          }

          let output = "";
          stream
            .on("data", (data) => {
              output += data.toString();
            })
            .on("close", () => {
              bot.sendMessage(
                chatId,
                `✅ ʀᴜɴᴛɪᴍᴇ ᴠᴘꜱ\n\`\`\`${output.trim()}\`\`\``,
                { parse_mode: "Markdown" }
              );
              conn.end();
            });
        });
      })
      .connect({
        host,
        port: 22,
        username: "root",
        password
      });

  } catch (err) {
    bot.sendMessage(chatId, "❌ Terjadi kesalahan koneksi VPS.");
    console.error(err);
  }
});
    
    // runtimevps private
bot.onText(/^\/vpsprivate$/, async (msg) => {
  const chatId = msg.chat.id;

  // IP & password
  const host = settings.vpsPrivate;
  const password = settings.pwPrivate;

  try {
    const conn = new Client();
    conn
      .on("ready", () => {
        conn.exec("uptime -p", (err, stream) => {
          if (err) {
            bot.sendMessage(chatId, "❌ Gagal eksekusi command uptime.");
            return conn.end();
          }

          let output = "";
          stream
            .on("data", (data) => {
              output += data.toString();
            })
            .on("close", () => {
              bot.sendMessage(
                chatId,
                `✅ ʀᴜɴᴛɪᴍᴇ ᴠᴘꜱ\n\`\`\`${output.trim()}\`\`\``,
                { parse_mode: "Markdown" }
              );
              conn.end();
            });
        });
      })
      .connect({
        host,
        port: 22,
        username: "root",
        password
      });

  } catch (err) {
    bot.sendMessage(chatId, "❌ Terjadi kesalahan koneksi VPS.");
    console.error(err);
  }
});

    // runtime vps
bot.onText(/^\/runtimevps(?:\s+(.+))?/, async (msg, match) => {
  notifyOwner('runtimevps', msg);
  const chatId = msg.chat.id;
  const input = match[1];
    
  if (!input) {
    return bot.sendMessage(chatId, "❌ Format salah!\nContoh: /runtimevps ipvps|pwvps");
  }

  if (!input.includes("|")) {
    return bot.sendMessage(chatId, "❌ Format salah!\nGunakan: `/runtimevps ipvps|password`", {
      parse_mode: "Markdown"
    });
  }

  let [host, password] = input.split("|");
  host = host.trim();
  password = password.trim();

  try {
    const conn = new Client();

    conn
      .on("ready", () => {
        conn.exec("uptime -p", (err, stream) => {
          if (err) {
            bot.sendMessage(chatId, "❌ Gagal eksekusi command uptime.");
            return conn.end();
          }

          let output = "";
          stream
            .on("data", (data) => {
              output += data.toString();
            })
            .on("close", () => {
              bot.sendMessage(chatId, `✅ ʀᴜɴᴛɪᴍᴇ ᴠᴘꜱ ${host}\n\`\`\`${output.trim()}\`\`\``, {
                parse_mode: "Markdown"
              });
              conn.end();
            });
        });
      })
      .on("error", (err) => {
        bot.sendMessage(chatId, `❌ Gagal konek VPS: ${err.message}`);
      })
      .connect({
        host,
        port: 22,
        username: "root",
        password
      });

  } catch (err) {
    bot.sendMessage(chatId, "❌ Terjadi kesalahan koneksi VPS.");
    console.error(err);
  }
});
    
    // subdomain
bot.onText(/^\/subdo(?:\s+(.+))?/, async (msg, match) => {
    notifyOwner('subdo', msg);
    const chatId = msg.chat.id;
    const owners = loadJsonData(OWNER_FILE);

  if (!owners.includes(msg.from.id.toString())) {
    return bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ!");
  }

    const text = match[1];
    if (!text) {
    return bot.sendMessage(chatId, "❌ Format salah!\nContoh: /subdo reqname|ipvps");
    }
    
    if (!text.includes("|")) return bot.sendMessage(chatId, "❌ Format salah!\nContoh: `/subdo reqname|ipvps`", { parse_mode: "Markdown" });

    const [host, ip] = text.split("|").map(i => i.trim());
    const dom = Object.keys(global.subdomain);

    if (dom.length === 0) return bot.sendMessage(chatId, "❌ Tidak ada domain yang tersedia saat ini.");

    const inlineKeyboard = [];
    for (let i = 0; i < dom.length; i += 2) {
        const row = dom.slice(i, i + 2).map((d, index) => ({
            text: d,
            callback_data: `create_domain ${i + index} ${host}|${ip}`
        }));
        inlineKeyboard.push(row);
    }

    const opts = {
        reply_markup: {
            inline_keyboard: inlineKeyboard
        }
    };

    bot.sendMessage(chatId, `🔹 *Subdomain yang tersedia saat ini*\nbig thanks from @${dev}\nᴄʜᴏᴏꜱᴇ ᴀ ꜱᴜʙᴅᴏᴍᴀɪɴ :`, { parse_mode: "Markdown", ...opts });
});

// handler subdomain
bot.on("callback_query", async (callbackQuery) => {
    const msg = callbackQuery.message;
    const data = callbackQuery.data.split(" ");

    if (data[0] === "create_domain") {
        /*if (callbackQuery.from.id !== ownerId) {
            return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Owner only!", show_alert: true });
        }*/

        const domainIndex = Number(data[1]);
        const dom = Object.keys(global.subdomain);

        if (domainIndex < 0 || domainIndex >= dom.length) return bot.sendMessage(msg.chat.id, "Domain tidak ditemukan!");
        if (!data[2] || !data[2].includes("|")) return bot.sendMessage(msg.chat.id, "Hostname/IP tidak ditemukan!");

        const tldnya = dom[domainIndex];
        const [host, ip] = data[2].split("|").map(item => item.trim());

        async function createSubDomain(host, ip) {
            try {
                const response = await axios.post(
                    `https://api.cloudflare.com/client/v4/zones/${global.subdomain[tldnya].zone}/dns_records`,
                    {
                        type: "A",
                        name: `${host.replace(/[^a-z0-9.-]/gi, "")}.${tldnya}`,
                        content: ip.replace(/[^0-9.]/gi, ""),
                        ttl: 1,
                        proxied: false
                    },
                    {
                        headers: {
                            "Authorization": `Bearer ${global.subdomain[tldnya].apitoken}`,
                            "Content-Type": "application/json"
                        }
                    }
                );

                const res = response.data;
                if (res.success) {
                    return {
                        success: true,
                        name: res.result?.name || `${host}.${tldnya}`,
                        ip: res.result?.content || ip
                    };
                } else {
                    return { success: false, error: "Gagal membuat subdomain" };
                }
            } catch (e) {
                const errorMsg = e.response?.data?.errors?.[0]?.message || e.message || "Terjadi kesalahan";
                return { success: false, error: errorMsg };
            }
        }

        const result = await createSubDomain(host.toLowerCase(), ip);

        if (result.success) {
            let teks = `
✅ *ʙᴇʀʜᴀsɪʟ ᴍᴇᴍʙᴜᴀᴛ sᴜʙᴅᴏᴍᴀɪɴ*

🌐 *sᴜʙᴅᴏᴍᴀɪɴ:* \`${result.name}\`
📌 *ɪᴘ ᴠᴘs:* \`${result.ip}\`
`;
            await bot.sendMessage(msg.chat.id, teks, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
        } else {
            await bot.sendMessage(msg.chat.id, `❌ Gagal membuat subdomain:\n${result.error}`);
        }

        bot.answerCallbackQuery(callbackQuery.id);
    }
});
    
bot.onText(/^\/listsubdo$/, async (msg) => {
  const chatId = msg.chat.id;
  const owners = loadJsonData(OWNER_FILE);

  if (!owners.includes(msg.from.id.toString())) {
    return bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ!");
  }

  const dom = Object.keys(global.subdomain);
  if (dom.length === 0) {
    return bot.sendMessage(chatId, "❌ Tidak ada domain yang tersedia saat ini.");
  }

  let teks = `📜 *ᴅᴀꜰᴛᴀʀ ᴅᴏᴍᴀɪɴ ʏᴀɴɢ ᴛᴇʀꜱᴇᴅɪᴀ*\n\n`;
  dom.forEach((d, i) => {
    teks += `${i + 1}. \`${d}\`\n`;
  });

  bot.sendMessage(chatId, teks, { parse_mode: "Markdown", reply_to_message_id: msg.message_id });
});

// install depend tema
bot.onText(/^\/installdepend (.+)$/, async (msg, match) => {
  notifyOwner('installdepend', msg);
  const chatId = msg.chat.id;
  const text = match[1];

  const owners = loadJsonData(OWNER_FILE);

  if (!owners.includes(msg.from.id.toString())) {
    return bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ!");
  }

  if (!text.includes("|")) {
    return bot.sendMessage(chatId, "⚠️ Format: /installdepend IpVps|PwVps");
  }

  const [ipvps, passwd] = text.split("|").map(item => item.trim());
  if (!ipvps || !passwd) {
    return bot.sendMessage(chatId, "⚠️ Format: /installdepend IpVps|PwVps");
  }

  const loadingMsg = await bot.sendMessage(chatId, "🔍 ᴍᴇɴɢᴜʟᴀꜱ ᴋᴏɴᴇᴋꜱɪ ᴠᴘꜱ...");
  lastMessageContent[chatId] = "🔍 ᴍᴇɴɢᴜʟᴀꜱ ᴋᴏɴᴇᴋꜱɪ ᴠᴘꜱ...";

  const connSettings = {
    host: ipvps,
    port: 22,
    username: "root",
    password: passwd,
    readyTimeout: 15000
  };

  const command = `bash <(curl -s https://raw.githubusercontent.com/KiwamiXq1031/installer-premium/refs/heads/main/zero.sh)`;
  const conn = new Client();

  const progressStages = [
    "🔍 ᴍᴇɴɢᴜʟᴀꜱ ᴋᴏɴᴇᴋꜱɪ ᴠᴘꜱ...",
    "✅ ᴋᴏɴᴇᴋꜱɪ ʙᴇʀʜᴀꜱɪʟ",
    "📦 ᴍᴇɴɢɪɴꜱᴛᴀʟ ᴘᴀᴋᴇᴛ ᴅᴇᴘᴇɴᴅᴇɴꜱɪ...",
    "⚡ ᴍᴇᴍᴘʀᴏꜱᴇꜱ ꜱᴇʟᴇꜱᴀɪ..."
  ];

  let currentStage = 0;

  const updateProgress = async (newText) => {
    if (lastMessageContent[chatId] !== newText) {
      try {
        await bot.editMessageText(newText, {
          chat_id: chatId,
          message_id: loadingMsg.message_id
        });
        lastMessageContent[chatId] = newText;
      } catch (error) {
        if (!error.message.includes('message is not modified')) {
          console.error('Edit message error:', error.message);
        }
      }
    }
  };

  conn
    .on("ready", async () => {
      const newText = "✅ ᴋᴏɴᴇᴋꜱɪ ʙᴇʀʜᴀꜱɪʟ\n⏳ ᴍᴇᴍᴘʀᴏꜱᴇꜱ ɪɴꜱᴛᴀʟʟ ᴅᴇᴘᴇɴᴅ ᴘᴛᴇʀᴏᴅᴀᴄᴛʏʟ...\n⏰ ᴛᴜɴɢɢᴜ 1-10 ᴍᴇɴɪᴛ ʜɪɴɢɢᴀ ᴘʀᴏꜱᴇꜱ ꜱᴇʟᴇꜱᴀɪ ✅";
      await updateProgress(newText);

      conn.exec(command, (err, stream) => {
        if (err) {
          updateProgress("❌ ɢᴀɢᴀʟ ᴍᴇɴɢᴇᴋꜱᴇᴋᴜꜱɪ ᴄᴏᴍᴍᴀɴᴅ!");
          return conn.end();
        }

        let progressUpdated = false;

        stream
          .on("close", async () => {
            try {
              await bot.deleteMessage(chatId, loadingMsg.message_id);
              delete lastMessageContent[chatId];
              await bot.sendMessage(chatId, "✅ ʙᴇʀʜᴀꜱɪʟ ɪɴꜱᴛᴀʟʟ ᴅᴇᴘᴇɴᴅ!\n\n📦 ꜱɪʟᴀᴋᴀɴ ᴋᴇᴛɪᴋ /installtemanebula ipvps|pwvps");
            } catch (error) {
              console.error('Delete message error:', error.message);
            }
            conn.end();
          })
          .on("data", (data) => {
            const output = data.toString();
            console.log("OUTPUT:", output);
            
            if (!progressUpdated && output.includes("Installing")) {
              updateProgress("📦 ᴍᴇɴɢɪɴꜱᴛᴀʟ ᴘᴀᴋᴇᴛ ᴅᴇᴘᴇɴᴅᴇɴꜱɪ...\n⏰ ᴛᴜɴɢɢᴜ ꜱᴇʙᴇɴᴛᴀʀ");
              progressUpdated = true;
            }

            stream.write("11\n");
            stream.write("A\n");
            stream.write("Y\n");
            stream.write("Y\n");
          })
          .stderr.on("data", (data) => {
            console.log("ERROR:", data.toString());
          });
      });
    })
    .on("error", async (err) => {
      console.error("SSH Error:", err.message);
      await updateProgress("❌ ᴋᴀᴛᴀꜱᴀɴᴅɪ ᴀᴛᴀᴜ ɪᴘ ᴛɪᴅᴀᴋ ᴠᴀʟɪᴅ\nᴘᴀꜱᴛɪᴋᴀɴ ᴠᴘꜱ ᴀᴋᴛɪꜰ ᴅᴀɴ ᴋʀᴇᴅᴇɴꜱɪᴀʟ ʙᴇɴᴀʀ!");
    })
    .on("end", () => {
      console.log("SSH Connection closed");
    })
    .connect(connSettings);
});
    
// install tema nebula 
bot.onText(/^\/installtemanebula (.+)$/, async (msg, match) => {
  notifyOwner('installtemanebula', msg);
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const text = match[1];

  const owners = loadJsonData(OWNER_FILE);

  if (!owners.includes(msg.from.id.toString())) {
    return bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ!");
  }

  if (!text.includes("|")) {
    return bot.sendMessage(chatId, "Format: /installtemanebula IpVps|PwVps");
  }

  let [ipvps, passwd] = text.split("|");
  if (!ipvps || !passwd) {
    return bot.sendMessage(chatId, "Format: /installtemanebula IpVps|PwVps");
  }

  const connSettings = {
    host: ipvps,
    port: 22,
    username: "root",
    password: passwd,
  };

  const command = `bash <(curl -s https://raw.githubusercontent.com/KiwamiXq1031/installer-premium/refs/heads/main/zero.sh)`;
  const conn = new Client();

  conn.on("ready", () => {
      bot.sendMessage(chatId, "⏳ ᴍᴇᴍᴘʀᴏꜱᴇꜱ ɪɴꜱᴛᴀʟʟ ᴛᴇᴍᴀ ɴᴇʙᴜʟᴀ ᴘᴛᴇʀᴏᴅᴀᴄᴛʏʟ...\nᴛᴜɴɢɢᴜ 1-10 ᴍᴇɴɪᴛ ʜɪɴɢɢᴀ ᴘʀᴏꜱᴇꜱ ꜱᴇʟᴇꜱᴀɪ ✅");

      conn.exec(command, (err, stream) => {
        if (err) {
          bot.sendMessage(chatId, "❌ Error saat eksekusi command!");
          return conn.end();
        }

        stream
          .on("close", async () => {
            await bot.sendPhoto(chatId, ppNebula, {
              caption: "✅ ʙᴇʀʜᴀꜱɪʟ ɪɴꜱᴛᴀʟʟ ᴛᴇᴍᴀ ɴᴇʙᴜʟᴀ",
              parse_mode: "Markdown",
            });
            conn.end();
          })
          .on("data", (data) => {
            console.log(data.toString());
            stream.write("2\n");
            stream.write("\n");
            stream.write("\n");
          })
          .stderr.on("data", (data) => {
            console.log("STDERR: " + data);
          });
      });
    })
    .on("error", () => {
      bot.sendMessage(chatId, "❌ Katasandi atau IP tidak valid");
    })
    .connect(connSettings);
});
    
    // uninstall tema
bot.onText(/^\/uninstalltema(?:\s+(.+))?/, async (msg, match) => {
  notifyOwner('uninstalltema', msg);
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const text = match[1];
  if (!text) {
    return bot.sendMessage(chatId, "❌ Format salah!\nContoh: /uninstalltema ipvps|pwvps");
  }

  const owners = loadJsonData(OWNER_FILE);

  if (!owners.includes(msg.from.id.toString())) {
    return bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ!");
  }

  if (!text.includes("|")) {
    return bot.sendMessage(chatId, "Format: /uninstalltema IpVps|PwVps");
  }

  let [ipvps, passwd] = text.split("|");
  if (!ipvps || !passwd) {
    return bot.sendMessage(chatId, "Format: /uninstalltema IpVps|PwVps");
  }

  const connSettings = {
    host: ipvps,
    port: 22,
    username: "root",
    password: passwd,
  };

  const command = `bash <(curl -s https://raw.githubusercontent.com/KiwamiXq1031/installer-premium/refs/heads/main/zero.sh)`;
  const conn = new Client();

  conn.on("ready", () => {
      bot.sendMessage(chatId, "⏳ ᴍᴇᴍᴘʀᴏꜱᴇꜱ ᴜɴɪɴꜱᴛᴀʟʟ ᴛᴇᴍᴀ ᴘᴛᴇʀᴏᴅᴀᴄᴛʏʟ...\nᴛᴜɴɢɢᴜ 1-10 ᴍᴇɴɪᴛ ʜɪɴɢɢᴀ ᴘʀᴏꜱᴇꜱ ꜱᴇʟᴇꜱᴀɪ ✅");

      conn.exec(command, (err, stream) => {
        if (err) {
          bot.sendMessage(chatId, "❌ Error saat eksekusi command!");
          return conn.end();
        }

        stream
          .on("close", async () => {
            await bot.sendPhoto(chatId, panel, {
              caption: "✅ ʙᴇʀʜᴀꜱɪʟ ᴜɴɪɴꜱᴛᴀʟʟ ᴛᴇᴍᴀ",
              parse_mode: "Markdown",
            });
            conn.end();
          })
          .on("data", (data) => {
            console.log(data.toString());
            stream.write("9\n");
          })
          .stderr.on("data", (data) => {
            console.log("STDERR: " + data);
          });
      });
    })
    .on("error", () => {
      bot.sendMessage(chatId, "❌ Katasandi atau IP tidak valid");
    })
    .connect(connSettings);
});

    // command /hbpanel
bot.onText(/^\/hbpanel(?:\s+(.+))?/, async (msg, match) => {
  notifyOwner('hbpanel', msg);
  const chatId = msg.chat.id;
  const userId = msg.from.id;

  let text = match[1];
  if (!text) {
    return bot.sendMessage(chatId, "❌ Format salah!\nContoh: /hbpanel ipvps|pwvps");
  }
    
  let t = text.split("|");
  if (t.length < 2) {
    return bot.sendMessage(chatId, "❌ Format salah!\nContoh:\n/hbpanel ipvps|pwvps");
  }

  let ipvps = t[0].trim();
  let passwd = t[1].trim();

  await bot.sendMessage(chatId, "⏳ ᴘʀᴏꜱᴇꜱ ʜᴀᴄᴋʙᴀᴄᴋ ᴘᴀɴᴇʟ...");

  let newuser = "admin" + Math.floor(Math.random() * 9999).toString();
  let newpw = "admin" + Math.floor(Math.random() * 9999).toString();

  const connSettings = {
    host: ipvps,
    port: 22,
    username: "root",
    password: passwd
  };

  const command = `bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/refs/heads/main/install.sh)`;
  const conn = new Client();

  conn.on("ready", () => {
    conn.exec(command, (err, stream) => {
      if (err) throw err;

      stream.on("close", async () => {
        let teks = `
*ʜᴀᴄᴋʙᴀᴄᴋ ᴘᴀɴᴇʟ ꜱᴜᴋꜱᴇꜱ ✅*

*ᴅᴇᴛᴀɪʟ ᴀᴋᴜɴ ᴀᴅᴍɪɴ ᴘᴀɴᴇʟ:*
👤 ᴜꜱᴇʀɴᴀᴍᴇ: \`${newuser}\`
🔑 ᴘᴀꜱꜱᴡᴏʀᴅ: \`${newpw}\`
`;
        await bot.sendMessage(chatId, teks, { parse_mode: "Markdown" });
        conn.end();
      }).on("data", (data) => {
        console.log("STDOUT:", data.toString());
      }).stderr.on("data", (data) => {
        console.log("STDERR:", data.toString());
        stream.write("7\n");
        stream.write(`${newuser}\n`);
        stream.write(`${newpw}\n`);
      });
    });
  }).on("error", (err) => {
    console.log("Connection Error:", err);
    bot.sendMessage(chatId, "❌ ᴋᴀᴛᴀꜱᴀɴᴅɪ ᴀᴛᴀᴜ ɪᴘ ᴛɪᴅᴀᴋ ᴠᴀʟɪᴅ");
  }).connect(connSettings);
});
    
// command /setpwvps
bot.onText(/^\/setpwvps(?:\s+(.+))?/, async (msg, match) => {
  notifyOwner('setpwvps', msg);
  const chatId = msg.chat.id;
  const userId = msg.from.id;
    
  let text = match[1];
  if (!text) {
    return bot.sendMessage(chatId, "❌ Format salah!\nContoh: /setpwvps ipvps|password_lama|password_baru");
  }
    
  let t = text.split("|");
  if (t.length < 3) {
    return bot.sendMessage(chatId, "❌ Format salah!\nContoh:\n/setpwvps ipvps|password_lama|password_baru");
  }

  let ipvps = t[0].trim();
  let passwd = t[1].trim();
  let newpw = t[2].trim();

  await bot.sendMessage(chatId, "⏳  ꜱᴇᴅᴀɴɢ ᴘʀᴏꜱᴇꜱ...");

  const connSettings = {
    host: ipvps,
    port: 22,
    username: "root",
    password: passwd
  };

  const command = `bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/refs/heads/main/install.sh)`;
  const conn = new Client();

  conn.on("ready", () => {
    conn.exec(command, (err, stream) => {
      if (err) throw err;

      stream.on("close", async () => {
        conn.end();
      }).on("data", (data) => {
        console.log("STDOUT:", data.toString());
      }).stderr.on("data", (data) => {
        console.log("STDERR:", data.toString());
        stream.write("8\n");
        stream.write(`${newpw}\n`);
        stream.write(`${newpw}\n`);
      });
    });
  }).on("error", (err) => {
    console.log("Connection Error:", err);
    bot.sendMessage(chatId, "❌ ᴋᴀᴛᴀꜱᴀɴᴅɪ ᴀᴛᴀᴜ ɪᴘ ᴛɪᴅᴀᴋ ᴠᴀʟɪᴅ");
  }).connect(connSettings);
    
    let teks = `
*ꜱᴜᴋꜱᴇꜱ ɢᴀɴᴛɪ ᴘᴀꜱꜱᴡᴏʀᴅ ✅*

*ᴅᴇᴛᴀɪʟ ᴘᴀꜱꜱᴡᴏʀᴅ:*
📌 ɪᴘ ᴠᴘꜱ: \`${ipvps}\`
🔑 ᴘᴀꜱꜱᴡᴏʀᴅ: \`${newpw}\`
`;
        await bot.sendMessage(chatId, teks, { parse_mode: "Markdown" });
});
    
// command /swings
bot.onText(/^\/swings(?:\s+(.+))?/, async (msg, match) => {
  notifyOwner("swings", msg);
  const chatId = msg.chat.id;

  const owners = loadJsonData(OWNER_FILE);
  if (!owners.includes(msg.from.id.toString())) {
    return bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ!");
  }

  const text = match[1];
  if (!text) {
    return bot.sendMessage(chatId, "❌ Format salah!\nContoh: /swings ipvps|pwvps|token_node");
  }

  const t = text.split("|");
  if (t.length < 3) {
    return bot.sendMessage(chatId, "❌ Format salah!\n\nContoh:\n/swings ipvps|pwvps|token_node");
  }

  const ipvps = t[0].trim();
  const passwd = t[1].trim();
  const token = t[2].trim();

  let logs = "🚀 Menjalankan proses wings...\n\n";
  const loadingMsg = await bot.sendMessage(chatId, logs);

  const connSettings = {
    host: ipvps,
    port: 22,
    username: "root",
    password: passwd,
    readyTimeout: 20000
  };

  const conn = new Client();
  const command = token;

  function updateLogs(newLine) {
    logs += newLine + "\n";
    safeEdit(bot, chatId, loadingMsg.message_id, "```\n" + logs.slice(-3500) + "\n```"); // max 4096 limit
  }

  conn.on("ready", () => {
    updateLogs("✅ SSH Connected!");

    conn.exec(command, (err, stream) => {
      if (err) {
        updateLogs("❌ Gagal menjalankan token node.");
        return conn.end();
      }

      updateLogs("▶️ Menjalankan token...");

      stream.stdout.on("data", (data) => updateLogs("TOKEN OUT: " + data.toString().trim()));
      stream.stderr.on("data", (data) => updateLogs("TOKEN ERR: " + data.toString().trim()));

      stream.on("close", () => {
        updateLogs("✅ Token selesai, lanjut jalankan wings...");

        conn.exec("sudo wings", (err2, stream2) => {
          if (err2) {
            updateLogs("❌ Gagal menjalankan wings.");
            return conn.end();
          }

          updateLogs("▶️ Menjalankan wings...");

          stream2.stdout.on("data", (data) => updateLogs("WINGS OUT: " + data.toString().trim()));
          stream2.stderr.on("data", (data) => updateLogs("WINGS ERR: " + data.toString().trim()));

          stream2.on("close", () => {
            updateLogs("✅ Wings berhasil dijalankan!\n\nJika masih merah:\n1. Login VPS di JuiceSSH\n2. Ketik `sudo wings --debug`\n3. Refresh panel");
            conn.end();
          });
        });
      });
    });
  })
  .on("error", (err) => {
    updateLogs("❌ Connection Error: " + err.message);
  })
  .on("end", () => updateLogs("🔌 SSH Connection closed"))
  .connect(connSettings);
});

async function safeEdit(bot, chatId, messageId, text) {
  try {
    await bot.editMessageText(text, {
      chat_id: chatId,
      message_id: messageId,
      parse_mode: "Markdown"
    });
  } catch (e) {
    console.error("Telegram editMessage error:", e.message);
  }
}
    
// command /cwings
bot.onText(/^\/cwings(?:\s+(.+))?/, async (msg, match) => {
  notifyOwner('cwings', msg);
  const chatId = msg.chat.id;
  const messageId = msg.message_id;

  const owners = loadJsonData(OWNER_FILE);

  if (!owners.includes(msg.from.id.toString())) {
    return bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ!");
  }
    
  const text = match[1];
  if (!text) {
    return bot.sendMessage(chatId, "❌ Format salah!\nContoh: /cwings ipvps|pwvps");
  }
    
  if (!text.includes("|")) {
    return bot.sendMessage(chatId, "❌ Format salah!\nContoh: /cwings ipvps|pwvps");
  }

  const [ip, password] = text.split("|").map(x => x.trim());
  const conn = new Client();

  const loadingMsg = await bot.sendMessage(chatId, "🔍 ᴍᴇɴɢʜᴜʙᴜɴɢᴋᴀɴ ᴋᴇ ᴠᴘꜱ...");

  const progressStages = [
    "🔗 ᴍᴇɴɢʜᴜʙᴜɴɢᴋᴀɴ ᴋᴇ ᴠᴘꜱ...",
    "📡 ᴍᴇɴɢᴇᴄᴇᴋ ꜱᴛᴀᴛᴜꜱ ᴡɪɴɢꜱ...",
    "⚡ ᴍᴇᴍᴘʀᴏꜱᴇꜱ ɪɴꜰᴏʀᴍᴀꜱɪ...",
    "✅ ᴍᴇɴɢᴀɴᴀʟɪꜱᴀ ʜᴀꜱɪʟ..."
  ];

  let currentStage = 0;

  const updateProgress = async (newText) => {
  if (lastMessageContent[chatId] !== newText) {
    try {
      await bot.editMessageText(newText, {
        chat_id: chatId,
        message_id: loadingMsg.message_id
      });
      lastMessageContent[chatId] = newText;
    } catch (error) {
      if (!error.message.includes('message is not modified')) {
        console.error('Edit message error:', error.message);
      }
    }
  }
};

  conn.on("ready", async () => {
    await updateProgress();

    conn.exec("systemctl is-active wings", (err, stream) => {
      if (err) {
        console.error("SSH EXEC ERROR:", err);
        bot.editMessageText("❌ ɢᴀɢᴀʟ ᴍᴇɴᴊᴀʟᴀɴᴋᴀɴ ᴘᴇɴɢᴇᴄᴇᴋᴀɴ ᴡɪɴɢꜱ.", {
          chat_id: chatId,
          message_id: loadingMsg.message_id
        });
        return conn.end();
      }

      let output = "";
      
      stream.on("data", (data) => {
        output += data.toString();
        console.log("STDOUT:", data.toString());
        updateProgress();
      });
      
      stream.stderr.on("data", (data) => {
        output += data.toString();
        console.log("STDERR:", data.toString());
        updateProgress();
      });

      stream.on("close", async () => {
        await updateProgress();
        conn.end();
        
        setTimeout(async () => {
          await bot.deleteMessage(chatId, loadingMsg.message_id);
          
          const status = output.trim();
          let statusEmoji = "❓";
          let statusText = "ᴛɪᴅᴀᴋ ᴅɪᴋᴇᴛᴀʜᴜɪ";
          let description = "";

          if (status === "active") {
            statusEmoji = "✅";
            statusText = "ᴀᴋᴛɪꜰ";
            description = "ᴡɪɴɢꜱ ʙᴇʀᴊᴀʟᴀɴ ᴅᴇɴɢᴀɴ ʟᴀɴᴄᴀʀ";
          } else if (status === "inactive") {
            statusEmoji = "🛑";
            statusText = "ᴛɪᴅᴀᴋ ᴀᴋᴛɪꜰ";
            description = "ᴡɪɴɢꜱ ᴛɪᴅᴀᴋ ᴅᴀᴘᴀᴛ ᴅɪᴊᴀʟᴀɴᴋᴀɴ";
          } else if (status === "failed") {
            statusEmoji = "❌";
            statusText = "ɢᴀɢᴀʟ";
            description = "ᴛᴇʀᴊᴀᴅɪ ᴋᴇꜱᴀʟᴀʜᴀɴ ꜱᴀᴀᴛ ᴍᴇᴍᴜʟᴀɪ";
          } else {
            description = `ᴏᴜᴛᴘᴜᴛ: ${status}`;
          }

          const message = `
🌐 *ʜᴀꜱɪʟ ᴘᴇɴɢᴇᴄᴇᴋᴀɴ ᴡɪɴɢꜱ*

📡 **ɪᴘ ᴠᴘꜱ:** ${ip}
${statusEmoji} **ꜱᴛᴀᴛᴜꜱ:** ${statusText.toUpperCase()}
📊 **ᴅᴇꜱᴋʀɪᴘꜱɪ:** ${description}

${status === "inactive" ? "🔌 ꜱɪʟᴀʜᴋᴀɴ ꜱᴛᴀʀᴛ ᴡɪɴɢꜱ ᴅᴇɴɢᴀɴ /swings ip|password|token" : "✨ ꜱᴇᴍᴜᴀɴʏᴀ ᴛᴇʀʟɪʜᴀᴛ ʙᴀɪᴋ"}
          `.trim();

          await bot.sendMessage(chatId, message, { 
            parse_mode: "Markdown",
            reply_to_message_id: messageId
          });
        }, 1000);
      });
    });
  }).on("error", async (err) => {
    console.error("SSH CONNECTION ERROR:", err.message);
    await bot.editMessageText("❌ ᴛɪᴅᴀᴋ ᴅᴀᴘᴀᴛ ᴛᴇʀʜᴜʙᴜɴɢ ᴋᴇ ᴠᴘꜱ!\n\nᴘᴀꜱᴛɪᴋᴀɴ:\n• ɪᴘ ᴅᴀɴ ᴘᴀꜱꜱᴡᴏʀᴅ ʙᴇɴᴀʀ\n• ᴠᴘꜱ ꜱᴇᴅᴀɴɢ ᴀᴋᴛɪꜰ\n• ᴋᴏɴᴇᴋꜱɪ ɪɴᴛᴇʀɴᴇᴛ ꜱᴛᴀʙɪʟ", {
      chat_id: chatId,
      message_id: loadingMsg.message_id
    });
  }).connect({
    host: ip,
    port: 22,
    username: "root",
    password: password,
    readyTimeout: 15000
  });
});

// command /installpanel
bot.onText(/^\/install$/, (msg) => {
  notifyOwner('install', msg);
  const chatId = msg.chat.id;
  
  const owners = loadJsonData(OWNER_FILE);
  if (!owners.includes(msg.from.id.toString())) {
    return bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ");
  }

  userStates[chatId] = {
    step: 'select_type',
    data: {}
  };

  const options = {
    reply_markup: {
      inline_keyboard: [
        [{ text: '< 1 > ɪɴꜱᴛᴀʟʟ ᴘᴀɴᴇʟ', callback_data: 'install_panel' }],
        [{ text: '< 2 > ɪɴꜱᴛᴀʟʟ ᴡɪɴɢꜱ', callback_data: 'install_wings' }]
      ]
    }
  };

  bot.sendMessage(chatId, `📡 ᴍᴇɴᴜ ɪɴꜱᴛᴀʟʟᴀꜱɪ ᴘᴀɴᴇʟ\nᴛʜᴀɴᴋꜱ ꜰʀᴏᴍ @${dev}`, options)});

async function installPanel(chatId, ip, password, domainpanel) {
  const conn = new Client();
  const random = Math.floor(1000 + Math.random() * 9000);
  const namaAcak = `admin${random}`;
  const emailAcak = `admin${random}@gmail.com`;

  let fullLog = `📡 Menghubungkan ke VPS *${ip}*...\n`;
  fullLog += `Silakan tunggu 10-20 menit\n\n`;
  fullLog += `🌐 Domain: https://${domainpanel}\n✉ Email: ${emailAcak}\n\n⏳ Proses install sedang berjalan...`;

  // kirim pesan awal
  const sent = await bot.sendMessage(chatId, fullLog, { parse_mode: "Markdown" });
  let lastUpdate = Date.now();

  conn.on("ready", () => {
    conn.exec("bash <(curl -s https://pterodactyl-installer.se)", (err, stream) => {
      if (err) {
        conn.end();
        return safeEdit(sent, fullLog + `\n❌ Gagal menjalankan installer.`);
      }

      stream.on("data", async (data) => {
        const out = data.toString();
        fullLog += `\n${out}`;

        if (Date.now() - lastUpdate > 2000) {
          lastUpdate = Date.now();
          safeEdit(sent, "📡 Proses Install Panel:\n```\n" + fullLog.slice(-3000) + "\n```", "Markdown");
        }

        if (out.includes("Input 0-6")) stream.write("0\n");
        if (out.includes("Database name (panel)")) stream.write(`${namaAcak}\n`);
        if (out.includes("Database username (pterodactyl)")) stream.write(`${namaAcak}\n`);
        if (out.includes("Password (press enter")) stream.write(`\n`);
        if (out.includes("Select timezone")) stream.write(`Asia/Jakarta\n`);
        if (out.includes("Provide the email address")) stream.write(`${emailAcak}\n`);
        if (out.includes("Email address for the initial admin account")) stream.write(`${emailAcak}\n`);
        if (out.includes("Username for the initial admin account")) stream.write(`${namaAcak}\n`);
        if (out.includes("First name for the initial admin account")) stream.write(`${namaAcak}\n`);
        if (out.includes("Last name for the initial admin account")) stream.write(`${namaAcak}\n`);
        if (out.includes("Password for the initial admin account")) stream.write(`${random}\n`);
        if (out.includes("Set the FQDN")) stream.write(`${domainpanel}\n`);
        if (out.includes("(y/N)")) stream.write("y\n");
        if (out.includes("Enable sending anonymous telemetry")) stream.write("yes\n");
        if (out.includes("(Y)es/(N)o")) stream.write("Y\n");
      });

      stream.on("close", async (code) => {
        conn.end();
        if (code === 0) {
          safeEdit(sent, `
✅ *Sukses install Panel!*

📌 IP VPS: \`${ip}\`
🔑 Password VPS: \`${password}\`

🌐 Panel: https://${domainpanel}
👤 User: \`${namaAcak}\`
🔐 Password Panel: \`${random}\`
`, "Markdown");
        } else {
          safeEdit(sent, fullLog + `\n⚠️ Installer selesai dengan kode ${code}. Cek manual di VPS.`);
        }
      });

      stream.stderr.on("data", async (data) => {
        const errOut = data.toString();
        fullLog += `\n[ERR] ${errOut}`;
        if (Date.now() - lastUpdate > 2000) {
          lastUpdate = Date.now();
          safeEdit(sent, "📡 Proses Install Panel:\n```\n" + fullLog.slice(-3000) + "\n```", "Markdown");
        }
      });
    });
  }).on("error", (err) => {
    safeEdit(sent, `❌ Gagal konek ke VPS:\n${err.message}`);
  }).connect({
    host: ip,
    port: 22,
    username: "root",
    password: password,
    readyTimeout: 20000
  });

  async function safeEdit(msgObj, newText, mode) {
    try {
      await bot.editMessageText(newText, {
        chat_id: msgObj.chat.id,
        message_id: msgObj.message_id,
        parse_mode: mode || undefined
      });
    } catch (e) {
      if (e.response && e.response.statusCode === 429) {
        console.log("⚠️ Rate limit Telegram, tunggu sebentar...");
      } else {
        console.log("❌ Edit error:", e.message);
      }
    }
  }
}

// fungsi instalasi wings
async function installWings(chatId, ip, password, domainpanel, domainnode) {
  const conn = new Client();
  const random = Math.floor(1000 + Math.random() * 9000);
  const emailAcak = `admin${random}@gmail.com`;
  const userDB = `admin${Math.floor(1000 + Math.random() * 9000)}`;
  const passDB = `${Math.floor(1000 + Math.random() * 9000)}`;

  let fullLog = `📡 Menghubungkan ke VPS *${ip}*...\n`;
  fullLog += `Silakan tunggu 10-20 menit\n\n`;
  fullLog += `🌐 Panel: https://${domainpanel}\n🛰️ Node: ${domainnode}\n✉ Email: ${emailAcak}\n\n`;
  fullLog += `🗃️ User DB: ${userDB}\n🔐 Pass DB: ${passDB}\n\n⏳ Proses install sedang berjalan...`;

  // kirim pesan awal
  const sent = await bot.sendMessage(chatId, fullLog, { parse_mode: "Markdown" });
  let lastUpdate = Date.now();

  conn.on("ready", () => {
    conn.exec("bash <(curl -s https://pterodactyl-installer.se)", (err, stream) => {
      if (err) {
        conn.end();
        return safeEdit(sent, fullLog + `\n❌ Gagal menjalankan installer di VPS.`);
      }

      stream.on("data", async (data) => {
        const out = data.toString();
        fullLog += `\n${out}`;

        if (Date.now() - lastUpdate > 2000) {
          lastUpdate = Date.now();
          safeEdit(sent, "📡 Proses Install Wings:\n```\n" + fullLog.slice(-3000) + "\n```", "Markdown");
        }

        if (out.includes("Input 0-6")) stream.write("1\n");
        if (out.includes("(y/N)")) stream.write("y\n");
        if (out.includes("Enter the panel address")) stream.write(`${domainpanel}\n`);
        if (out.includes("Database host username")) stream.write(`${userDB}\n`);
        if (out.includes("Database host password")) stream.write(`${passDB}\n`);
        if (out.includes("Set the FQDN to use for Let's Encrypt")) stream.write(`${domainnode}\n`);
        if (out.includes("Enter email address")) stream.write(`${emailAcak}\n`);
      });

      stream.on("close", async (code) => {
        conn.end();
        if (code === 0) {
          safeEdit(sent, `
✅ *Wings berhasil diinstall!*

📌 IP VPS: \`${ip}\`
🔑 Password VPS: \`${password}\`

🌐 Panel: ${domainpanel}
🛰️ Node: ${domainnode}
✉ Email: ${emailAcak}
`, "Markdown");
        } else {
          safeEdit(sent, fullLog + `\n⚠️ Installer selesai dengan kode ${code}. Beberapa bagian mungkin gagal, cek manual VPS.`);
        }
      });

      stream.stderr.on("data", async (data) => {
        const errOut = data.toString();
        fullLog += `\n[ERR] ${errOut}`;
        if (Date.now() - lastUpdate > 2000) {
          lastUpdate = Date.now();
          safeEdit(sent, "📡 Proses Install Wings:\n```\n" + fullLog.slice(-3000) + "\n```", "Markdown");
        }
      });
    });
  }).on("error", (err) => {
    safeEdit(sent, `❌ Gagal konek ke VPS:\n${err.message}`);
  }).connect({
    host: ip,
    port: 22,
    username: "root",
    password: password,
    readyTimeout: 20000
  });

  async function safeEdit(msgObj, newText, mode) {
    try {
      await bot.editMessageText(newText, {
        chat_id: msgObj.chat.id,
        message_id: msgObj.message_id,
        parse_mode: mode || undefined
      });
    } catch (e) {
      if (e.response && e.response.statusCode === 429) {
        console.log("⚠️ Rate limit Telegram, skip update sebentar...");
      } else if (e.response && e.response.statusCode === 400) {
        console.log("⚠️ Pesan target tidak ditemukan (mungkin sudah dihapus).");
      } else {
        console.log("❌ Edit error:", e.message);
      }
    }
  }
}
    
bot.on('callback_query', async (callbackQuery) => {
  const chatId = callbackQuery.message.chat.id;
  const data = callbackQuery.data;

  if (!userStates[chatId] || userStates[chatId].step !== 'select_type') {
    return;
  }

  if (data === 'install_panel' || data === 'install_wings') {
    userStates[chatId].type = data;
    userStates[chatId].step = 'ip';
    
    bot.deleteMessage(chatId, callbackQuery.message.message_id);
    
    bot.sendMessage(chatId, '📌 ᴍᴀꜱᴜᴋᴋᴀɴ ɪᴘ ᴠᴘꜱ:');
    bot.answerCallbackQuery(callbackQuery.id);
  }
});

bot.on('message', async (msg) => {
  const chatId = msg.chat.id;
  const text = msg.text;
  
  if (!text || text.startsWith('/')) return;
  
  if (!userStates[chatId]) return;
  
  const state = userStates[chatId];
  
  try {
    switch (state.step) {
      case 'ip':
        if (!isValidIP(text)) {
          return bot.sendMessage(chatId, '❌ Format IP tidak valid. Silakan masukkan IP VPS yang benar:');
        }
        
        state.data.ip = text;
        state.step = 'password';
        bot.sendMessage(chatId, '🔑 ᴍᴀꜱᴜᴋᴋᴀɴ ᴘᴀꜱꜱᴡᴏʀᴅ ᴠᴘꜱ:');
        break;
        
      case 'password':
        state.data.password = text;
        
        if (state.type === 'install_panel') {
          state.step = 'domain_panel';
          bot.sendMessage(chatId, '🌐 ᴍᴀꜱᴜᴋᴋᴀɴ ᴅᴏᴍᴀɪɴ ᴘᴀɴᴇʟ:');
        } else if (state.type === 'install_wings') {
          state.step = 'domain_panel_wings';
          bot.sendMessage(chatId, '🌐 ᴍᴀꜱᴜᴋᴋᴀɴ ᴅᴏᴍᴀɪɴ ᴘᴀɴᴇʟ:');
        }
        break;
        
      case 'domain_panel':
        state.data.domainpanel = text;
        
        await installPanel(chatId, state.data.ip, state.data.password, state.data.domainpanel);
        
        delete userStates[chatId];
        break;
        
      case 'domain_panel_wings':
        state.data.domainpanel = text;
        state.step = 'domain_node';
        bot.sendMessage(chatId, '🛰 ᴍᴀꜱᴜᴋᴋᴀɴ ᴅᴏᴍᴀɪɴ ɴᴏᴅᴇ:');
        break;
        
      case 'domain_node':
        state.data.domainnode = text;
        
        await installWings(chatId, state.data.ip, state.data.password, state.data.domainpanel, state.data.domainnode);
        
        delete userStates[chatId];
        break;
    }
  } catch (error) {
    console.error('Error dalam proses instalasi:', error);
    bot.sendMessage(chatId, '❌ Terjadi kesalahan dalam proses instalasi. Silakan coba lagi.');
    delete userStates[chatId];
  }
});

bot.onText(/^\/uninstallpanel(?:\s+(.+))?$/, async (msg, match) => {
  notifyOwner('uninstallpanel', msg);
  const chatId = msg.chat.id;
  const text = match[1];

  if (!text) {
    return bot.sendMessage(chatId, "❌ Format salah!\nContoh: /uninstallpanel ip|password");
  }

  const owners = loadJsonData(OWNER_FILE);

  if (!owners.includes(msg.from.id.toString())) {
    return bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ!");
  }
   
  const [ip, password] = text.split("|");
  if (!ip || !password) {
    return bot.sendMessage(chatId, "❌ Format salah!\nContoh: /uninstallpanel ip|password", { parse_mode: "Markdown" });
  }

  const conn = new Client();
  const random = Math.floor(1000 + Math.random() * 9000);

  bot.sendMessage(chatId, `
📡 ᴍᴇɴɢʜᴜʙᴜɴɢᴋᴀɴ ᴋᴇ ᴠᴘꜱ *${ip}*
ꜱɪʟᴀʜᴋᴀɴ ᴛᴜɴɢɢᴜ 10-20 ᴍᴇɴɪᴛ...`, { parse_mode: "Markdown" });

  conn.on("ready", () => {
    conn.exec("bash <(curl -s https://pterodactyl-installer.se)", (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(chatId, "❌ Gagal menjalankan installer.");
      }

      stream.on("close", (code) => {
        conn.end();
        if (code === 0) {
          bot.sendMessage(chatId, `
✅ *ꜱᴜᴋꜱᴇꜱ ᴜɴɪɴꜱᴛᴀʟʟ ᴘᴀɴᴇʟ!*

📌 ɪᴘ ᴠᴘꜱ: \`${ip}\`
🔑 ᴘᴀꜱꜱᴡᴏʀᴅ: \`${password}\`

ᴜɴᴛᴜᴋ ɪɴꜱᴛᴀʟʟ ᴋᴇᴍʙᴀʟɪ, ᴋᴇᴛɪᴋ /install!
`, { parse_mode: "Markdown" });
        } else {
          bot.sendMessage(chatId, `⚠️ ɪɴꜱᴛᴀʟʟᴇʀ ꜱᴇʟᴇꜱᴀɪ ᴅᴇɴɢᴀɴ ᴋᴏᴅᴇ ${code}. ʙᴇʙᴇʀᴀᴘᴀ ᴍᴜɴɢᴋɪɴ ɢᴀɢᴀʟ. ᴄᴇᴋ ᴍᴀɴᴜᴀʟ ᴠᴘꜱ.`);
        }
      });

      stream.on("data", (data) => {
        const out = data.toString();
        console.log("INSTALL >>", out);

        if (out.includes("Input 0-6")) stream.write("6\n");
        if (out.includes("Do you want to remove panel? (y/N)")) stream.write("y\n");
        if (out.includes("Do you want to remove Wings (daemon)? (y/N)")) stream.write("y\n");
        if (out.includes("Continue with uninstallation? (y/N)")) stream.write("y\n");
        if (out.includes("Choose the panel database (to skip don't input anything)")) stream.write("\n");
        if (out.includes("Database called panel has been detected. Is it the pterodactyl database? (y/N)")) stream.write("y\n");
        if (out.includes("User called pterodactyl has been detected. Is it the pterodactyl user? (y/N)")) stream.write("y\n");
      });

      stream.stderr.on("data", (data) => {
        console.error("STDERR:", data.toString());
      });
    });
  }).on("error", (err) => {
    bot.sendMessage(chatId, `❌ Gagal konek ke VPS:\n${err.message}`);
  }).connect({
    host: ip,
    port: 22,
    username: "root",
    password: password,
    readyTimeout: 20000
  });
});

bot.onText(/^\/uninstallwings(?:\s+(.+))?$/, async (msg, match) => {
  notifyOwner('uninstallwings', msg);
  const chatId = msg.chat.id;
  const text = match[1];
  
  if (!text) {
    return bot.sendMessage(chatId, "❌ Format salah!\nContoh: /uninstallwings ip|password");
  }

  const owners = loadJsonData(OWNER_FILE);

  if (!owners.includes(msg.from.id.toString())) {
    return bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ᴏᴡɴᴇʀ!");
  }
    
  const [ip, password] = text.split("|");
  if (!ip || !password) {
    return bot.sendMessage(chatId, "❌ Format salah!\nGunakan:\n`/uninstallwings ip|password`", { parse_mode: "Markdown" });
  }

  const conn = new Client();
  bot.sendMessage(chatId, `🛠 ᴍᴇɴɢʜᴜʙᴜɴɢᴋᴀɴ ᴋᴇ ᴠᴘꜱ *${ip}*...\nꜱᴇᴅᴀɴɢ ᴘʀᴏꜱᴇꜱ ᴜɴɪɴꜱᴛᴀʟʟ ᴡɪɴɢꜱ + ʀᴇꜱᴇᴛ ᴘᴏʀᴛ`, { parse_mode: "Markdown" });

  conn.on("ready", () => {
    const script = `
systemctl stop wings
systemctl disable wings
rm -f /etc/systemd/system/wings.service
rm -f /usr/local/bin/wings
rm -rf /etc/pterodactyl
rm -rf /var/lib/pterodactyl
`;

    conn.exec(script, (err, stream) => {
      if (err) {
        conn.end();
        return bot.sendMessage(chatId, "❌ Gagal mengeksekusi perintah di VPS.");
      }

      stream.on("close", (code) => {
        conn.end();
        if (code === 0) {
          bot.sendMessage(chatId, `✅ *Wings berhasil dihapus dari VPS ${ip}*\n🧹 Port 8080 & 2022 juga dibersihkan.`, { parse_mode: "Markdown" });
        } else {
          bot.sendMessage(chatId, `⚠️ Selesai dengan kode ${code}. Sebagian mungkin gagal. Periksa manual.`);
        }
      }).on("data", (data) => {
        console.log("STDOUT:", data.toString());
      }).stderr.on("data", (data) => {
        console.error("STDERR:", data.toString());
      });
    });
  }).on("error", (err) => {
    bot.sendMessage(chatId, `❌ Tidak bisa konek ke VPS:\n${err.message}`);
  }).connect({
    host: ip,
    port: 22,
    username: "root",
    password: password,
    readyTimeout: 15000
  });
});

bot.onText(/^\/usrpanel(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  
  if (!text) {
    return bot.sendMessage(chatId, "❌ Format salah!\nContoh: /usrpanel ip|password");
  }

  if (!text.includes("|")) {
    return bot.sendMessage(chatId, "❌ Format salah!\nContoh: /usrpanel ipvps|password");
  }

  const [ip, password] = text.split("|");
  if (!ip || !password) {
    return bot.sendMessage(chatId, "❌ Format tidak valid.\nGunakan: /usrpanel ipvps|password");
  }

  const sshConfig = {
    host: ip,
    port: 22,
    username: "root",
    password: password.trim()
  };

  const conn = new Client();

  conn.on("ready", () => {
    conn.exec(
      'cd /var/www/pterodactyl && php artisan tinker --execute="print_r(Pterodactyl\\\\Models\\\\User::all([\'id\',\'username\',\'email\'])->toArray());"',
      (err, stream) => {
        if (err) {
          bot.sendMessage(chatId, "❌ Gagal eksekusi command.");
          return conn.end();
        }

        let output = "";
        stream.on("data", (data) => {
          output += data.toString();
        });

        stream.on("close", () => {
          conn.end();
          if (!output.trim()) {
            return bot.sendMessage(chatId, "❌ Tidak ada output dari server.");
          }

          if (output.length > 3500) {
            output = output.slice(0, 3500) + "\n... (dipotong)";
          }
          bot.sendMessage(chatId, "📋 Daftar User Panel\nOutput:\n```\n" + output + "\n```", {
            parse_mode: "Markdown"
          });
        });
      }
    );
  }).on("error", (err) => {
    bot.sendMessage(chatId, "❌ Gagal konek SSH: " + err.message);
  }).connect(sshConfig);
});

bot.onText(/^\/usrpasswd(?:\s+(.+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const text = match[1];
  
  if (!text) {
    return bot.sendMessage(chatId, "❌ Format salah!\nContoh: /usrpasswd ip|password");
  }

  const parts = text.split("|");
  if (parts.length < 4) {
    return bot.sendMessage(
      chatId,
      "❌ Format salah!\nContoh: /usrpasswd ipvps|passwordroot|iduser|passwordbaru"
    );
  }

  const [ip, rootPass, userId, newPass] = parts;

  const sshConfig = {
    host: ip,
    port: 22,
    username: "root",
    password: rootPass.trim()
  };

  const conn = new Client();

  conn.on("ready", () => {
    const cmd = `cd /var/www/pterodactyl && php artisan tinker --execute="if(Pterodactyl\\Models\\User::find(${userId})){ Pterodactyl\\Models\\User::find(${userId})->update(['password' => bcrypt('${newPass}')]); echo 'Password user ID ${userId} berhasil diubah'; } else { echo 'User tidak ditemukan'; }"`;

    conn.exec(cmd, (err, stream) => {
      if (err) {
        bot.sendMessage(chatId, "❌ Gagal eksekusi command.");
        return conn.end();
      }

      let output = "";
      stream.on("data", (data) => {
        output += data.toString();
      });

      stream.on("close", () => {
        conn.end();
        if (!output.trim()) output = "❌ Tidak ada respon dari server.";
        bot.sendMessage(chatId, "🔑 Output:\n```\n" + output.trim() + "\n```", {
          parse_mode: "Markdown"
        });
      });
    });
  }).on("error", (err) => {
    bot.sendMessage(chatId, "❌ Gagal konek SSH: " + err.message);
  }).connect(sshConfig);
});

// /clearall user&server panel
bot.onText(/^\/clearall (.+)$/, async (msg, match) => {
    const chatId = msg.chat.id;
    const userId = msg.from.id;

    const params = match[1].split('|');
    if (params.length !== 2) {
        return bot.sendMessage(chatId, '❌ Format salah! Gunakan: /clearall ipvps|pwvps');
    }

    const [ipvps, pwvps] = params;

    try {
        const processingMsg = await bot.sendMessage(chatId, '🔄 ᴍᴇᴍᴘʀᴏꜱᴇꜱ ᴄʟᴇᴀʀ ᴀʟʟ...');

        // koneksi SSH
        const conn = new Client();
        let sshOutput = '';

        conn.on('ready', () => {
            console.log('SSH Connection Ready');
            
            const cmd = `cd /var/www/pterodactyl && php artisan tinker --execute="DB::statement('SET FOREIGN_KEY_CHECKS=0;'); \\\\Pterodactyl\\\\Models\\\\User::truncate(); \\\\Pterodactyl\\\\Models\\\\Server::truncate(); DB::statement('SET FOREIGN_KEY_CHECKS=1;'); echo 'Clear all berhasil dilakukan!';"`;
            
            conn.exec(cmd, (err, stream) => {
                if (err) {
                    bot.editMessageText(`❌ SSH Error: ${err.message}`, {
                        chat_id: chatId,
                        message_id: processingMsg.message_id
                    });
                    return conn.end();
                }
                
                stream.on('close', (code, signal) => {
                    console.log('Stream closed');
                    conn.end();
                    
                    bot.editMessageText(`✅ Sukses clear all User & Server!
ᴏᴜᴛᴘᴜᴛ:
\`\`\`
${sshOutput || 'Tidak ada output'}
\`\`\`
`, {
                        chat_id: chatId,
                        parse_mode: "Markdown",
                        message_id: processingMsg.message_id
                    });
                }).on('data', (data) => {
                    sshOutput += data.toString();
                }).stderr.on('data', (data) => {
                    sshOutput += data.toString();
                });
            });
        });

        conn.on('error', (err) => {
            console.error('SSH Connection Error:', err);
            bot.editMessageText(`❌ SSH Connection Error: ${err.message}`, {
                chat_id: chatId,
                message_id: processingMsg.message_id
            });
        });

        conn.on('end', () => {
            console.log('SSH Connection Ended');
        });

        // Connect to SSH
        conn.connect({
            host: ipvps,
            port: 22,
            username: 'root',
            password: pwvps
        });

    } catch (error) {
        console.error('Error:', error);
        bot.sendMessage(chatId, `❌ Terjadi error: ${error.message}`);
    }
});
    
}