const fs = require("fs");

const PRIVATE_FILE = "./db/users/private/privateID.json";
const PRIVPREM_FILE = "./db/users/private/privatePrem.json";
const PRIVRESS_FILE = "./db/users/private/privateRess.json";
const CADMIN_FILE = "./db/cadmin.json";

const settings = require("../settings.js");
const dev = settings.dev;
const OWNER_ID = settings.ownerId;
const ALLOWED_GROUP_ID = settings.exPGroupId;
const panel = settings.panel;

const domain = settings.domainV2;
const plta = settings.pltaV2;
const pltc = settings.pltcV2;
const eggs = settings.eggs;
const locs = settings.loc;

// fungsi load json file
function loadJsonData(filename) {
    try {
        if (fs.existsSync(filename)) {
            const data = fs.readFileSync(filename, 'utf8');
            return JSON.parse(data);
        }
    } catch (error) {
        console.error(`Error loading ${filename}:`, error);
    }
    return [];
}

// fungsi save json file
function saveJsonData(filename, data) {
    try {
        fs.writeFileSync(filename, JSON.stringify(data, null, 4));
        return true;
    } catch (error) {
        console.error(`Error saving ${filename}:`, error);
        return false;
    }
}

if (!fs.existsSync(PRIVATE_FILE)) {
    saveJsonData(PRIVATE_FILE, []);
}

if (!fs.existsSync(PRIVPREM_FILE)) {
    saveJsonData(PRIVPREM_FILE, []);
}

if (!fs.existsSync(PRIVRESS_FILE)) {
    saveJsonData(PRIVRESS_FILE, []);
}

if (!fs.existsSync(CADMIN_FILE)) {
    saveJsonData(CADMIN_FILE, []);
}

module.exports = (bot) => {
    // log command
function notifyOwner(commandName, msg) {
    const userId = msg.from.id;
    const username = msg.from.username || msg.from.first_name;
    const chatId = msg.chat.id;
    const now = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });

    const logMessage = `<pre>📌 Command: /${commandName}
👤 User: @${username}
🆔 ID: ${userId}
🕒 Waktu: ${now}
</pre>
    `;
    bot.sendMessage(OWNER_ID, logMessage, { parse_mode: 'HTML' });
}
    
    // createadmin
bot.onText(/\/cadmin(?:\s+(.+))?/, async (msg, match) => {
  notifyOwner('cadmin', msg);
  const chatId = msg.chat.id;
  const userId = msg.from.id;
  const text = match[1];
    
  if (msg.chat.type !== "group" && msg.chat.type !== "supergroup") {
  bot.sendMessage(msg.chat.id, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  return;
}
    
  if (!text) {
      return bot.sendMessage(chatId,
"❌ Format salah!\nContoh: /cadmin nama,id");
  }
    
  const privPrem = JSON.parse(fs.readFileSync(PRIVPREM_FILE));
  const isPrivPrem = privPrem.includes(String(msg.from.id));
    
  if (!isPrivPrem) {
    bot.sendMessage(chatId, "ᴋʜᴜsᴜs ᴘʀᴇᴍɪᴜᴍ ᴘʀɪᴠᴀᴛᴇ!", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ʙᴜʏ ᴘʀɪᴠᴀᴛᴇ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
  
  const commandParams = match[1].split(",");
if (commandParams.length < 2) {
  bot.sendMessage(
    chatId,
    "Format Salah! Penggunaan: /cadmin nama,idtele"
  );
  return;
}

  const panelName = commandParams[0].trim();
  const telegramId = commandParams[1].trim();

  const password = panelName + Math.random().toString(36).slice(2, 5);
    
  try {
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: `${panelName}@admin.${dev}`,
        username: panelName,
        first_name: panelName,
        last_name: "admin",
        language: "en",
        root_admin: true,
        password: password,
      }),
    });
    const data = await response.json();
    if (data.errors) {
      bot.sendMessage(chatId, JSON.stringify(data.errors[0], null, 2));
      return;
    }
    const user = data.attributes;
    const userInfo = `
TYPE: ADMIN PANEL PRIVATE
➟ ID: ${user.id}
➟ USERNAME: ${user.username}
➟ EMAIL: ${user.email}
➟ NAME: ${user.first_name} ${user.last_name}
➟ LANGUAGE: ${user.language}
➟ ADMIN: ${user.root_admin}
➟ CREATED AT: ${user.created_at}
    `;
    bot.sendMessage(chatId, userInfo);
     
    const caption = `🔐 Sukses Created Admin Panel!

👤 Username: <code>${user.username}</code>
🔑 Password: <code>${password}</code>
🌐 Login: ${domain}

<blockquote>📌 Catatan :
Simpan informasi data ini dengan aman
dan jangan bagikan ke orang lain!
</blockquote>
`;

bot.sendPhoto(telegramId, panel, { caption, parse_mode: "HTML" });
      
let db = [];
if (fs.existsSync(CADMIN_FILE)) {
  db = JSON.parse(fs.readFileSync(CADMIN_FILE));
}

if (!db.includes(String(userId))) {
  db.push(String(userId));
  fs.writeFileSync(CADMIN_FILE, JSON.stringify(db, null, 2));
}
   
  } catch (error) {
    console.error(error);
    bot.sendMessage(
      chatId,
      "Terjadi kesalahan dalam pembuatan admin. Silakan coba lagi nanti."
    );
  }
});
    
bot.onText(/\/listcadmin/, (msg) => {
  const chatId = msg.chat.id;

  if (!fs.existsSync(CADMIN_FILE)) {
    return bot.sendMessage(chatId, "❌ Belum ada data cadmin tersimpan.");
  }

  const db = JSON.parse(fs.readFileSync(CADMIN_FILE));

  if (db.length === 0) {
    return bot.sendMessage(chatId, "❌ Tidak user yang tercatat.");
  }

  let text = "📋 <b>User yang pakai /cadmin:</b>\n\n";
  db.forEach((id, index) => {
    text += `${index + 1}. <code>${id}</code>\n`;
  });

  bot.sendMessage(chatId, text, { parse_mode: "HTML" });
});

    // createunli
bot.onText(/\/cunli(?:\s+(.+))?/, async (msg, match) => {
  notifyOwner('cunli', msg);
  const chatId = msg.chat.id;
  const text = match[1];
    
  if (msg.chat.type !== "group" && msg.chat.type !== "supergroup") {
  bot.sendMessage(msg.chat.id, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  return;
}
    
  if (!text) {
      return bot.sendMessage(chatId,
"❌ Format salah!\nContoh: /cunli nama,id");
  }

  const privRess = JSON.parse(fs.readFileSync(PRIVRESS_FILE));
  const isPrivRess = privRess.includes(String(msg.from.id));
    
  if (!isPrivRess) {
    bot.sendMessage(chatId, "ᴋʜᴜsᴜs ʀᴇsᴇʟʟᴇʀ ᴘʀɪᴠᴀᴛᴇ", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ʙᴜʏ ᴘʀɪᴠᴀᴛᴇ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }

  const t = text.split(",");
  if (t.length < 2) {
    bot.sendMessage(chatId, "⚠️ Format: /cunli namapanel,idtele");
    return;
  }

  const username = t[0].trim();
  const u = parseInt(t[1].trim());
  const name = username + "unli";
  const egg = eggs;
  const loc = locs;
  const memo = "0";
  const cpu = "0";
  const disk = "0";
  const email = `${username}@unli.${dev}`;
  const spc =
    'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';
    
  const password = username + Math.random().toString(36).slice(2, 5);
  
  let user;
  let server;

  try {
    // CREATE USER
    const response = await fetch(`${domain}/api/application/users`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        email: email,
        username: username,
        first_name: username,
        last_name: username,
        language: "en",
        password: password,
      }),
    });

    const data = await response.json();
    if (data.errors) {
      if (
        data.errors[0].meta.rule === "unique" &&
        data.errors[0].meta.source_field === "email"
      ) {
        bot.sendMessage(chatId, "⚠️ Email & Username sudah ada di panel! Coba lagi.");
      } else {
        bot.sendMessage(chatId, `❌ Error: ${JSON.stringify(data.errors[0], null, 2)}`);
      }
      return;
    }
    user = data.attributes;

    // CREATE SERVER
    const response2 = await fetch(`${domain}/api/application/servers`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
      body: JSON.stringify({
        name: name,
        description: "",
        user: user.id,
        egg: parseInt(egg),
        docker_image: "ghcr.io/parkervcp/yolks:nodejs_20",
        startup: spc,
        environment: {
          INST: "npm",
          USER_UPLOAD: "0",
          AUTO_UPDATE: "0",
          CMD_RUN: "npm start",
        },
        limits: {
          memory: memo,
          swap: 0,
          disk: disk,
          io: 500,
          cpu: cpu,
        },
        feature_limits: {
          databases: 5,
          backups: 5,
          allocations: 1,
        },
        deploy: {
          locations: [parseInt(loc)],
          dedicated_ip: false,
          port_range: [],
        },
      }),
    });

    const data2 = await response2.json();
    if (data2.errors) {
      bot.sendMessage(chatId, `❌ Error saat buat server: ${JSON.stringify(data2.errors[0], null, 2)}`);
      return;
    }
    server = data2.attributes;

  } catch (error) {
    bot.sendMessage(chatId, `❌ Error: ${error.message}`);
    return;
  }

  if (user && server) {
    bot.sendMessage(
      chatId,
      `Type: Unli Private
📡 ID: ${user.id}
👤 USERNAME: ${username}
⚙️ MEMORY: ${server.limits.memory === 0 ? "Unlimited" : server.limits.memory} MB
`
    );

    // kirim data panel ke user yang dituju
      
    bot.sendPhoto(u, panel, {
      caption: `🔐 *Sukses Created Panel Private!*

🌐 *Akun Panel*
▸ Username: ${user.username}
▸ Password: \`${password}\`

\`\`\`
┏━━━ RULES PANEL ━━⬣
│• No Share Panel
│• Sensor Domain
│• Garansi 15 hari
┗━━━━━━━━━━━━━━⬣
\`\`\`
`,
      parse_mode: "Markdown",
      reply_markup: {
        inline_keyboard: [
          [
          { text: "🌐 Domain", url: domain },
          { text: "🔑 Salin Password", switch_inline_query_current_chat: password }
          ],
        ],
      },
    });

    bot.sendMessage(
      chatId,
      `✅ Berhasil kirim panel private ke @${msg.from.username}\n(ID: ${u})`, {
    parse_mode: "Markdown", reply_to_message_id: msg.message_id
  });
  } else {
    bot.sendMessage(chatId, `❌ Akun admin panel private tidak ada! Laporkan ke @${dev}.`);
  }
});
    
    // /pinfo
bot.onText(/\/pinfo/, (msg) => {
  const chatId = msg.chat.id;
    
  // ambil target
  const target = msg.reply_to_message ? msg.reply_to_message.from : msg.from;

  const username = target.username || "-";
  const userId = target.id.toString();

  let privUsers = [];
  let privPrem = [];
  let privRess = [];

  if (fs.existsSync(PRIVATE_FILE)) {
    privUsers = JSON.parse(fs.readFileSync(PRIVATE_FILE));
  }

  if (fs.existsSync(PRIVPREM_FILE)) {
    privPrem = JSON.parse(fs.readFileSync(PRIVPREM_FILE));
  }

  if (fs.existsSync(PRIVRESS_FILE)) {
    privRess = JSON.parse(fs.readFileSync(PRIVRESS_FILE));
  }

  const txtInfo = `
ID: <code>${userId}</code>
Username: @${username}
Status:
<blockquote>- Private Owner? ${privUsers.includes(userId) ? "✅" : "❌"}
- Premium Private? ${privPrem.includes(userId) ? "✅" : "❌"}
- Reseller Private? ${privRess.includes(userId) ? "✅" : "❌"}
</blockquote>
`;

  bot.sendMessage(chatId, txtInfo, {
    parse_mode: "HTML", reply_to_message_id: msg.message_id
  });
});
    
// === /addpriv ===
bot.onText(/^\/addpriv$/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();

  const privates = loadJsonData(PRIVATE_FILE)
  if (msg.from.id !== OWNER_ID && !privates.includes(userId)) {
    return bot.sendMessage(chatId, '❌ Khusus Owner Private yang dapat menambahkan ke User Private!')
  }

  if (!msg.reply_to_message) {
    return bot.sendMessage(chatId, '⚠️ Reply pesan user yang ingin ditambahkan!');
  }

  const targetUserId = msg.reply_to_message.from.id.toString();

  if (privates.includes(targetUserId)) {
    return bot.sendMessage(chatId, '⚠️ ᴜꜱᴇʀ ꜱᴜᴅᴀʜ ᴍᴇɴᴊᴀᴅɪ ꜱᴇʙᴀɢᴀɪ ᴘʀɪᴠᴀᴛᴇ!');
  }

  privates.push(targetUserId);
  const success = saveJsonData(PRIVATE_FILE, privates);

  if (success) {
    bot.sendMessage(chatId, `✅ ᴜsᴇʀ ɪᴅ ${targetUserId} ʙᴇʀʜᴀꜱɪʟ ᴅɪᴛᴀᴍʙᴀʜᴋᴀɴ ꜱᴇʙᴀɢᴀɪ ᴜꜱᴇʀ ᴘʀɪᴠᴀᴛᴇ!`, {
      parse_mode: "Markdown",
      reply_to_message_id: msg.message_id
    });
  } else {
    bot.sendMessage(chatId, '❌ Gagal menyimpan data User Private!');
  }
});

// === /addpremp ===
bot.onText(/^\/addpremp$/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();

  const privates = loadJsonData(PRIVATE_FILE)
  if (msg.from.id !== OWNER_ID && !privates.includes(userId)) {
    return bot.sendMessage(chatId, '❌ Khusus Owner Private yang dapat menambahkan ke Premium Private!')
  }

  if (!msg.reply_to_message) {
    return bot.sendMessage(chatId, '⚠️ Reply pesan user yang ingin ditambahkan!');
  }

  const targetUserId = msg.reply_to_message.from.id.toString();
  const privPrem = loadJsonData(PRIVPREM_FILE);

  if (privPrem.includes(targetUserId)) {
    return bot.sendMessage(chatId, '⚠️ ᴜꜱᴇʀ ꜱᴜᴅᴀʜ ᴍᴇɴᴊᴀᴅɪ ꜱᴇʙᴀɢᴀɪ ᴘʀᴇᴍɪᴜᴍ ᴘʀɪᴠᴀᴛᴇ!');
  }

  privPrem.push(targetUserId);
  const success = saveJsonData(PRIVPREM_FILE, privPrem);

  if (success) {
    bot.sendMessage(chatId, `✅ ᴜsᴇʀ ɪᴅ ${targetUserId} ʙᴇʀʜᴀꜱɪʟ ᴅɪᴛᴀᴍʙᴀʜᴋᴀɴ ꜱᴇʙᴀɢᴀɪ ᴜꜱᴇʀ ᴘʀᴇᴍɪᴜᴍ ᴘʀɪᴠᴀᴛᴇ!`, {
      parse_mode: "Markdown",
      reply_to_message_id: msg.message_id
    });
  } else {
    bot.sendMessage(chatId, '❌ Gagal menyimpan data User Private!');
  }
});

// === /addressp ===
bot.onText(/^\/addressp$/, (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id.toString();

  const privates = loadJsonData(PRIVATE_FILE)
  if (msg.from.id !== OWNER_ID && !privates.includes(userId)) {
    return bot.sendMessage(chatId, '❌ Khusus Owner Private yang dapat menambahkan ke Reseller Private!')
  }

  if (!msg.reply_to_message) {
    return bot.sendMessage(chatId, '⚠️ Reply pesan user yang ingin ditambahkan!');
  }

  const targetUserId = msg.reply_to_message.from.id.toString();
  const privRess = loadJsonData(PRIVRESS_FILE);

  if (privRess.includes(targetUserId)) {
    return bot.sendMessage(chatId, '⚠️ ᴜꜱᴇʀ ꜱᴜᴅᴀʜ ᴍᴇɴᴊᴀᴅɪ ꜱᴇʙᴀɢᴀɪ ʀᴇꜱᴇʟʟᴇʀ ᴘʀɪᴠᴀᴛᴇ!');
  }

  privRess.push(targetUserId);
  const success = saveJsonData(PRIVRESS_FILE, privRess);

  if (success) {
    bot.sendMessage(chatId, `✅ ᴜsᴇʀ ɪᴅ ${targetUserId} ʙᴇʀʜᴀꜱɪʟ ᴅɪᴛᴀᴍʙᴀʜᴋᴀɴ ꜱᴇʙᴀɢᴀɪ ᴜꜱᴇʀ ʀᴇꜱᴇʟʟᴇʀ ᴘʀɪᴠᴀᴛᴇ!`, {
      parse_mode: "Markdown",
      reply_to_message_id: msg.message_id
    });
  } else {
    bot.sendMessage(chatId, '❌ Gagal menyimpan data User Private!');
  }
});
    
    // srvofflist
bot.onText(/\/srvofflist/, async (msg) => {
  const chatId = msg.chat.id;
  
  if (msg.chat.type !== "group" && msg.chat.type !== "supergroup") {
  bot.sendMessage(msg.chat.id, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  return;
}

  try {
    const ownerUsers = JSON.parse(fs.readFileSync(PRIVATE_FILE));
    const isOwner = ownerUsers.includes(String(msg.from.id));
    if (!isOwner) {
      return bot.sendMessage(chatId, "❌ Khusus Owner!", {
        reply_markup: {
          inline_keyboard: [[{ text: "LAPORAN", url: `https://t.me/${dev}` }]],
        },
      });
    }
      
    bot.sendMessage(chatId, "⏳");

    let offlineServers = [];
    let page = 1;
    let totalPages = 1;

    // Ambil semua halaman server
    do {
      let f = await fetch(`${domain}/api/application/servers?page=${page}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${plta}`,
        },
      });

      let res = await f.json();
      let servers = res.data;
      totalPages = res.meta.pagination.total_pages;

      for (let server of servers) {
        let s = server.attributes;
        try {
          let f3 = await fetch(
            `${domain}/api/client/servers/${s.uuid.split("-")[0]}/resources`,
            {
              method: "GET",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${pltc}`,
              },
            }
          );

          let data = await f3.json();
          let status = data.attributes ? data.attributes.current_state : s.status;

          if (status === "offline") {
            offlineServers.push(
              `ID Server: ${s.id}\nNama: ${s.name}\nStatus: ${status}\n`
            );
          }
        } catch (err) {
          console.error(`Gagal ambil data server ${s.id}`, err);
        }
      }

      page++;
    } while (page <= totalPages);

    if (offlineServers.length === 0) {
      return bot.sendMessage(chatId, "✅ Semua server sedang online.");
    }

    // Gabung semua offline server ke string
    let messageText = `📋 Server Private Offline (${offlineServers.length}):\n\n${offlineServers.join("\n")}`;

    // Handle limit karakter Telegram (4096)
    while (messageText.length > 0) {
      let chunk = messageText.slice(0, 4000); 
      messageText = messageText.slice(4000);
      await bot.sendMessage(chatId, chunk);
    }

  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, "⚠️ Terjadi kesalahan saat memproses /srvofflist.");
  }
});
    
    // srvoffdel
bot.onText(/\/srvoffdel/, async (msg) => {
  const chatId = msg.chat.id;
  
  if (msg.chat.type !== "group" && msg.chat.type !== "supergroup") {
  bot.sendMessage(msg.chat.id, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  return;
}

  try {
    const ownerUsers = JSON.parse(fs.readFileSync(PRIVATE_FILE));
    const isOwner = ownerUsers.includes(String(msg.from.id));
    if (!isOwner) {
      return bot.sendMessage(chatId, "❌ Khusus Owner Private!", {
        reply_markup: {
          inline_keyboard: [[{ text: "PRIVATE JOIN", url: `https://t.me/${dev}` }]],
        },
      });
    }
      
    bot.sendMessage(chatId, "⏳");

    let page = 1;
    let totalPages = 1;
    let offlineServers = [];

    // Ambil semua server dari semua page
    do {
      let f = await fetch(`${domain}/api/application/servers?page=${page}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${plta}`,
        },
      });

      let res = await f.json();
      let servers = res.data;
      totalPages = res.meta.pagination.total_pages;

      for (let server of servers) {
        let s = server.attributes;
        try {
          let f3 = await fetch(
            `${domain}/api/client/servers/${s.uuid.split("-")[0]}/resources`,
            {
              method: "GET",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: `Bearer ${pltc}`,
              },
            }
          );

          let data = await f3.json();
          let status = data.attributes ? data.attributes.current_state : s.status;

          if (status === "offline") {
            offlineServers.push({ id: s.id, name: s.name });
          }
        } catch (err) {
          console.error(`Gagal ambil data server ${s.id}`, err);
        }
      }

      page++;
    } while (page <= totalPages);

    if (offlineServers.length === 0) {
      return bot.sendMessage(chatId, "✅ Tidak ada server offline untuk dihapus.");
    }

    let success = [];
    let failed = [];

    for (let srv of offlineServers) {
      try {
        let del = await fetch(`${domain}/api/application/servers/${srv.id}`, {
          method: "DELETE",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${plta}`,
          },
        });

        if (del.status === 204) {
          success.push(`✅ ${srv.name} (ID: ${srv.id})`);
        } else {
          failed.push(`❌ ${srv.name} (ID: ${srv.id})`);
        }
      } catch (err) {
        console.error(`Gagal hapus server ${srv.id}`, err);
        failed.push(`❌ ${srv.name} (ID: ${srv.id})`);
      }
    }

    let report = `🗑️ Hasil penghapusan server private offline:\n\n` +
      `Berhasil dihapus: ${success.length}\n` +
      `Gagal dihapus: ${failed.length}\n\n`;

    if (success.length) {
      report += `✅ Berhasil:\n${success.join("\n")}\n\n`;
    }
    if (failed.length) {
      report += `❌ Gagal:\n${failed.join("\n")}`;
    }

    // Handle limit karakter telegram
    while (report.length > 0) {
      let chunk = report.slice(0, 4000);
      report = report.slice(4000);
      await bot.sendMessage(chatId, chunk);
    }

  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, "⚠️ Terjadi kesalahan saat memproses /delsrvoff.");
  }
});
    
    // totalsrv
bot.onText(/\/totalsrv/, async (msg) => {
  const chatId = msg.chat.id;

  bot.sendMessage(chatId, "⏳"); 
    
  try {
    let page = 1;
    let totalPages = 1;
    let totalServers = 0;

    // Loop semua halaman server
    do {
      let f = await fetch(`${domain}/api/application/servers?page=${page}`, {
        method: "GET",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/json",
          Authorization: `Bearer ${plta}`,
        },
      });

      let res = await f.json();
      totalPages = res.meta.pagination.total_pages;

      if (res.data && res.data.length > 0) {
        totalServers += res.data.length;
      }

      page++;
    } while (page <= totalPages);

    return bot.sendMessage(
      chatId,
      `*📊 Total server private:* ${totalServers}`, {
    parse_mode: "Markdown", reply_to_message_id: msg.message_id }
    );

  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, "⚠️ Terjadi kesalahan saat memproses /totalsrv.");
  }
});
    
    // srvlist
bot.onText(/\/srvlist/, async (msg) => {
  const chatId = msg.chat.id;
  const userId = msg.from.id;
    
  if (msg.chat.type !== "group" && msg.chat.type !== "supergroup") {
  bot.sendMessage(msg.chat.id, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  return;
}

  const privUsers = JSON.parse(fs.readFileSync(PRIVATE_FILE));
  const isPrivate = privUsers.includes(String(msg.from.id));
    
  if (!isPrivate) {
    bot.sendMessage(chatId, "ᴋʜᴜsᴜs ᴜsᴇʀ ᴘʀɪᴠᴀᴛᴇ!", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ʙᴜʏ ᴘʀɪᴠᴀᴛᴇ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }
    
  bot.sendMessage(chatId, "⏳");
   
  let page = 1;
  try {
    let f = await fetch(`${domain}/api/application/servers?page=${page}`, {
      // Menggunakan backticks untuk string literal
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
    });
    let res = await f.json();
    let servers = res.data;
    let messageText = "📋 ᴅᴀғᴛᴀʀ sᴇʀᴠᴇʀ ᴘʀɪᴠᴀᴛᴇ:\n\n";
    for (let server of servers) {
      let s = server.attributes;

      let f3 = await fetch(
        `${domain}/api/client/servers/${s.uuid.split("-")[0]}/resources`,
        {
          method: "GET",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/json",
            Authorization: `Bearer ${pltc}`,
          },
        }
      );
      let data = await f3.json();
      let status = data.attributes ? data.attributes.current_state : s.status;

      messageText += `ID Server: ${s.id}\n`;
      messageText += `Nama Server: ${s.name}\n`;
      messageText += `Status: ${status}\n\n`;
    }

    bot.sendMessage(chatId, messageText);
  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, "Terjadi kesalahan dalam memproses permintaan.");
  }});

bot.onText(/^\/srvdel (.+)$/, async (msg, match) => {
  notifyOwner('srvdel', msg);
  const chatId = msg.chat.id;
    
  if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  }
    
  const srv = match[1].trim();
    
  const privUsers = JSON.parse(fs.readFileSync(PRIVATE_FILE));
  const isPrivate = privUsers.includes(String(msg.from.id));
    
  if (!isPrivate) {
    bot.sendMessage(chatId, "ᴋʜᴜsᴜs ᴜsᴇʀ ᴘʀɪᴠᴀᴛᴇ!", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ʙᴜʏ ᴘʀɪᴠᴀᴛᴇ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }

  if (!srv) {
    bot.sendMessage(
      chatId,
      "Mohon masukkan ID server yang ingin dihapus, contoh: /srvdel 1234"
    );
    return;
  }

  try {
    let f = await fetch(domain + "/api/application/servers/" + srv, {
      method: "DELETE",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
        Authorization: `Bearer ${plta}`,
      },
    });

    let res = f.ok ? { errors: null } : await f.json();

    if (res.errors) {
      bot.sendMessage(chatId, "❌ sᴇʀᴠᴇʀ ᴛɪᴅᴀᴋ ᴀᴅᴀ");
    } else {
      bot.sendMessage(chatId, `✅ ꜱᴜᴋꜱᴇꜱ ᴅᴇʟᴇᴛᴇ ꜱᴇʀᴠᴇʀ ${srv}`, { parse_mode: "MarkDown",
    reply_to_message_id: msg.message_id });
    }
  } catch (error) {
    console.error(error);
    bot.sendMessage(chatId, "Terjadi kesalahan saat menghapus server private.");
  }
});
    
    // 1gebe-10gebe
const specs = {
  "1gebe": { memo: 1024,  cpu: 30,  disk: 1024 },
  "2gebe": { memo: 2048,  cpu: 60,  disk: 2048 },
  "3gebe": { memo: 3072,  cpu: 90,  disk: 3072 },
  "4gebe": { memo: 4096,  cpu: 120, disk: 4096 },
  "5gebe": { memo: 5120,  cpu: 150, disk: 5120 },
  "6gebe": { memo: 6144,  cpu: 180, disk: 6144 },
  "7gebe": { memo: 7168,  cpu: 210, disk: 7168 },
  "8gebe": { memo: 8192,  cpu: 240, disk: 8192 },
  "9gebe": { memo: 9216,  cpu: 270, disk: 9216 },
  "10gebe":{ memo: 10240, cpu: 300, disk: 10240 }
};

bot.onText(/\/(1gebe|2gebe|3gebe|4gebe|5gebe|6gebe|7gebe|8gebe|9gebe|10gebe) (.+)/, async (msg, match) => {
  const chatId = msg.chat.id;
  const plan = match[1];
  const text = match[2];
  
  if ((msg.chat.type !== "group" && msg.chat.type !== "supergroup") && msg.from.id !== OWNER_ID) {
    return bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ɢʀᴜᴘ!");
  }
    
  if (!text) {
      return bot.sendMessage(chatId,
`❌ Format salah!\nContoh: /${plan} nama,id`);
  }
    
  const ressUsers = JSON.parse(fs.readFileSync(PRIVRESS_FILE));
  const isReseller = ressUsers.includes(String(msg.from.id));
    
  if (!isReseller) {
    bot.sendMessage(chatId, "❌ ᴋʜᴜꜱᴜꜱ ʀᴇꜱᴇʟʟᴇʀ!", {
      reply_markup: {
        inline_keyboard: [
          [{ text: "ʟᴀᴘᴏʀᴀɴ", url: `https://t.me/${dev}` }],
        ],
      },
    });
    return;
  }

  const [username,u] = text.split(",");
  if (!username || !u) return bot.sendMessage(chatId, `Usage: /${plan} namapanel,idtele`);

  const { memo,cpu,disk } = specs[plan];
  const name = username+plan;
  const email = `${username}@buyer.${dev}`;
  const password = username+Math.random().toString(36).slice(2,5);
  const spc = 'if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == "1" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi; /usr/local/bin/${CMD_RUN}';

  let user,server;
  try {
    const res1 = await fetch(`${domain}/api/application/users`, {
      method:"POST",
      headers:{ "Content-Type":"application/json", Authorization:`Bearer ${plta}` },
      body:JSON.stringify({ email, username, first_name:username, last_name:username, language:"en", password })
    });
    const data1 = await res1.json();
    if (data1.errors) return bot.sendMessage(chatId, `Error user: ${JSON.stringify(data1.errors[0])}`);
    user = data1.attributes;

    const res2 = await fetch(`${domain}/api/application/servers`, {
      method:"POST",
      headers:{ "Content-Type":"application/json", Authorization:`Bearer ${plta}` },
      body:JSON.stringify({
        name, user:user.id, egg:parseInt(eggs),
        docker_image:"ghcr.io/parkervcp/yolks:nodejs_18", startup:spc,
        environment:{ INST:"npm",USER_UPLOAD:"0",AUTO_UPDATE:"0",CMD_RUN:"npm start" },
        limits:{ memory:memo,swap:0,disk,io:500,cpu },
        feature_limits:{ databases:5,backups:5,allocations:1 },
        deploy:{ locations:[parseInt(settings.loc)],dedicated_ip:false,port_range:[] }
      })
    });
    const data2 = await res2.json();
    server = data2.attributes;
  } catch(e) {
    return bot.sendMessage(chatId, `Error: ${e.message}`);
  }

  if (!user || !server) return bot.sendMessage(chatId,"Gagal membuat data panel.");

  bot.sendMessage(chatId, `- SUKSES KIRIM PANEL ${plan} -
NAMA: ${username}
EMAIL: ${email}
ID: ${user.id}
MEMORY: ${server.limits.memory} MB
DISK: ${server.limits.disk} MB
CPU: ${server.limits.cpu}%`);
    
  bot.sendMessage(
      chatId,
      `✅ Berhasil kirim Panel Private ${plan} ke @${msg.from.username}\n(ID: ${u})`, {
    parse_mode: "Markdown", reply_to_message_id: msg.message_id
  });

  function esc(text) {
  return String(text).replace(/([_*\[\]()~`>#+\-=|{}.!])/g, '\\$1');
}

const safeName = esc(username);
const safeEmail = esc(email);
const safeId = esc(user.id);
const safePlan = esc(plan);
const safeUser = esc(user.username);
const safePass = esc(password);
const safeDomain = esc(domain);

// copy
const copyUser = `\`${safeUser}\``;
const copyPass = `\`${safePass}\``;
    
// spoiler
const spoilerDomain = `||${safeDomain}||`;

bot.sendPhoto(u, panel, {
  caption: `🔐 *Sukses Created Panel Private\\!*
▸ Name: ${safeName}
▸ Email: ${safeEmail}
▸ ID: ${safeId}
▸ RAM: ${safePlan}

🌐 *Domain Panel*
▸ Username: ${copyUser}
▸ Password: ${copyPass}
▸ Login: ${spoilerDomain}

⚠️ *Rules Panel*
▸ Sensor domain
▸ Simpan data akun
▸ Garansi 15 hari`,
  parse_mode: "MarkdownV2",
  reply_markup: {
    inline_keyboard: [
      [
        { text: "🌐 Domain", url: domain },
        { text: "🔑 Salin Password", switch_inline_query_current_chat: password }
      ],
    ],
  },
});
});
}