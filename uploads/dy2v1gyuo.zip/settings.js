const settings = {
  token: '8520469183:AAEUVxa7w2HEIom5nbzI3mm_pamRLG1OixE', // token dari @BotFather
    
  vercelToken: '9c0laRcYJhT7wW6OHWvigJwk', // token vercel
  ownerId: 6840832028, // user id
  dev: 'miunnst', // wajib username tele
  
  dana: 'NO_DANA', // nomer dana
  namaDana: '', // nama
    
  chUsn: '@huntersXq', // ch tele
  
  exPGroupid: -1002912957410, // id group
  exGroupId: -1002768938548, // id group
    
  vpsPublic: "", // ip vps
  pwPublic: "", // pw vps
    
  vpsPrivate: "", // ip vps
  pwPrivate: "", // pw vps
    
  apiDigitalOcean: "APIKEY_DO", // apikey do
    
  apiDigitalOcean2: "APIKEY_DO2", // apikey do 2
  
  apiDigitalOcean3: "APIKEY_DO3", // apikey do 3
  
  pp: 'https://files.catbox.moe/no0fpu.jpg', // file catbox foto
  ppVid: 'https://files.catbox.moe/2zdg8d.mp4', // file catbox video
  panel: 'https://files.catbox.moe/a7ljii.jpeg', // foto panel

  qris: 'https://files.catbox.moe/a4l723.jpg', // qris

  domain: 'ISI_DOMAIN', // domain panel
  plta: 'ISI_PTLA', // ptla panel
  pltc: 'ISI_PTLC', // ptlc panel
    
  domainAdp: 'ISI_DOMAIN', // domain panel
  ptlaAdp: 'ISI_PTLA', // apikey ptla
  ptlcAdp: 'ISI_PTLC', // apikey ptlc
    
    // PANEL SERVER 2
  domainV2: 'ISI_DOMAIN', // domain v2
  pltaV2: 'ISI_PTLA', // plta v2
  pltcV2: 'ISI_PTLC', // ptlc v2
    
    // PANEL SERVER 3
  domainV3: 'ISI_DOMAIN', // domain v3 
  pltaV3: 'ISI_PTLA', // ptla v3
  pltcV3: 'ISI_PTLC', // ptlc v3
    
    // PANEL SERVER 4
  domainV4: 'ISI_DOMAIN', // domain v4
  pltaV4: 'ISI_PTLA', // ptla v4
  pltcV4: 'ISI_PTLC', // ptlc v4
    
    // PANEL SERVER 5
  domainV5: 'ISI_DOMAIN', // domain v5
  pltaV5: 'ISI_PTLA', // ptla v5
  pltcV5: 'ISI_PTLC', // ptlc v5
  
  PATH: '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',
  
  RAW: 'https://raw.githubusercontent.com/iLyxxDev/database/refs/heads/main/token',
  
  API: 'https://api.github.com/repos/iLyxxDev/database/contents/token',
  
  loc: '1',
  eggs: '15'
};

module.exports = settings;