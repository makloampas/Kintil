const axios = require('axios');

module.exports = {
  tokens: "78312524:AAHibg2WiODO90faPBYhyDWOyB79lN20N0g",  // Masukin Bot token kamu
  owners: "5589953", // Masukin ID Telegram kamu
  port: "200", // Masukin Port panel kamu 
  ipvps: "http://989.mbbstore.my.id", // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://AiiSigma.id ) menjadi ( http://AiiSigma.id )

  // Bot Appearance & Settings (Move here for easier renaming/encrypted index.js)
  botSettings: {
    botName: "ZYZ PETIR V5 × 𝖨𝖭𝖣𝖨𝖢𝖳𝖨V𝖤 𝖢 SIX",
    startImage: 'https://files.catbox.moe/j5k0yy.jpg',
    footerText: "Five𝐒𝐢𝐗 ☊ 𝐕𝐞𝐫𝐬𝐢𝐨𝐧",
    footerLink: "https://t.me/official",

    // Poll Menu Settings
    pollTitle: '🌜 Pilih Menu yang Diinginkan',
    pollOptions: ['🔑 sᴇᴛᴛɪɴɢs ᴍᴇɴᴜ', '🔧 ᴏᴡɴᴇʀ ᴍᴇɴᴜ', '📊 sᴇssɪᴏɴ sᴛᴀᴛᴜs', '❌ ᴄᴀɴᴄᴇʟ'],

    // Devs / Links buttons
    buttons: [
      { text: 'ϟ', url: 'https://t.me/official' },
      { text: '🍷', url: 'https://t.me/official' }
    ]
  },

  // Dynamic Functions for Messages
  messages: {
    getStartCaption: (username, settings) => {
      // You can edit the HTML/style here
      return `<blockquote><b>${settings.botName}</b></blockquote>\nWelcome, @${username}\n\n<blockquote><a href="${settings.footerLink}">${settings.footerText}</a></blockquote>`;
    }
  }
};