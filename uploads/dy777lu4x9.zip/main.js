/*
© Copyright By AiiSigma
*/

const startServer = require('./index.js');

const chalk = require('chalk');

console.log(chalk.green('🚀 ZyZ Petir starting...'));