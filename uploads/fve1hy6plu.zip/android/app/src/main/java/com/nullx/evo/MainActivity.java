package com.ravencopy.id;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
