import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:web_socket_channel/status.dart' as status;

import 'bug_page.dart';
import 'login_page.dart';
import 'chat_private.dart';
import 'chat_home_page.dart';
import 'tools_gateway.dart';
import 'wifi_internal.dart';
import 'chat_public.dart';
import 'chatbot_page.dart';
import 'dashboard_chat.dart';
import 'change_password_page.dart';
import 'nik_check.dart';
import 'admin_page.dart';
import 'seller_page.dart';
import 'bug_sender.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String sessionKey;
  final String expiredDate;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.sessionKey,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  static const bannerUrl = 'https://pomf2.lain.la/f/o6rnuqvv.jpg';

  late WebSocketChannel channel;
  String androidId = "unknown";

  int _selectedTabIndex = 0;
  late Widget _selectedPage;

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

// ===== THEME (RED EDITION, CONST NAME TETAP) =====
final Color bg = const Color(0xFF0B0B0B);        // hitam pekat (aman buat merah)
final Color yellow = const Color(0xFFDC2626);    // merah utama (gantinya yellow)
final Color purple = const Color(0xFF991B1B);    // merah gelap / aksen (gantinya purple)

  @override
  void initState() {
    super.initState();
    _initAndroidIdAndConnect();
    _selectedPage = _buildHomePage();
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(
      Uri.parse('wss://ws-xyzzcafee.lixzhosting.biz.id:2231'),
    );

    channel.sink.add(jsonEncode({
      "type": "validate",
      "key": widget.sessionKey,
      "androidId": androidId,
    }));
  }

  @override
  void dispose() {
    channel.sink.close(status.goingAway);
    super.dispose();
  }

  // ================= SIDEBAR (ASLI) =================
  Widget _buildDrawer() {
  return Drawer(
    backgroundColor: bg,
    child: Column(
      children: [
        DrawerHeader(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [bg, purple.withOpacity(0.5)],
            ),
          ),
          child: const Align(
            alignment: Alignment.bottomLeft,
            child: Text(
              "RavenXTeam",
              style: TextStyle(
                color: Colors.white,
                fontSize: 22,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),

        // ⬇️ SATU-SATUNYA Expanded
        Expanded(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              if (widget.role == "owner")
                _drawerItem(Icons.admin_panel_settings, "Admin Page", () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => AdminPage(sessionKey: widget.sessionKey),
                    ),
                  );
                }),

              if (widget.role == "reseller")
                _drawerItem(Icons.add_shopping_cart, "Seller Page", () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (_) => SellerPage(keyToken: widget.sessionKey),
                    ),
                  );
                }),

              _drawerItem(Icons.lock, "Change Password", () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => ChangePasswordPage(
                      username: widget.username,
                      sessionKey: widget.sessionKey,
                    ),
                  ),
                );
              }),

              _drawerItem(Icons.person, "NIK Check", () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (_) => NikCheckerPage(),
                  ),
                );
              }),

              // 🔥 THANKS TO — LANGSUNG DI BAWAH NIK CHECK
              const Divider(color: Colors.white24, height: 32),

              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Text(
                      "Thanks To",
                      style: TextStyle(
                        color: Colors.white70,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 8),
                    Text("- PermenMD {Inspired}", style: TextStyle(color: Colors.white54)),
                    Text("- KaiiOfficial {Creators Base}", style: TextStyle(color: Colors.white54)),
                    Text("- Zsnz {Best Friends}", style: TextStyle(color: Colors.white54)),
                    Text("- Zyrex {Hitam Nigeria}", style: TextStyle(color: Colors.white54)),
                  ],
                ),
              ),

              const SizedBox(height: 24),
            ],
          ),
        ),
      ],
    ),
  );
}

Widget _drawerItem(IconData icon, String title, VoidCallback onTap) {
  return ListTile(
    leading: Icon(icon, color: yellow),
    title: Text(title, style: const TextStyle(color: Colors.white)),
    onTap: onTap,
  );
}

  // ================= NAVBAR LOGIC (ASLI) =================
  void _onTabTapped(int index) {
    setState(() {
      _selectedTabIndex = index;

      if (index == 0) {
        _selectedPage = _buildHomePage();
      } else if (index == 1) {
        _selectedPage = BugPage(
          username: widget.username,
          password: widget.password,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
          listBug: widget.listBug,
          listDoos: widget.listDoos,
        );
      } else if (index == 2) {
        _selectedPage = WifiKillerPage();
      } else if (index == 3) {
  _selectedPage = GoToChatBot(
    username: widget.username,
  );
}
    });
  }

  // ================= BUILD =================
  @override
Widget build(BuildContext context) {
  return Scaffold(
    key: _scaffoldKey,
    drawer: _buildDrawer(),
    backgroundColor: bg,

    // 🔥 HEADER DENGAN SHADOW
    appBar: PreferredSize(
      preferredSize: const Size.fromHeight(60),
      child: Container(
        decoration: BoxDecoration(
          color: const Color(0xFF1A0E0E),
          boxShadow: [
            BoxShadow(
              color: yellow.withOpacity(0.35),
              blurRadius: 18,
              spreadRadius: 2,
              offset: const Offset(0, 6),
            ),
          ],
        ),
        child: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          leading: IconButton(
            icon: const Icon(Icons.menu),
            onPressed: () => _scaffoldKey.currentState?.openDrawer(),
          ),
          title: const Text(
            "RavenXTeam",
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w600,
              letterSpacing: 1.1,
            ),
          ),
          actions: [
            Icon(Icons.account_circle, color: yellow),
            const SizedBox(width: 12),
          ],
        ),
      ),
    ),

    body: _selectedPage,

    bottomNavigationBar: BottomNavigationBar(
      backgroundColor: const Color(0xFF151515),
      type: BottomNavigationBarType.fixed,
      currentIndex: _selectedTabIndex,
      onTap: _onTabTapped,

      selectedItemColor: yellow,
      unselectedItemColor: Colors.grey,

      showSelectedLabels: true,
      showUnselectedLabels: false, // label muncul hanya saat aktif

      items: const [
        BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
        BottomNavigationBarItem(icon: Icon(Icons.call), label: 'WhatsApp'),
        BottomNavigationBarItem(icon: Icon(Icons.flash_on), label: 'Wi-Fi Panel'),
        BottomNavigationBarItem(icon: Icon(Icons.chat), label: 'Chat'),
      ],
    ),
  );
}

  // ================= HOME =================
  Widget _buildHomePage() {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          _banner(),
          const SizedBox(height: 22),

          Row(
  mainAxisAlignment: MainAxisAlignment.spaceAround,
  children: [
    _circleMenu(
      Icons.flash_on,
      "Wi-Fi Panel",
      () {
        _onTabTapped(2);
      },
    ),

    _circleMenu(
      Icons.call_missed,
      "WhatsApp",
      () {
        _onTabTapped(1);
      },
    ),

    // 🔥 CHAT PUBLIC
    _circleMenu(
      Icons.chat,
      "Chat",
      () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => ChatHomePage(
              myName: widget.username, // 👈 nama user
            ),
          ),
        );
      },
    ),

    _circleMenu(
  Icons.smart_toy_outlined,
  "ChatBot",
  () {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => const AiChatPage(),
      ),
    );
  },
),
  ],
),

          const SizedBox(height: 24),

          // TELEGRAM (ASLI, TIDAK DIUBAH)
          GestureDetector(
            onTap: () async {
              await launchUrl(
                Uri.parse("https://t.me/RavenChannels"),
                mode: LaunchMode.externalApplication,
              );
            },
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [yellow, purple]),
                borderRadius: BorderRadius.circular(18),
              ),
              child: Row(
                children: const [
                  Icon(Icons.group_add, color: Colors.white),
                  SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      "🔥 Telegram Channel: Join To Get More Info!",
                      style: TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                  Icon(Icons.arrow_forward_ios, color: Colors.white, size: 14),
                ],
              ),
            ),
          ),

          const SizedBox(height: 24),
          _serverStats(),
        ],
      ),
    );
  }

  Widget _banner() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(22),
      child: Stack(
        children: [
          Image.network(
            bannerUrl,
            height: 230,
            width: double.infinity,
            fit: BoxFit.cover,
          ),
          Container(
            height: 230,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.black.withOpacity(0.85),
                  Colors.black.withOpacity(0.25),
                ],
                begin: Alignment.bottomCenter,
                end: Alignment.topCenter,
              ),
            ),
          ),
          const Positioned(
            left: 18,
            bottom: 20,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "RavenXTeam",
                  style: TextStyle(
                    color: Colors.red,
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 6),
                Text(
                  "Inspired By @permen_md",
                  style: TextStyle(color: Colors.white70, fontSize: 12),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // 🔥 ICON BULAT OPACITY + GLOW
  Widget _circleMenu(
  IconData icon,
  String label,
  VoidCallback onTap,
) {
  return GestureDetector(
    onTap: onTap,
    child: Column(
      children: [
        Container(
          width: 60,
          height: 60,
          decoration: BoxDecoration(
            shape: BoxShape.circle,

            // 🔥 BACKGROUND OPACITY (TETAP)
            color: yellow.withOpacity(0.10),

            // 🔥 RING TIPIS (TETAP)
            border: Border.all(
              color: yellow.withOpacity(0.6),
              width: 1.4,
            ),
          ),
          child: Center(
            child: Icon(
              icon,
              color: yellow,
              size: 26,
            ),
          ),
        ),

        const SizedBox(height: 8),
        Text(
          label,
          style: const TextStyle(
            color: Colors.grey,
            fontSize: 12,
          ),
        ),
      ],
    ),
  );
}

// ================= SERVER STATS =================
  Widget _serverStats() {
  return Container(
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(18),
      border: Border.all(color: Colors.white.withOpacity(0.15)),
    ),
    child: Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // ================= HEADER =================
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                purple.withOpacity(0.90),
                yellow.withOpacity(0.90),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: const BorderRadius.vertical(
              top: Radius.circular(18),
            ),
          ),
          child: const Row(
            children: [
              Text("📊", style: TextStyle(fontSize: 18)),
              SizedBox(width: 8),
              Text(
                "Server Stats",
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),

        // ================= BODY =================
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                purple,
                bg.withOpacity(0.85),
              ],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: const BorderRadius.vertical(
              bottom: Radius.circular(18),
            ),
          ),
          child: Column(
            children: [
              _statsRowLine(
                emoji: "👥",
                label: "Online Users",
                value: "0",
              ),

              const SizedBox(height: 12),
              Container(height: 1, color: Colors.white24),
              const SizedBox(height: 12),

              _statsRowLine(
                emoji: "🚀",
                label: "Active Sender",
                value: "0",
              ),
            ],
          ),
        ),
      ],
    ),
  );
}

  Widget _statsRowLine({
  required String emoji,
  required String label,
  required String value,
}) {
  return Row(
    children: [
      Expanded(
        child: Row(
          children: [
            Text(emoji, style: const TextStyle(fontSize: 18)),
            const SizedBox(width: 10),
            Text(
              label,
              style: TextStyle(
                color: Colors.white.withOpacity(0.85),
                fontSize: 14,
              ),
            ),
          ],
        ),
      ),

      Container(
        width: 1,
        height: 28,
        color: Colors.white24,
      ),

      SizedBox(
        width: 40,
        child: Text(
          value,
          textAlign: TextAlign.right,
          style: TextStyle(
            color: yellow,
            fontSize: 16,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    ],
  );
}
} // ✅ tutup class _DashboardPageState