module.exports = {
  tokens: "8318678185:AAEGcnBFfsqPF2li1RGb3JnS9QOZANJGznc",  // Masukin Bot token kamu
  owners: "7882058841", // Masukin ID Telegram kamu
  port: "2000", // Masukin Port panel kamu 
  ipvps: "http://pnelkzx.dontl.my.id"  // Masukin IP vps kamu atau domain panel kamu yg asalnya ( https://AiiSigma.id ) menjadi ( http://AiiSigma.id )
};