// Data untuk random generation
const kurirList = [
    "JST Express", "JNE", "SiCepat", "Shopee Xpress", 
    "Ninja Xpress", "Lazada Express", "GoSend", 
    "GrabExpress", "AnterAja", "J&T Express", "POS Indonesia", 
    "Wahana Express", "SAP Express", "RPX Holding", "Pahala Express"
];

const barangList = [
    { name: "iPhone 15 Pro Max", price: "Rp 18.450.000" },
    { name: "Samsung Galaxy S23 Ultra", price: "Rp 16.999.000" },
    { name: "HP INFINIX HOT 40", price: "Rp 5.534.000" },
    { name: "Xiaomi Redmi Note 13 Pro", price: "Rp 4.999.000" },
    { name: "OPPO Reno 10", price: "Rp 6.299.000" },
    { name: "Vivo V29", price: "Rp 5.799.000" },
    { name: "ASUS ROG Phone 7", price: "Rp 14.500.000" },
    { name: "Google Pixel 8 Pro", price: "Rp 13.999.000" },
    { name: "Laptop ASUS Vivobook 15", price: "Rp 8.750.000" },
    { name: "Apple MacBook Air M2", price: "Rp 17.999.000" }
];

const statusList = [
    "DALAM PERJALANAN",
    "SEDANG DI PICKUP",
    "DI PUSAT SORTIR",
    "MENUJU ALAMAT TUJUAN"
];

const estimasiList = [
    "Hari ini (2-3 jam lagi)",
    "Hari ini (4-5 jam lagi)",
    "Besok (pagi hari)",
    "Besok (siang hari)",
    "2 hari lagi"
];

// Fungsi untuk generate nomor resi
function generateNomorResi(kurir) {
    const prefixMap = {
        "J&T Express": "JNT",
        "JNE": "JNE",
        "SiCepat": "SIC",
        "Shopee Xpress": "SPX",
        "Ninja Xpress": "NJX",
        "Lazada Express": "LAZ",
        "GoSend": "GOS",
        "GrabExpress": "GRX",
        "AnterAja": "ANT",
        "JST Express": "JST",
        "POS Indonesia": "POS",
        "Wahana Express": "WHE",
        "SAP Express": "SAP",
        "RPX Holding": "RPX",
        "Pahala Express": "PHE"
    };
    
    const prefix = prefixMap[kurir] || "PKG";
    const randomNumbers = Math.floor(1000000000 + Math.random() * 9000000000);
    return `${prefix}${randomNumbers}ID`;
}

// Fungsi untuk generate paket acak
function generateRandomPackage() {
    // Pilih kurir acak
    const randomKurir = kurirList[Math.floor(Math.random() * kurirList.length)];
    
    // Pilih barang acak
    const randomBarang = barangList[Math.floor(Math.random() * barangList.length)];
    
    // Generate nomor resi
    const resi = generateNomorResi(randomKurir);
    
    // Pilih status dan estimasi acak
    const randomStatus = statusList[Math.floor(Math.random() * statusList.length)];
    const randomEstimasi = estimasiList[Math.floor(Math.random() * estimasiList.length)];
    
    return {
        resi: resi,
        kurir: randomKurir,
        barang: randomBarang.name,
        harga: randomBarang.price,
        status: randomStatus,
        estimasi: randomEstimasi
    };
}

// Update tampilan paket
function updatePackageDisplay(packageData) {
    document.getElementById('resiNumber').textContent = packageData.resi;
    document.getElementById('kurirName').textContent = packageData.kurir;
    document.getElementById('barangName').textContent = packageData.barang;
    document.getElementById('hargaCOD').textContent = packageData.harga;
}

// Cek status sender
async function checkSenderStatus() {
    try {
        const response = await fetch('/api/mysenders');
        const data = await response.json();
        
        const senderStatus = document.getElementById('senderStatus');
        
        if (data.success && data.senders.length > 0) {
            const activeSenders = data.senders.length;
            senderStatus.innerHTML = `<p><i class="fas fa-check-circle"></i> <span class="active-sender">${activeSenders} sender aktif</span> siap digunakan</p>`;
            return true;
        } else {
            senderStatus.innerHTML = `<p><i class="fas fa-exclamation-triangle"></i> Tidak ada sender aktif. Silakan tambahkan sender terlebih dahulu.</p>`;
            return false;
        }
    } catch (error) {
        console.error('Error checking sender status:', error);
        return false;
    }
}

// Kirim package prank
async function sendPackagePrank() {
    const targetNumber = document.getElementById('targetNumber').value.trim();
    const currentPackage = {
        resi: document.getElementById('resiNumber').textContent,
        kurir: document.getElementById('kurirName').textContent,
        barang: document.getElementById('barangName').textContent,
        harga: document.getElementById('hargaCOD').textContent,
        status: "DALAM PERJALANAN",
        estimasi: "Hari ini (4-5 jam lagi)"
    };

    // Validasi
    if (!targetNumber) {
        showMessage('error', 'Masukkan nomor target terlebih dahulu!');
        return;
    }

    if (!targetNumber.startsWith('62')) {
        showMessage('error', 'Format nomor harus diawali dengan 62 (contoh: 6282284243004)');
        return;
    }

    // Cek sender aktif
    const hasActiveSender = await checkSenderStatus();
    if (!hasActiveSender) {
        showMessage('error', 'Tidak ada sender aktif. Silakan tambahkan sender terlebih dahulu.');
        return;
    }

    // Tampilkan loading
    const sendBtn = document.getElementById('sendBtn');
    sendBtn.disabled = true;
    sendBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> MENGIRIM...';

    try {
        const response = await fetch('/api/send-package-prank', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                targetNumber: targetNumber,
                packageData: currentPackage
            })
        });

        const result = await response.json();

        if (result.success) {
            showMessage('success', 'Paket prank berhasil dikirim!');
        } else {
            showMessage('error', result.error || 'Gagal mengirim paket prank');
        }
    } catch (error) {
        showMessage('error', 'Terjadi kesalahan saat mengirim: ' + error.message);
    } finally {
        sendBtn.disabled = false;
        sendBtn.innerHTML = '<i class="fab fa-whatsapp"></i> KIRIM PAKET PRANK';
    }
}

// Tampilkan pesan
function showMessage(type, text) {
    const messageStatus = document.getElementById('messageStatus');
    messageStatus.className = `message-status ${type}`;
    messageStatus.innerHTML = `<p><i class="fas fa-${type === 'success' ? 'check-circle' : 'exclamation-triangle'}"></i> ${text}</p>`;
    messageStatus.style.display = 'block';

    // Scroll ke pesan
    messageStatus.scrollIntoView({ behavior: 'smooth' });

    // Sembunyikan pesan setelah 5 detik
    if (type === 'success') {
        setTimeout(() => {
            messageStatus.style.display = 'none';
        }, 5000);
    }
}

// Event Listeners
document.addEventListener('DOMContentLoaded', function() {
    // Generate paket pertama
    const initialPackage = generateRandomPackage();
    updatePackageDisplay(initialPackage);

    // Event untuk generate button
    document.getElementById('generateBtn').addEventListener('click', function() {
        const newPackage = generateRandomPackage();
        updatePackageDisplay(newPackage);
    });

    // Event untuk send button
    document.getElementById('sendBtn').addEventListener('click', sendPackagePrank);

    // Cek status sender
    checkSenderStatus();
});