// sender-settings.js
let senderList = [];
let globalSettings = {};

// Load initial data
document.addEventListener('DOMContentLoaded', function() {
    loadSenders();
    loadGlobalSettings();
    
    // Auto refresh every 30 seconds
    setInterval(loadSenders, 30000);
});

// Load sender list
async function loadSenders() {
    try {
        showMessage('info', 'Memuat daftar sender...');
        
        // Load sender status
        const statusResponse = await fetch('/api/sender/status');
        const statusData = await statusResponse.json();
        
        if (statusData.success) {
            senderList = statusData.senders;
            displaySenders(senderList);
            updateStats(senderList);
        }
        
        // Load sender settings
        const settingsResponse = await fetch('/api/sender/settings');
        const settingsData = await settingsResponse.json();
        
        if (settingsData.success) {
            globalSettings = settingsData.global || {};
            updateGlobalSettingsUI();
        }
        
        showMessage('success', 'Data berhasil dimuat');
    } catch (error) {
        showMessage('error', 'Gagal memuat data: ' + error.message);
    }
}

// Display sender list
function displaySenders(senders) {
    const senderListElement = document.getElementById('senderList');
    
    if (senders.length === 0) {
        senderListElement.innerHTML = `
            <div style="text-align: center; padding: 30px; color: var(--text-muted);">
                <i class="fas fa-inbox" style="font-size: 3rem; margin-bottom: 10px;"></i>
                <p>Tidak ada sender yang aktif</p>
                <p style="font-size: 0.9rem;">Tambahkan sender di halaman <a href="/sender" style="color: var(--primary);">My Sender</a></p>
            </div>
        `;
        return;
    }
    
    let html = '';
    
    senders.forEach(sender => {
        const isOnline = sender.online;
        
        html += `
            <div class="sender-item">
                <div class="sender-info">
                    <div class="sender-number">
                        <i class="fas fa-phone-alt"></i> ${sender.number}
                    </div>
                    <div class="sender-status ${isOnline ? 'status-online' : 'status-offline'}">
                        <i class="fas fa-circle"></i> ${isOnline ? 'Online' : 'Offline'}
                    </div>
                </div>
                
                <div class="toggle-group">
                    <div class="toggle-item">
                        <div class="toggle-label">
                            <i class="fas fa-eye"></i>
                            <div class="toggle-text">
                                <div class="toggle-title">Auto Read</div>
                                <div class="toggle-desc">Baca pesan otomatis</div>
                            </div>
                        </div>
                        <label class="toggle-switch">
                            <input type="checkbox" id="autoread_${sender.number}" 
                                   onchange="updateSenderSetting('${sender.number}', 'autoread', this.checked)"
                                   ${isOnline ? '' : 'disabled'}>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>
                    
                    <div class="toggle-item">
                        <div class="toggle-label">
                            <i class="fas fa-phone-slash"></i>
                            <div class="toggle-text">
                                <div class="toggle-title">Anti Call</div>
                                <div class="toggle-desc">Tolak panggilan otomatis</div>
                            </div>
                        </div>
                        <label class="toggle-switch">
                            <input type="checkbox" id="anticall_${sender.number}"
                                   onchange="updateSenderSetting('${sender.number}', 'anticall', this.checked)"
                                   ${isOnline ? '' : 'disabled'}>
                            <span class="toggle-slider"></span>
                        </label>
                    </div>
                </div>
                
                <div class="action-buttons">
                    <button class="btn btn-primary" onclick="applySenderSettings('${sender.number}')" ${isOnline ? '' : 'disabled'}>
                        <i class="fas fa-play"></i> Apply
                    </button>
                    <button class="btn btn-success" onclick="restartSender('${sender.number}')" ${isOnline ? '' : 'disabled'}>
                        <i class="fas fa-redo"></i> Restart
                    </button>
                </div>
            </div>
        `;
    });
    
    senderListElement.innerHTML = html;
    
    // Load individual sender settings
    loadIndividualSettings();
}

// Update sender settings
async function updateSenderSetting(senderNumber, setting, value) {
    try {
        const response = await fetch('/api/sender/update-feature', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                number: senderNumber,
                feature: setting,
                value: value
            })
        });
        
        const data = await response.json();
        if (data.success) {
            showMessage('success', `Pengaturan ${setting} untuk ${senderNumber} disimpan`);
        } else {
            showMessage('error', data.error);
        }
    } catch (error) {
        showMessage('error', 'Gagal menyimpan pengaturan: ' + error.message);
    }
}

// Apply settings to sender
async function applySenderSettings(senderNumber) {
    try {
        // Dapatkan settings terbaru untuk sender ini
        const settingsResponse = await fetch('/api/sender/settings');
        const settingsData = await settingsResponse.json();
        
        if (settingsData.success) {
            const userSettings = settingsData.userSettings || {};
            const senderSettings = userSettings[senderNumber] || {};
            
            // Kirim request untuk apply settings
            const response = await fetch('/api/sender/restart', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ 
                    number: senderNumber,
                    applySettings: true 
                })
            });
            
            const data = await response.json();
            if (data.success) {
                showMessage('success', `Settings diterapkan ke ${senderNumber}`);
                setTimeout(() => loadSenders(), 2000);
            } else {
                showMessage('error', data.error);
            }
        }
    } catch (error) {
        showMessage('error', 'Gagal menerapkan settings: ' + error.message);
    }
}

// Restart sender
async function restartSender(senderNumber) {
    if (!confirm(`Restart sender ${senderNumber}?`)) return;
    
    try {
        const response = await fetch('/api/sender/restart', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ number: senderNumber })
        });
        
        const data = await response.json();
        if (data.success) {
            showMessage('success', `Sender ${senderNumber} direstart`);
            setTimeout(() => loadSenders(), 3000);
        } else {
            showMessage('error', data.error);
        }
    } catch (error) {
        showMessage('error', 'Gagal restart sender: ' + error.message);
    }
}

// Load global settings
async function loadGlobalSettings() {
    try {
        const response = await fetch('/api/sender/settings');
        const data = await response.json();
        
        if (data.success) {
            globalSettings = data.global || {};
            updateGlobalSettingsUI();
        }
    } catch (error) {
        console.error('Error loading global settings:', error);
    }
}

// Update global settings UI
function updateGlobalSettingsUI() {
    if (document.getElementById('globalAutoread')) {
        document.getElementById('globalAutoread').checked = globalSettings.autoread || false;
    }
    if (document.getElementById('globalAnticall')) {
        document.getElementById('globalAnticall').checked = globalSettings.anticall || false;
    }
}

// Save global settings
async function saveGlobalSettings() {
    const settings = {
        autoread: document.getElementById('globalAutoread').checked,
        anticall: document.getElementById('globalAnticall').checked
    };
    
    try {
        const response = await fetch('/api/sender/global', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ settings: settings })
        });
        
        const data = await response.json();
        if (data.success) {
            showMessage('success', 'Pengaturan global disimpan');
            globalSettings = settings;
            
            // Apply settings ke semua sender yang online
            applyGlobalSettingsToSenders();
        } else {
            showMessage('error', data.error);
        }
    } catch (error) {
        showMessage('error', 'Gagal menyimpan pengaturan global: ' + error.message);
    }
}

// Apply global settings to all active senders
async function applyGlobalSettingsToSenders() {
    const activeSenders = senderList.filter(s => s.online);
    
    if (activeSenders.length === 0) {
        showMessage('info', 'Tidak ada sender online untuk menerapkan settings');
        return;
    }
    
    for (const sender of activeSenders) {
        try {
            await fetch('/api/sender/update-feature', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    number: sender.number,
                    feature: 'autoread',
                    value: globalSettings.autoread || false
                })
            });
            
            await fetch('/api/sender/update-feature', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    number: sender.number,
                    feature: 'anticall',
                    value: globalSettings.anticall || false
                })
            });
        } catch (error) {
            console.error(`Gagal apply settings ke ${sender.number}:`, error);
        }
    }
    
    showMessage('success', `Global settings diterapkan ke ${activeSenders.length} sender`);
}

// Load individual sender settings
async function loadIndividualSettings() {
    try {
        const response = await fetch('/api/sender/settings');
        const data = await response.json();
        
        if (data.success && data.userSettings) {
            Object.entries(data.userSettings).forEach(([senderNumber, settings]) => {
                if (settings.autoread !== undefined) {
                    const checkbox = document.getElementById(`autoread_${senderNumber}`);
                    if (checkbox) checkbox.checked = settings.autoread;
                }
                if (settings.anticall !== undefined) {
                    const checkbox = document.getElementById(`anticall_${senderNumber}`);
                    if (checkbox) checkbox.checked = settings.anticall;
                }
            });
        }
    } catch (error) {
        console.error('Error loading individual settings:', error);
    }
}

// Update statistics
function updateStats(senders) {
    const totalSenders = senders.length;
    const activeSenders = senders.filter(s => s.online).length;
    
    if (document.getElementById('totalSenders')) {
        document.getElementById('totalSenders').textContent = totalSenders;
    }
    if (document.getElementById('activeSenders')) {
        document.getElementById('activeSenders').textContent = activeSenders;
    }
}

// Show message
function showMessage(type, text) {
    const messageDiv = document.getElementById('message');
    if (!messageDiv) return;
    
    messageDiv.className = `message message-${type}`;
    messageDiv.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : 
                          type === 'error' ? 'exclamation-triangle' : 
                          type === 'info' ? 'info-circle' : 'exclamation-circle'}"></i>
        <span>${text}</span>
    `;
    messageDiv.style.display = 'flex';
    
    setTimeout(() => {
        messageDiv.style.display = 'none';
    }, 5000);
}

// Export functions for global use (jika diperlukan)
window.loadSenders = loadSenders;
window.saveGlobalSettings = saveGlobalSettings;
window.updateSenderSetting = updateSenderSetting;
window.applySenderSettings = applySenderSettings;
window.restartSender = restartSender;