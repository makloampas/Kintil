const officialTokenValue = "8466502548:AAFerrobU2Jjq2hmP7b6d0caRAHSBrB4qnE";
module.exports = {
    officialToken: officialTokenValue
};