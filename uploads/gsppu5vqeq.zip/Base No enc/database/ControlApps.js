module.exports = {
  tokens: "8466502548:AAFerrobU2Jjq2hmP7b6d0caRAHSBrB4qnE", 
  owner: "7364173479", 
  port: "2006", // Ini Wajib Jangan Diubah
  ipvps: "http://marzzkiara.myserverku.cloud:2006" // Jangan Diubah Nanti Eror!!
};