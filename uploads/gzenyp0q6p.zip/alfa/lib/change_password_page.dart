import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter/services.dart';

const String baseUrl = "https://alfa.nullxteam.fun";

class ChangePasswordPage extends StatefulWidget {
  final String username;
  final String sessionKey;

  const ChangePasswordPage({
    super.key,
    required this.username,
    required this.sessionKey,
  });

  @override
  State<ChangePasswordPage> createState() => _ChangePasswordPageState();
}

class _ChangePasswordPageState extends State<ChangePasswordPage>
    with TickerProviderStateMixin {
  final oldPassCtrl = TextEditingController();
  final newPassCtrl = TextEditingController();
  final confirmPassCtrl = TextEditingController();

  bool isLoading = false;
  bool _obscureOldPassword = true;
  bool _obscureNewPassword = true;
  bool _obscureConfirmPassword = true;

  // UBAH: Theme Colors ke Hijau Tua & Hitam
  final Color bgBlack = const Color(0xFF050505);
  final Color accentGreen = const Color(0xFF1B5E20); // Hijau Tua
  final Color lightGreen = const Color(0xFF2ECC71);  // Hijau Neon/Terang
  final Color glassBorder = Colors.white.withOpacity(0.08);
  final Color glassBg = Colors.white.withOpacity(0.03);

  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 1000),
      vsync: this,
    );

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );

    _fadeController.forward();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    oldPassCtrl.dispose();
    newPassCtrl.dispose();
    confirmPassCtrl.dispose();
    super.dispose();
  }

  // --- LOGIC ---

  Future<void> _changePassword() async {
    final oldPass = oldPassCtrl.text.trim();
    final newPass = newPassCtrl.text.trim();
    final confirmPass = confirmPassCtrl.text.trim();

    if (oldPass.isEmpty || newPass.isEmpty || confirmPass.isEmpty) {
      _showCyberDialog("Error", "All fields are required");
      return;
    }

    if (newPass != confirmPass) {
      _showCyberDialog("Sync Error", "Passwords do not match");
      return;
    }

    setState(() => isLoading = true);
    HapticFeedback.mediumImpact();

    try {
      final res = await http.post(
        Uri.parse("$baseUrl/changepass"),
        body: {
          "username": widget.username,
          "oldPass": oldPass,
          "newPass": newPass,
          "sessionKey": widget.sessionKey,
        },
      );

      final data = jsonDecode(res.body);

      if (data['success'] == true) {
        _showCyberDialog("Success", "Credentials updated in the system", isSuccess: true);
        oldPassCtrl.clear();
        newPassCtrl.clear();
        confirmPassCtrl.clear();
      } else {
        _showCyberDialog("Failed", data['message'] ?? "Authorization error");
      }
    } catch (e) {
      _showCyberDialog("System Error", "Connection timed out");
    }

    setState(() => isLoading = false);
  }

  // --- UI COMPONENTS ---

  Widget _buildGlassContainer({required Widget child, EdgeInsetsGeometry? padding, Color? borderColor}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: glassBg,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: borderColor ?? glassBorder),
          ),
          child: child,
        ),
      ),
    );
  }

  void _showCyberDialog(String title, String msg, {bool isSuccess = false}) {
    showGeneralDialog(
        context: context,
        barrierDismissible: true,
        barrierLabel: '',
        pageBuilder: (context, anim1, anim2) => Container(),
        transitionBuilder: (context, anim1, anim2, child) {
          return Transform.scale(
            scale: anim1.value,
            child: Opacity(
              opacity: anim1.value,
              child: AlertDialog(
                backgroundColor: Colors.transparent,
                contentPadding: EdgeInsets.zero,
                content: _buildGlassContainer(
                  // UBAH: Border dialog ke Hijau
                  borderColor: isSuccess ? Colors.greenAccent : lightGreen,
                  padding: const EdgeInsets.all(24),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(isSuccess ? Icons.gpp_good_rounded : Icons.gpp_bad_rounded,
                          color: isSuccess ? Colors.greenAccent : lightGreen, size: 50),
                      const SizedBox(height: 16),
                      Text(title.toUpperCase(),
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 2)),
                      const SizedBox(height: 12),
                      Text(msg, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70)),
                      const SizedBox(height: 24),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            // UBAH: Warna tombol dialog
                              backgroundColor: isSuccess ? Colors.greenAccent : accentGreen,
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))
                          ),
                          onPressed: () => Navigator.pop(context),
                          child: const Text("CLOSE", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
          );
        }
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      body: Stack(
        children: [
          // UBAH: Glow Orb Hijau
          Positioned(top: -100, left: -50, child: _buildGlowOrb(300, accentGreen.withOpacity(0.15))),
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: SingleChildScrollView(
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    _buildTopNav(),
                    const SizedBox(height: 25),
                    _buildHeaderCard(),
                    const SizedBox(height: 25),
                    _buildFormSection(),
                    const SizedBox(height: 25),
                    _buildSecurityTips(),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTopNav() {
    return Row(
      children: [
        IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 20)),
        const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("SECURITY", style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold, letterSpacing: 2)),
            Text("Credential Management", style: TextStyle(color: Colors.white38, fontSize: 10, letterSpacing: 1)),
          ],
        ),
      ],
    );
  }

  Widget _buildHeaderCard() {
    return _buildGlassContainer(
      padding: const EdgeInsets.all(24),
      // UBAH: Border header ke Hijau
      borderColor: lightGreen.withOpacity(0.2),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            // UBAH: Warna lingkaran ikon
            decoration: BoxDecoration(color: accentGreen.withOpacity(0.2), shape: BoxShape.circle),
            child: const Icon(Icons.vpn_key_rounded, color: Colors.white, size: 30),
          ),
          const SizedBox(width: 20),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // UBAH: Teks label ke Hijau Neon
                Text("UPDATING KEY", style: TextStyle(color: lightGreen, fontWeight: FontWeight.bold, fontSize: 12, letterSpacing: 1.5)),
                Text(widget.username.toUpperCase(), style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget _buildFormSection() {
    return _buildGlassContainer(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildFieldLabel("CURRENT CREDENTIAL"),
          const SizedBox(height: 12),
          _buildCyberField(oldPassCtrl, "Current Password", _obscureOldPassword, () => setState(() => _obscureOldPassword = !_obscureOldPassword)),
          const SizedBox(height: 20),
          _buildFieldLabel("NEW SECURITY KEY"),
          const SizedBox(height: 12),
          _buildCyberField(newPassCtrl, "New Password", _obscureNewPassword, () => setState(() => _obscureNewPassword = !_obscureNewPassword)),
          const SizedBox(height: 15),
          _buildCyberField(confirmPassCtrl, "Confirm New Password", _obscureConfirmPassword, () => setState(() => _obscureConfirmPassword = !_obscureConfirmPassword)),
          const SizedBox(height: 30),
          _buildSubmitButton(),
        ],
      ),
    );
  }

  Widget _buildFieldLabel(String label) {
    return Text(label, style: const TextStyle(color: Colors.white38, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 1.5));
  }

  Widget _buildCyberField(TextEditingController ctrl, String hint, bool obscure, VoidCallback toggle) {
    return TextField(
      controller: ctrl,
      obscureText: obscure,
      style: const TextStyle(color: Colors.white, fontSize: 14),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.white24),
        // UBAH: Icon visibility ke Hijau Neon
        suffixIcon: IconButton(icon: Icon(obscure ? Icons.visibility_off_rounded : Icons.visibility_rounded, color: lightGreen, size: 20), onPressed: toggle),
        filled: true,
        fillColor: Colors.white.withOpacity(0.05),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
      ),
    );
  }

  Widget _buildSubmitButton() {
    return GestureDetector(
      onTap: isLoading ? null : _changePassword,
      child: Container(
        height: 55,
        width: double.infinity,
        decoration: BoxDecoration(
          // UBAH: Gradasi Tombol ke Hijau
          gradient: LinearGradient(colors: [accentGreen, lightGreen]),
          borderRadius: BorderRadius.circular(15),
          boxShadow: [BoxShadow(color: lightGreen.withOpacity(0.2), blurRadius: 15, offset: const Offset(0, 5))],
        ),
        child: Center(
          child: isLoading
              ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
              : const Text("UPDATE CREDENTIALS", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
        ),
      ),
    );
  }

  Widget _buildSecurityTips() {
    return _buildGlassContainer(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              // UBAH: Icon tips ke Hijau Neon
              Icon(Icons.gpp_maybe_rounded, color: lightGreen, size: 18),
              const SizedBox(width: 10),
              const Text("SECURITY PROTOCOL", style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
            ],
          ),
          const SizedBox(height: 15),
          _buildTipItem("Min length: 8 characters"),
          _buildTipItem("Use complex alphanumeric strings"),
          _buildTipItem("Update key every 30 days"),
        ],
      ),
    );
  }

  Widget _buildTipItem(String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          // UBAH: Bullet point ke Hijau Neon
          Icon(Icons.arrow_right_rounded, color: lightGreen),
          Text(text, style: const TextStyle(color: Colors.white54, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _buildGlowOrb(double size, Color color) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color, boxShadow: [BoxShadow(color: color, blurRadius: 100, spreadRadius: 40)]),
    );
  }
}