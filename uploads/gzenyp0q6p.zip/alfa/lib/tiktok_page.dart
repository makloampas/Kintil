import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';

class TiktokDownloaderPage extends StatefulWidget {
  const TiktokDownloaderPage({super.key});

  @override
  State<TiktokDownloaderPage> createState() => _TiktokDownloaderPageState();
}

class _TiktokDownloaderPageState extends State<TiktokDownloaderPage> {
  final TextEditingController _urlController = TextEditingController();
  bool _isLoading = false;
  Map<String, dynamic>? _videoData;
  String? _errorMessage;
  VideoPlayerController? _videoController;
  ChewieController? _chewieController;

  // UBAH: Theme Colors ke Deep Green & Black
  final Color bgBlack = const Color(0xFF050505);
  final Color accentGreen = const Color(0xFF1B5E20);
  final Color lightGreen = const Color(0xFF2ECC71);
  final Color glassBorder = Colors.white.withOpacity(0.08);
  final Color glassBg = Colors.white.withOpacity(0.04);

  @override
  void dispose() {
    _urlController.dispose();
    _videoController?.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  // --- API LOGIC ---
  Future<void> _downloadTiktok() async {
    final url = _urlController.text.trim();
    if (url.isEmpty) {
      _showSnackBar("URL is required for extraction", Colors.redAccent);
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _videoData = null;
      _videoController?.dispose();
      _chewieController?.dispose();
    });

    final apiUrl = Uri.parse("https://api.siputzx.my.id/api/d/tiktok?url=$url");

    try {
      final response = await http.get(apiUrl);
      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        if (json['status'] == true && json['data'] != null) {
          setState(() {
            _videoData = json['data'];
          });
          _initializeVideoPlayer();
        } else {
          setState(() => _errorMessage = "Extraction failed: Invalid data stream");
        }
      } else {
        setState(() => _errorMessage = "Server uplink failed");
      }
    } catch (e) {
      setState(() => _errorMessage = "Error: Protocol interrupt");
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _initializeVideoPlayer() {
    if (_videoData?['urls'] != null && _videoData!['urls'].isNotEmpty) {
      final videoUrl = _videoData!['urls'][0];
      _videoController = VideoPlayerController.networkUrl(Uri.parse(videoUrl))
        ..initialize().then((_) {
          setState(() {
            _chewieController = ChewieController(
              videoPlayerController: _videoController!,
              autoPlay: true,
              looping: false,
              showControls: true,
              materialProgressColors: ChewieProgressColors(
                playedColor: lightGreen,
                handleColor: lightGreen,
                backgroundColor: Colors.white10,
                bufferedColor: Colors.white24,
              ),
            );
          });
        });
    }
  }

  Future<void> _shareVideo() async {
    if (_videoData?['urls'] == null || _videoData!['urls'].isEmpty) return;
    try {
      final videoUrl = _videoData!['urls'][0];
      final response = await http.get(Uri.parse(videoUrl));
      final tempDir = await getTemporaryDirectory();
      final file = File('${tempDir.path}/tt_export_${DateTime.now().millisecondsSinceEpoch}.mp4');
      await file.writeAsBytes(response.bodyBytes);

      await Share.shareXFiles([XFile(file.path)],
        text: 'Decrypted TikTok: ${_videoData!['metadata']?['title'] ?? ''}',
      );
    } catch (e) {
      _showSnackBar("Export failed: $e", Colors.redAccent);
    }
  }

  void _showSnackBar(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message, style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
        backgroundColor: color.withOpacity(0.9),
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(20),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
      ),
    );
  }

  // --- UI COMPONENTS ---

  Widget _buildGlassContainer({required Widget child, EdgeInsetsGeometry? padding, Color? borderColor}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: glassBg,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: borderColor ?? glassBorder),
          ),
          child: child,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      body: Stack(
        children: [
          Positioned(top: -50, left: -50, child: _buildGlowOrb(300, accentGreen.withOpacity(0.15))),
          Positioned(bottom: -50, right: -50, child: _buildGlowOrb(200, lightGreen.withOpacity(0.05))),

          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 20),
                  _buildHeader(),
                  const SizedBox(height: 30),

                  // Input Section
                  _buildGlassContainer(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        TextField(
                          controller: _urlController,
                          style: const TextStyle(color: Colors.white, fontSize: 14, fontFamily: 'monospace'),
                          decoration: InputDecoration(
                            hintText: 'INSERT TIKTOK LINK...',
                            hintStyle: const TextStyle(color: Colors.white12, fontSize: 12),
                            filled: true,
                            fillColor: Colors.black.withOpacity(0.3),
                            prefixIcon: Icon(Icons.webhook_rounded, color: lightGreen, size: 20),
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
                            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: glassBorder)),
                          ),
                        ),
                        const SizedBox(height: 15),
                        _buildMainButton(),
                      ],
                    ),
                  ),

                  const SizedBox(height: 20),

                  if (_errorMessage != null)
                    Center(child: Text(_errorMessage!, style: TextStyle(color: Colors.redAccent.withOpacity(0.7), fontSize: 11, fontWeight: FontWeight.bold))),

                  // Result Section
                  Expanded(
                    child: _videoData != null
                        ? SingleChildScrollView(
                      physics: const BouncingScrollPhysics(),
                      child: _buildResultCard(),
                    )
                        : _buildEmptyState(),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: _buildGlassContainer(
            padding: const EdgeInsets.all(10),
            child: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 18),
          ),
        ),
        const SizedBox(width: 15),
        const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("TIKTOK PRO", style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 1)),
            Text("No-Watermark Media Extractor", style: TextStyle(color: Color(0xFF2ECC71), fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
          ],
        ),
      ],
    );
  }

  Widget _buildMainButton() {
    return GestureDetector(
      onTap: _isLoading ? null : _downloadTiktok,
      child: Container(
        height: 55,
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [accentGreen, lightGreen]),
          borderRadius: BorderRadius.circular(15),
          boxShadow: [BoxShadow(color: lightGreen.withOpacity(0.1), blurRadius: 10, offset: const Offset(0, 5))],
        ),
        child: Center(
          child: _isLoading
              ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2))
              : const Text("INITIALIZE EXTRACTION", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, letterSpacing: 1.5, fontSize: 13)),
        ),
      ),
    );
  }

  Widget _buildResultCard() {
    return _buildGlassContainer(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          if (_chewieController != null && _videoController!.value.isInitialized)
            ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: AspectRatio(
                aspectRatio: _videoController!.value.aspectRatio,
                child: Chewie(controller: _chewieController!),
              ),
            )
          else
            const SizedBox(height: 200, child: Center(child: CircularProgressIndicator(color: Color(0xFF2ECC71)))),
          const SizedBox(height: 20),
          Text(
            _videoData!['metadata']?['title'] ?? 'Extracted Stream',
            style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14),
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          const SizedBox(height: 8),
          _buildGlassContainer(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: Text(
              "SOURCE: ${_videoData!['metadata']?['creator'] ?? 'IDENT_UNKNOWN'}",
              style: TextStyle(color: lightGreen.withOpacity(0.7), fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'monospace'),
            ),
          ),
          const SizedBox(height: 25),
          GestureDetector(
            onTap: _shareVideo,
            child: Container(
              padding: const EdgeInsets.symmetric(vertical: 15),
              decoration: BoxDecoration(
                color: lightGreen.withOpacity(0.05),
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: lightGreen.withOpacity(0.3)),
              ),
              child: const Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.ios_share_rounded, color: Color(0xFF2ECC71), size: 18),
                  const SizedBox(width: 10),
                  Text("EXPORT TO DEVICE", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13, letterSpacing: 1)),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.cloud_sync_rounded, color: Colors.white.withOpacity(0.03), size: 120),
          const SizedBox(height: 15),
          Text("AWAITING STREAM URL", style: TextStyle(color: Colors.white.withOpacity(0.15), letterSpacing: 2, fontWeight: FontWeight.bold, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _buildGlowOrb(double size, Color color) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color, boxShadow: [BoxShadow(color: color, blurRadius: 100, spreadRadius: 40)]),
    );
  }
}