const global = {
    owner: [7093265853], // ganti jadi id mu
    botToken: "8372591585:AAH8so6aHJn1OUgzcmQ0NUzYXxnke2NlrHY", //isi make token bot mu
}

module.exports = global;