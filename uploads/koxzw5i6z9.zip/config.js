module.exports = {
  BOT_TOKEN: "8362671236:AAGc9dwDD7X3sWr9WFgOycWJAcY-Iti0xgk",
  OWNER_ID: ["8353486366"],
};