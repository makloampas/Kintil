module.exports = {
  tokens: "8530623984:AAE0tGJldpaBbHA7i8DWQm1rgWv2SR4B2eA",  // Ubah Jadi Token Bot Mu !!!
  owner: "7582105036", // Ubah Jadi Id Mu !!!
  port: "4385", // Ubah Jadi Port Panel Mu !!!
  ipvps: "https://widixprivate.storexyz.web.id" // Ubah Jadi Ip Vps Mu !!!
};