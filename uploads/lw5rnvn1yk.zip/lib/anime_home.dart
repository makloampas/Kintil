import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shimmer/shimmer.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:webview_flutter/webview_flutter.dart';
import 'package:shared_preferences/shared_preferences.dart';

// --- MAIN PAGE (ANIME HOME) ---
class HomeAnimePage extends StatefulWidget {
  const HomeAnimePage({super.key});

  @override
  State<HomeAnimePage> createState() => _HomeAnimePageState();
}

class _HomeAnimePageState extends State<HomeAnimePage> {
  Map<String, dynamic>? animeData;
  bool isLoading = true;
  bool isSearching = false;
  List<dynamic> searchResults = [];
  final TextEditingController _searchController = TextEditingController();
  final FocusNode _searchFocusNode = FocusNode();
  List<Map<String, dynamic>> _watchHistory = [];
  bool _isHistoryLoading = true;

  // --- PALETTE WARNA NEON ---
  final Color primaryPurple = const Color(0xFFD500F9);
  final Color primaryPink = const Color(0xFFFF4081);
  final Color bgDark = const Color(0xFF141414);

  @override
  void initState() {
    super.initState();
    fetchAnimeData();
    _loadWatchHistory();
  }

  void refreshHistory() {
    _loadWatchHistory();
  }

  Future<void> _loadWatchHistory() async {
    setState(() => _isHistoryLoading = true);
    try {
      final prefs = await SharedPreferences.getInstance();
      final historyJson = prefs.getStringList('anime_history') ?? [];
      setState(() {
        _watchHistory = historyJson
            .map((item) => Map<String, dynamic>.from(json.decode(item)))
            .toList();
        _isHistoryLoading = false;
      });
    } catch (e) {
      debugPrint('Error loading history: $e');
      setState(() => _isHistoryLoading = false);
    }
  }

  // --- FETCH DATA MENGGUNAKAN JIKAN API (STABIL) ---
  Future<void> fetchAnimeData() async {
    try {
      // Ongoing (Season Now)
      final ongoingRes = await http.get(Uri.parse('https://api.jikan.moe/v4/seasons/now?limit=10'));
      // Top Anime
      final topRes = await http.get(Uri.parse('https://api.jikan.moe/v4/top/anime?filter=bypopularity&limit=10'));

      if (ongoingRes.statusCode == 200 && topRes.statusCode == 200) {
        final ongoingJson = json.decode(ongoingRes.body)['data'] as List;
        final topJson = json.decode(topRes.body)['data'] as List;

        setState(() {
          animeData = {
            'ongoing_anime': ongoingJson.map((e) => _mapJikanToApp(e)).toList(),
            'top_anime': topJson.map((e) => _mapJikanToApp(e)).toList(),
          };
          isLoading = false;
        });
      } else {
        throw Exception('Gagal memuat data anime');
      }
    } catch (e) {
      debugPrint('Error: $e');
      if (mounted) setState(() => isLoading = false);
    }
  }

  Future<void> searchAnime(String query) async {
    if (query.isEmpty) {
      setState(() {
        isSearching = false;
        searchResults.clear();
      });
      return;
    }

    setState(() => isSearching = true);

    try {
      final response = await http.get(
        Uri.parse('https://api.jikan.moe/v4/anime?q=$query&limit=10'),
      );

      if (response.statusCode == 200) {
        final jsonData = json.decode(response.body);
        final rawList = jsonData['data'] as List;
        setState(() {
          searchResults = rawList.map((e) => _mapJikanToApp(e)).toList();
        });
      } else {
        setState(() => searchResults = []);
      }
    } catch (e) {
      debugPrint('Search Error: $e');
      setState(() => searchResults = []);
    }
  }

  Map<String, dynamic> _mapJikanToApp(dynamic item) {
    return {
      'title': item['title'] ?? 'No Title',
      'poster': item['images']['jpg']['large_image_url'] ?? '',
      'score': item['score']?.toString() ?? 'N/A',
      'type': item['type'] ?? 'TV',
      'status': item['status'] ?? 'Unknown',
      'episodes': item['episodes']?.toString() ?? '?',
      'slug': item['mal_id'].toString(), // ID Jikan
      'synopsis': item['synopsis'] ?? '',
      'year': item['year']?.toString() ?? '-',
      'genres': (item['genres'] as List?)?.map((g) => {'name': g['name']}).toList() ?? [],
    };
  }

  void _clearSearch() {
    _searchController.clear();
    setState(() {
      isSearching = false;
      searchResults.clear();
    });
    _searchFocusNode.unfocus();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: Column(
        children: [
          // Search Bar
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              controller: _searchController,
              focusNode: _searchFocusNode,
              style: const TextStyle(color: Colors.white),
              textInputAction: TextInputAction.search,
              decoration: InputDecoration(
                hintText: "Search anime on Subnime...",
                hintStyle: const TextStyle(color: Colors.grey),
                prefixIcon: Icon(Icons.search, color: primaryPurple),
                suffixIcon: _searchController.text.isNotEmpty
                    ? IconButton(
                        icon: const Icon(Icons.clear, color: Colors.grey),
                        onPressed: _clearSearch,
                      )
                    : null,
                filled: true,
                fillColor: Colors.white.withOpacity(0.05),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12.0),
                  borderSide: BorderSide(color: primaryPurple.withOpacity(0.3)),
                ),
                enabledBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12.0),
                  borderSide: BorderSide(color: Colors.white.withOpacity(0.1)),
                ),
                focusedBorder: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12.0),
                  borderSide: BorderSide(color: primaryPurple),
                ),
              ),
              onSubmitted: (value) {
                if (value.trim().isNotEmpty) {
                  _searchFocusNode.unfocus();
                  searchAnime(value.trim());
                }
              },
            ),
          ),

          // Content
          Expanded(
            child: isLoading
                ? _buildLoadingShimmer()
                : isSearching
                    ? _buildSearchResults()
                    : animeData == null
                        ? _buildErrorWidget()
                        : _buildHomeContent(),
          ),
        ],
      ),
    );
  }

  Widget _buildHomeContent() {
    return RefreshIndicator(
      onRefresh: () async {
        await Future.wait([fetchAnimeData(), _loadWatchHistory()]);
      },
      color: primaryPink,
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // History
            if (!_isHistoryLoading && _watchHistory.isNotEmpty) ...[
              _buildSectionHeader(Icons.history, "Resume Watching"),
              const SizedBox(height: 12),
              SizedBox(
                height: 220,
                child: ListView.builder(
                  scrollDirection: Axis.horizontal,
                  itemCount: _watchHistory.length,
                  itemBuilder: (context, index) {
                    return _buildHistoryCard(_watchHistory[index]);
                  },
                ),
              ),
              const SizedBox(height: 24),
            ],

            // Quick Access
            _buildSectionHeader(Icons.explore, "Subnime Explorer"),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: _buildQuickAccessCard("Subnime Home", Icons.web, () {
                  Navigator.push(context, MaterialPageRoute(builder: (_) => const SubnimeWebView(url: "https://subnime.com")));
                })),
                const SizedBox(width: 12),
                Expanded(child: _buildQuickAccessCard("Trending", Icons.local_fire_department, () {
                   Navigator.push(context, MaterialPageRoute(builder: (_) => const SubnimeWebView(url: "https://subnime.com/trending/")));
                })),
              ],
            ),
            const SizedBox(height: 24),

            // Ongoing Anime
            _buildSectionHeader(Icons.calendar_today, "Simulcast (Ongoing)"),
            const SizedBox(height: 12),
            _buildAnimeGrid(animeData!['ongoing_anime']),
            const SizedBox(height: 24),

            // Top Anime
            _buildSectionHeader(Icons.star, "Top Rated"),
            const SizedBox(height: 12),
            _buildAnimeGrid(animeData!['top_anime']),
            const SizedBox(height: 80),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionHeader(IconData icon, String title) {
    return Row(
      children: [
        Icon(icon, color: primaryPink, size: 24),
        const SizedBox(width: 8),
        Text(
          title,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
      ],
    );
  }

  Widget _buildHistoryCard(Map<String, dynamic> anime) {
    return Container(
      width: 120,
      margin: const EdgeInsets.only(right: 12),
      child: GestureDetector(
        onTap: () {
          // Open direct webview search for history item
          final url = "https://subnime.com/?s=${Uri.encodeComponent(anime['title'])}";
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => SubnimeWebView(url: url, title: anime['title']),
            ),
          );
        },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Stack(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(8),
                  child: Image.network(
                    anime['poster'],
                    height: 160,
                    width: 120,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(color: Colors.white10),
                  ),
                ),
                Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: Container(
                    padding: const EdgeInsets.symmetric(vertical: 4),
                    color: Colors.black87.withOpacity(0.8),
                    child: const Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.play_circle_fill, color: Colors.white, size: 12),
                        SizedBox(width: 4),
                        Text("Watch", style: TextStyle(color: Colors.white, fontSize: 10)),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              anime['title'],
              style: const TextStyle(color: Colors.white, fontSize: 12),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildAnimeGrid(List<dynamic> list) {
    return GridView.builder(
      itemCount: list.length,
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 2,
        mainAxisExtent: 280,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemBuilder: (context, index) {
        final anime = list[index];
        return GestureDetector(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => AnimeDetailPage(
                  animeData: anime,
                  onHistoryUpdate: refreshHistory,
                ),
              ),
            );
          },
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.network(
                        anime['poster'],
                        fit: BoxFit.cover,
                        errorBuilder: (_, __, ___) => Container(color: Colors.white10),
                      ),
                      // Gradient overlay
                      Positioned.fill(
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                              colors: [Colors.transparent, Colors.black.withOpacity(0.8)],
                            ),
                          ),
                        ),
                      ),
                      // Score Badge
                      Positioned(
                        top: 8,
                        right: 8,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                          decoration: BoxDecoration(
                            color: primaryPurple,
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            anime['score'],
                            style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                anime['title'],
                style: const TextStyle(
                    fontSize: 13, fontWeight: FontWeight.w600, color: Colors.white),
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              const SizedBox(height: 4),
              Text(
                "${anime['type']} • ${anime['episodes']} Eps",
                style: TextStyle(fontSize: 11, color: Colors.grey[400]),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSearchResults() {
    if (searchResults.isEmpty) {
      return const Center(child: Text("No anime found", style: TextStyle(color: Colors.white)));
    }
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: searchResults.length,
      itemBuilder: (context, index) {
        final anime = searchResults[index];
        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.05),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: Colors.white10),
          ),
          child: ListTile(
            contentPadding: const EdgeInsets.all(8),
            leading: ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.network(anime['poster'], width: 60, height: 90, fit: BoxFit.cover),
            ),
            title: Text(anime['title'], style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            subtitle: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 4),
                Text("${anime['type']} • ${anime['year']}", style: const TextStyle(color: Colors.grey)),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Icon(Icons.star, size: 14, color: primaryPink),
                    const SizedBox(width: 4),
                    Text(anime['score'], style: TextStyle(color: primaryPink)),
                  ],
                ),
              ],
            ),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => AnimeDetailPage(
                    animeData: anime,
                    onHistoryUpdate: refreshHistory,
                  ),
                ),
              );
            },
          ),
        );
      },
    );
  }

  Widget _buildLoadingShimmer() {
    return const Center(child: CircularProgressIndicator(color: Color(0xFFD500F9)));
  }

  Widget _buildErrorWidget() {
    return Center(
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(backgroundColor: primaryPurple),
        onPressed: fetchAnimeData,
        child: const Text("Retry Connection", style: TextStyle(color: Colors.white)),
      ),
    );
  }

  Widget _buildQuickAccessCard(String title, IconData icon, VoidCallback onTap) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [primaryPurple.withOpacity(0.2), primaryPink.withOpacity(0.2)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: primaryPurple.withOpacity(0.3)),
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Icon(icon, color: Colors.white, size: 28),
              const SizedBox(height: 8),
              Text(title,
                  style: const TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.bold)),
            ],
          ),
        ),
      ),
    );
  }
}

// --- ANIME DETAIL PAGE ---
class AnimeDetailPage extends StatefulWidget {
  final Map<String, dynamic> animeData;
  final Function()? onHistoryUpdate;

  const AnimeDetailPage({super.key, required this.animeData, this.onHistoryUpdate});

  @override
  State<AnimeDetailPage> createState() => _AnimeDetailPageState();
}

class _AnimeDetailPageState extends State<AnimeDetailPage> {
  final Color primaryPurple = const Color(0xFFD500F9);
  final Color primaryPink = const Color(0xFFFF4081);

  @override
  void initState() {
    super.initState();
    _saveHistory();
  }

  Future<void> _saveHistory() async {
    final prefs = await SharedPreferences.getInstance();
    final historyJson = prefs.getStringList('anime_history') ?? [];
    List<Map<String, dynamic>> history = historyJson
        .map((item) => Map<String, dynamic>.from(json.decode(item)))
        .toList();

    // Avoid duplicates
    history.removeWhere((item) => item['slug'] == widget.animeData['slug']);
    history.insert(0, widget.animeData);
    
    // Limit history
    if (history.length > 20) history = history.sublist(0, 20);

    await prefs.setStringList('anime_history', history.map((e) => json.encode(e)).toList());
    if (widget.onHistoryUpdate != null) widget.onHistoryUpdate!();
  }

  @override
  Widget build(BuildContext context) {
    final anime = widget.animeData;
    
    return Scaffold(
      backgroundColor: const Color(0xFF050505),
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            expandedHeight: 400,
            backgroundColor: const Color(0xFF050505),
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                fit: StackFit.expand,
                children: [
                  Image.network(
                    anime['poster'],
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) => Container(color: Colors.grey[900]),
                  ),
                  // Gradient Overlay
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter,
                        end: Alignment.bottomCenter,
                        colors: [
                          Colors.transparent,
                          const Color(0xFF050505).withOpacity(0.5),
                          const Color(0xFF050505),
                        ],
                      ),
                    ),
                  ),
                  Positioned(
                    bottom: 20,
                    left: 20,
                    right: 20,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                          decoration: BoxDecoration(
                            color: primaryPurple,
                            borderRadius: BorderRadius.circular(4),
                          ),
                          child: Text(
                            anime['type'],
                            style: const TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Text(
                          anime['title'],
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 24,
                            fontWeight: FontWeight.bold,
                            shadows: [Shadow(color: Colors.black, blurRadius: 10)],
                          ),
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            const Icon(Icons.star, color: Colors.amber, size: 20),
                            const SizedBox(width: 4),
                            Text(anime['score'], style: const TextStyle(color: Colors.white, fontSize: 16)),
                            const SizedBox(width: 16),
                            const Icon(Icons.movie, color: Colors.grey, size: 20),
                            const SizedBox(width: 4),
                            Text("${anime['episodes']} Episodes", style: const TextStyle(color: Colors.white, fontSize: 16)),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Watch Button
                  Container(
                    width: double.infinity,
                    height: 50,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(colors: [primaryPurple, primaryPink]),
                      borderRadius: BorderRadius.circular(25),
                      boxShadow: [
                        BoxShadow(color: primaryPurple.withOpacity(0.4), blurRadius: 10, offset: const Offset(0, 4)),
                      ],
                    ),
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        shadowColor: Colors.transparent,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25)),
                      ),
                      onPressed: () {
                        // Logic untuk membuka Subnime dengan pencarian judul anime
                        final url = "https://subnime.com/?s=${Uri.encodeComponent(anime['title'])}";
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => SubnimeWebView(url: url, title: anime['title']),
                          ),
                        );
                      },
                      icon: const Icon(Icons.play_arrow, color: Colors.white),
                      label: const Text("WATCH ON SUBNIME", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                    ),
                  ),
                  
                  const SizedBox(height: 24),
                  
                  // Genres
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: (anime['genres'] as List).map<Widget>((g) {
                      return Chip(
                        label: Text(g['name'], style: const TextStyle(color: Colors.white, fontSize: 12)),
                        backgroundColor: Colors.white.withOpacity(0.1),
                        side: BorderSide.none,
                      );
                    }).toList(),
                  ),
                  
                  const SizedBox(height: 24),
                  
                  const Text("Synopsis", style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text(
                    anime['synopsis'] ?? "No synopsis available.",
                    style: TextStyle(color: Colors.grey[400], height: 1.5),
                  ),
                  
                  const SizedBox(height: 40),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// --- SUBNIME WEBVIEW ---
class SubnimeWebView extends StatefulWidget {
  final String url;
  final String? title;

  const SubnimeWebView({super.key, required this.url, this.title});

  @override
  State<SubnimeWebView> createState() => _SubnimeWebViewState();
}

class _SubnimeWebViewState extends State<SubnimeWebView> {
  late WebViewController _controller;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF000000))
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (String url) {
            if(mounted) setState(() => _isLoading = true);
          },
          onPageFinished: (String url) {
            if(mounted) setState(() => _isLoading = false);
          },
          onNavigationRequest: (NavigationRequest request) {
            // Block ads or external non-video links if necessary (simple filter)
            return NavigationDecision.navigate;
          },
        ),
      )
      ..loadRequest(Uri.parse(widget.url));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        iconTheme: const IconThemeData(color: Colors.white),
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(widget.title ?? "Subnime", style: const TextStyle(color: Colors.white, fontSize: 14)),
            const Text("Source: subnime.com", style: TextStyle(color: Colors.grey, fontSize: 10)),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => _controller.reload(),
          ),
          IconButton(
            icon: const Icon(Icons.open_in_browser),
            onPressed: () => launchUrl(Uri.parse(widget.url), mode: LaunchMode.externalApplication),
          ),
        ],
      ),
      body: Stack(
        children: [
          WebViewWidget(controller: _controller),
          if (_isLoading)
            const Center(child: CircularProgressIndicator(color: Color(0xFFD500F9))),
        ],
      ),
    );
  }
}