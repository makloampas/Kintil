import 'dart:convert';
import 'dart:ui'; // Diperlukan untuk efek blur (BackdropFilter)
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  // Controllers
  final TextEditingController targetController = TextEditingController();
  late VideoPlayerController _videoController;
   
  // Animation Controllers
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  // State Variables
  bool _isVideoInitialized = false;
  String selectedBugId = "";
  bool _isSending = false;

  // --- PALETTE WARNA NEON ---
  final Color _neonPurple = const Color(0xFFD500F9); // Ungu Menyala
  final Color _neonPink = const Color(0xFFFF4081);   // Pink Menyala
  final Color _bgBlack = const Color(0xFF000000);    // Hitam Pekat

  @override
  void initState() {
    super.initState();

    // Init Animation
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
    _fadeAnimation = CurvedAnimation(parent: _fadeController, curve: Curves.easeIn);
    _fadeController.forward();

    // Set default selected bug
    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }

    // Init Video Background
    _initializeVideoPlayer();
  }

  void _initializeVideoPlayer() {
    // URL Video
    _videoController = VideoPlayerController.networkUrl(
      Uri.parse('https://i.top4top.io/m_36702w8j31.mp4'),
    )..initialize().then((_) {
        setState(() {
          _isVideoInitialized = true;
          // --- SET VOLUME KE 1.0 AGAR BERSUARA ---
          _videoController.setVolume(1.0); 
          // --------------------------------------
          _videoController.setLooping(true);
          _videoController.play();
        });
      }).catchError((error) {
        debugPrint("Error initializing video: $error");
      });
  }

  @override
  void dispose() {
    targetController.dispose();
    _videoController.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  // --- LOGIC PENGIRIMAN BUG ---
  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') || cleaned.length < 8) return null;
    return cleaned;
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final target = formatPhoneNumber(rawInput);
    final key = widget.sessionKey;

    if (target == null || key.isEmpty) {
      _showNotification("Invalid Number", "Gunakan format internasional (cth: +628xxx)", Colors.redAccent);
      return;
    }

    setState(() {
      _isSending = true;
    });

    try {
      final url = "http://izumidev.kennhosting.my.id:1544/sendBug?key=$key&target=$target&bug=$selectedBugId";
      final res = await http.get(Uri.parse(url));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) {
        _showNotification("⏳ Cooldown", "Harap tunggu beberapa saat sebelum mengirim lagi.", Colors.orange);
      } else if (data["valid"] == false) {
        _showNotification("❌ Invalid Key", "Sesi Anda tidak valid atau berakhir.", Colors.red);
      } else if (data["sended"] == false) {
        _showNotification("⚠️ Maintenance", "Server sedang dalam perbaikan.", Colors.redAccent);
      } else {
        _showNotification("✅ Success", "Bug berhasil dikirim ke $target!", _neonPurple);
        targetController.clear();
      }
    } catch (e) {
      _showNotification("❌ Error", "Gagal terhubung ke server.", Colors.red);
    } finally {
      if (mounted) {
        setState(() {
          _isSending = false;
        });
      }
    }
  }

  void _showNotification(String title, String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        content: ClipRRect(
          borderRadius: BorderRadius.circular(15),
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.8), // Background lebih gelap
                borderRadius: BorderRadius.circular(15),
                border: Border.all(color: color.withOpacity(0.8), width: 1.5), // Border berwarna neon
                boxShadow: [
                  BoxShadow(color: color.withOpacity(0.2), blurRadius: 15, spreadRadius: 1) // Efek Glow
                ]
              ),
              child: Row(
                children: [
                  Icon(
                    title.contains("Success") ? Icons.check_circle : Icons.info_outline,
                    color: color,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(title, style: TextStyle(color: color, fontWeight: FontWeight.bold, fontSize: 16)),
                        Text(msg, style: const TextStyle(color: Colors.white70, fontSize: 12)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        duration: const Duration(seconds: 3),
      ),
    );
  }

  // --- UI BUILDER ---

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: _bgBlack, 
      resizeToAvoidBottomInset: false, 
      body: Stack(
        children: [
          // 1. BACKGROUND VIDEO
          Positioned.fill(
            child: _isVideoInitialized
                ? FittedBox(
                    fit: BoxFit.cover,
                    child: SizedBox(
                      width: _videoController.value.size.width,
                      height: _videoController.value.size.height,
                      child: VideoPlayer(_videoController),
                    ),
                  )
                : Container(color: _bgBlack),
          ),

          // 2. PURPLE/BLACK GRADIENT OVERLAY (Agar tema Neon lebih terasa)
          Positioned.fill(
            child: Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    _bgBlack.withOpacity(0.3),
                    _bgBlack.withOpacity(0.8),
                    const Color(0xFF1A051A).withOpacity(0.9), // Sedikit ungu tua di bawah
                  ]
                )
              ),
            ),
          ),

          // 3. MAIN CONTENT
          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 10),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 10),
                     
                    // --- HEADER (PROFILE) ---
                    _buildNeonHeader(),

                    const SizedBox(height: 30),

                    // --- INPUT TARGET NUMBER ---
                    Text(
                      "Target Number",
                      style: TextStyle(
                        color: _neonPink, // Judul Pink
                        fontWeight: FontWeight.bold, 
                        fontSize: 14,
                        shadows: [Shadow(color: _neonPink.withOpacity(0.5), blurRadius: 10)]
                      ),
                    ),
                    const SizedBox(height: 8),
                    _buildNeonInputContainer(
                      child: TextField(
                        controller: targetController,
                        style: const TextStyle(color: Colors.white, fontSize: 16),
                        keyboardType: TextInputType.phone,
                        decoration: InputDecoration(
                          hintText: "e.g. +62xxxxxxxxxx",
                          hintStyle: TextStyle(color: Colors.white.withOpacity(0.3)),
                          border: InputBorder.none,
                          prefixIcon: Icon(Icons.call, color: _neonPurple, size: 20),
                          contentPadding: const EdgeInsets.symmetric(vertical: 14),
                        ),
                      ),
                    ),

                    const SizedBox(height: 20),

                    // --- DROPDOWN BUG TYPE ---
                    Text(
                      "Bug Type",
                      style: TextStyle(
                        color: _neonPurple, // Judul Ungu
                        fontWeight: FontWeight.bold, 
                        fontSize: 14,
                        shadows: [Shadow(color: _neonPurple.withOpacity(0.5), blurRadius: 10)]
                      ),
                    ),
                    const SizedBox(height: 8),
                    _buildNeonInputContainer(
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: selectedBugId,
                          dropdownColor: const Color(0xFF150515), // Background dropdown gelap ungu
                          icon: Icon(Icons.keyboard_arrow_down, color: _neonPink),
                          isExpanded: true,
                          style: const TextStyle(color: Colors.white),
                          items: widget.listBug.map((bug) {
                            return DropdownMenuItem<String>(
                              value: bug['bug_id'],
                              child: Row(
                                children: [
                                  Icon(Icons.bug_report, size: 16, color: _neonPink),
                                  const SizedBox(width: 10),
                                  Text(bug['bug_name']),
                                ],
                              ),
                            );
                          }).toList(),
                          onChanged: (val) {
                            setState(() {
                              selectedBugId = val!;
                            });
                          },
                        ),
                      ),
                    ),

                    const SizedBox(height: 40),

                    // --- MENU ICONS ---
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        _buildMenuIcon(Icons.dns, "Server", _neonPurple),
                        _buildMenuIcon(Icons.security, "Security", Colors.white),
                        _buildMenuIcon(Icons.storage, "Database", _neonPink),
                      ],
                    ),

                    const Spacer(),

                    // --- SEND BUTTON WITH ANIME ART ---
                    SizedBox(
                      height: 220, 
                      child: Stack(
                        alignment: Alignment.bottomCenter,
                        children: [
                          // Anime Character Image
                          Positioned(
                            bottom: 0,
                            left: 0,
                            child: Opacity(
                              opacity: 0.9,
                              child: Image.network(
                                'https://i.pinimg.com/originals/c9/22/68/c92268d92cf2dbf96e3195638d9214ce.png', 
                                height: 200,
                                fit: BoxFit.contain,
                                errorBuilder: (ctx, err, stack) => const SizedBox(),
                              ),
                            ),
                          ),
                           
                          // Send Button Strip
                          Positioned(
                            bottom: 60,
                            left: 0,
                            right: 0,
                            child: GestureDetector(
                              onTap: _isSending ? null : _sendBug,
                              child: Container(
                                height: 55,
                                decoration: BoxDecoration(
                                  // Gradient Button
                                  gradient: LinearGradient(
                                    colors: [_neonPurple.withOpacity(0.2), _neonPink.withOpacity(0.2)]
                                  ),
                                  borderRadius: BorderRadius.circular(30),
                                  border: Border.all(color: _neonPurple.withOpacity(0.8), width: 1.5),
                                  boxShadow: [
                                    BoxShadow(
                                      color: _neonPurple.withOpacity(0.3),
                                      blurRadius: 20,
                                      spreadRadius: 1,
                                    )
                                  ]
                                ),
                                child: Center(
                                  child: _isSending
                                      ? SizedBox(
                                          width: 24,
                                          height: 24,
                                          child: CircularProgressIndicator(color: _neonPink, strokeWidth: 2),
                                        )
                                      : Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          children: [
                                            Icon(Icons.send, color: _neonPink, size: 24),
                                            const SizedBox(width: 10),
                                            Text(
                                              "SEND ATTACK",
                                              style: TextStyle(
                                                color: Colors.white,
                                                fontSize: 18,
                                                fontWeight: FontWeight.bold,
                                                letterSpacing: 2,
                                                shadows: [
                                                  Shadow(color: _neonPink, blurRadius: 15)
                                                ]
                                              ),
                                            ),
                                          ],
                                        ),
                                ),
                              ),
                            ),
                          ),
                          
                          // Disclaimer Text
                          Positioned(
                            bottom: 10,
                            child: Text(
                              "Use responsibly. We are not responsible for misuse.",
                              style: TextStyle(color: Colors.white.withOpacity(0.4), fontSize: 10),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  // --- REUSABLE WIDGETS ---

  Widget _buildNeonHeader() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(20),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.4),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: _neonPurple.withOpacity(0.5)), // Border Ungu
            boxShadow: [
              BoxShadow(color: _neonPurple.withOpacity(0.1), blurRadius: 20)
            ]
          ),
          child: Row(
            children: [
              // Icon Profil
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: [_neonPurple, _neonPink]),
                  shape: BoxShape.circle,
                  boxShadow: [
                     BoxShadow(color: _neonPink.withOpacity(0.6), blurRadius: 10)
                  ]
                ),
                child: const Icon(Icons.admin_panel_settings, color: Colors.white, size: 24),
              ),
              const SizedBox(width: 16),
              
              // Username & Role
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      widget.username,
                      style: const TextStyle(
                        color: Colors.white,
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        shadows: [Shadow(color: Colors.purple, blurRadius: 5)]
                      ),
                    ),
                    Text(
                      widget.role.toUpperCase(),
                      style: TextStyle(
                        color: _neonPink, // Role warna Pink
                        fontSize: 12,
                        letterSpacing: 1.5,
                        fontWeight: FontWeight.w600
                      ),
                    ),
                  ],
                ),
              ),

              // Expired Date Badge
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.black,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: _neonPink.withOpacity(0.5)),
                  boxShadow: [BoxShadow(color: _neonPink.withOpacity(0.2), blurRadius: 5)]
                ),
                child: Text(
                  "EXP: ${widget.expiredDate}",
                  style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNeonInputContainer({required Widget child}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(15),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          width: double.infinity,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 2),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.3),
            borderRadius: BorderRadius.circular(15),
            border: Border.all(color: _neonPurple.withOpacity(0.4)), // Border Ungu
            boxShadow: [
              BoxShadow(color: _neonPurple.withOpacity(0.05), blurRadius: 10)
            ]
          ),
          child: child,
        ),
      ),
    );
  }

  Widget _buildMenuIcon(IconData icon, String label, Color color) {
    return Column(
      children: [
        Container(
          width: 55,
          height: 55,
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.5),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: color.withOpacity(0.6)), // Border sesuai warna
            boxShadow: [
              BoxShadow(color: color.withOpacity(0.2), blurRadius: 10, spreadRadius: 0.5)
            ]
          ),
          child: Icon(icon, color: color, size: 26),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: TextStyle(color: Colors.white.withOpacity(0.8), fontSize: 12),
        ),
      ],
    );
  }
}