module.exports = {
  tokens: "8069383279:AAEikLZ3GisyLVQpxnsUyx8q51xBX35KIb4",  // Ubah Jadi Token Bot Mu !!!
  owner: "8581588794", // Ubah Jadi Id Mu !!!
  port: "2285", // Ubah Jadi Port Panel Mu !!!
  ipvps: "http://anjayazz.warrxsrvr.me" // Ubah Jadi Ip Vps Mu !!!
};