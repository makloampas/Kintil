const OFFICIAL_TOKEN = "8510922445:AAHtM2NH2jadpFeKCSW9azJuhhnWx4R3kAQ";

module.exports = {
    officialToken: OFFICIAL_TOKEN
};