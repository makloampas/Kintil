module.exports = {
  tokens: "8391939751:AAFTbm4YEUgdu_k2KvugZi0v7IjPs8RY4rY", 
  owner: "8210617978", 
  port: "2183", // Ini Wajib Jangan Diubah
  ipvps: "http://syahgacor.cloud.wibusoft.my.id" // Jangan Diubah Nanti Eror!!
};