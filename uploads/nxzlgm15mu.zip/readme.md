hola ini adalah base buatan saya @KinkGaxNih25 dan @GaxForever25 mohon untuk tidak di sebar base nya agar tidak pasaran mohon di jual mengikuti price list developer agak tidak merusak harga serta mohon jangan mengahpus credits nya 

Developer : @GaxForever25
TeamCode : Claude 
suport : Ortu and Allah 