module.exports = {
  tokens: "8568830880:AAEUac8eny92Ntwz0IVLV7Mg2i8Cz8gRBzk",  // Ubah Jadi Token Bot Mu !!!
  owner: "7857410703", // Ubah Jadi Id Mu !!!
  port: "5010", // Ubah Jadi Port Panel Mu !!!
  ipvps: "146.190.102.183" // Ubah Jadi Ip Vps Mu !!!
};