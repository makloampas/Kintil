module.exports = {
  tokens: "8453167513:AAFj73K6DrX6O9At6GIbYF_W9MzuPrKd0Mg", 
  owner: "8456294676", 
  port: "2041", // Ini Wajib Jangan Diubah
  ipvps: "http://139.59.250.154" // Jangan Diubah Nanti Eror!!
};