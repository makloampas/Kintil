const fs = require('fs');
const TelegramBot = require('node-telegram-bot-api');
const axios = require('axios');
const { TOKEN, OWNER_ID, BANNER_FILE_ID } = require('./setting');

const bot = new TelegramBot(TOKEN, { polling: true }); 
let autoForwardInterval = null;
let forwardChatId = null;
let forwardMessageId = null;
// Helper JSON
function readJSON(file, fallback = {}) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch {
    return fallback;
  }
}
function writeJSON(file, data) {
  fs.writeFileSync(file, JSON.stringify(data, null, 2));
}

// File Data
const groupsFile = 'groups.json';
const premiumFile = 'premium.json';
const linkFile = 'linkpremium.json';
// Group Manager
function getGroups() {
  return readJSON(groupsFile, []);
}
function saveGroup(id) {
  const groups = getGroups();
  if (!groups.includes(id)) {
    groups.push(id);
    writeJSON(groupsFile, groups);
    return true;
  }
  return false;
}
function removeGroup(id) {
  const groups = getGroups().filter(g => g !== id);
  writeJSON(groupsFile, groups);
}

// Premium Manager
function getPremium() {
  return readJSON(premiumFile, {});
}
function savePremium(data) {
  writeJSON(premiumFile, data);
}
function addPremium(userId, days) {
  const db = getPremium();
  const now = Date.now();
  const ms = days * 24 * 60 * 60 * 1000;
  db[userId] = { until: now + ms };
  savePremium(db);
}
function removePremium(userId) {
  const db = getPremium();
  delete db[userId];
  savePremium(db);
}
function isPremium(userId) {
  const db = getPremium();
  return db[userId] && db[userId].until > Date.now();
}
//~Runtime🗑️🔧
function formatRuntime(seconds) {
  const days = Math.floor(seconds / (3600 * 24));
  const hours = Math.floor((seconds % (3600 * 24)) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = seconds % 60;
  
  return `${days} Hari, ${hours} Jam, ${minutes} Menit, ${secs} Detik`;
}

const startTime = Math.floor(Date.now() / 1000); 

function getBotRuntime() {
  const now = Math.floor(Date.now() / 1000);
  return formatRuntime(now - startTime);
}
// ========== /start ==========
bot.onText(/\/start(?:\s+(\w+))?/, async (msg, match) => {
  const chatId = msg.chat.id;
  const isOwner = chatId == OWNER_ID;
  const kode = match[1];
  const username = msg.from.username ? `@${msg.from.username}` : "Tidak ada username";
  const runtime = getBotRuntime();
  const groupCount = getGroups().length;
  const status = isPremium(chatId) ? "🔮 Sudah Premium" : "🪐 Belum Premium";

  // Cek kode link
  const links = readJSON(linkFile, {});
  if (kode && links[kode]) {
    const durasi = links[kode];
    addPremium(chatId, durasi);
    delete links[kode];
    writeJSON(linkFile, links);
    bot.sendMessage(chatId, `🎉 Selamat! Premium aktif selama ${durasi} hari.`);
  }

  const textUser = `
┏──────────────────────────⊰
│ꪶ あ ꫂ  𝗕𝗢𝗧 𝗝𝗔𝗦𝗛𝗘𝗥 𝗢𝗧𝗢𝗠𝗔𝗧𝗜𝗦
┗─⊰
( 👋🏻 ) - Hello, ${username}!\nI Am Bot Jasher Version 1.0
┌──────── >
├──── 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗦𝗜 𝗕𝗢𝗧
├── ⭔ Developer : @CRAZYBOTZZ
├─ ⭔ Version : 1.0
├ ⭔Total Grup : ${groupCount}
├ ⭔ Your Status : ${status}
├ ⭔Run Time Bot
├─╰➤ ${runtime}
└──── >
┌─ ⧼ 𝗖𝗔𝗥𝗔 𝗗𝗔𝗣𝗔𝗧𝗜𝗡 𝗣𝗥𝗘𝗠 ⧽
├ 𝙼𝙰𝚂𝚄𝙺𝙸𝙽 𝙱𝙾𝚃 𝙺𝙴 𝙶𝚁𝚄𝙱
├ 𝙻𝙰𝙻𝚄 𝚂𝙴𝙽𝙳 𝚃𝙴𝙺𝚂 𝙺𝙰𝙻𝙸𝙰𝙽 𝙺𝙴 𝙱𝙾𝚃
├ 𝙱𝙾𝚃 𝙰𝙺𝙰𝙽 𝚂𝙷𝙴𝚁 𝙾𝚃𝙾𝙼𝙰𝚃𝙸𝚂
├ 𝚃𝙰𝙽𝙿𝙰 𝙿𝙴𝙽𝙶𝙶𝚄𝙽𝙰𝙰𝙽 𝙵𝙸𝚃𝚄𝚁
╰────────────────────
`;

  const textOwner = `
┏──────────────────────────⊰
│ꪶ あ ꫂ  𝗕𝗢𝗧 𝗝𝗔𝗦𝗛𝗘𝗥 𝗢𝗧𝗢𝗠𝗔𝗧𝗜𝗦
┗─⊰
( 👋🏻 ) - Hello, ${username}!\nI Am Bot Jasher Version 1.0
┌──────── >
├──── 𝗜𝗡𝗙𝗢𝗥𝗠𝗔𝗦𝗜 𝗕𝗢𝗧
├── ⭔ Developer : @CRAZYBOTZZ
├─ ⭔ Version : 1.0
├ ⭔Total Grup : ${groupCount}
├ ⭔ Your Status : ${status}
├ ⭔Run Time Bot
├─╰➤ ${runtime}
└──── >
┌───── >
├── 𝗢𝗪𝗡𝗘𝗥 𝗠𝗘𝗡𝗨
├─
├> /idgrup
├> /hapusgrup < ID >
├> /info < REPLY TEKS >
├> /resetgrup
├> /createlink < ID > < HARI >
├─
┠── CRAZYBOTZZ 2025
└──── >`;

  try {
   await bot.sendVideo(chatId, BANNER_FILE_ID, {
      caption: isOwner ? textOwner : textUser,
      parse_mode: 'Markdown'
    });
  } catch {
    bot.sendMessage(chatId, isOwner ? textOwner : textUser, { parse_mode: 'Markdown' });
  }
});
bot.on('message', async (msg) => {
  const chatId = msg.chat.id;
  const from = msg.from;
  const caption = `Pesan Ini Dari @${from.username || "pengguna"}`;
  const isPremiumUser = isPremium(chatId);
  const isOwner = chatId == OWNER_ID;

  // 📌 Deteksi grup baru
  if (msg.chat.type === 'group' || msg.chat.type === 'supergroup') {
    const added = saveGroup(chatId);
    if (added) {
      const groupList = getGroups();
      bot.sendMessage(OWNER_ID, `
🪐 Bot Di Tambah Kan Ke Grup!\n
💫 ID : \`${chatId}\`\n
💎 Total Grup : ${groupList.length}`, { parse_mode: 'Markdown' });

      // 🎁 Berikan premium otomatis
      addPremium(from.id, 2);
      bot.sendMessage(from.id, `
🌊 Kamu berhasil menambahkan bot ke grup!\n
🔱 Premium aktif selama 2 hari.`);
    }
    return;
  }

  // 🛑 Abaikan command
  if (msg.text && msg.text.startsWith('/')) return;

  // 🔐 Hanya premium dan owner yang bisa kirim
  if (!isPremiumUser && !isOwner) {
  bot.sendMessage(chatId, `
❌ Kamu belum menambahkan bot ini ke dalam grup.\n\n
Untuk mendapatkan akses premium gratis:\n
Tambahkan bot ini ke minimal 1 grup,\n
✅ Maka kamu akan otomatis menjadi user premium.\n\n
Jika sudah, kirim pesan ulang.`);
  return;
}

  // 🚀 Broadcast ke semua grup
  const groups = getGroups();
  let success = 0, failed = 0;

  for (const groupId of groups) {
    try {
      if (msg.photo) {
        const file = msg.photo[msg.photo.length - 1].file_id;
        await bot.sendVideo(groupId, file, { caption });
      } else if (msg.video) {
        await bot.sendVideo(groupId, msg.video.file_id, { caption });
      } else if (msg.text) {
        await bot.sendMessage(groupId, `${caption}:\n${msg.text}`);
      }
      success++;
    } catch {
      failed++;
    }
  }

  bot.sendMessage(chatId, `
╭━≫ 〖 Selesai Share Teks 〗
┃ 流 Sukses Di Kirim
┃ ╰➤ ${success}
┃ 能 Gagal Di Kirim
┃ ╰➤ ${failed}
┗━━━━━━━━━━━━━━━━━≫`, { parse_mode: 'Markdown' });
});
// Handle Message dan Kirim ke Grup

bot.onText(/\/set/, (msg) => {
  const chatId = msg.chat.id;
  if (chatId !== OWNER_ID) return;
  if (!msg.reply_to_message || !msg.reply_to_message.text) {
    return bot.sendMessage(chatId, '❌ Gunakan /set dengan membalas pesan yang ingin disimpan.');
  }
  forwardChatId = chatId;
  forwardMessageId = msg.reply_to_message.message_id;
  bot.sendMessage(chatId, '✅ Pesan berhasil disimpan untuk diteruskan.');
});

bot.onText(/\/share/, (msg) => {
    const chatId = msg.chat.id;
    if (chatId !== OWNER_ID) return;
    if (!forwardChatId || !forwardMessageId) {
        return bot.sendMessage(chatId, '❌ Belum ada pesan yang diset. Gunakan /set.');
    }
    getGroups().forEach(groupId => {
        bot.forwardMessage(groupId, forwardChatId, forwardMessageId).catch(err => {
            console.log(`Gagal kirim ke ${groupId}: ${err.message}`);
        });
    });
    bot.sendMessage(chatId, `✅ Pesan diforward ke ${getGroups().length} grup.`);
});


bot.onText(/\/auto/, (msg) => {
  const chatId = msg.chat.id;
  if (chatId !== OWNER_ID) return;
  if (!forwardChatId || !forwardMessageId) {
    return bot.sendMessage(chatId, '❌ Belum ada pesan yang diset. Gunakan /set.');
  }
  if (autoForwardInterval) {
    clearInterval(autoForwardInterval);
    autoForwardInterval = null;
    return bot.sendMessage(chatId, '❌ Auto forward dimatikan.');
  }
  autoForwardInterval = setInterval(() => {
    getGroups().forEach(groupId => {
      bot.forwardMessage(groupId, forwardChatId, forwardMessageId).catch(() => {});
    });
  }, 5 * 60 * 1000); // 5 menit
  bot.sendMessage(chatId, `✅ Auto forward aktif setiap 5 menit ke ${getGroups().length} grup.`);
});
// Perintah Owner
bot.onText(/\/idgrup/, (msg) => {
  if (msg.chat.id !== OWNER_ID) return;
  const text = getGroups().join('\n') || 'Belum ada grup.';
  bot.sendMessage(OWNER_ID, `📋 List Id Grup\n\n${text}`, { parse_mode: 'Markdown' });
});

bot.onText(/\/hapusgrup (.+)/, (msg, match) => {
  if (msg.chat.id !== OWNER_ID) return;
  const id = parseInt(match[1]);
  removeGroup(id);
  bot.sendMessage(OWNER_ID, `✅ Grup ${id} berhasil dihapus.`);
});

bot.onText(/\/resetgrup/, (msg) => {
  if (msg.chat.id !== OWNER_ID) return;
  writeJSON(groupsFile, []);
  bot.sendMessage(OWNER_ID, '🔄 Semua grup direset.');
});

// 🔗 Create Link Premium
bot.onText(/\/createlink (\d+) (\d+)/, (msg, match) => {
  if (msg.chat.id !== OWNER_ID) return;
  const userId = match[1];
  const days = parseInt(match[2]);

  const links = readJSON(linkFile, {});
  const kode = Math.random().toString(36).slice(2, 8);
  links[kode] = days;
  writeJSON(linkFile, links);

  const link = `https://t.me/${bot.botInfo?.username}?start=${kode}`;
  bot.sendMessage(OWNER_ID, `🔗 Link berhasil dibuat:\n\n${link}\n\n💎 Premium aktif selama ${days} hari.`, { parse_mode: 'Markdown' });
});
// Bot Dikeluarkan
bot.on('left_chat_member', (msg) => {
  if (!bot.botInfo) return;
  if (msg.left_chat_member.id === bot.botInfo.id) {
    const groupId = msg.chat.id;
    removeGroup(groupId);

    const userId = msg.from?.id;
    if (userId) {
      removePremium(userId);
      bot.sendMessage(userId, `⚠️ Kamu telah mengeluarkan bot dari grup.\n💎 Premium kamu dicabut.`);
    }

    const list = getGroups();
    bot.sendMessage(OWNER_ID, `🚫 Bot dikeluarkan dari grup!\n🆔 *ID:* \`${groupId}\`\n📦 Tersisa: ${list.length}`, { parse_mode: 'Markdown' });
  }
});
// Cek Premium Setiap Jam
setInterval(() => {
  const db = getPremium();
  const now = Date.now();

  for (const id in db) {
    if (db[id].until < now) {
      removePremium(id);
      bot.sendMessage(id, `⚠️ Masa premium kamu sudah habis.\n\nHubungi owner:\n👉 [KLIK DI SINI](https://t.me/${bot.botInfo?.username})`, {
        parse_mode: 'Markdown'
      });
    }
  }
}, 1000 * 60 * 60); // setiap 1 jam

// Inisialisasi Bot
bot.getMe().then(botInfo => {
  bot.botInfo = botInfo;
  console.log(`Bot Sukses Aktif Di @${botInfo.username} Selamat Menikmati`);
});
