module.exports = {
  TOKEN: '8148248552:AAHydK5MBTIZBkXTuyVTNJQaMvKHH6dwwfs',   // Ganti token bot kamu
  OWNER_ID: 7964806637,                              // Ganti ID Telegram kamu
  BANNER_FILE_ID: 'https://files.catbox.moe/frrtsi.mp4' // URL gambar banner (bisa juga pakai file_id)
};