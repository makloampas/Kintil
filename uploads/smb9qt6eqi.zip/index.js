
const { Telegraf, Markup } = require("telegraf");
const fs = require("fs");
const path = require("path");

const express = require("express");
const multer = require("multer");
const bodyParser = require("body-parser");
const cors = require("cors");

const upload = multer({ storage: multer.memoryStorage() });

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use(express.static(__dirname));

// ================= CONFIG =================
const BOT_TOKEN = "8176925634:AAELGyzke23WzYsqQrudOdr1e1bqXKgr17U";   //TOKEN BOT MU
const GITHUB_TOKEN = "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";        //ISI TOKEN GHP ALL DI CEKLIS
const OWNER = "makloampas"; //NAME AKUN GH ELU
const REPO = "Kintil"; //NAME REPO
const BRANCH = "main";
const WORKFLOW_FILE = "flutter_build_apk.yml";
// ===========================================
// ========= OWNER / CHANNEL =========
const OWNER_ID = 5052601400;
const BUILD_CHANNEL_ID = -1003114383066;
// ========= STORAGE (FIX ENOENT) =========
const LIMIT_FILE = path.join(process.cwd(), "limits.json");
const JOB_FILE = path.join(process.cwd(), "jobs.json");
const USER_FILE = path.join(process.cwd(), "user.json");

if (!fs.existsSync(USER_FILE)) fs.writeFileSync(USER_FILE, "[]", "utf8");
if (!fs.existsSync(LIMIT_FILE)) fs.writeFileSync(LIMIT_FILE, "{}", "utf8");
if (!fs.existsSync(JOB_FILE)) fs.writeFileSync(JOB_FILE, "{}", "utf8");

function readJson(p) {
  try {
    const raw = fs.readFileSync(p, "utf8");
    return JSON.parse(raw);
  } catch {
   
    if (p === USER_FILE) return [];
    return {};
  }
}

function writeJson(p, obj) {

  fs.mkdirSync(path.dirname(p), { recursive: true });
  fs.writeFileSync(p, JSON.stringify(obj, null, 2), "utf8");
}

// ===== user.json helpers =====
function getUsers() {
  const arr = readJson(USER_FILE);
  return Array.isArray(arr) ? arr : [];
}

function saveUser(userId) {
  const users = getUsers();
  const id = Number(userId);
  if (!users.includes(id)) {
    users.push(id);
    writeJson(USER_FILE, users);
  }
}

function isOwner(userId) {
  return Number(userId) === Number(OWNER_ID);
}
// ==========LOGIN==============
app.use(express.json());

const DATA_DIR = path.join(process.cwd(), "data");
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

const KEY_FILE = path.join(DATA_DIR, "keys.json");
if (!fs.existsSync(KEY_FILE)) {
  fs.writeFileSync(KEY_FILE, "{}", "utf8");
}

function getKeys() {
  return readJson(KEY_FILE) || {};
}

function checkKey(userId, key) {
  const db = getKeys();
  return String(db[userId] || "") === String(key || "");
}

app.post("/api/login", (req, res) => {
  const userId = Number(req.body?.userId || 0);
  const key = String(req.body?.key || "").trim();

  if (!userId || !key) {
    return res.status(400).json({ ok:false, error:"userId+key required" });
  }

  if (!checkKey(userId, key)) {
    return res.status(401).json({ ok:false, error:"Key salah / belum dibuat" });
  }

  return res.json({ ok:true });
});

app.post("/upload", upload.single("file"), async (req, res) => {
  try {
    const filePath = req.file.path;
    const jobId = randomJobId();

    const buffer = fs.readFileSync(filePath);
    await uploadToRepo(`uploads/${jobId}.zip`, buffer, `Upload from web ${jobId}`);

    await dispatchWorkflow(jobId, { zipPath: `uploads/${jobId}.zip` });

    return res.json({ success: true, jobId });
  } catch (e) {
    return res.json({ success: false, error: e.message });
  }
});

app.get("/api/status/:jobId", (req, res) => {
  try {
    const jobId = String(req.params.jobId || "").trim();
    const job = getJob(jobId); // pakai function lu yg biasa
    if (!job) return res.status(404).json({ ok:false, error:"JOB NOT FOUND" });
    return res.json({ ok:true, job });
  } catch (e) {
    return res.status(500).json({ ok:false, error:e?.message || String(e) });
  }
});

// POST /api/buildzip  (form-data: file, userId)
app.post("/api/buildzip", upload.single("file"), async (req, res) => {
  try {
    const userId = Number(req.body.userId || 0);
    if (!userId) return res.status(400).json({ ok:false, error:"userId required" });

    const file = req.file;
    if (!file) return res.status(400).json({ ok:false, error:"file required" });
    if (!String(file.originalname || "").toLowerCase().endsWith(".zip")) {
      return res.status(400).json({ ok:false, error:"file must be .zip" });
    }

    // LIMIT CHECK (PAKAI LOGIC LU YANG SAMA)
    if (!isOwner(userId)) {
      const limit = getUserLimit(userId);
      if (limit <= 0) return res.status(403).json({ ok:false, error:"LIMIT HABIS" });
      consumeLimit(userId);
    }

    const jobId = randomJobId();
    const zipPath = `uploads/${jobId}.zip`;

    // upload ke repo persis buildapk
    await uploadToRepo(zipPath, file.buffer, `Upload job ${jobId} (web)`);

    const dispatchAt = Date.now();
    await dispatchWorkflow(jobId, { zipPath });

    // cari run id/url
    let runId = null, runUrl = null;
    for (let i = 0; i < 10; i++) {
      await new Promise(r => setTimeout(r, 2500));
      const runsData = await listWorkflowRuns();
      const runs = runsData.workflow_runs || [];
      const candidate = runs
        .filter(r => new Date(r.created_at).getTime() >= dispatchAt - 30000)
        .sort((a,b)=> new Date(b.created_at)-new Date(a.created_at))[0];
      const newest = candidate || runs[0];
      if (newest?.id) { runId = newest.id; runUrl = newest.html_url; break; }
    }

    // INI KUNCI: simpan job biar /status ketemu
    saveJob(jobId, {
      job_id: jobId,
      zip_path: zipPath,
      zip_url: "",
      run_id: runId,
      run_url: runUrl,
      user_id: userId,
      created_at: new Date().toISOString(),
    });

    return res.json({ ok:true, jobId, runUrl, runId });
  } catch (e) {
    return res.status(500).json({ ok:false, error: e?.message || String(e) });
  }
});

const { PANEL_PORT } = require("./key");

app.listen(PANEL_PORT, () => {
  console.log("WEB RUNNING ON PORT", PANEL_PORT);
});

// ========= UI HELPERS =========
function box(text) {
  return `<blockquote><pre>${text}</pre></blockquote>`;
}

function mainMenu() {
  return Markup.inlineKeyboard([
    [Markup.button.callback("📥 BUILDING APK", "MENU_BUILD")],
    [Markup.button.callback("👤 ANTRIAN", "MENU_QUEUE")],
    [Markup.button.callback("📖 PANDUAN MENGGUNAKAN BOT", "MENU_GUIDE")],
    [Markup.button.url("👋 ADMIN", "https://t.me/Lixxisheree2")],
  ]);
}

// ========= BOT =========
const bot = new Telegraf(BOT_TOKEN);

bot.use(async (ctx, next) => {
  try {
    const uid = ctx.from?.id;
    if (uid) saveUser(uid);
  } catch {}
  return next();
});

async function isJoinChannel(ctx) {
  const userId = ctx.from?.id
  if (!userId) return false

  try {
    const member = await ctx.telegram.getChatMember('@Lixxback', userId)

    if (member.status === 'left' || member.status === 'kicked') {
      await ctx.reply(
        '❌ Kamu belum join channel!\n\n' +
        '👉 Wajib join dulu untuk menggunakan bot.',
        {
          reply_markup: {
            inline_keyboard: [
              [{ text: '📢 Join Channel', url: 'https://t.me/Lixxback' }],
              [{ text: '🔄 Refresh', callback_data: 'cek_join' }]
            ]
          }
        }
      )
      return false
    }

    return true
  } catch {
    return false
  }
}

bot.action('cek_join', async (ctx) => {
  await ctx.answerCbQuery()
  if (await isJoinChannel(ctx)) {
    await ctx.editMessageText('✅ Akses diterima, silakan gunakan command.')
  }
})

// ===== /start menu =====
bot.start(async (ctx) => {

if (!(await isJoinChannel(ctx))) return

  const text =
    `L I X X  -  B U I L D  A P K\n\n` +
    `PILIH MENU DI BAWAH\n`;

  await ctx.replyWithPhoto(
    "https://b.top4top.io/p_3696ryxuk1.jpg",
    {
      caption: box(text),
      parse_mode: "HTML",
      ...mainMenu(),
    }
  );
});

// ===== Menu buttons =====
bot.action("MENU_BUILD", async (ctx) => {
  await ctx.answerCbQuery();
  const t =
    `BUILDING APK\n\n` +
    `SILAHKAN KIRIM FILE .ZIP\n` +
    `LALU REPLY FILE TERSEBUT DENGAN TEKS:\n` +
    `/buildapk\n\n` +
    `NOTE:\n` +
    `- ZIP harus berisi project Flutter (pubspec.yaml ada)\n` +
    `- Jangan spam, pakai menu ANTRIAN untuk cek.\n`;
  await ctx.reply(box(t), { parse_mode: "HTML" });
});

bot.action("MENU_GUIDE", async (ctx) => {
  await ctx.answerCbQuery();
  const t =
    `PANDUAN MENGGUNAKAN BOT\n\n` +
    `1) KIRIM FILE .ZIP PROJECT FLUTTER\n` +
    `2) REPLY FILE .ZIP ITU\n` +
    `3) KETIK: /buildapk\n` +
    `4) TUNGGU PROGRESS BAR\n` +
    `5) KALAU SUCCESS, AMBIL HASIL: /getapk Id antrian\n\n` +
    `CEK STATUS:\n` +
    `/status id antrian\n\n` +
    `LIMIT:\n` +
    `- USER BIASA: 3x build\n` +
    `- TERIMA KASIH TELAH MENGGUNAKAN BOT LIXX\n`;
  await ctx.reply(box(t), { parse_mode: "HTML" });
});

bot.action("MENU_QUEUE", async (ctx) => {
  await ctx.answerCbQuery();
  await ctx.reply(box(getQueueText()), { parse_mode: "HTML" });
});

// ========= LIMIT SYSTEM =========
function getUserLimit(userId) {
  if (isOwner(userId)) return Infinity;
  const db = readJson(LIMIT_FILE);
  // default 3
  if (db[userId] === undefined) db[userId] = 3, writeJson(LIMIT_FILE, db);
  return Number(db[userId] || 0);
}
function setUserLimit(userId, val) {
  const db = readJson(LIMIT_FILE);
  db[userId] = Number(val);
  writeJson(LIMIT_FILE, db);
}
function addUserLimit(userId, add) {
  const cur = getUserLimit(userId);
  if (cur === Infinity) return Infinity;
  const next = cur + Number(add);
  setUserLimit(userId, next);
  return next;
}
function consumeLimit(userId) {
  if (isOwner(userId)) return Infinity;
  const cur = getUserLimit(userId);
  if (cur <= 0) return 0;
  setUserLimit(userId, cur - 1);
  return cur - 1;
}

// ========= QUEUE SYSTEM =========
// Non-owner: 1 build at a time (antrian). Owner bypass queue.
let busyUserId = null;              // siapa yang lagi build (non-owner)
let queue = [];                     // array of { userId, chatId, messageId? } - non-owner waiting

function inQueue(userId) {
  return queue.findIndex(q => Number(q.userId) === Number(userId));
}
function queuePosition(userId) {
  const idx = inQueue(userId);
  return idx >= 0 ? idx + 1 : null;
}

function getQueueText() {
  const lines = [];
  if (busyUserId) lines.push(`SEDANG BUILD: ${busyUserId}`);
  else lines.push(`SEDANG BUILD: -`);
  if (queue.length === 0) lines.push(`ANTRIAN: kosong`);
  else {
    lines.push(`ANTRIAN:`);
    queue.forEach((q, i) => lines.push(`${i + 1}. ${q.userId}`));
  }
  return lines.join("\n");
}

// ========= GITHUB HELPERS =========
function randomJobId() {
  return Math.random().toString(36).substring(2, 12);
}

function ghHeaders(extra = {}) {
  return {
    Authorization: `Bearer ${GITHUB_TOKEN}`,
    "X-GitHub-Api-Version": "2022-11-28",
    Accept: "application/vnd.github+json",
    ...extra,
  };
}

async function downloadTelegramFile(ctx, fileId) {
  const link = await ctx.telegram.getFileLink(fileId);
  const res = await fetch(link.href);
  if (!res.ok) throw new Error("Gagal download file Telegram");
  return Buffer.from(await res.arrayBuffer());
}

async function uploadToRepo(repoPath, buffer, message) {
  const url = `https://api.github.com/repos/${OWNER}/${REPO}/contents/${repoPath}`;

  const body = {
    message,
    content: buffer.toString("base64"),
    branch: BRANCH,
  };

  const res = await fetch(url, {
    method: "PUT",
    headers: ghHeaders({ "Content-Type": "application/json" }),
    body: JSON.stringify(body),
  });

  if (!res.ok) {
    const txt = await res.text();
    throw new Error("Upload gagal: " + txt);
  }

  return await res.json();
}

// ✅ FIX: dispatchWorkflow wajib object, biar input zip_path/zip_url bener
async function dispatchWorkflow(jobId, { zipPath = "", zipUrl = "" } = {}) {
  const url = `https://api.github.com/repos/${OWNER}/${REPO}/actions/workflows/${WORKFLOW_FILE}/dispatches`;

  const body = {
    ref: BRANCH,
    inputs: {
      job_id: String(jobId),
      zip_path: String(zipPath || ""),
      zip_url: String(zipUrl || ""),
    },
  };

  const res = await fetch(url, {
    method: "POST",
    headers: ghHeaders({ "Content-Type": "application/json" }),
    body: JSON.stringify(body),
  });

  if (!(res.status === 204 || res.ok)) {
    const txt = await res.text();
    throw new Error("Trigger workflow gagal: " + txt);
  }
}

async function listWorkflowRuns() {
  const url = `https://api.github.com/repos/${OWNER}/${REPO}/actions/workflows/${WORKFLOW_FILE}/runs?branch=${BRANCH}&event=workflow_dispatch&per_page=10`;
  const res = await fetch(url, { headers: ghHeaders() });
  if (!res.ok) throw new Error("Gagal list workflow runs: " + (await res.text()));
  return await res.json(); // workflow_runs
}

async function getRunById(runId) {
  const url = `https://api.github.com/repos/${OWNER}/${REPO}/actions/runs/${runId}`;
  const res = await fetch(url, { headers: ghHeaders() });
  if (!res.ok) throw new Error("Gagal ambil status run: " + (await res.text()));
  return await res.json();
}

// ✅ FIX: cari artifact by run_id dulu (paling akurat), baru fallback list global
async function getArtifact(jobId) {
  // 1) Paling akurat: ambil artifact dari RUN ID job ini
  const job = getJob(jobId);
  if (job?.run_id) {
    const runUrl = `https://api.github.com/repos/${OWNER}/${REPO}/actions/runs/${job.run_id}/artifacts`;
    const runRes = await fetch(runUrl, { headers: ghHeaders() });
    if (!runRes.ok) throw new Error("Gagal ambil artifacts run: " + (await runRes.text()));
    const runData = await runRes.json();
    const runArts = runData.artifacts || [];

    // prioritas: yang namanya cocok
    const exactName = `apk-${jobId}`;
    let found = runArts.find(a => a.name === exactName && !a.expired);

    // kalau workflow lu namanya beda, fallback: cari yang ada jobId nya
    if (!found) found = runArts.find(a => String(a.name || "").includes(jobId) && !a.expired);

    if (!found) {
      found = runArts
        .filter(a => !a.expired)
        .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0];
    }
    return found || null;
  }

  // 2) Fallback: global artifacts (kurang akurat tapi tetap jalan)
  const url = `https://api.github.com/repos/${OWNER}/${REPO}/actions/artifacts?per_page=100`;
  const res = await fetch(url, { headers: ghHeaders() });
  if (!res.ok) throw new Error("Gagal ambil artifact list: " + (await res.text()));
  const data = await res.json();
  const arts = data.artifacts || [];

  const exactName = `apk-${jobId}`;
  let found = arts.find(a => a.name === exactName && !a.expired);

  if (!found) found = arts.find(a => String(a.name || "").includes(jobId) && !a.expired);

  if (!found) {
    found = arts
      .filter(a => !a.expired)
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0];
  }

  return found || null;
}

async function downloadArtifactZip(id) {
  const url = `https://api.github.com/repos/${OWNER}/${REPO}/actions/artifacts/${id}/zip`;
  const res = await fetch(url, { headers: ghHeaders() });
  if (!res.ok) throw new Error("Gagal download artifact");
  return Buffer.from(await res.arrayBuffer());
}

// ========= JOB META (local) =========
function saveJob(jobId, meta) {
  const db = readJson(JOB_FILE);
  db[jobId] = meta;
  writeJson(JOB_FILE, db);
}

function getJob(jobId) {
  const db = readJson(JOB_FILE);
  return db[jobId] || null;
}

// ========= PROGRESS BAR =========
function makeBar(pct) {
  const total = 18;
  const filled = Math.max(0, Math.min(total, Math.round((pct / 100) * total)));
  const empty = total - filled;
  return `[` + "█".repeat(filled) + "░".repeat(empty) + `] ${pct}%`;
}

// anti double-run (biar ga ada 2 loop edit pesan yang saling tabrakan)
const ACTIVE_PROGRESS = new Set();

async function runProgress(ctx, chatId, msgId, jobId) {
  const key = `${chatId}:${msgId}`;
  if (ACTIVE_PROGRESS.has(key)) return;
  ACTIVE_PROGRESS.add(key);

  const start = Date.now();
  const steps = [10, 18, 27, 36, 45, 55, 66, 76, 85, 92, 97];
  let idx = 0;

  try {
    while (true) {
      const job = getJob(jobId);
      let statusText = "queued";
      let conclusion = null;
      let runUrl = null;

      // ✅ CHECK 1: kalau APK artifact sudah ada -> anggap sukses dan STOP
      try {
        const artifact = await getArtifact(jobId);
        if (artifact) {
          await ctx.telegram.editMessageText(
            chatId,
            msgId,
            undefined,
            box(
              `PROSES BUILD APK\n` +
              `JOB: ${jobId}\n` +
              `STATUS: completed\n` +
              `${makeBar(100)}\n\n` +
              `🟢 BUILD SELESAI: SUCCESS\n\n` +
              `AMBIL APK:\n/getapk ${jobId}`
            ),
            { parse_mode: "HTML" }
          );
          break;
        }
      } catch {}

      // ✅ CHECK 2: poll status workflow dari run_id
      if (job?.run_id) {
        try {
          const run = await getRunById(job.run_id);
          statusText = run.status;
          conclusion = run.conclusion;
          runUrl = run.html_url;

          if (statusText === "completed") {
            const line = conclusion === "success"
              ? `🟢 BUILD SELESAI: SUCCESS`
              : `🔴 BUILD SELESAI: FAILED (${conclusion})`;

            await ctx.telegram.editMessageText(
              chatId,
              msgId,
              undefined,
              box(
                `PROSES BUILD APK\n` +
                `JOB: ${jobId}\n` +
                `STATUS: ${statusText}\n` +
                `${makeBar(100)}\n\n` +
                `${line}\n` +
                (conclusion === "success"
                  ? `\nAMBIL APK:\n/getapk ${jobId}`
                  : `\nKIRIM SCREENSHOT ERROR DARI LOG`)
              ),
              { parse_mode: "HTML" }
            );
            break;
          }
        } catch {}
      }

      // persen palsu tetap jalan
      const elapsedSec = Math.floor((Date.now() - start) / 1000);
      if (elapsedSec >= 10 && idx < 2) idx = 2;

      if (idx < steps.length) {
        const gate = 18 * idx + 1;
        if (elapsedSec >= gate) idx++;
      }

      let pct = steps[Math.min(idx, steps.length - 1)];
      if (statusText === "queued") pct = Math.min(pct, 20);
      if (statusText === "in_progress") pct = Math.max(pct, 35);

      try {
        await ctx.telegram.editMessageText(
          chatId,
          msgId,
          undefined,
          box(
            `PROSES BUILD APK\n` +
            `JOB: ${jobId}\n` +
            `STATUS: ${statusText}\n` +
            `${makeBar(pct)}\n\n` +
            `⏳ Sedang build...`
          ),
          { parse_mode: "HTML" }
        );
      } catch {}

      await new Promise((r) => setTimeout(r, 6000));
    }
  } finally {
    ACTIVE_PROGRESS.delete(key);
  }
}

// ===== /status =====
bot.command("status", async (ctx) => {
  try {
    const parts = (ctx.message.text || "").trim().split(/\s+/);
    const jobId = parts[1];
    if (!jobId) return ctx.reply(box("FORMAT:\n/status <jobId>"), { parse_mode: "HTML" });

    const job = getJob(jobId);
    if (!job) return ctx.reply(box("JOB TIDAK DITEMUKAN"), { parse_mode: "HTML" });

    if (!job.run_id) {
      return ctx.reply(box("RUN ID BELUM ADA. COBA LAGI SEBENTAR."), { parse_mode: "HTML" });
    }

    const run = await getRunById(job.run_id);
    const line =
      `STATUS BUILD APK\n` +
      `JOB ANTRIAN: ${jobId}\n` +
      `STATUS: ${run.status}\n` +
      `CONCLUSION: ${run.conclusion || "-"}\n` +
      `LOG: ${run.html_url}\n`;

    return ctx.reply(box(line), { parse_mode: "HTML" });
  } catch (e) {
    return ctx.reply(box("ERROR:\n" + e.message), { parse_mode: "HTML" });
  }
});

async function notifyChannel(ctx, { userId, jobId, mode }) {
  try {
    await ctx.telegram.sendMessage(
      BUILD_CHANNEL_ID,
      box(
        `PROSES BUILD APK\n` +
        `USER: ${userId}\n` +
        `ANTRIAN: ${jobId}\n` +
        `MODE: ${mode}\n` +
        `REPO: [HIDDEN]\n` +
        `STATUS: BUILD DIMULAI ✅`
      ),
      { parse_mode: "HTML" } // ✅ NO button biar ga 400
    );
  } catch (e) {
    console.log("CHANNEL NOTIF ERROR:", e?.response?.description || e?.message || e);
  }
}

// ✅ FIX NOTIF CHANNEL: aman (ctx optional) + ada button
async function notifyChannel(ctx, { userId, jobId, mode }) {
  try {
    // ctx bisa null/undefined, fallback ke bot.telegram
    const tg = ctx?.telegram || bot.telegram;

    if (!BUILD_CHANNEL_ID) {
      console.log("CHANNEL NOTIF ERROR: BUILD_CHANNEL_ID belum di set");
      return;
    }

    const text = box(
      `PROSES BUILD APK\n` +
      `USER: ${userId}\n` +
      `ANTRIAN: ${jobId}\n` +
      `MODE: ${mode}\n` +
      `REPO: [HIDDEN]\n` +
      `STATUS: BUILD DIMULAI ✅`
    );

    await tg.sendMessage(BUILD_CHANNEL_ID, text, {
      parse_mode: "HTML",
      disable_web_page_preview: true,
      reply_markup: {
        inline_keyboard: [
          [{ text: "👤 CHAT USER", url: `tg://user?id=${userId}` }]
        ]
      }
    });

  } catch (e) {
    console.log("CHANNEL NOTIF ERROR:", e?.response?.description || e?.message || e);
  }
}

// ===== /buildapk with queue + limit + channel notify + progress bar =====
bot.command("buildapk", async (ctx) => {
  const userId = ctx.from?.id;
  const chatId = ctx.chat?.id;

  try {
    const replied = ctx.message.reply_to_message;
    const doc = replied?.document;

    if (!doc) {
      return ctx.reply(box("❌ REPLY FILE .ZIP PROJECT FLUTTER LALU KETIK /buildapk"), { parse_mode: "HTML" });
    }
    if (!String(doc.file_name || "").toLowerCase().endsWith(".zip")) {
      return ctx.reply(box("❌ FILE HARUS .ZIP"), { parse_mode: "HTML" });
    }

    // ✅ LIMIT CHECK (non-owner)
    if (!isOwner(userId)) {
      const limit = getUserLimit(userId);
      if (limit <= 0) {
        return ctx.reply(
          box("LIMIT HABIS ❌\n\nKAMU SUDAH PAKAI 3x.\nHUBUNGI ADMIN UNTUK TAMBAH LIMIT."),
          { parse_mode: "HTML" }
        );
      }
    }

    // ===== QUEUE CHECK (non-owner) =====
    if (!isOwner(userId)) {
      if (busyUserId && Number(busyUserId) !== Number(userId)) {
        const pos = queuePosition(userId);
        if (pos) {
          return ctx.reply(
            box(`SEDANG ADA USER LAIN YG MENGGUNAKAN\nKAMU MASIH DI ANTRIAN KE ${pos}\n\nCEK MENU: ANTRIAN`),
            { parse_mode: "HTML" }
          );
        }
        queue.push({ userId, chatId });
        const myPos = queuePosition(userId);
        return ctx.reply(
          box(`SEDANG ADA USER LAIN YG MENGGUNAKAN\nKAMU ANTRIAN KE ${myPos}\n\nCEK MENU: ANTRIAN`),
          { parse_mode: "HTML" }
        );
      }
      busyUserId = userId;
    }

    // ✅ CONSUME LIMIT (pas user udah diterima/lock, bukan pas masih antri)
    if (!isOwner(userId)) {
      const left = consumeLimit(userId);
      await ctx.reply(
        box(`LIMIT TERPAKAI 1x ✅\nSISA LIMIT KAMU: ${left}`),
        { parse_mode: "HTML" }
      );
    }

    const jobId = randomJobId();
    const zipPath = `uploads/${jobId}.zip`;

    // 🔥 NOTIF KE CHANNEL + BUTTON
    try {
      await ctx.telegram.sendMessage(
        BUILD_CHANNEL_ID,
        box(
          `PROSES BUILD APK\n` +
          `USER: ${userId}\n` +
          `ANTRIAN: ${jobId}\n` +
          `MODE: ZIP UPLOAD\n` +
          `REPO: [HIDDEN]\n` +
          `STATUS: BUILD DIMULAI ✅`
        ),
        {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [{ text: "👤 BUKA PROFILE USER", url: `tg://user?id=${userId}` }]
            ]
          }
        }
      );
    } catch (e) {
      console.log("CHANNEL NOTIF ERROR:", e?.response?.description || e?.message || e);
    }

    const progressMsg = await ctx.reply(
      box(`PROSES BUILD APK\nJOB: ${jobId}\nSTATUS: starting\n${makeBar(0)}\n\n⏳ Sedang mulai...`),
      { parse_mode: "HTML" }
    );

    await ctx.telegram.editMessageText(
      chatId,
      progressMsg.message_id,
      undefined,
      box(`PROSES BUILD APK\nJOB: ${jobId}\nSTATUS: downloading\n${makeBar(8)}\n\n📥 Downloading file...`),
      { parse_mode: "HTML" }
    );
    const buffer = await downloadTelegramFile(ctx, doc.file_id);

    await ctx.telegram.editMessageText(
      chatId,
      progressMsg.message_id,
      undefined,
      box(`PROSES BUILD APK\nJOB: ${jobId}\nSTATUS: uploading\n${makeBar(18)}\n\n⬆️ Uploading...`),
      { parse_mode: "HTML" }
    );
    await uploadToRepo(zipPath, buffer, `Upload job ${jobId}`);

    await ctx.telegram.editMessageText(
      chatId,
      progressMsg.message_id,
      undefined,
      box(`PROSES BUILD APK\nJOB: ${jobId}\nSTATUS: triggering\n${makeBar(25)}\n\n🚀 Triggering build...`),
      { parse_mode: "HTML" }
    );

    const dispatchAt = Date.now();
    await dispatchWorkflow(jobId, { zipPath });

    let runId = null;
    let runUrl = null;

    for (let i = 0; i < 10; i++) {
      await new Promise((r) => setTimeout(r, 2500));
      const runsData = await listWorkflowRuns();
      const runs = runsData.workflow_runs || [];

      const candidate = runs
        .filter((r) => new Date(r.created_at).getTime() >= dispatchAt - 30000)
        .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0];

      const newest = candidate || runs[0];

      if (newest?.id) {
        runId = newest.id;
        runUrl = newest.html_url;
        break;
      }
    }

    saveJob(jobId, {
      job_id: jobId,
      zip_path: zipPath,
      zip_url: "",
      run_id: runId,
      run_url: runUrl,
      user_id: userId,
      created_at: new Date().toISOString(),
    });

    runProgress(ctx, chatId, progressMsg.message_id, jobId)
      .finally(() => {
        if (!isOwner(userId)) {
          busyUserId = null;
          if (queue.length > 0) {
            const next = queue.shift();
            busyUserId = next.userId;
            ctx.telegram.sendMessage(
              next.chatId,
              box(`ANTRIAN KAMU SEKARANG GILIRAN ✅\nSILAHKAN REPLY FILE .ZIP KAMU LALU KETIK /buildapk`),
              { parse_mode: "HTML" }
            ).catch(() => {});
          }
        }
      });

  } catch (e) {
    // ✅ kalau gagal: balikin limit + release lock
    if (!isOwner(userId)) {
      try { addUserLimit(userId, 1); } catch {}
      if (busyUserId && Number(busyUserId) === Number(userId)) busyUserId = null;
    }
    return ctx.reply(box("❌ ERROR:\n" + (e?.message || String(e))), { parse_mode: "HTML" });
  }
});

// ===== /getapk =====
bot.command("getapk", async (ctx) => {
  try {
    const parts = (ctx.message.text || "").trim().split(/\s+/);
    const jobId = parts[1];

    if (!jobId) return ctx.reply(box("FORMAT:\n/getapk jobantrian"), { parse_mode: "HTML" });

    await ctx.reply(box("🔎 MENCARI APK..."), { parse_mode: "HTML" });

    const artifact = await getArtifact(jobId);
    if (!artifact) return ctx.reply(box("⏳ BELUM ADA ARTIFACT.\nCEK STATUS:\n/status " + jobId), { parse_mode: "HTML" });

    const zipBuffer = await downloadArtifactZip(artifact.id);

    await ctx.replyWithDocument(
      { source: zipBuffer, filename: `apk-${jobId}.zip` },
      {
        caption: box(`✅ APK SIAP (DALAM ZIP)\nANTRIAN: ${jobId}`),
        parse_mode: "HTML"
      }
    );
  } catch (e) {
    return ctx.reply(box("❌ ERROR:\n" + e.message), { parse_mode: "HTML" });
  }
});

// ✅ FIX: buildurl sekarang saveJob + cari runId biar /status & /getapk gak error
bot.command("buildurl", async (ctx) => {
  const userId = ctx.from?.id;
  const chatId = ctx.chat?.id;

  try {
    const parts = (ctx.message.text || "").trim().split(/\s+/);
    const zipUrl = parts.slice(1).join(" "); // ✅ biar URL panjang aman (kalau ada spasi/encoded)

    if (!zipUrl) {
      return ctx.reply(box("FORMAT:\n/buildurl url_zip"), { parse_mode: "HTML" });
    }

    // ✅ LIMIT CHECK (non-owner)
    if (!isOwner(userId)) {
      const limit = getUserLimit(userId);
      if (limit <= 0) {
        return ctx.reply(
          box("LIMIT HABIS ❌\n\nKAMU SUDAH PAKAI 3x.\nHUBUNGI ADMIN UNTUK TAMBAH LIMIT."),
          { parse_mode: "HTML" }
        );
      }
    }

    // ✅ QUEUE CHECK (non-owner)
    if (!isOwner(userId)) {
      if (busyUserId && Number(busyUserId) !== Number(userId)) {
        const pos = queuePosition(userId);
        if (pos) {
          return ctx.reply(
            box(`SEDANG ADA USER LAIN YG MENGGUNAKAN\nKAMU MASIH DI ANTRIAN KE ${pos}\n\nCEK MENU: ANTRIAN`),
            { parse_mode: "HTML" }
          );
        }
        queue.push({ userId, chatId });
        const myPos = queuePosition(userId);
        return ctx.reply(
          box(`SEDANG ADA USER LAIN YG MENGGUNAKAN\nKAMU ANTRIAN KE ${myPos}\n\nCEK MENU: ANTRIAN`),
          { parse_mode: "HTML" }
        );
      }

      // lock user ini
      busyUserId = userId;
    }

    // ✅ CONSUME LIMIT setelah lock (non-owner)
    if (!isOwner(userId)) {
      const left = consumeLimit(userId);
      await ctx.reply(
        box(`LIMIT TERPAKAI 1x ✅\nSISA LIMIT KAMU: ${left}`),
        { parse_mode: "HTML" }
      );
    }

    const jobId = randomJobId();

    // ✅ NOTIF KE CHANNEL + BUTTON
    try {
      await ctx.telegram.sendMessage(
        BUILD_CHANNEL_ID,
        box(
          `PROSES BUILD APK\n` +
          `USER: ${userId}\n` +
          `ANTRIAN: ${jobId}\n` +
          `MODE: URL ZIP\n` +
          `REPO: [HIDDEN]\n` +
          `STATUS: BUILD DIMULAI ✅`
        ),
        {
          parse_mode: "HTML",
          reply_markup: {
            inline_keyboard: [
              [{ text: "👤 BUKA PROFILE USER", url: `tg://user?id=${userId}` }]
            ]
          }
        }
      );
    } catch (e) {
      console.log("CHANNEL NOTIF ERROR:", e?.response?.description || e?.message || e);
    }

    const progressMsg = await ctx.reply(
      box(
        `PROSES BUILD APK (URL)\n` +
        `JOB: ${jobId}\n` +
        `STATUS: triggering\n` +
        `${makeBar(25)}\n\n` +
        `🚀 Triggering build...`
      ),
      { parse_mode: "HTML" }
    );

    const dispatchAt = Date.now();
    await dispatchWorkflow(jobId, { zipUrl });

    let runId = null;
    let runUrl = null;

    for (let i = 0; i < 10; i++) {
      await new Promise((r) => setTimeout(r, 2500));
      const runsData = await listWorkflowRuns();
      const runs = runsData.workflow_runs || [];

      const candidate = runs
        .filter((r) => new Date(r.created_at).getTime() >= dispatchAt - 30000)
        .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())[0];

      const newest = candidate || runs[0];

      if (newest?.id) {
        runId = newest.id;
        runUrl = newest.html_url;
        break;
      }
    }

    // simpan job
    saveJob(jobId, {
      job_id: jobId,
      zip_path: "",
      zip_url: zipUrl,
      run_id: runId,
      run_url: runUrl,
      user_id: userId,
      created_at: new Date().toISOString(),
    });

    // progress + release queue
    runProgress(ctx, chatId, progressMsg.message_id, jobId)
      .finally(() => {
        if (!isOwner(userId)) {
          busyUserId = null;

          if (queue.length > 0) {
            const next = queue.shift();
            busyUserId = next.userId;

            ctx.telegram.sendMessage(
              next.chatId,
              box(`ANTRIAN KAMU SEKARANG GILIRAN ✅\nSILAHKAN KETIK:\n/buildurl <url_zip>`),
              { parse_mode: "HTML" }
            ).catch(() => {});
          }
        }
      })
      .catch(() => {});

    return ctx.reply(
      box(`✅ BUILD DIMULAI (URL)\nJOB: ${jobId}\n\n/getapk ${jobId}\n/status ${jobId}`),
      { parse_mode: "HTML" }
    );

  } catch (e) {
    // ✅ kalau gagal: balikin limit + release lock
    if (!isOwner(userId)) {
      try { addUserLimit(userId, 1); } catch {}
      if (busyUserId && Number(busyUserId) === Number(userId)) busyUserId = null;
    }
    return ctx.reply(box("❌ ERROR:\n" + (e?.message || String(e))), { parse_mode: "HTML" });
  }
});

bot.command("broadcast", async (ctx) => {
  const userId = ctx.from?.id;
  if (!isOwner(userId)) {
    return ctx.reply(box("AKSES DITOLAK: OWNER ONLY"), { parse_mode: "HTML" });
  }

  const replied = ctx.message?.reply_to_message;
  if (!replied) {
    return ctx.reply(
      box("CARANYA:\nREPLY PESAN YANG MAU DIKIRIM\nLALU KETIK:\n/broadcast"),
      { parse_mode: "HTML" }
    );
  }

  const users = getUsers();
  if (users.length === 0) {
    return ctx.reply(box("USER LIST KOSONG. BELUM ADA USER TERSIMPAN."), { parse_mode: "HTML" });
  }

  // pesan status
  const statusMsg = await ctx.reply(box(`BROADCAST DIMULAI...\nTOTAL USER: ${users.length}`), { parse_mode: "HTML" });

  const fromChatId = ctx.chat.id;
  const messageId = replied.message_id;

  let ok = 0, fail = 0;

  for (const uid of users) {
    try {
      // FORWARD = "meneruskan"
      await ctx.telegram.forwardMessage(uid, fromChatId, messageId);
      ok++;
    } catch (e) {
      fail++;
      // kalau user block bot / privacy, pasti fail. skip.
    }

    // update tiap 20 user biar ga spam edit
    if ((ok + fail) % 20 === 0) {
      await ctx.telegram.editMessageText(
        ctx.chat.id,
        statusMsg.message_id,
        undefined,
        box(`BROADCAST PROGRESS...\nOK: ${ok}\nFAIL: ${fail}\nTOTAL: ${users.length}`),
        { parse_mode: "HTML" }
      ).catch(() => {});
    }

    // anti rate limit (aman)
    await new Promise(r => setTimeout(r, 80));
  }

  await ctx.telegram.editMessageText(
    ctx.chat.id,
    statusMsg.message_id,
    undefined,
    box(`BROADCAST SELESAI ✅\nOK: ${ok}\nFAIL: ${fail}\nTOTAL: ${users.length}`),
    { parse_mode: "HTML" }
  ).catch(() => {});
});

bot.command("ceklimit", async (ctx) => {
  const userId = ctx.from?.id;

  if (isOwner(userId)) {
    return ctx.reply(box("LIMIT KAMU: UNLIMITED (OWNER)"), { parse_mode: "HTML" });
  }

  const sisa = getUserLimit(userId);
  return ctx.reply(
    box(`CEK LIMIT\nUSER: ${userId}\nSISA LIMIT: ${sisa}`),
    { parse_mode: "HTML" }
  );
});

bot.command("addlimit", async (ctx) => {
  const userId = ctx.from?.id;

  if (!isOwner(userId)) {
    return ctx.reply(
      box("AKSES DITOLAK ❌\nOWNER ONLY"),
      { parse_mode: "HTML" }
    );
  }

  const parts = (ctx.message.text || "").trim().split(/\s+/);
  const targetId = parts[1];
  const value = parts[2];

  if (!targetId || !value) {
    return ctx.reply(
      box(
        "FORMAT:\n" +
        "/addlimit userId jumlah|free\n\n" +
        "CONTOH:\n" +
        "/addlimit 123456 5\n" +
        "/addlimit 123456 free"
      ),
      { parse_mode: "HTML" }
    );
  }

  const db = readJson(LIMIT_FILE);

  // ===== MODE FREE (UNLIMITED) =====
  if (value.toLowerCase() === "free") {
    db[targetId] = { unlimited: true, limit: 999999999 };
    writeJson(LIMIT_FILE, db);

    return ctx.reply(
      box(
        "USER DIJADIKAN UNLIMITED ✅\n\n" +
        "USER: " + targetId + "\n" +
        "STATUS: BEBAS LIMIT (PERMANEN)"
      ),
      { parse_mode: "HTML" }
    );
  }

  // ===== MODE TAMBAH LIMIT ANGKA =====
  const amount = Number(value);
  if (isNaN(amount) || amount <= 0) {
    return ctx.reply(
      box("JUMLAH LIMIT HARUS ANGKA > 0"),
      { parse_mode: "HTML" }
    );
  }

  if (!db[targetId]) {
    db[targetId] = { unlimited: false, limit: 0 };
  }

  db[targetId].unlimited = false;
  db[targetId].limit += amount;

  writeJson(LIMIT_FILE, db);

  return ctx.reply(
    box(
      "ADD LIMIT BERHASIL ✅\n\n" +
      "USER: " + targetId + "\n" +
      "DITAMBAH: " + amount + "\n" +
      "TOTAL LIMIT: " + db[targetId].limit
    ),
    { parse_mode: "HTML" }
  );
});

bot.command("addkey", async (ctx) => {
  const ownerId = ctx.from.id;
  if (!isOwner(ownerId)) return ctx.reply("OWNER ONLY");

  const parts = ctx.message.text.split(" ");
  const targetId = parts[1];

  if (!targetId) return ctx.reply("FORMAT: /addkey id_user");

  const key = "KEY-" + Math.random().toString(36).substring(2,10).toUpperCase();

  const db = readJson(KEY_FILE);
  db[targetId] = key;

  writeJson(KEY_FILE, db);

  await ctx.reply(
    `KEY BERHASIL DIBUAT\nUSER: ${targetId}\nKEY: ${key}`
  );
});
// ===== fallback: /antrian command optional =====
bot.command("antrian", async (ctx) => {
  return ctx.reply(box(getQueueText()), { parse_mode: "HTML" });
});

bot.launch();
console.log("BOT BUILD APK READY 🚀");