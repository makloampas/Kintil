module.exports = {
  VPS_IP: "152.42.253.8",
  PANEL_PORT: 2187,
  FULL_URL: "http://152.42.253.8:2187"
};