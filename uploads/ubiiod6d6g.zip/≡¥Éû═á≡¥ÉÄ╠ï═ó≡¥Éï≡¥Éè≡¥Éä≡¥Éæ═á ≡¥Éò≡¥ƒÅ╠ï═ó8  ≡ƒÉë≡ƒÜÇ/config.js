module.exports = {
  BOT_TOKEN: "TOKEN BOT KAMU",
  OWNER_IDS: ["ID KAMU"],
};


