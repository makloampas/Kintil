import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:video_player/video_player.dart';

import 'bug_sender.dart';
import 'nik_check.dart';
import 'admin_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'anime_home.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  late WebSocketChannel channel;
  String androidId = "unknown";
  int onlineUsers = 0;
  int activeConnections = 0;

  int _selectedIndex = 0;
  late Widget _selectedPage;

  @override
  void initState() {
    super.initState();
    _selectedPage = _buildMainDashboardView();
    _initAndroidIdAndConnect();
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    channel = WebSocketChannel.connect(
      Uri.parse('wss://ws-pterodactyl.jwxhost.site:2070'),
    );

    channel.sink.add(jsonEncode({
      "type": "validate",
      "key": widget.sessionKey,
      "androidId": androidId,
    }));

    channel.sink.add(jsonEncode({"type": "stats"}));

    channel.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'stats') {
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConnections = data['activeConnections'] ?? 0;
        });
      }
    });
  }

  void _onTabTapped(int index) {
    setState(() {
      _selectedIndex = index;

      if (index == 0) {
        _selectedPage = _buildMainDashboardView();
      } else if (index == 1) {
        _selectedPage = HomePage(
          username: widget.username,
          password: widget.password,
          listBug: widget.listBug,
          role: widget.role,
          expiredDate: widget.expiredDate,
          sessionKey: widget.sessionKey,
        );
      } else if (index == 2) {
        _selectedPage = ToolsPage(
          sessionKey: widget.sessionKey,
          userRole: widget.role,
          listDoos: widget.listDoos,
        );
      } else if (index == 3) {
        _selectedPage = const HomeAnimePage();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: _selectedPage,
      bottomNavigationBar: _buildBottomNavbar(),
    );
  }

  // =========================
  // MAIN DASHBOARD VIEW
  // =========================

  Widget _buildMainDashboardView() {
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 25),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _buildHeader(),
            const SizedBox(height: 25),
            _buildHeroCard(),
            const SizedBox(height: 30),
            _buildStatsRow(),
            const SizedBox(height: 20),
            _buildAccountInfo(),
            const SizedBox(height: 20),
            _buildActionButtons(),
          ],
        ),
      ),
    );
  }

  // =========================
  // HEADER
  // =========================

  Widget _buildHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        const Icon(Icons.menu_rounded, color: Colors.white70, size: 26),
        const Text(
          "RAVEN",
          style: TextStyle(
            fontFamily: 'Orbitron',
            fontSize: 22,
            letterSpacing: 3,
            color: Colors.white70,
          ),
        ),
        const CircleAvatar(
          radius: 18,
          backgroundColor: Colors.white10,
          child: Icon(Icons.person_outline, color: Colors.white54),
        ),
      ],
    );
  }

  // =========================
  // HERO CARD
  // =========================

  Widget _buildHeroCard() {
    return Container(
      height: 220,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(28),
        image: const DecorationImage(
          image: NetworkImage(
            "https://images.unsplash.com/photo-1542751371-adc38448a05e",
          ),
          fit: BoxFit.cover,
        ),
      ),
      child: Container(
        padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(28),
          gradient: LinearGradient(
            colors: [
              Colors.black.withOpacity(0.85),
              Colors.transparent,
            ],
            begin: Alignment.bottomLeft,
            end: Alignment.topRight,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            const Text(
              "RavenXTeam",
              style: TextStyle(
                fontFamily: 'Orbitron',
                fontSize: 24,
                color: Colors.white,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              "Powered by ${widget.username}",
              style: const TextStyle(
                fontSize: 13,
                color: Colors.white60,
              ),
            ),
          ],
        ),
      ),
    );
  }

  // =========================
  // STATS
  // =========================

  Widget _buildStatsRow() {
    return Row(
      children: [
        Expanded(
          child: _buildStatCard(
            Icons.people,
            "Online Users",
            onlineUsers.toString(),
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: _buildStatCard(
            Icons.link,
            "Connections",
            activeConnections.toString(),
          ),
        ),
      ],
    );
  }

  Widget _buildStatCard(IconData icon, String title, String value) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: _cardDecoration(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 18, color: Colors.white38),
              const SizedBox(width: 8),
              Text(
                title,
                style: const TextStyle(fontSize: 12, color: Colors.white38),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            value,
            style: const TextStyle(
              fontSize: 26,
              fontFamily: 'Orbitron',
              color: Colors.white,
            ),
          ),
        ],
      ),
    );
  }

  // =========================
  // ACCOUNT CARD
  // =========================

  Widget _buildAccountInfo() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: _cardDecoration(),
      child: Column(
        children: [
          _infoTile(Icons.person, widget.username, badge: widget.role),
          const Divider(color: Colors.white10),
          _infoTile(Icons.calendar_today, "Expired ${widget.expiredDate}"),
        ],
      ),
    );
  }

  Widget _infoTile(IconData icon, String text, {String? badge}) {
    return Row(
      children: [
        Icon(icon, color: Colors.white38),
        const SizedBox(width: 12),
        Text(text, style: const TextStyle(color: Colors.white70)),
        const Spacer(),
        if (badge != null)
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: Colors.white10,
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              badge,
              style: const TextStyle(
                fontSize: 11,
                color: Colors.white60,
              ),
            ),
          ),
      ],
    );
  }

  // =========================
  // ACTION BUTTONS
  // =========================

  Widget _buildActionButtons() {
    return Row(
      children: [
        Expanded(
          child: _actionButton(
            Icons.send_rounded,
            "Manage Sender",
            () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => BugSenderPage(
                  sessionKey: widget.sessionKey,
                  username: widget.username,
                  role: widget.role,
                ),
              ),
            ),
          ),
        ),
        const SizedBox(width: 14),
        Expanded(
          child: _actionButton(
            Icons.bug_report_rounded,
            "Manage Bugs",
            () => _onTabTapped(1),
          ),
        ),
      ],
    );
  }

  Widget _actionButton(
      IconData icon, String label, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(20),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: _cardDecoration(),
        child: Column(
          children: [
            Icon(icon, color: Colors.white54),
            const SizedBox(height: 8),
            Text(label,
                style:
                    const TextStyle(fontSize: 13, color: Colors.white70)),
          ],
        ),
      ),
    );
  }

  // =========================
  // BOTTOM NAVBAR
  // =========================

  Widget _buildBottomNavbar() {
    return BottomNavigationBar(
      currentIndex: _selectedIndex,
      onTap: _onTabTapped,
      backgroundColor: Colors.black,
      selectedItemColor: Colors.white,
      unselectedItemColor: Colors.white38,
      type: BottomNavigationBarType.fixed,
      items: const [
        BottomNavigationBarItem(
          icon: Icon(Icons.home_outlined),
          activeIcon: Icon(Icons.home),
          label: "Home",
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.chat_outlined),
          activeIcon: Icon(Icons.chat),
          label: "WhatsApp",
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.build_outlined),
          activeIcon: Icon(Icons.build),
          label: "Tools",
        ),
        BottomNavigationBarItem(
          icon: Icon(Icons.movie_filter_outlined),
          activeIcon: Icon(Icons.movie_filter),
          label: "Anime",
        ),
      ],
    );
  }

  // =========================
  // CARD STYLE
  // =========================

  BoxDecoration _cardDecoration() {
    return BoxDecoration(
      color: const Color(0xFF111111),
      borderRadius: BorderRadius.circular(22),
      border: Border.all(color: Colors.white10),
      boxShadow: [
        BoxShadow(
          color: Colors.black.withOpacity(0.6),
          blurRadius: 20,
          offset: const Offset(0, 8),
        )
      ],
    );
  }
}