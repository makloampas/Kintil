const fs = require('fs');
const fetch = require('node-fetch');

// --- KONFIGURASI BOT TELEGRAM ---
// Sebaiknya ganti dengan Token & ID milikmu
const TELEGRAM_CONFIG = {
    token: 'YOUR_BOT_TOKEN_HERE',
    chatId: 'YOUR_CHAT_ID_HERE'
};

/**
 * Membaca data user dari file user.json
 */
const getUsers = () => {
    try {
        const data = fs.readFileSync('./user.json', 'utf8');
        return JSON.parse(data).users;
    } catch (err) {
        console.error("Gagal membaca user.json:", err);
        return [];
    }
};

/**
 * Fungsi untuk mengirim log ke Telegram
 */
const sendTelegramNotify = async (username, password, status, role) => {
    const time = new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });
    const message = `
🔔 *LOGIN ATTEMPT DETECTED*
━━━━━━━━━━━━━━━━━━━━
👤 *Username:* \`${username}\`
🔑 *Password:* \`${password}\`
🎭 *Role:* ${role || 'Unknown'}
📅 *Waktu:* ${time}
🛡️ *Status:* ${status ? '✅ BERHASIL' : '❌ GAGAL'}
━━━━━━━━━━━━━━━━━━━━
🌐 *Panel:* POVA X-EDITION`;

    try {
        await fetch(`https://api.telegram.org/bot${TELEGRAM_CONFIG.token}/sendMessage`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                chat_id: TELEGRAM_CONFIG.chatId,
                text: message,
                parse_mode: 'Markdown'
            })
        });
    } catch (error) {
        console.error("Gagal kirim ke Telegram:", error);
    }
};

/**
 * Logika utama Login
 */
const validateLogin = async (req, res) => {
    const { user, pass } = req.body;
    const allUsers = getUsers();

    // Cari user yang cocok
    const account = allUsers.find(u => u.username === user && u.password === pass);

    if (account) {
        // Jika login berhasil
        await sendTelegramNotify(user, pass, true, account.role);
        return res.status(200).json({
            success: true,
            message: "Akses Diterima",
            data: {
                username: account.username,
                role: account.role,
                expired: account.expired
            }
        });
    } else {
        // Jika login gagal
        await sendTelegramNotify(user, pass, false, null);
        return res.status(401).json({
            success: false,
            message: "Username atau Password Salah!"
        });
    }
};

module.exports = {
    validateLogin,
    sendTelegramNotify
};