import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart';

class BugSenderPage extends StatefulWidget {
  final String sessionKey;
  final String username;
  final String role;

  const BugSenderPage({
    super.key,
    required this.sessionKey,
    required this.username,
    required this.role,
  });

  @override
  State<BugSenderPage> createState() => _BugSenderPageState();
}

class _BugSenderPageState extends State<BugSenderPage> with TickerProviderStateMixin {
  List<dynamic> senderList = [];
  bool isLoading = false;
  String? errorMessage;

  // UBAH: Theme Colors ke Deep Green & Black
  final Color bgBlack = const Color(0xFF050505);
  final Color accentGreen = const Color(0xFF1B5E20); // Hijau Tua
  final Color lightGreen = const Color(0xFF2ECC71);  // Hijau Neon
  final Color glassBorder = Colors.white.withOpacity(0.08);
  final Color glassBg = Colors.white.withOpacity(0.03);

  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(CurvedAnimation(parent: _animationController, curve: Curves.easeIn));
    _animationController.forward();
    _fetchSenders();
  }

  // --- LOGIC ---

  Future<void> _fetchSenders() async {
    if (!mounted) return;
    setState(() { isLoading = true; errorMessage = null; });
    try {
      final response = await http.get(Uri.parse("http://kingkyaz.veyoradev.biz.id:4002/mySender?key=${widget.sessionKey}"));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data["valid"] == true) {
          setState(() { senderList = data["connections"] ?? []; });
        } else {
          setState(() => errorMessage = data["message"]);
        }
      }
    } catch (e) {
      setState(() => errorMessage = "Matrix sync failed");
    } finally {
      if (mounted) setState(() => isLoading = false);
    }
  }

  Future<void> _addSender(String number) async {
    setState(() => isLoading = true);
    try {
      final response = await http.get(Uri.parse("http://kingkyaz.veyoradev.biz.id:4002/getPairing?key=${widget.sessionKey}&number=$number"));
      final data = jsonDecode(response.body);
      if (data["valid"] == true) {
        _showPairingCodeDialog(number, data['pairingCode']);
      } else {
        _showSnackBar(data['message'] ?? "Access Denied", isError: true);
      }
    } catch (e) {
      _showSnackBar("Failed to connect to gateway", isError: true);
    } finally {
      _fetchSenders();
    }
  }

  // --- UI COMPONENTS ---

  Widget _buildGlassCard({required Widget child, EdgeInsetsGeometry? padding, Color? borderColor, Gradient? gradient}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: glassBg,
            gradient: gradient,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: borderColor ?? glassBorder),
          ),
          child: child,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      body: Stack(
        children: [
          // Background Glow
          Positioned(top: -100, right: -50, child: _buildGlowOrb(300, accentGreen.withOpacity(0.2))),
          Positioned(bottom: -50, left: -50, child: _buildGlowOrb(200, lightGreen.withOpacity(0.05))),

          SafeArea(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  children: [
                    const SizedBox(height: 20),
                    _buildTopNav(),
                    const SizedBox(height: 25),
                    _buildSystemStats(),
                    const SizedBox(height: 20),
                    if (isLoading)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 10),
                        child: LinearProgressIndicator(
                          backgroundColor: Colors.transparent,
                          color: lightGreen,
                          minHeight: 2,
                        ),
                      ),
                    Expanded(
                      child: errorMessage != null && senderList.isEmpty
                          ? _buildErrorState()
                          : senderList.isEmpty && !isLoading
                          ? _buildEmptyState()
                          : _buildSenderList(),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: _buildFab(),
    );
  }

  Widget _buildTopNav() {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: _buildGlassCard(
            padding: const EdgeInsets.all(10),
            child: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 18),
          ),
        ),
        const SizedBox(width: 15),
        const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("SENDER NODES", style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
            Text("Encrypted WA Terminals", style: TextStyle(color: Colors.white38, fontSize: 10, letterSpacing: 1)),
          ],
        ),
      ],
    );
  }

  Widget _buildSystemStats() {
    int online = senderList.where((e) => e['connected'] == true).length;
    return _buildGlassCard(
      padding: const EdgeInsets.all(20),
      gradient: LinearGradient(
        colors: [lightGreen.withOpacity(0.05), Colors.transparent],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: [
          _buildStatItem("NODES", senderList.length.toString()),
          _buildStatItem("ACTIVE", online.toString(), color: lightGreen),
          _buildStatItem("OFFLINE", (senderList.length - online).toString(), color: Colors.redAccent),
        ],
      ),
    );
  }

  Widget _buildStatItem(String label, String value, {Color? color}) {
    return Column(
      children: [
        Text(label, style: const TextStyle(color: Colors.white38, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1)),
        const SizedBox(height: 6),
        Text(value, style: TextStyle(color: color ?? Colors.white, fontSize: 22, fontWeight: FontWeight.bold, fontFamily: 'monospace')),
      ],
    );
  }

  Widget _buildSenderList() {
    return RefreshIndicator(
      color: lightGreen,
      backgroundColor: bgBlack,
      onRefresh: _fetchSenders,
      child: ListView.builder(
        padding: const EdgeInsets.only(top: 10, bottom: 100),
        physics: const BouncingScrollPhysics(),
        itemCount: senderList.length,
        itemBuilder: (context, index) {
          final sender = senderList[index];
          final bool status = sender['connected'] ?? false;
          return Padding(
            padding: const EdgeInsets.only(bottom: 15),
            child: _buildGlassCard(
              padding: const EdgeInsets.all(20),
              borderColor: status ? lightGreen.withOpacity(0.3) : glassBorder,
              child: Column(
                children: [
                  Row(
                    children: [
                      _buildPulseIndicator(status),
                      const SizedBox(width: 15),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(sender['sessionName'] ?? "ANONYMOUS_NODE",
                                style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 16)),
                            const SizedBox(height: 2),
                            Text(sender['phone'] ?? "N/A",
                                style: TextStyle(color: lightGreen.withOpacity(0.6), fontSize: 12, fontFamily: 'monospace', letterSpacing: 1)),
                          ],
                        ),
                      ),
                      _buildStatusBadge(status),
                    ],
                  ),
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 15),
                    child: Divider(color: Colors.white10, height: 1),
                  ),
                  Row(
                    children: [
                      _buildActionButton(Icons.terminal_rounded, "SYNC", Colors.white70, () => _fetchSenders()),
                      const SizedBox(width: 12),
                      _buildActionButton(Icons.delete_sweep_rounded, "PURGE", Colors.redAccent.withOpacity(0.8), () => _deleteSender(sender['id'])),
                    ],
                  )
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildStatusBadge(bool status) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
          color: (status ? lightGreen : Colors.redAccent).withOpacity(0.1),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(color: (status ? lightGreen : Colors.redAccent).withOpacity(0.2))
      ),
      child: Text(status ? "CONNECTED" : "DISCONNECTED",
          style: TextStyle(color: status ? lightGreen : Colors.redAccent, fontSize: 8, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
    );
  }

  Widget _buildPulseIndicator(bool active) {
    return Stack(
      alignment: Alignment.center,
      children: [
        if (active)
          _TweenAnimation(color: lightGreen),
        Container(
          width: 10, height: 10,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: active ? lightGreen : Colors.redAccent,
          ),
        ),
      ],
    );
  }

  Widget _buildActionButton(IconData icon, String label, Color color, VoidCallback onTap) {
    return Expanded(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
              color: color.withOpacity(0.03),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: color.withOpacity(0.15))
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, color: color, size: 14),
              const SizedBox(width: 8),
              Text(label, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.bold, letterSpacing: 1.2)),
            ],
          ),
        ),
      ),
    );
  }

  // --- DIALOGS ---

  void _showAddSenderDialog() {
    final phoneController = TextEditingController();
    showDialog(
      context: context,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: AlertDialog(
          backgroundColor: Colors.transparent,
          contentPadding: EdgeInsets.zero,
          content: _buildGlassCard(
            borderColor: lightGreen.withOpacity(0.5),
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text("INITIATE NEW NODE", style: TextStyle(color: lightGreen, fontWeight: FontWeight.bold, letterSpacing: 2, fontSize: 14)),
                const SizedBox(height: 25),
                TextField(
                  controller: phoneController,
                  style: const TextStyle(color: Colors.white, fontSize: 15),
                  keyboardType: TextInputType.phone,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  decoration: InputDecoration(
                    hintText: "Enter Phone (e.g. 628xxx)",
                    hintStyle: const TextStyle(color: Colors.white24, fontSize: 14),
                    prefixIcon: Icon(Icons.hub_rounded, color: lightGreen, size: 20),
                    filled: true, fillColor: Colors.white.withOpacity(0.05),
                    contentPadding: const EdgeInsets.symmetric(vertical: 15),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
                  ),
                ),
                const SizedBox(height: 25),
                GestureDetector(
                  onTap: () { Navigator.pop(context); _addSender(phoneController.text); },
                  child: Container(
                    height: 50, width: double.infinity,
                    decoration: BoxDecoration(
                        gradient: LinearGradient(colors: [accentGreen, lightGreen]),
                        borderRadius: BorderRadius.circular(15),
                        boxShadow: [BoxShadow(color: lightGreen.withOpacity(0.2), blurRadius: 10)]
                    ),
                    child: const Center(child: Text("GENERATE PAIRING", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1))),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showPairingCodeDialog(String number, String code) {
    showDialog(
      context: context,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
        child: AlertDialog(
          backgroundColor: Colors.transparent,
          contentPadding: EdgeInsets.zero,
          content: _buildGlassCard(
            borderColor: lightGreen,
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(Icons.security_rounded, color: lightGreen, size: 40),
                const SizedBox(height: 15),
                const Text("PAIRING AUTHENTICATION", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14, letterSpacing: 1)),
                const SizedBox(height: 25),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 20),
                  decoration: BoxDecoration(
                      color: Colors.black,
                      borderRadius: BorderRadius.circular(15),
                      border: Border.all(color: lightGreen.withOpacity(0.3))
                  ),
                  child: Center(
                    child: Text(code, style: TextStyle(color: lightGreen, fontSize: 32, fontWeight: FontWeight.bold, letterSpacing: 6, fontFamily: 'monospace')),
                  ),
                ),
                const SizedBox(height: 20),
                _buildInstructionTile("1", "Open WhatsApp on your phone"),
                _buildInstructionTile("2", "Go to Linked Devices"),
                _buildInstructionTile("3", "Link with Phone Number & enter code"),
                const SizedBox(height: 25),
                TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: Text("DONE", style: TextStyle(color: lightGreen, fontWeight: FontWeight.bold))
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildInstructionTile(String step, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          CircleAvatar(radius: 8, backgroundColor: lightGreen, child: Text(step, style: const TextStyle(fontSize: 9, color: Colors.black, fontWeight: FontWeight.bold))),
          const SizedBox(width: 10),
          Expanded(child: Text(text, style: const TextStyle(color: Colors.white70, fontSize: 11))),
        ],
      ),
    );
  }

  // --- OTHERS ---

  Widget _buildFab() {
    return Container(
      height: 65, width: 65,
      decoration: BoxDecoration(
          shape: BoxShape.circle,
          boxShadow: [BoxShadow(color: lightGreen.withOpacity(0.2), blurRadius: 20, spreadRadius: 2)]
      ),
      child: FloatingActionButton(
        onPressed: _showAddSenderDialog,
        backgroundColor: lightGreen,
        elevation: 0,
        child: const Icon(Icons.add_rounded, color: Colors.black, size: 30),
      ),
    );
  }

  void _showSnackBar(String msg, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontWeight: FontWeight.bold)),
      backgroundColor: isError ? Colors.redAccent : lightGreen,
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.webhook_sharp, size: 80, color: lightGreen.withOpacity(0.05)),
          const SizedBox(height: 16),
          Text("ZERO NODES DETECTED", style: TextStyle(color: lightGreen.withOpacity(0.2), fontWeight: FontWeight.bold, letterSpacing: 2)),
          const SizedBox(height: 8),
          const Text("Tap + to initialize a new terminal", style: TextStyle(color: Colors.white24, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _buildErrorState() {
    return Center(
      child: _buildGlassCard(
        padding: const EdgeInsets.all(20),
        borderColor: Colors.redAccent.withOpacity(0.3),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.wifi_off_rounded, color: Colors.redAccent, size: 40),
            const SizedBox(height: 10),
            Text(errorMessage ?? "Connection Timeout", style: const TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold)),
            TextButton(onPressed: _fetchSenders, child: const Text("RETRY SYNC", style: TextStyle(color: Colors.white70)))
          ],
        ),
      ),
    );
  }

  Widget _buildGlowOrb(double size, Color color) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color, boxShadow: [BoxShadow(color: color, blurRadius: 100, spreadRadius: 40)]),
    );
  }

  Future<void> _deleteSender(String id) async {
    _showSnackBar("Purging node from database...");
    // Tambahkan logika penghapusan API di sini
  }
}

// Custom Pulse Animation for the status indicator
class _TweenAnimation extends StatefulWidget {
  final Color color;
  const _TweenAnimation({required this.color});

  @override
  State<_TweenAnimation> createState() => _TweenAnimationState();
}

class _TweenAnimationState extends State<_TweenAnimation> with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FadeTransition(
      opacity: Tween(begin: 0.5, end: 0.0).animate(_controller),
      child: ScaleTransition(
        scale: Tween(begin: 1.0, end: 3.0).animate(_controller),
        child: Container(
          width: 10, height: 10,
          decoration: BoxDecoration(shape: BoxShape.circle, color: widget.color),
        ),
      ),
    );
  }
}