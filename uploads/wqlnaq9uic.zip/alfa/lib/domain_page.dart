import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:flutter/services.dart';

class DomainOsintPage extends StatefulWidget {
  const DomainOsintPage({super.key});

  @override
  State<DomainOsintPage> createState() => _DomainOsintPageState();
}

class _DomainOsintPageState extends State<DomainOsintPage> {
  final TextEditingController _domainController = TextEditingController();
  bool _isLoading = false;
  Map<String, dynamic>? _dnsData;
  List<dynamic>? _subdomainsData;
  String? _errorMessage;

  // Theme Colors (Deep Green & Black)
  final Color bgBlack = const Color(0xFF050505);
  final Color accentGreen = const Color(0xFF1B5E20);
  final Color lightGreen = const Color(0xFF2ECC71);
  final Color glassBg = Colors.white.withOpacity(0.03);
  final Color glassBorder = Colors.white.withOpacity(0.08);

  Future<void> _checkDomain() async {
    final domain = _domainController.text.trim();
    if (domain.isEmpty) {
      setState(() {
        _errorMessage = "TARGET DOMAIN NULL";
        _dnsData = null;
        _subdomainsData = null;
      });
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _dnsData = null;
      _subdomainsData = null;
    });

    try {
      final dnsResult = await _fetchDnsInfo(domain);
      final subdoResult = await _fetchSubdomains(domain);

      if (dnsResult != null && subdoResult != null) {
        setState(() {
          _dnsData = dnsResult;
          _subdomainsData = subdoResult;
        });
      } else {
        setState(() {
          _errorMessage = "FAIL: DATA_NOT_FOUND";
        });
      }
    } catch (e) {
      setState(() {
        _errorMessage = "CRITICAL_ERROR: $e";
      });
    } finally {
      setState(() {
        _isLoading = false;
      });
    }
  }

  Future<Map<String, dynamic>?> _fetchDnsInfo(String domain) async {
    final url = Uri.parse("https://api.siputzx.my.id/api/tools/dns?domain=$domain");
    final response = await http.get(url);
    if (response.statusCode == 200) {
      final json = jsonDecode(response.body);
      return json['status'] == true ? json['data'] : null;
    }
    return null;
  }

  Future<List<dynamic>?> _fetchSubdomains(String domain) async {
    final url = Uri.parse("https://api.siputzx.my.id/api/tools/subdomains?domain=$domain");
    final response = await http.get(url);
    if (response.statusCode == 200) {
      final json = jsonDecode(response.body);
      return json['status'] == true ? json['data'] : null;
    }
    return null;
  }

  void _copyToClipboard(String text, String label) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('$label: DATA_COPIED', style: TextStyle(color: lightGreen, fontWeight: FontWeight.bold)),
        backgroundColor: bgBlack,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10), side: BorderSide(color: lightGreen.withOpacity(0.3))),
      ),
    );
  }

  Widget _buildCategoryCard({
    required String title,
    required IconData icon,
    required List<Widget> children,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: glassBg,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: glassBorder),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(20),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: lightGreen.withOpacity(0.05),
                  border: Border(bottom: BorderSide(color: glassBorder)),
                ),
                child: Row(
                  children: [
                    Icon(icon, color: lightGreen, size: 18),
                    const SizedBox(width: 12),
                    Text(title,
                        style: TextStyle(
                            color: lightGreen,
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 1.5)),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(16),
                child: Column(children: children),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildInfoRow({
    required String label,
    required String? value,
    bool showCopyButton = false,
  }) {
    if (value == null || value.isEmpty) return const SizedBox.shrink();

    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.02),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.white.withOpacity(0.05)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(label.toUpperCase(),
                    style: const TextStyle(color: Colors.white38, fontSize: 10, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(value,
                    style: const TextStyle(color: Colors.white, fontSize: 14, fontFamily: 'monospace')),
              ],
            ),
          ),
          if (showCopyButton)
            IconButton(
              icon: Icon(Icons.content_copy_rounded, color: lightGreen.withOpacity(0.5), size: 18),
              onPressed: () => _copyToClipboard(value, label),
              padding: EdgeInsets.zero,
              constraints: const BoxConstraints(minWidth: 30),
            ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      appBar: AppBar(
        title: const Text('DOMAIN OSINT',
            style: TextStyle(fontFamily: 'Orbitron', fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white, letterSpacing: 2)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Stack(
        children: [
          // Background Glow
          Positioned(top: -50, right: -50, child: _buildGlowOrb(200, accentGreen.withOpacity(0.1))),

          SafeArea(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  // Input Terminal
                  _buildInputTerminal(),
                  const SizedBox(height: 20),

                  // Error State
                  if (_errorMessage != null)
                    _buildStatusBox(_errorMessage!, Colors.redAccent),

                  // Results List
                  if (_dnsData != null || _subdomainsData != null)
                    Expanded(
                      child: SingleChildScrollView(
                        physics: const BouncingScrollPhysics(),
                        child: Column(
                          children: [
                            if (_dnsData != null) _buildDomainInfo(),
                            const SizedBox(height: 16),
                            if (_subdomainsData != null) _buildSubdomainList(),
                          ],
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInputTerminal() {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: glassBg,
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: glassBorder),
      ),
      child: Column(
        children: [
          TextField(
            controller: _domainController,
            style: const TextStyle(color: Colors.white, fontFamily: 'monospace'),
            decoration: InputDecoration(
              hintText: 'TARGET_DOMAIN.COM',
              hintStyle: TextStyle(color: Colors.white.withOpacity(0.2)),
              prefixIcon: Icon(Icons.language_rounded, color: lightGreen),
              filled: true,
              fillColor: Colors.black.withOpacity(0.3),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
              enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: glassBorder)),
              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: lightGreen.withOpacity(0.5))),
            ),
            onSubmitted: (_) => _checkDomain(),
          ),
          const SizedBox(height: 16),
          SizedBox(
            width: double.infinity,
            height: 55,
            child: ElevatedButton(
              onPressed: _isLoading ? null : _checkDomain,
              style: ElevatedButton.styleFrom(
                backgroundColor: lightGreen,
                foregroundColor: Colors.black,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                elevation: 0,
              ),
              child: _isLoading
                  ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2))
                  : const Text('INITIATE OSINT SCAN', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusBox(String msg, Color color) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(Icons.terminal_rounded, color: color, size: 16),
          const SizedBox(width: 12),
          Text(msg, style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 1)),
        ],
      ),
    );
  }

  Widget _buildDomainInfo() {
    return _buildCategoryCard(
      title: "DOMAIN_METADATA",
      icon: Icons.hub_rounded,
      children: [
        _buildInfoRow(label: "Domain", value: _dnsData!['unicodeDomain'], showCopyButton: true),
        _buildInfoRow(label: "Punycode", value: _dnsData!['punycodeDomain'], showCopyButton: true),
        const Divider(color: Colors.white10, height: 20),
        ..._buildDnsRecords(),
      ],
    );
  }

  Widget _buildSubdomainList() {
    final cleanSubdomains = _subdomainsData!
        .map((item) => item.toString().split('\n').last.trim())
        .where((subdomain) => subdomain.isNotEmpty && !subdomain.startsWith('*'))
        .toSet()
        .toList()..sort();

    return _buildCategoryCard(
      title: "SUBDOMAIN_ENUMERATION",
      icon: Icons.lan_rounded,
      children: [
        Text("${cleanSubdomains.length} NODES IDENTIFIED",
            style: TextStyle(color: lightGreen.withOpacity(0.6), fontSize: 10, fontWeight: FontWeight.bold)),
        const SizedBox(height: 12),
        ...cleanSubdomains.map((subdomain) => Container(
          margin: const EdgeInsets.only(bottom: 8),
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.02),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: glassBorder),
          ),
          child: Row(
            children: [
              Icon(Icons.link_rounded, color: lightGreen.withOpacity(0.4), size: 14),
              const SizedBox(width: 12),
              Expanded(child: Text(subdomain, style: const TextStyle(color: Colors.white70, fontSize: 13, fontFamily: 'monospace'))),
              GestureDetector(
                onTap: () => _copyToClipboard(subdomain, 'Subdomain'),
                child: Icon(Icons.copy_all_rounded, color: lightGreen.withOpacity(0.3), size: 16),
              ),
            ],
          ),
        )).toList(),
      ],
    );
  }

  List<Widget> _buildDnsRecords() {
    if (_dnsData == null || _dnsData!['records'] == null) return [];
    final records = _dnsData!['records'] as Map<String, dynamic>;
    final widgets = <Widget>[];

    void addSection(String title, List<dynamic>? answers, String field) {
      if (answers != null && answers.isNotEmpty) {
        widgets.add(Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Text(title, style: TextStyle(color: lightGreen, fontSize: 11, fontWeight: FontWeight.bold)),
        ));
        for (var record in answers) {
          widgets.add(_buildInfoRow(
            label: '$title Record',
            value: record['record']?[field]?.toString() ?? record['record']?['data']?.toString(),
            showCopyButton: true,
          ));
        }
      }
    }

    addSection('NS', records['ns']?['response']?['answer'], 'target');
    addSection('A', records['a']?['response']?['answer'], 'data');

    return widgets;
  }

  Widget _buildGlowOrb(double size, Color color) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color, boxShadow: [BoxShadow(color: color, blurRadius: 100, spreadRadius: 40)]),
    );
  }
}