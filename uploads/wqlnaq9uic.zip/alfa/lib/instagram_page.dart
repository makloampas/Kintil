import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:video_player/video_player.dart';
import 'package:chewie/chewie.dart';
import 'package:share_plus/share_plus.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';

class InstagramDownloaderPage extends StatefulWidget {
  const InstagramDownloaderPage({super.key});

  @override
  State<InstagramDownloaderPage> createState() => _InstagramDownloaderPageState();
}

class _InstagramDownloaderPageState extends State<InstagramDownloaderPage> with TickerProviderStateMixin {
  final TextEditingController _urlController = TextEditingController();
  bool _isLoading = false;
  List<dynamic>? _mediaData;
  String? _errorMessage;
  VideoPlayerController? _videoController;
  ChewieController? _chewieController;

  // Theme Colors (Purple Glassmorphism)
  final Color bgBlack = const Color(0xFF08080E);
  final Color accentPurple = const Color(0xFF7B2CBF);
  final Color lightPurple = const Color(0xFF9D4EDD);
  final Color glassBorder = Colors.white.withOpacity(0.1);
  final Color glassBg = Colors.white.withOpacity(0.05);

  late AnimationController _slideController;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _slideController = AnimationController(vsync: this, duration: const Duration(milliseconds: 800));
    _slideAnimation = Tween<Offset>(begin: const Offset(0, 0.1), end: Offset.zero)
        .animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOut));
    _slideController.forward();
  }

  @override
  void dispose() {
    _slideController.dispose();
    _urlController.dispose();
    _videoController?.dispose();
    _chewieController?.dispose();
    super.dispose();
  }

  // --- LOGIC SECTION ---

  Future<void> _downloadInstagram() async {
    final url = _urlController.text.trim();
    if (url.isEmpty) {
      _showSnackBar("URL tidak boleh kosong!", Colors.redAccent);
      return;
    }

    setState(() {
      _isLoading = true;
      _errorMessage = null;
      _mediaData = null;
      _videoController?.dispose();
      _chewieController?.dispose();
      _chewieController = null;
    });

    try {
      final response = await http.get(Uri.parse("https://api.siputzx.my.id/api/d/igdl?url=${Uri.encodeComponent(url)}"));
      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        if (json['status'] == true && json['data'] != null) {
          setState(() => _mediaData = json['data']);
          HapticFeedback.mediumImpact();
        } else {
          setState(() => _errorMessage = "Gagal mengambil data media.");
        }
      }
    } catch (e) {
      setState(() => _errorMessage = "Koneksi terputus.");
    } finally {
      setState(() => _isLoading = false);
    }
  }

  void _initializeVideo(String url) {
    _videoController?.dispose();
    _chewieController?.dispose();

    _videoController = VideoPlayerController.networkUrl(Uri.parse(url))
      ..initialize().then((_) {
        setState(() {
          _chewieController = ChewieController(
            videoPlayerController: _videoController!,
            autoPlay: true,
            aspectRatio: _videoController!.value.aspectRatio,
            materialProgressColors: ChewieProgressColors(
              playedColor: lightPurple,
              handleColor: accentPurple,
              bufferedColor: Colors.white24,
              backgroundColor: Colors.white10,
            ),
          );
        });
      });
  }

  Future<void> _shareMedia(String url) async {
    try {
      _showSnackBar("Preparing media...", lightPurple);
      final response = await http.get(Uri.parse(url));
      final tempDir = await getTemporaryDirectory();
      final file = File('${tempDir.path}/ig_media_${DateTime.now().millisecondsSinceEpoch}.mp4');
      await file.writeAsBytes(response.bodyBytes);
      await Share.shareXFiles([XFile(file.path)], text: 'Downloaded via CyberApp');
    } catch (e) {
      _showSnackBar("Gagal membagikan media", Colors.redAccent);
    }
  }

  void _showSnackBar(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontWeight: FontWeight.bold)),
      backgroundColor: color.withOpacity(0.8),
      behavior: SnackBarBehavior.floating,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
    ));
  }

  // --- UI COMPONENTS ---

  Widget _buildGlassContainer({required Widget child, EdgeInsetsGeometry? padding}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: glassBg,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: glassBorder),
          ),
          child: child,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      body: Stack(
        children: [
          Positioned(top: -50, right: -50, child: _buildGlowOrb(250, accentPurple.withOpacity(0.15))),
          SafeArea(
            child: SlideTransition(
              position: _slideAnimation,
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  children: [
                    const SizedBox(height: 20),
                    _buildHeader(),
                    const SizedBox(height: 30),
                    _buildInputSection(),
                    const SizedBox(height: 25),
                    if (_isLoading) CircularProgressIndicator(color: lightPurple),
                    if (_errorMessage != null) _buildErrorState(),
                    if (_chewieController != null) _buildVideoPlayer(),
                    if (_mediaData != null) _buildGallerySection(),
                    if (_mediaData == null && !_isLoading && _errorMessage == null) _buildEmptyState(),
                    const SizedBox(height: 50),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        IconButton(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 20)),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("IG EXTRACTOR", style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
            Text("Social Media Downloader", style: TextStyle(color: lightPurple.withOpacity(0.5), fontSize: 11, letterSpacing: 1.2)),
          ],
        ),
      ],
    );
  }

  Widget _buildInputSection() {
    return _buildGlassContainer(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text("PASTE URL", style: TextStyle(color: Colors.white38, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 2)),
          const SizedBox(height: 15),
          TextField(
            controller: _urlController,
            style: const TextStyle(color: Colors.white, fontSize: 14),
            decoration: InputDecoration(
              hintText: "Instagram Link...",
              hintStyle: const TextStyle(color: Colors.white24),
              filled: true,
              fillColor: Colors.white.withOpacity(0.05),
              prefixIcon: Icon(Icons.link_rounded, color: lightPurple),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
            ),
          ),
          const SizedBox(height: 15),
          _buildActionButton(),
        ],
      ),
    );
  }

  Widget _buildActionButton() {
    return GestureDetector(
      onTap: _isLoading ? null : _downloadInstagram,
      child: Container(
        height: 55,
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [accentPurple, lightPurple]),
          borderRadius: BorderRadius.circular(15),
          boxShadow: [BoxShadow(color: accentPurple.withOpacity(0.3), blurRadius: 10, offset: const Offset(0, 5))],
        ),
        child: const Center(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.bolt_rounded, color: Colors.white, size: 20),
              SizedBox(width: 10),
              Text("FETCH MEDIA", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1.1)),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildVideoPlayer() {
    return Padding(
      padding: const EdgeInsets.only(top: 20),
      child: _buildGlassContainer(
        padding: const EdgeInsets.all(15),
        child: Column(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(15),
              child: AspectRatio(
                aspectRatio: _videoController!.value.aspectRatio,
                child: Chewie(controller: _chewieController!),
              ),
            ),
            const SizedBox(height: 15),
            _buildGlassButton(
              onTap: () => _shareMedia(_mediaData![0]['url']),
              icon: Icons.share_rounded,
              label: "SHARE VIDEO",
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildGallerySection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 30),
        const Text("COLLECTED ASSETS", style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold)),
        const SizedBox(height: 15),
        GridView.builder(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            crossAxisCount: 2, crossAxisSpacing: 15, mainAxisSpacing: 15, childAspectRatio: 0.75,
          ),
          itemCount: _mediaData!.length,
          itemBuilder: (context, index) {
            final media = _mediaData![index];
            final isVideo = media['type'] == 'video';
            return _buildMediaTile(media, isVideo);
          },
        ),
      ],
    );
  }

  Widget _buildMediaTile(dynamic media, bool isVideo) {
    return GestureDetector(
      onTap: () => isVideo ? _initializeVideo(media['url']) : null,
      child: _buildGlassContainer(
        child: Stack(
          fit: StackFit.expand,
          children: [
            Image.network(media['thumbnail'] ?? media['url'], fit: BoxFit.cover),
            Container(decoration: BoxDecoration(gradient: LinearGradient(colors: [Colors.transparent, Colors.black.withOpacity(0.8)], begin: Alignment.topCenter, end: Alignment.bottomCenter))),
            Positioned(top: 10, right: 10, child: Icon(isVideo ? Icons.videocam_rounded : Icons.image_rounded, color: lightPurple, size: 18)),
            if (isVideo) const Center(child: Icon(Icons.play_circle_fill_rounded, color: Colors.white70, size: 40)),
            Positioned(
              bottom: 8, left: 8, right: 8,
              child: _buildMiniShareButton(media['url']),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildMiniShareButton(String url) {
    return InkWell(
      onTap: () => _shareMedia(url),
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 6),
        decoration: BoxDecoration(color: lightPurple.withOpacity(0.2), borderRadius: BorderRadius.circular(8), border: Border.all(color: lightPurple.withOpacity(0.3))),
        child: const Center(child: Text("SHARE", style: TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold))),
      ),
    );
  }

  Widget _buildGlassButton({required VoidCallback onTap, required IconData icon, required String label}) {
    return InkWell(
      onTap: onTap,
      child: Container(
        height: 50,
        decoration: BoxDecoration(color: lightPurple.withOpacity(0.1), borderRadius: BorderRadius.circular(12), border: Border.all(color: lightPurple.withOpacity(0.3))),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: lightPurple, size: 18),
            const SizedBox(width: 10),
            Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 13)),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Padding(
      padding: const EdgeInsets.only(top: 40),
      child: Column(
        children: [
          Icon(Icons.auto_awesome_motion_rounded, size: 80, color: lightPurple.withOpacity(0.2)),
          const SizedBox(height: 15),
          const Text("Ready to extract media assets", style: TextStyle(color: Colors.white30, fontSize: 14)),
        ],
      ),
    );
  }

  Widget _buildErrorState() {
    return Padding(
      padding: const EdgeInsets.only(top: 20),
      child: _buildGlassContainer(
        padding: const EdgeInsets.all(15),
        child: Row(
          children: [
            const Icon(Icons.warning_amber_rounded, color: Colors.redAccent),
            const SizedBox(width: 15),
            Expanded(child: Text(_errorMessage ?? "Unknown Error", style: const TextStyle(color: Colors.redAccent, fontSize: 12))),
          ],
        ),
      ),
    );
  }

  Widget _buildGlowOrb(double size, Color color) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color, boxShadow: [BoxShadow(color: color, blurRadius: 100, spreadRadius: 40)]),
    );
  }
}