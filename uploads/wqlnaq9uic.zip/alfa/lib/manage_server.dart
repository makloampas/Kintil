import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class ManageServerPage extends StatefulWidget {
  final String keyToken;
  const ManageServerPage({super.key, required this.keyToken});

  @override
  State<ManageServerPage> createState() => _ManageServerPageState();
}

class _ManageServerPageState extends State<ManageServerPage> with TickerProviderStateMixin {
  List<Map<String, dynamic>> vpsList = [];
  bool isLoading = false;

  final _hostController = TextEditingController();
  final _userController = TextEditingController();
  final _passController = TextEditingController();

  // Theme Colors (Deep Green & Black)
  final Color bgBlack = const Color(0xFF050505);
  final Color accentGreen = const Color(0xFF1B5E20);
  final Color lightGreen = const Color(0xFF2ECC71);
  final Color glassBorder = Colors.white.withOpacity(0.08);
  final Color glassBg = Colors.white.withOpacity(0.04);

  late AnimationController _slideController;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _slideController = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    _slideAnimation = Tween<Offset>(begin: const Offset(0, 0.05), end: Offset.zero)
        .animate(CurvedAnimation(parent: _slideController, curve: Curves.easeOutCubic));
    _slideController.forward();
    _fetchVpsList();
  }

  @override
  void dispose() {
    _slideController.dispose();
    _hostController.dispose();
    _userController.dispose();
    _passController.dispose();
    super.dispose();
  }

  // --- LOGIC SECTION ---

  Future<void> _fetchVpsList() async {
    setState(() => isLoading = true);
    try {
      final res = await http.get(Uri.parse('http://kingkyaz.veyoradev.biz.id:4002/myServer?key=${widget.keyToken}'));
      final data = jsonDecode(res.body);
      setState(() => vpsList = List<Map<String, dynamic>>.from(data));
    } catch (_) {
      _showSnackBar("UPLINK_ERROR: Failed to fetch clusters", Colors.redAccent);
    } finally {
      setState(() => isLoading = false);
    }
  }

  Future<void> _addVps() async {
    final host = _hostController.text.trim(), user = _userController.text.trim(), pass = _passController.text.trim();
    if (host.isEmpty || user.isEmpty || pass.isEmpty) return;

    Navigator.pop(context);
    setState(() => isLoading = true);

    try {
      final res = await http.post(Uri.parse('http://kingkyaz.veyoradev.biz.id:4002/addServer'), body: {
        'key': widget.keyToken, 'host': host, 'username': user, 'password': pass,
      });
      final data = jsonDecode(res.body);
      if (data['success'] == true) {
        _hostController.clear(); _userController.clear(); _passController.clear();
        _showSnackBar("SUCCESS: Node provisioned", lightGreen);
        _fetchVpsList();
      }
    } catch (_) {
      _showSnackBar("FAILURE: Deployment failed", Colors.redAccent);
    } finally {
      setState(() => isLoading = false);
    }
  }

  Future<void> _deleteVps(String host) async {
    final res = await http.post(Uri.parse('http://kingkyaz.veyoradev.biz.id:4002/delServer'), body: {
      'key': widget.keyToken, 'host': host,
    });
    if (jsonDecode(res.body)['success'] == true) {
      _showSnackBar("PROTOCOL: Node terminated", Colors.orangeAccent);
      _fetchVpsList();
    }
  }

  void _showSnackBar(String msg, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12, fontFamily: 'monospace')),
      backgroundColor: color.withOpacity(0.9),
      behavior: SnackBarBehavior.floating,
      margin: const EdgeInsets.all(20),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
    ));
    HapticFeedback.mediumImpact();
  }

  // --- UI COMPONENTS ---

  Widget _buildGlassCard({required Widget child, Color? borderColor}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
        child: Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            color: glassBg,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: borderColor ?? glassBorder),
          ),
          child: child,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      body: Stack(
        children: [
          Positioned(top: -50, right: -50, child: _buildGlowOrb(250, accentGreen.withOpacity(0.15))),
          Positioned(bottom: -50, left: -50, child: _buildGlowOrb(200, lightGreen.withOpacity(0.05))),

          SafeArea(
            child: SlideTransition(
              position: _slideAnimation,
              child: RefreshIndicator(
                color: lightGreen,
                backgroundColor: bgBlack,
                onRefresh: _fetchVpsList,
                child: SingleChildScrollView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    children: [
                      const SizedBox(height: 20),
                      _buildHeader(),
                      const SizedBox(height: 25),
                      _buildAddButton(),
                      const SizedBox(height: 30),
                      Row(
                        children: [
                          const Text("ACTIVE_INFRASTRUCTURE", style: TextStyle(color: Colors.white24, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 3)),
                          const Spacer(),
                          if(isLoading) SizedBox(width: 12, height: 12, child: CircularProgressIndicator(strokeWidth: 2, color: lightGreen)),
                        ],
                      ),
                      const SizedBox(height: 15),
                      if (vpsList.isEmpty && !isLoading)
                        _buildEmptyState()
                      else
                        ...vpsList.map((vps) => _buildVpsItem(vps)).toList(),
                      const SizedBox(height: 50),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Row(
          children: [
            GestureDetector(
              onTap: () => Navigator.pop(context),
              child: _buildSmallGlass(
                padding: const EdgeInsets.all(10),
                child: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 18),
              ),
            ),
            const SizedBox(width: 15),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("SERVER CLOUD", style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 1)),
                Text("${vpsList.length} OPERATIONAL NODES", style: TextStyle(color: lightGreen, fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
              ],
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildSmallGlass({required Widget child, required EdgeInsets padding}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: padding,
        decoration: BoxDecoration(color: glassBg, border: Border.all(color: glassBorder), borderRadius: BorderRadius.circular(12)),
        child: child,
      ),
    );
  }

  Widget _buildAddButton() {
    return GestureDetector(
      onTap: _showAddDialog,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 300),
        height: 60,
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [accentGreen, lightGreen]),
          borderRadius: BorderRadius.circular(18),
          boxShadow: [BoxShadow(color: lightGreen.withOpacity(0.2), blurRadius: 15, offset: const Offset(0, 8))],
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.add_to_photos_rounded, color: Colors.black, size: 20),
            SizedBox(width: 12),
            Text("PROVISION_NEW_VPS", style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold, letterSpacing: 1.5, fontSize: 13)),
          ],
        ),
      ),
    );
  }

  Widget _buildVpsItem(Map<String, dynamic> vps) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      child: _buildGlassCard(
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.4),
                  borderRadius: BorderRadius.circular(15),
                  border: Border.all(color: lightGreen.withOpacity(0.2))
              ),
              child: Icon(Icons.storage_rounded, color: lightGreen, size: 22),
            ),
            const SizedBox(width: 15),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(vps['host'], style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold, fontFamily: 'monospace')),
                  const SizedBox(height: 4),
                  Text("USER_ID: ${vps['username']}", style: TextStyle(color: lightGreen.withOpacity(0.5), fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1)),
                ],
              ),
            ),
            _buildSmallGlass(
              padding: EdgeInsets.zero,
              child: IconButton(
                onPressed: () => _showDeleteConfirm(vps['host']),
                icon: const Icon(Icons.power_settings_new_rounded, color: Colors.redAccent, size: 20),
              ),
            )
          ],
        ),
      ),
    );
  }

  void _showAddDialog() {
    showDialog(
      context: context,
      builder: (context) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: AlertDialog(
          backgroundColor: const Color(0xFF0A0A0A),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(25), side: BorderSide(color: glassBorder)),
          title: Text("DEPLOY_SERVER", style: TextStyle(color: lightGreen, fontWeight: FontWeight.bold, letterSpacing: 2, fontSize: 16)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildPopupInput(_hostController, "GATEWAY_IP_HOST", Icons.dns_rounded),
              _buildPopupInput(_userController, "SSH_ROOT_USER", Icons.terminal_rounded),
              _buildPopupInput(_passController, "SSH_AUTH_KEY", Icons.vpn_key_rounded, isPass: true),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text("ABORT", style: TextStyle(color: Colors.white24, fontWeight: FontWeight.bold))),
            ElevatedButton(
              onPressed: _addVps,
              style: ElevatedButton.styleFrom(
                  backgroundColor: lightGreen,
                  foregroundColor: Colors.black,
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  elevation: 0
              ),
              child: const Text("INITIALIZE", style: TextStyle(fontWeight: FontWeight.bold)),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildPopupInput(TextEditingController ctrl, String hint, IconData icon, {bool isPass = false}) {
    return Container(
      margin: const EdgeInsets.only(bottom: 15),
      child: TextField(
        controller: ctrl,
        obscureText: isPass,
        style: const TextStyle(color: Colors.white, fontSize: 13, fontFamily: 'monospace'),
        decoration: InputDecoration(
          hintText: hint,
          hintStyle: const TextStyle(color: Colors.white12, fontSize: 11),
          prefixIcon: Icon(icon, color: lightGreen, size: 18),
          filled: true,
          fillColor: Colors.black,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: glassBorder)),
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: glassBorder)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: lightGreen.withOpacity(0.5))),
        ),
      ),
    );
  }

  void _showDeleteConfirm(String host) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: const Color(0xFF100505),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: const BorderSide(color: Colors.redAccent)),
        title: const Text("TERMINATE_NODE?", style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.bold, letterSpacing: 1.5, fontSize: 16)),
        content: Text("Permanent disconnection of node $host from matrix.", style: const TextStyle(color: Colors.white38, fontSize: 12)),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text("CANCEL", style: TextStyle(color: Colors.white24))),
          ElevatedButton(onPressed: () { Navigator.pop(context); _deleteVps(host); },
              style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
              child: const Text("CONFIRM_DESTRUCTION", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 11))),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Column(
      children: [
        const SizedBox(height: 60),
        Icon(Icons.cloud_off_rounded, size: 70, color: lightGreen.withOpacity(0.1)),
        const SizedBox(height: 15),
        const Text("NO_CLUSTERS_DETECTED", style: TextStyle(color: Colors.white10, fontSize: 12, fontWeight: FontWeight.bold, letterSpacing: 2)),
      ],
    );
  }

  Widget _buildGlowOrb(double size, Color color) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color, boxShadow: [BoxShadow(color: color, blurRadius: 100, spreadRadius: 40)]),
    );
  }
}