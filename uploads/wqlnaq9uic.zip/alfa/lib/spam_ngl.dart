import 'dart:convert';
import 'dart:math';
import 'dart:async';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

class NglPage extends StatefulWidget {
  const NglPage({super.key});

  @override
  State<NglPage> createState() => _NglPageState();
}

class _NglPageState extends State<NglPage> with TickerProviderStateMixin {
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController messageController = TextEditingController();

  bool isRunning = false;
  int counter = 0;
  String statusLog = "READY TO INJECT";
  Timer? timer;

  // Theme Colors (Deep Green & Black)
  final Color bgBlack = const Color(0xFF050505);
  final Color accentGreen = const Color(0xFF1B5E20);
  final Color lightGreen = const Color(0xFF2ECC71);
  final Color glassBorder = Colors.white.withOpacity(0.08);
  final Color glassBg = Colors.white.withOpacity(0.04);

  @override
  void dispose() {
    timer?.cancel();
    usernameController.dispose();
    messageController.dispose();
    super.dispose();
  }

  // --- LOGIC SECTION ---
  String generateDeviceId(int length) {
    final random = Random.secure();
    return List.generate(length, (_) => random.nextInt(16).toRadixString(16)).join();
  }

  Future<void> sendMessage(String username, String message) async {
    final deviceId = generateDeviceId(42);
    final url = Uri.parse("https://ngl.link/api/submit");

    final headers = {
      "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36",
      "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
      "Referer": "https://ngl.link/$username",
    };

    final body = "username=$username&question=$message&deviceId=$deviceId&gameSlug=&referrer=";

    try {
      final response = await http.post(url, headers: headers, body: body);
      if (response.statusCode == 200) {
        setState(() {
          counter++;
          statusLog = "DISPATCHED: PKT #$counter SUCCESS";
        });
        HapticFeedback.lightImpact();
      } else if (response.statusCode == 429) {
        setState(() => statusLog = "RATE_LIMIT: Cooling down 5s...");
      } else {
        setState(() => statusLog = "FAILED: Server Rejected");
      }
    } catch (e) {
      setState(() => statusLog = "ERROR: Connection Timed Out");
    }
  }

  void toggleLoop() {
    if (isRunning) {
      setState(() {
        isRunning = false;
        statusLog = "PROTOCOL_HALTED";
      });
      timer?.cancel();
    } else {
      final user = usernameController.text.trim();
      final msg = messageController.text.trim();
      if (user.isEmpty || msg.isEmpty) {
        _showSnackBar("ERROR: Identity/Payload required");
        return;
      }
      setState(() {
        isRunning = true;
        counter = 0;
        statusLog = "INITIALIZING_PULSE...";
      });
      timer = Timer.periodic(const Duration(seconds: 2), (_) => sendMessage(user, msg));
    }
    HapticFeedback.mediumImpact();
  }

  // --- UI COMPONENTS ---

  void _showSnackBar(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 12)),
        backgroundColor: Colors.redAccent,
        behavior: SnackBarBehavior.floating,
        margin: const EdgeInsets.all(20),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  Widget _buildGlassContainer({required Widget child, EdgeInsetsGeometry? padding, Color? borderColor}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: glassBg,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: borderColor ?? glassBorder),
          ),
          child: child,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      body: Stack(
        children: [
          Positioned(top: -50, left: -50, child: _buildGlowOrb(300, accentGreen.withOpacity(0.15))),
          Positioned(bottom: -50, right: -50, child: _buildGlowOrb(250, lightGreen.withOpacity(0.05))),

          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(height: 20),
                  _buildHeader(context),
                  const SizedBox(height: 30),

                  // Input Panel
                  _buildGlassContainer(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        _buildTextField(usernameController, "TARGET USERNAME", Icons.alternate_email_rounded),
                        const SizedBox(height: 15),
                        _buildTextField(messageController, "MESSAGE PAYLOAD", Icons.code_rounded, maxLines: 3),
                        const SizedBox(height: 20),

                        // Action Button
                        GestureDetector(
                          onTap: toggleLoop,
                          child: AnimatedContainer(
                            duration: const Duration(milliseconds: 300),
                            height: 60,
                            decoration: BoxDecoration(
                              gradient: isRunning
                                  ? const LinearGradient(colors: [Color(0xFFB71C1C), Color(0xFFFF5252)])
                                  : LinearGradient(colors: [accentGreen, lightGreen]),
                              borderRadius: BorderRadius.circular(18),
                              boxShadow: [
                                BoxShadow(
                                    color: (isRunning ? Colors.red : lightGreen).withOpacity(0.2),
                                    blurRadius: 15, offset: const Offset(0, 8)
                                )
                              ],
                            ),
                            child: Center(
                              child: Row(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(isRunning ? Icons.stop_circle_rounded : Icons.bolt_rounded,
                                      color: isRunning ? Colors.white : Colors.black, size: 24),
                                  const SizedBox(width: 12),
                                  Text(
                                    isRunning ? "ABORT EXECUTION" : "INITIATE ATTACK",
                                    style: TextStyle(
                                        color: isRunning ? Colors.white : Colors.black,
                                        fontWeight: FontWeight.bold,
                                        letterSpacing: 1.5,
                                        fontSize: 14
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 25),

                  // Console Area
                  const Text("CONSOLE_LOGS", style: TextStyle(color: Colors.white24, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 3)),
                  const SizedBox(height: 10),
                  Expanded(
                    child: _buildGlassContainer(
                      borderColor: isRunning ? lightGreen.withOpacity(0.2) : glassBorder,
                      padding: const EdgeInsets.all(24),
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Text(statusLog,
                                  style: TextStyle(
                                      color: isRunning ? lightGreen : Colors.white38,
                                      fontSize: 12,
                                      fontFamily: 'monospace',
                                      fontWeight: FontWeight.bold
                                  )),
                              const Spacer(),
                              if(isRunning) SizedBox(width: 12, height: 12, child: CircularProgressIndicator(strokeWidth: 2, color: lightGreen)),
                            ],
                          ),
                          const Padding(
                            padding: EdgeInsets.symmetric(vertical: 20),
                            child: Divider(color: Colors.white10, height: 1),
                          ),
                          const Spacer(),
                          // Matrix Counter
                          Center(
                            child: Column(
                              children: [
                                Text(counter.toString().padLeft(3, '0'),
                                    style: TextStyle(
                                        color: isRunning ? lightGreen : Colors.white12,
                                        fontSize: 80,
                                        fontWeight: FontWeight.w900,
                                        letterSpacing: -4,
                                        fontFamily: 'monospace'
                                    )),
                                Text("PACKETS DISPATCHED",
                                    style: TextStyle(
                                        color: isRunning ? lightGreen.withOpacity(0.5) : Colors.white10,
                                        fontSize: 10,
                                        fontWeight: FontWeight.bold,
                                        letterSpacing: 2
                                    )),
                              ],
                            ),
                          ),
                          const Spacer(),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 30),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Row(
      children: [
        GestureDetector(
          onTap: () => Navigator.pop(context),
          child: _buildGlassContainer(
            padding: const EdgeInsets.all(10),
            child: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 18),
          ),
        ),
        const SizedBox(width: 15),
        const Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("NGL PULSE", style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 1)),
            Text("Automated Message Protocol", style: TextStyle(color: Color(0xFF2ECC71), fontSize: 9, fontWeight: FontWeight.bold, letterSpacing: 1.5)),
          ],
        ),
      ],
    );
  }

  Widget _buildTextField(TextEditingController controller, String hint, IconData icon, {int maxLines = 1}) {
    return TextField(
      controller: controller,
      maxLines: maxLines,
      style: const TextStyle(color: Colors.white, fontSize: 13, fontFamily: 'monospace'),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: const TextStyle(color: Colors.white12, fontSize: 11),
        filled: true,
        fillColor: Colors.black.withOpacity(0.4),
        prefixIcon: Icon(icon, color: lightGreen, size: 18),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide.none),
        enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: glassBorder)),
        focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(15), borderSide: BorderSide(color: lightGreen.withOpacity(0.3))),
        contentPadding: const EdgeInsets.all(20),
      ),
    );
  }

  Widget _buildGlowOrb(double size, Color color) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color, boxShadow: [BoxShadow(color: color, blurRadius: 100, spreadRadius: 40)]),
    );
  }
}